
/// \mainpage
///
/// The eTWlib is a collection of C source code libraries supplementing the CodevisionAVR 
/// Standard C libraries. It contains a complete network stack with support of TCP, IP, 
/// Ethernet, HTTP, IPSec, BootP etc.
/// 
/// \section Supported Hardware
///
/// The eTWlib at the moment supports AVR controllers only. Nevertheless it distinguishes 
/// between AVR specific code and generic code. The following controllers are supported 
/// by the most modules:
/// <ul>
/// <li>ATmega128</li>
///	<li>ATmega103</li>
/// <li>ATmega64</li>
/// <li>ATmega32</li>
/// <li>ATmega8</li></ul>
///
/// The included application examples supports the following boards:
/// <ul>
///	<li>eTW-AVR</li>
/// <li>eTW-All-in-One</li>
///	<li>eTW-ATmega32</li>
/// <li>eTW-CS8900-16bit</li></ul>
///
/// \section Directory-Structure
/// <ul>
/// <li>apps - contains the application examples.</li>
/// <li>arch - contains architecture specific modules. Only AVR controllers are supported at the moment.</li>
/// <li>debug - common debug framework</li>
/// <li>devices - architecture independent code for interfacing of several chips</li>
/// <li>doc - doxygen documentation</li>
/// <li>encryption - libraries for encryption algorithms and checksum calculation</li>
/// <li>fs - file system libraries</li>
/// <li>include - some generic header files, including eTWlib version macros</li>
/// <li>network - network stack</li>
/// <li>obsolete - contains some modules, which will not be updated anymore.</li>
/// <li>tools - some generic libraries</li></ul>
///
/// \section Code-Examples
/// 
/// The apps directory contains application examples and project files for the CodeVisionAVR C-Compiler
/// For detailes description see the "Examples" Tab of this doxygen documentation.
///
/// \section Global-macros
/// 
/// The eTWlib uses 3 macros to use the Codevision specific #pragma library directive
/// This proprietary preprocessor directive can be used to include modules as libaries in your CodeVision 
/// project. This way, they doesn't appear as c-modules in your project navigator.
/// <ul>
/// <li>DEBUG_LIBRARY_ENABLE - enables library mode for \debug\debug.c and \arch\avr\debug_io.c</li>
/// <li>NETWORK_LIBRARY_ENABLE - enables library mode for all modules in the network directory</li>
/// <li>COMMON_LIBRARY_ENABLE - enables library mode for all other modules</li></ul>
