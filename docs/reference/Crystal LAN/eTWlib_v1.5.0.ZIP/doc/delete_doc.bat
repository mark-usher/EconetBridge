del .\html\*.html /Q /S
del .\html\*.css /Q /S
del .\html\*.png /Q /S
del .\html\*.gif /Q /S

