// ************************************************************************************************
///
/// \file 			measure.c
/// \brief			Time measure functions and variables
///
/// \todo			Rework whole module
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef WEB_DEBUG_MEASURE

#include <stdio.h>
#include <math.h>
#include "measure.h"

#pragma regalloc-
unsigned char 		measure_timer1=0;		// count with every overflow of timer1 XTAL/256
unsigned char 		measure_flag=0;	  		// flag to switch to a new TIME_FRAME
unsigned char 		measure_frame=0;		// pointer to actuall TIME_FRAME
p_MEASURE_FRAME		measure_pointer=&measure_buffer[0];	
MEASURE_FRAME 		measure_buffer[MEA_MAX_TIME_FRAMES];	// buffer for time-variables
#pragma regalloc+


//********************************************************************************
// Description	: inits the measure buffer
// Input  	 	: none
// Output  	 	: none
// Indication	: none
//********************************************************************************
void measure_init(void)
{   
measure_flag=0;		// flag to switch to a new TIME_FRAME
measure_frame=0;	// pointer to actuall TIME_FRAME
measure_pointer=&measure_buffer[0];		// set pointer to actual frame
memset(measure_buffer, 0x0, sizeof(measure_buffer));
}
 

//********************************************************************************
// Description	: counts the 8bit-Counter with every overflow
// Input  	 	: none
// Output  	 	: none
// Indication	: a polling function
//********************************************************************************
void measure_time(void)
{   
if(TIFR & 0x04)		// Timer/Counter1, Overflow Flag Set?
	{
	measure_timer1++;
	TIFR|=0x04;		// TOV1 - Timer/Counter1, Clear Overflow Flag
	}
}

//********************************************************************************
// Description	: counts the 8bit-Counter with every overflow
// Input  	 	: none
// Output  	 	: none
// Indication	: a polling function
//********************************************************************************
void measure_switch_time_frame(void)
{   
if(measure_flag)		// flag to switch to a new TIME_FRAME
	{
	measure_flag=0;		// flag to switch to a new TIME_FRAME
	measure_frame++;	// pointer to actuall TIME_FRAME
	if(measure_frame>=MEA_MAX_TIME_FRAMES)
		measure_frame=0;
	measure_pointer=&measure_buffer[measure_frame];		// set pointer actuall frame
	}
}



//********************************************************************************
// Description	: calculates the measure time in millisecond
// Input	 	: none
// Output      	: none
// Indication	: none
//********************************************************************************
unsigned long measure_calc_time(unsigned int time, unsigned char over)
{
unsigned long time1;

time1=over;
time1*=(0xffff*MEASURE_TIME);
time1+=(unsigned long)time*MEASURE_TIME;
return time1;
}

char flash *measure_name[MEA_MAX_TIMES]={
				"BUFFER_FRAME1_S ", "BUFFER_FRAME1_E ", "BUFFER_FRAME2_S ", "BUFFER_FRAME2_E ",	
				"UDP_CHECKSUM_S  ", "UDP_CHECKSUM_E  ", "ICMP_CHECKSUM_S1", "ICMP_CHECKSUM_E1",			
				"ICMP_CHECKSUM_S2", "ICMP_CHECKSUM_E2", "TCP_CHECKSUM_S1 ", "TCP_CHECKSUM_E1 ",			
				"TCP_CHECKSUM_S2 ", "TCP_CHECKSUM_E2 ", "TCP_DATA_S      ", "TCP_DATA_E      ",			
				"TCP_FRAME_S     ", "TCP_FRAME_E     ", "ICMP_ECHO_S     ", "ICMP_ECHO_E     ",		
				"ARP_ANSWER_S    ", "ARP_ANSWER_E    ", "ARP_REQUEST_S   ", "ARP_REQUEST_E   ",     		
				"TCP_S           ", "TCP_E1          ", "TCP_E2          ", "TCP_E3          ",   
				"ETHERNET_S      ", "ETHERNET_E      ", "NET_S           ", "NET_E           ",	
				"MAIN_S          ", "MAIN_E          "};

unsigned char flash measure_diff[MEA_MAX_TIMES]={
				255,  0, 255,   2,		// 0...3
				255,  4, 255,   6,		// 4...7	
				255,  8, 255,  10,		// 8...11
				255, 12, 255,  14,     	// 12...15	
				255, 16, 255,  18,      // 16...19
				255, 20, 255,  22,      // 20...23
				255, 24,  24,  24,      // 24...27
				255, 28, 255,  30,      // 28...31
				255, 32};               // 32...33


unsigned long time[MEA_MAX_TIMES];
//********************************************************************************
// Description	: writes the measure value to Debug-Channel
// Input	 	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void measure_diplay(void)
{
unsigned char Lva, Lvb, Lvc, min_Lva;
unsigned long time1;
unsigned char act_frame;

time1=measure_calc_time(TCNT1, measure_timer1);
printf("Measure time:%lu,%03ums\r\n", time1/1000, time1%1000);
act_frame=measure_frame;	// starts with oldest time-measure-frame
for (Lvb=0;Lvb<MEA_MAX_TIME_FRAMES;Lvb++)
	{
	#asm("wdr");	// Reset Watchdog
	act_frame++;
	if(act_frame>=MEA_MAX_TIME_FRAMES)
		act_frame=0;
	for (Lva=0;Lva<MEA_MAX_TIMES;Lva++)
		{
		time[Lva]=measure_calc_time(measure_buffer[act_frame].time[Lva], measure_buffer[act_frame].over[Lva]);
		}
	for (Lva=0;Lva<MEA_MAX_TIMES;Lva++)
		{
		min_Lva=0xff;
		// search the smallest value
		for (Lvc=0;Lvc<MEA_MAX_TIMES;Lvc++)
			{
			if(time[Lvc]!=0)	// first search valid entry
				{
				if(min_Lva==0xff)
					min_Lva=Lvc;
				else
					if(time[Lvc]<time[min_Lva])	// second checks wether smaller ???
						min_Lva=Lvc;
				}				
			}
		if(min_Lva==0xff)	// no value available
			break;
		printf("%2u-%p: %lu.%03ums", Lvb, measure_name[min_Lva], time[min_Lva]/1000, time[min_Lva]%1000);
		if(measure_diff[min_Lva]!=255)
			{
			time1=measure_calc_time(measure_buffer[act_frame].time[measure_diff[min_Lva]], 
						measure_buffer[act_frame].over[measure_diff[min_Lva]]);
			time1=labs(time1-time[min_Lva]);
			printf(" (%lu.%03ums)\r\n", time1/1000, time1%1000);
			}
		else
			putsf("\r");
		time[min_Lva]=0;	// delete old value
		}
	}
measure_init();
}

#endif		// #ifdef WEB_DEBUG_MEASURE

