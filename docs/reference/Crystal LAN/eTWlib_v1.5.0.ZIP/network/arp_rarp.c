// ************************************************************************************************
///
/// \file 			arp_rarp.c
/// \brief			Implementatin of ARP/RARP
///
/// \date	 		$LastChangedDate: 2007-03-28 10:43:12 +0200 (Mi, 28 Mrz 2007) $
/// \version 		$Rev: 660 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#if (defined(ARP_ENABLE) || defined(RARP_ENABLE)) && !defined(IP_ENABLE)
#error "ARP_ENABLE or RARP_ENABLE needs IP_ENABLE! Define it in project.h"
#endif


#if defined(ARP_ENABLE) || defined(RARP_ENABLE)

#include <stdio.h>
#include <string.h>
#include "device.h"
#include "ethernet.h"
#include "buffer.h"
#include "ip.h"
#ifdef TCP_ENABLE		
#include "tcp.h"
#endif
#include "arp_rarp.h"
#ifdef WEB_DEBUG_MEASURE			// enable time-measure debug functions, see measure.c
#include "measure.h"
#endif
#ifdef WEB_DEBUG
#include "web_debug.h"
#endif

#pragma regalloc-
#if defined(ARP_ENABLE) && defined(ARP_CACHE_ENABLE)
ARP_CACHE_STRUCTURE		arp_cache_buffer[ARP_CACHE_SIZE];
#endif
#pragma regalloc+


//*********************************************************************************
// Description	: handles the ARP-Ethernet-Frames (see ethernet.c)
// Input   		: broadcast_flag - signals the broadcast frame
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void arp_rarp_process_frame(unsigned char broadcast_flag) 
{
#if defined(WEB_DEBUG_ARP)||defined(WEB_DEBUG_RARP)
static  unsigned int arp_rarp_count=0;
#endif
unsigned char ip_destination[IP_ADR_SIZE]=RARP_DEFAULT_ANSWER_IP;
unsigned int arp_rarp_option;

#ifdef WEB_DEBUG_MEASURE
//measure_flag=1;			// flag to switch to a new TIME_FRAME
#endif
#if defined(WEB_DEBUG_ARP)||defined(WEB_DEBUG_RARP)
if(!broadcast_flag)
	{
	arp_rarp_count++;
	if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
		printf("ARP_RARP Read-FRAME:%u\r\n", arp_rarp_count);
	}
#else
broadcast_flag=0;
#endif
if((DEVICE_READ_FRAME_16BIT() == HARDW_ETH10)&&		// check for the right prot. etc.
   (DEVICE_READ_FRAME_16BIT() == IP_FRAME)&&
   (DEVICE_READ_FRAME_16BIT() == IP_HLEN_PLEN))
	{
	arp_rarp_option=DEVICE_READ_FRAME_16BIT();
	#ifdef ARP_ENABLE
	if(arp_rarp_option == ARP_OP_ANSWER)
		{
		DEVICE_READ_FRAME_DATA(mac_of_last_frame, 6);  			// extract opponents MAC
		DEVICE_READ_FRAME_DATA(ip_of_last_frame, IP_ADR_SIZE); 	// read sender's protocol address
		#ifdef WEB_DEBUG_ARP
		if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
			{
			putsf("ARP Answer\r");
			debug_print_ip("ARP IP ", ip_of_last_frame);
			debug_print_mac("ARP MAC", mac_of_last_frame);
			}
		#endif
		#ifdef ARP_CACHE_ENABLE
		arp_cache(ip_of_last_frame, mac_of_last_frame); 
		#endif
		#ifdef TCP_ENABLE
		tcp_arp_resolved(mac_of_last_frame);
		#endif
		}
	if(arp_rarp_option == ARP_OP_REQUEST)
		{
		DEVICE_READ_FRAME_DATA(mac_of_last_frame, 6);			// read sender's MAC address
		DEVICE_READ_FRAME_DATA(ip_of_last_frame, IP_ADR_SIZE);	// read sender's protocol address
		DEVICE_READ_FRAME_DUMMY(6);			 					// ignore target's hardware address
		DEVICE_READ_FRAME_DATA(ip_destination, IP_ADR_SIZE);	// read destination's protocol address
		if(!memcmp(&ip_destination[0], &ip_address[0], sizeof(ip_address)))// is it for us?
			{
			#ifdef WEB_DEBUG_ARP
			if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
				{
				if(broadcast_flag)
					putsf("ARP Read-FRAME: Broadcast:\r"); 
				else
					putsf("ARP Request\r");
				debug_print_ip("ARP IP-Source     ", ip_of_last_frame);
				debug_print_ip("ARP IP-Destination", ip_destination);
				}
			#endif
			arp_prepare_answer();               // yes->create ARP_ANSWER frame
			}
		}
	#endif	//	#ifdef ARP_ENABLE
	#ifdef RARP_ENABLE
	if(arp_rarp_option == RARP_OP_ANSWER)
		{
		DEVICE_READ_FRAME_DATA(mac_of_last_frame, 6);  			// read sender MAC address
		DEVICE_READ_FRAME_DATA(ip_of_last_frame, IP_ADR_SIZE); 	// read sender IP address
		#ifdef WEB_DEBUG_RARP
		if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
			{
			putsf("RARP Answer\r");
			debug_print_ip("RARP IP ", ip_of_last_frame);
			debug_print_mac("RARP MAC", mac_of_last_frame);
			}
		#endif
		}
	if(arp_rarp_option == RARP_OP_REQUEST)
		{
		DEVICE_READ_FRAME_DATA(mac_of_last_frame, 6);	// read sender's MAC address
		DEVICE_READ_FRAME_DUMMY(4+6+4);				 	// ignore sender IP address, target's hardware address and destination IP address
		#ifdef WEB_DEBUG_RARP
		if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
			putsf("RARP Request\r");
		#endif
		rarp_prepare_answer(ip_destination);               // yes->create ARP_ANSWER frame
		}
	#endif	//	#ifdef RARP_ENABLE
	}
else
	{
	#if defined(WEB_DEBUG_ARP)||defined(WEB_DEBUG_RARP)
	if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
		printf("ARP_RARP wrong FRAME:%u\r\n", arp_rarp_count);
	#endif
	}
}


#ifdef ARP_ENABLE
#ifdef ARP_CACHE_ENABLE
//*********************************************************************************
// Description	: serarch and write ARP-Cache-Entries
//                if(ip_adr!=0)the search MAC-Address
//                if(mac_adr!=0)the search IP-Address
//                if((ip_adr!=0)&&(mac_adr!=0))the write a new entry
// Input   		: ip_adr - pointer to IP-address
//                mac_adr - pointer to MAC-address
// Output  		: 0 - no IP or MAC found
//				: 1 - if(ip_adr!=0) then ponter to MAC-Address
//				: 1 - if(mac_adr!=0) then ponter to IP-Address
// Indication	: none
//*********************************************************************************
unsigned char *arp_cache(unsigned char *ip_adr, unsigned char *mac_adr)
{
static unsigned char write_position=0;
unsigned char Lva;

if((ip_adr==0)&&(mac_adr==0))
	{
	#ifdef WEB_DEBUG_ARP
	if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
		putsf("ARP Cache Error\r");
	#endif
	return 0x0; 
	}
if((ip_adr!=0)&&(mac_adr!=0))
	{
	for(Lva=0;Lva<ARP_CACHE_SIZE;Lva++)	// search the IP
		{
		if((ip_adr!=0x0)&&(!memcmp(ip_adr, arp_cache_buffer[Lva].ip_adr, IP_ADR_SIZE)))
			break;
		}
	if(Lva>=ARP_CACHE_SIZE)		// doesn't find Cache-Entry
		{
		Lva=write_position;
		write_position++;
		if(write_position>=ARP_CACHE_SIZE)
			write_position=0;	// starts with first entry
		}
	memcpy(arp_cache_buffer[Lva].ip_adr, ip_adr, IP_ADR_SIZE);
	memcpy(arp_cache_buffer[Lva].mac_adr, mac_adr, 6);
	#ifdef WEB_DEBUG_ARP
	if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
		{
		printf("ARP Write-Cache: %u\r\n", Lva);
		debug_print_ip("ARP IP ", ip_adr);
		debug_print_mac("ARP MAC", mac_adr);
		}
	#endif
	return 0x0; 
	}
for(Lva=0;Lva<ARP_CACHE_SIZE;Lva++)
	{
	if((ip_adr!=0x0)&&(!memcmp(ip_adr, arp_cache_buffer[Lva].ip_adr, IP_ADR_SIZE)))
		{
		#ifdef WEB_DEBUG_ARP
		if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
			{
			printf("ARP Read-MAC-Cache: %u\r\n", Lva);
			debug_print_ip("ARP IP ", arp_cache_buffer[Lva].ip_adr);
			debug_print_mac("ARP MAC", arp_cache_buffer[Lva].mac_adr);
			}
		#endif
		return arp_cache_buffer[Lva].mac_adr;
		}
	if((mac_adr!=0x0)&&(!memcmp(mac_adr, arp_cache_buffer[Lva].mac_adr, 6)))
		{
		#ifdef WEB_DEBUG_ARP
		if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
			{
			printf("ARP Read-IP-Cache: %u\r\n", Lva);
			debug_print_ip("ARP IP ", arp_cache_buffer[Lva].ip_adr);
			debug_print_mac("ARP MAC", arp_cache_buffer[Lva].mac_adr);
			}
		#endif
		return arp_cache_buffer[Lva].ip_adr;
		}
	}
return 0x0; 
}
#endif	// #ifdef ARP_CACHE_ENABLE


//*********************************************************************************
// Description	: prepares the tx_frame2-buffer to send an ARP-request
// Input   		: arp_ip - pointer to arp IP
//         		: mode - mode of ARP-Request
//				:		  ARP_REQUEST_IP,		- ARP-Request to IP
//				:		  ARP_REQUEST_SELF,		- ARP-Request to myself
//				:		  ARP_REQUEST_GATEWAY	- ARP-Request to gateway
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void arp_prepare_request(unsigned char *arp_ip, ARP_REQUEST_MODE mode)
{
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_ARP_REQUEST_S)
#endif
// Ethernet
memset(&tx_frame2[ETH_DA_OFS], 0xFF, 6);                  // we don't know opposites MAC!
memcpy(&tx_frame2[ETH_SA_OFS], &mac_address[0], sizeof(mac_address));
*(unsigned int *)&tx_frame2[ETH_TYPE_OFS] = SWAPB(ARP_FRAME);
// ARP
*(unsigned int *)&tx_frame2[ARP_HARDW_OFS] = SWAPB(HARDW_ETH10);
*(unsigned int *)&tx_frame2[ARP_PROT_OFS] = SWAPB(IP_FRAME);
*(unsigned int *)&tx_frame2[ARP_HLEN_PLEN_OFS] = SWAPB(IP_HLEN_PLEN);
*(unsigned int *)&tx_frame2[ARP_OPCODE_OFS] = SWAPB(ARP_OP_REQUEST);
memcpy(&tx_frame2[ARP_SENDER_HA_OFS], &mac_address[0], 6);
memcpy(&tx_frame2[ARP_SENDER_IP_OFS], &ip_address[0], sizeof(ip_address));
memset(&tx_frame2[ARP_TARGET_HA_OFS], 0x00, 6);			// we don't know opposites MAC!
if(mode==ARP_REQUEST_IP)
	{
	if (((arp_ip[0] ^ ip_address[0]) & ip_subnet_mask[0])|| 
	    ((arp_ip[1] ^ ip_address[1]) & ip_subnet_mask[1])||
	    ((arp_ip[2] ^ ip_address[2]) & ip_subnet_mask[2])||
	    ((arp_ip[3] ^ ip_address[3]) & ip_subnet_mask[3]))
		memcpy(&tx_frame2[ARP_TARGET_IP_OFS], &ip_gateway[0], sizeof(ip_gateway));   // IP not in subnet, use gateway
	else
		memcpy(&tx_frame2[ARP_TARGET_IP_OFS], arp_ip, 4);    // other IP is next to us...
	}
else if(mode==ARP_REQUEST_SELF)
	{
	memcpy(&tx_frame2[ARP_TARGET_HA_OFS], &mac_address[0], sizeof(mac_address));	// Target Hardware Address
	memcpy(&tx_frame2[ARP_TARGET_IP_OFS], &ip_address[0], sizeof(ip_address));	// Target Protocoll Address 
	}
else if(mode==ARP_REQUEST_GATEWAY)
	{
	memcpy(&tx_frame2[ARP_TARGET_IP_OFS], &ip_gateway[0], sizeof(ip_gateway));	// Target Protocoll Address 
	}
tx_frame2_size = ETH_HEADER_SIZE + ARP_FRAME_SIZE;
buffer_write_command(tx_frame2, tx_frame2_size);
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_ARP_REQUEST_E)
#endif
#ifdef WEB_DEBUG_ARP
if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
	{
	printf("ARP Write-REQUEST: %ubyte\r\n", tx_frame2_size); 
	debug_print_ip("ARP IP", &tx_frame2[ARP_TARGET_IP_OFS]);
	}
#endif
}


//*********************************************************************************
// Description	: prepares the tx_frame2-buffer to send an ARP-answer (reply)
// Input   		: none
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void arp_prepare_answer(void)
{
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_ARP_ANSWER_S)
#endif
// Ethernet
memcpy(&tx_frame2[ETH_DA_OFS], &mac_of_last_frame[0], 6);
memcpy(&tx_frame2[ETH_SA_OFS], &mac_address[0], 6);
*(unsigned int *)&tx_frame2[ETH_TYPE_OFS] = SWAPB(ARP_FRAME);
// ARP
*(unsigned int *)&tx_frame2[ARP_HARDW_OFS] = SWAPB(HARDW_ETH10);
*(unsigned int *)&tx_frame2[ARP_PROT_OFS] = SWAPB(IP_FRAME);
*(unsigned int *)&tx_frame2[ARP_HLEN_PLEN_OFS] = SWAPB(IP_HLEN_PLEN);
*(unsigned int *)&tx_frame2[ARP_OPCODE_OFS] = SWAPB(ARP_OP_ANSWER);
memcpy(&tx_frame2[ARP_SENDER_HA_OFS], &mac_address[0], sizeof(mac_address));
memcpy(&tx_frame2[ARP_SENDER_IP_OFS], &ip_address[0], sizeof(ip_address));
memcpy(&tx_frame2[ARP_TARGET_HA_OFS], &mac_of_last_frame[0], 6);
memcpy(&tx_frame2[ARP_TARGET_IP_OFS], &ip_of_last_frame[0], sizeof(ip_of_last_frame));

tx_frame2_size = ETH_HEADER_SIZE + ARP_FRAME_SIZE;
buffer_write_command(tx_frame2, tx_frame2_size);
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_ARP_ANSWER_E)
#endif
#ifdef WEB_DEBUG_ARP
if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
	{
	printf("ARP Write-ANSWER: %ubyte\r\n", tx_frame2_size); 
	debug_print_mac("ARP Source-MAC", &tx_frame2[ARP_SENDER_HA_OFS]);
	debug_print_mac("ARP Dest-MAC  ", &tx_frame2[ARP_TARGET_HA_OFS]);
	}
#endif
}


//*********************************************************************************
// Description	: activate the "ARP_REQUEST_SELF" and "ARP_REQUEST_GATEWAY" cyclic
// Input	   	: start: ARP_REQUEST_TIMER_CONTINUE - normal mode
//			   	:        ARP_REQUEST_TIMER_START    - start: timer set to zero and send directly ARP-REQUEST
// Output      	: none
// Indication	: promote the MAC and IP to the gateways and switches
//              : time-value: 0xfff - DEBUG-MODE ca. 41 seconds (execute every 10ms)
//              : time-value: 0xffff - DEBUG-MODE ca. 11 minutes (execute every 10ms)
//              : time-value: 0xffff*11 - DEBUG-MODE ca. 121 minutes (execute every 10ms)
//              : time-value: 0xffff*10 - active-mode ca. 23 seconds (execute every 351�s)
//              : time-value: 0xfff - idle-mode ca. 24.3 seconds (execute every 5,9ms)
//********************************************************************************
void arp_request_timer(ARP_REQUEST_TIMER_MODE mode)
{
static	unsigned long arp_timer1 = 0;
  
if((arp_timer1 == 0)||(mode==ARP_REQUEST_TIMER_START))
	{
	arp_timer1 = 0;
	// ARP-Request to the easyToWeb-Server self - promote the MAC and IP to switch
	arp_prepare_request(ip_address, ARP_REQUEST_SELF);
	// send the frame to Ethernet-Controller
	if(mode==ARP_REQUEST_TIMER_START)
		buffer_process_wait();
	else
		buffer_process();
	// ARP-Request to the Gateway - promote the MAC and IP to the gateway
	arp_prepare_request(ip_address, ARP_REQUEST_GATEWAY);	
	// send the frame to Ethernet-Controller
	if(mode==ARP_REQUEST_TIMER_START)
		buffer_process_wait();
	else
		buffer_process();
    arp_timer1 = 0xfffff*10;
	}
arp_timer1--;
}
#endif	// #ifdef ARP_ENABLE

#ifdef RARP_ENABLE
//*********************************************************************************
// Description	: prepares the tx_frame2-buffer to send an RARP-request
// Input   		: *arp_mac: pointer to rarp MAC
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void rarp_prepare_request(void)
{
// Ethernet
memset(&tx_frame2[ETH_DA_OFS], 0xFF, 6);                  // we don't know opposites MAC!
memcpy(&tx_frame2[ETH_SA_OFS], &mac_address[0], 6);
*(unsigned int *)&tx_frame2[ETH_TYPE_OFS] = SWAPB(RARP_FRAME);
// RARP
*(unsigned int *)&tx_frame2[RARP_HARDW_OFS] = SWAPB(HARDW_ETH10);
*(unsigned int *)&tx_frame2[RARP_PROT_OFS] = SWAPB(IP_FRAME);
*(unsigned int *)&tx_frame2[RARP_HLEN_PLEN_OFS] = SWAPB(IP_HLEN_PLEN);
*(unsigned int *)&tx_frame2[RARP_OPCODE_OFS] = SWAPB(RARP_OP_REQUEST);
memcpy(&tx_frame2[RARP_SENDER_HA_OFS], &mac_address[0], 6);
memset(&tx_frame2[RARP_SENDER_IP_OFS], 0x0, 4);
memcpy(&tx_frame2[RARP_TARGET_HA_OFS], &mac_address[0], 6);	// we know opposites MAC
memset(&tx_frame2[RARP_TARGET_IP_OFS], 0x0, 4);				// we don't know opposites IP!
tx_frame2_size = ETH_HEADER_SIZE + RARP_FRAME_SIZE;
buffer_write_command(tx_frame2, tx_frame2_size);
#ifdef WEB_DEBUG_RARP
if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
	{
	printf("RARP Write-REQUEST: %ubyte\r\n", tx_frame2_size); 
	debug_print_mac("RARP MAC", &tx_frame2[RARP_TARGET_HA_OFS]);
	}
#endif
}

//*********************************************************************************
// Description	: prepares the tx_frame2-buffer to send an ARP-answer (reply)
// Input   		: none
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void rarp_prepare_answer(unsigned char *rarp_ip)
{
// Ethernet
memcpy(&tx_frame2[ETH_DA_OFS], &mac_of_last_frame[0], 6);
memcpy(&tx_frame2[ETH_SA_OFS], &mac_address[0], 6);
*(unsigned int *)&tx_frame2[ETH_TYPE_OFS] = SWAPB(RARP_FRAME);
// RARP
*(unsigned int *)&tx_frame2[RARP_HARDW_OFS] = SWAPB(HARDW_ETH10);
*(unsigned int *)&tx_frame2[RARP_PROT_OFS] = SWAPB(IP_FRAME);
*(unsigned int *)&tx_frame2[RARP_HLEN_PLEN_OFS] = SWAPB(IP_HLEN_PLEN);
*(unsigned int *)&tx_frame2[RARP_OPCODE_OFS] = SWAPB(RARP_OP_ANSWER);
memcpy(&tx_frame2[RARP_SENDER_HA_OFS], &mac_address[0], sizeof(mac_address));
memcpy(&tx_frame2[RARP_SENDER_IP_OFS], &ip_address[0], sizeof(ip_address));
memcpy(&tx_frame2[RARP_TARGET_HA_OFS], &mac_of_last_frame[0], 6);
memcpy(&tx_frame2[RARP_TARGET_IP_OFS], rarp_ip, 4);

tx_frame2_size = ETH_HEADER_SIZE + RARP_FRAME_SIZE;
buffer_write_command(tx_frame2, tx_frame2_size);
#ifdef WEB_DEBUG_RARP
if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
	{
	printf("RARP Write-ANSWER: %ubyte\r\n", tx_frame2_size); 
	debug_print_mac("RARP Source-MAC", &tx_frame2[RARP_SENDER_HA_OFS]);
	debug_print_mac("RARP Dest-MAC  ", &tx_frame2[RARP_TARGET_HA_OFS]);
	debug_print_ip("RARP Dest-IP   ", &tx_frame2[RARP_TARGET_IP_OFS]);
	}
#endif
}
#endif	// #ifdef RARP_ENABLE

#endif	// #if defined(ARP_ENABLE) || defined(RARP_ENABLE)
