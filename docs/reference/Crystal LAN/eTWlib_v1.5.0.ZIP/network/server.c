// ************************************************************************************************
///
/// \file 			server.c
/// \brief			Generell server functions
///
/// \date	 		$LastChangedDate: 2007-03-28 10:43:12 +0200 (Mi, 28 Mrz 2007) $
/// \version 		$Rev: 660 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <stdio.h>
#include <string.h>
#include "device.h"
#include "buffer.h"
#include "board.h"
#ifdef ETHERNET_ENABLE
#include "ethernet.h"
#endif
#ifdef DEVICE_PPP
#include "ppp.h"
#endif
#ifdef TCP_ENABLE
#include "tcp.h"
#include "tcp_debug.h"
#endif
#ifdef DATAFLASH_FILE_ENABLE
#include "dataflash_file.h"
#include "dataflash_file_debug.h"
#endif
#ifdef HTTP_ENABLE
#include "http_server.h"
#endif
#ifdef FTP_ENABLE
#include "ftp_server.h"
#endif
#ifdef TFTP_ENABLE
#include "tftp.h"
#endif
#include "server.h"
#include "avr_spi.h"


#pragma regalloc-
unsigned char	server_ok=0;
#pragma regalloc+


//*********************************************************************************
// Description	: init the server
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void server_init(void)
{
server_ok=0;
#ifdef DEVICE_CS8900
board_init_mac_address();	// write mac to CS8900-Init-Data-Buffer (cs8900_init_data)
#endif
#ifdef IP_ENABLE
board_load_ip_addresses(ip_address, ip_subnet_mask, ip_gateway);
#endif
buffer_clear();
if(DEVICE_INIT()==0)
	return;
#ifdef UDP_ENABLE
udp_init();
	#ifdef BOOTP_ENABLE
	server_ok=1;		// necessary to start "server_main"
	bootp_init();
	server_ok=0;		// reset the server flag
	#endif				// #ifdef BOOTP_ENABLE
	#ifdef TFTP_ENABLE
	tftp_init();
	#endif              // #ifdef TFTP_ENABLE
#endif					// #ifdef UDP_ENABLE
#ifdef TCP_ENABLE
tcp_init();
#endif
#ifdef HTTP_ENABLE
http_server_tcp=tcp_passive_open(TCP_PORT_HTTP);
if(http_server_tcp==TCP_WRONG_CONNECTIONS)	// set port we want to listen to
	return;
#endif
#ifdef FTP_ENABLE
ftp_server_init();
ftp_server_tcp_command=tcp_passive_open(TCP_PORT_FTP_COMMAND);
if(ftp_server_tcp_command==TCP_WRONG_CONNECTIONS)	// set port we want to listen to
	return;
#endif
#ifdef ARP_ENABLE
arp_request_timer(ARP_REQUEST_TIMER_START);		// start mode
#endif
#ifdef DATAFLASH_FILE_ENABLE
dataflash_file_init(DATAFLASH_SPI_MODE);		// init dataflash
#endif	// #ifdef	DATAFLASH_FILE_ENABLE
server_ok=1;
}

//*********************************************************************************
// Description	: main routine to handle the network-traffic
// Input     	: none
// Output	   	: none
// Indication	: none
//*********************************************************************************
void server_main(void)
{
if(server_ok)
	{
	#ifdef DEVICE_PPP
	ppp_main();
	if(DEVICE_READ_READY())
		{
		#ifdef IP_ENABLE
		ip_process_frame(0);
		#endif
		ppp_data_clear();
		}
	#else
	ethernet_process();		 	// handle network and easyToWeb-stack events
	#endif	// #ifdef DEVICE_PPP

	buffer_process();			// handles the buffer management

	#ifdef UDP_ENABLE
	udp_main();
	#ifdef BOOTP_ENABLE
	bootp_process();
	#endif	// #ifdef BOOTP_ENABLE
	#ifdef TFTP_ENABLE
	tftp_main();
	#endif	// #ifdef TFTP_ENABLE
	#endif	// #ifdef UDP_ENABLE

	#ifdef TCP_ENABLE
		tcp_main();	  	  	   	// handles all TCP-actions
		#ifdef TCP_DEBUG_TESTBENCH
		tcp_debug_client_server();
		#endif
		buffer_process();		// handles the buffer management
		#ifdef HTTP_ENABLE
		http_server();			// go to the http-Server
		#endif	// #ifdef HTTP_ENABLE
		#ifdef FTP_ENABLE
		ftp_server_main();				// go to the ftp-Server
		#endif	// #ifdef FTP_ENABLE
	#endif	// #ifdef TCP_ENABLE
	buffer_process();			// handles the buffer management
	}
}