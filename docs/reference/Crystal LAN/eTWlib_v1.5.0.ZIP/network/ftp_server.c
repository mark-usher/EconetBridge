// ************************************************************************************************
///
/// \file 			ftp_server.c
/// \brief			Implementation of ftp server
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// \par History
///					1.) 06.10.2003 Version 2.02
///						a.)	- FTP RFC-959 Experimental Commands, see function 
///								"ftp_server_get_command()"
///					2.) 13.01.2004 Version 2.03
///						a.)	- supports now the User-Server Connection if data transfer in progress,
///								see RFC-959, page 35;
///						--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef FTP_ENABLE

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "device.h"
#include "buffer.h"
#ifdef WEB_DEBUG_FTP
#include "debug.h"
#endif
#include "board.h"
#ifdef ETHERNET_ENABLE
#include "ethernet.h"
#endif
#ifdef TCP_ENABLE
#include "tcp.h"
#endif
#ifdef DEVICE_PPP
#include "modem.h"
#include "ppp.h"
#endif
#ifdef WEB_DEBUG_MEASURE			// enable time-measure debug functions, see measure.c
#include "measure.h"
#endif
#include "ftp_server.h"
#ifdef	DATAFLASH_FILE_ENABLE	
#include "dataflash.h"
#include "dataflash_file.h"
#endif	// #ifdef	DATAFLASH_FILE_ENABLE
#include "server.h"


#pragma regalloc-
unsigned char		 ftp_server_tcp_command=TCP_WRONG_CONNECTIONS;
unsigned char		 ftp_server_tcp_data=TCP_WRONG_CONNECTIONS;
unsigned char		 ftp_server_command[FTP_MAX_COMMAND_SIZE+1];			// buffer to ftp-command
unsigned char		 ftp_server_parameter[FTP_MAX_PARAMETER_SIZE+1];		// buffer to ftp-parameter
unsigned char		 ftp_server_data_ip[IP_ADR_SIZE]; 	// see PORT Command
unsigned int		 ftp_server_data_port;				// see PORT and PASV Command
unsigned int		 ftp_server_flag=FTP_FLAG_TYPE_A|FTP_FLAG_TYPE_N|FTP_FLAG_MODE_S|FTP_FLAG_STRU_F;	// flag to handle the FTP-Connection
FTP_STATE_MACHINE	 ftp_state_machine=FTP_STATE_CLOSED;
unsigned char		 ftp_file_handle=FILE_HANDLE_DISABLE;
unsigned char 		 ftp_temp_buffer[TCP_TX_SEGMENT_SIZE];	// space for LIST data
eeprom unsigned char ftp_debug_flag = 0x00;	// default: debug output off
#pragma regalloc+

// prototype
#ifdef WEB_DEBUG_FTP
void ftp_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);
#endif
//*********************************************************************************
// Description	: 
// Input	   	: 
// Output      	: 
// Indication	: none
//*********************************************************************************
void ftp_server_init(void)
{
#ifdef WEB_DEBUG_FTP
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &ftp_debug_handler;
p_struct.id_string = "ftp";
debug_register_handler(&p_struct);
#endif
}


//*********************************************************************************
// Description	: writes reply to command channel
// Input	   	: *data  - pointer to flash-area
// Output      	: 0 - error
//              : 1 - ok
// Indication	: none
//*********************************************************************************
unsigned char ftp_server_reply(flash unsigned char *data)
{
#ifdef WEB_DEBUG_FTP
static unsigned char repeat_count;
#endif

if (tcp_tx_buffer_write_f(ftp_server_tcp_command, data, strlenf(data), TCP_TX_BUFFER_WRITE_FLASH_DATA))
	{
	#ifdef WEB_DEBUG_FTP
	if (ftp_debug_flag)
		printf("FTP Reply: %p", data);
	repeat_count=0;
	#endif	// #ifdef WEB_DEBUG_FTP
	return 1;
	}
#ifdef WEB_DEBUG_FTP
if (ftp_debug_flag)
	{
	if (repeat_count==0)
		printf("FTP Reply-Error: %p", data);
	repeat_count=1;
	}
#endif	// #ifdef WEB_DEBUG_FTP
return 0;
}


//*********************************************************************************
// Description	: check the received command and get a pointer of command
// Input	   	: none
// Output      	: 0 - no FTP command
//              : 1 - normal FTP Command
//              : 2 - User break data connection and send a new FTP-Command
// Indication	: none
//*********************************************************************************
FTP_SERVER_GET_MODE ftp_server_get_command(TCP_STRUCTURE *p_struct)
{
unsigned char	command_len=0, parameter_len=0;
unsigned char	*data, telnet_command=0;
unsigned int	tcp_data_len;
#ifdef WEB_DEBUG_FTP
unsigned char	*temp_data;
#endif

if(p_struct->tcp_socket_status & SOCK_DATA_AVAILABLE)
	{
	data=tcp_rx_buffer_read(ftp_server_tcp_command, 0x0, &tcp_data_len, TCP_RX_BUFFER_GET_SIZE);
	#ifdef WEB_DEBUG_FTP
	temp_data=data;
	#endif
	if(tcp_data_len>4)
		{
		while((*data!=' ')&&(*data!=FTP_CRLF[0])&&(command_len<FTP_MAX_COMMAND_SIZE))	// max. length of command
			{
			ftp_server_command[command_len]=*data;
			data++;
			command_len++;			// count size of command
			}
		ftp_server_command[command_len]=0x0;	// now set the endsign
		if((command_len>0)&&(command_len<=FTP_MAX_COMMAND_SIZE))	// max. length of command (\xF2ABORT)	
			{
			// ----------------------------------------------
			// ftp parameter
			if(*data==' ')							// first parameter??
				data++;
			while((*data!=FTP_CRLF[0])&&(parameter_len<FTP_MAX_PARAMETER_SIZE))
				{
				ftp_server_parameter[parameter_len]=*data;
				data++;
				parameter_len++;			// count size of parameter
				}
			ftp_server_parameter[parameter_len]=0x0;	// set endsign
			// ----------------------------------------------
			// ftp command
			if(ftp_server_command[0]=='X')			// a Experimental Command
				strcpy(ftp_server_command, &ftp_server_command[1]);	// delete the 'X'			
			if(ftp_server_command[0]==0xF2)			// a Telnet Synch-Signal
				{
				telnet_command=ftp_server_command[0];
				strcpy(ftp_server_command, &ftp_server_command[1]);	// delete the '\xF2' (Telnet Data Mark Signal)
				}
			// ----------------------------------------------
			#ifdef WEB_DEBUG_FTP
			if (ftp_debug_flag)
				{
				printf("FTP Command: %s %s", ftp_server_command, ftp_server_parameter);
				if(telnet_command)
					{
					switch(telnet_command)
						{
						case 0xF2: printf(" + Telnet-Synch"); break;
					//	case 0xF4: printf(" + Telnet-IP"); break;
						}
					}
				putsf("\r");
				}
			#endif	// #ifdef WEB_DEBUG_FTP
			if(telnet_command)
				return FTP_SERVER_GET_BREAK;
			return FTP_SERVER_GET_NORMAL;
			}
		else
			{
			#ifdef WEB_DEBUG_FTP
			if (ftp_debug_flag)
				{
				printf("FTP wrong Command: %u Byte\r\n", tcp_data_len);
				debug_display_mem_hex(temp_data, tcp_data_len, 0);
				}
			#endif	// #ifdef WEB_DEBUG_FTP
			}
		}
	}	// if(p_struct->tcp_socket_status & SOCK_DATA_AVAILABLE)
return FTP_SERVER_GET_NOTHING;
}


//*********************************************************************************
// Description	: checks the USER ID
// Input	   	: none
// Output      	: 0 - 
//              : 1 - 
// Indication	: none
//*********************************************************************************
unsigned char ftp_server_user(void)
{
if(strcmpf(ftp_server_parameter, FTP_USER_ID)!=0)
	return 0;
if(ftp_server_reply(FTP_REPLY_331))
	return 1;
return 0;
}


//*********************************************************************************
// Description	: checks the USER Password
// Input	   	: none
// Output      	: 0 - 
//              : 1 - 
// Indication	: none
//*********************************************************************************
unsigned char ftp_server_password(void)
{
if(strcmpf(ftp_server_parameter, FTP_PASSWORD)!=0)
	return 0;
#ifdef FTP_ACCOUNT_ENABLE
if(ftp_server_reply(FTP_REPLY_332))	// "332 Need account for login"FTP_CRLF
	return 1;
#else
if(ftp_server_reply(FTP_REPLY_230))	// "230 User looged in, proceed"FTP_CRLF
	return 1;
#endif	// #ifdef FTP_ACCOUNT_ENABLE
return 0;
}


#ifdef FTP_ACCOUNT_ENABLE
//*********************************************************************************
// Description	: checks the USER account
// Input	   	: none
// Output      	: 0 - 
//              : 1 - 
// Indication	: none
//*********************************************************************************
unsigned char ftp_server_account(void)
{
if(strcmpf(ftp_server_parameter, FTP_ACCOUNT)!=0)
	return 0;
if(ftp_server_reply(FTP_REPLY_230))	// "230 User looged in, proceed"FTP_CRLF
	return 1;
return 0;
}
#endif	// #ifdef FTP_ACCOUNT_ENABLE


//*********************************************************************************
// Description	: handle the PORT Command
// Input	   	: none
// Output      	: 0 - 
//              : 1 - 
// Indication	: none
//*********************************************************************************
unsigned char ftp_server_port(void)
{
unsigned char	*parameter;

if(ftp_server_parameter==0x0)
	return 0;
parameter=ftp_server_parameter;

ftp_server_data_ip[0]=atoi(parameter);
// delete the first part of ip-parameter
while((*parameter!=',')&&(*parameter!=0x0))
	parameter++;
parameter++;
ftp_server_data_ip[1]=atoi(parameter);
// delete the second part of ip-parameter
while((*parameter!=',')&&(*parameter!=0x0))
	parameter++;
parameter++;
ftp_server_data_ip[2]=atoi(parameter);
// delete the third part of ip-parameter
while((*parameter!=',')&&(*parameter!=0x0))
	parameter++;
parameter++;
ftp_server_data_ip[3]=atoi(parameter);
// delete the fourth part of ip-parameter
while((*parameter!=',')&&(*parameter!=0x0))
	parameter++;
parameter++;
ftp_server_data_port=atoi(parameter);
ftp_server_data_port<<=8;
// delete the first part of port-parameter
while((*parameter!=',')&&(*parameter!=0x0))
	parameter++;
parameter++;
ftp_server_data_port|=atoi(parameter);
#ifdef WEB_DEBUG_FTP
if (ftp_debug_flag)
	{
	printf("FTP PORT-IP: %u.%u.%u.%u Port: %u\r\n", ftp_server_data_ip[0], ftp_server_data_ip[1], 
			ftp_server_data_ip[2], ftp_server_data_ip[3], ftp_server_data_port);
	}
#endif	// #ifdef WEB_DEBUG_FTP
return 1;
}

/*
//*********************************************************************************
// Description	: handle the PASV Command
// Input	   	: none
// Output      	: 0 - 
//              : 1 - 
// Indication	: none
//*********************************************************************************
unsigned char ftp_server_pasv(void)
{
unsigned int	new_port;
unsigned char	data_buffer[52];

new_port=TCP_PORT_FTP_DATA;			// set the Server Data-Port
sprintf(data_buffer, FTP_REPLY_227, ip_address[0], ip_address[1], ip_address[2], ip_address[3], 
				new_port>>8, new_port & 0xff);
if(tcp_tx_buffer_prepare(ftp_server_tcp_command, data_buffer, strlen(data_buffer)))
	{
	memcpy(ftp_server_data_ip, ip_address, IP_ADR_SIZE);
	ftp_server_data_port=TCP_PORT_FTP_DATA;			// set the Server Data-Port
	ftp_server_flag|=FTP_FLAG_PASSIVE;
	#ifdef WEB_DEBUG_FTP
	if (ftp_debug_flag)
		{
		printf("FTP PASV-IP: %u.%u.%u.%u Port: %u\r\n", ftp_server_data_ip[0], ftp_server_data_ip[1], 
				ftp_server_data_ip[2], ftp_server_data_ip[3], ftp_server_data_port);
		}
	#endif	// #ifdef WEB_DEBUG_FTP
	if(ftp_server_tcp_data==TCP_WRONG_CONNECTIONS)
		ftp_server_tcp_data=tcp_passive_open(TCP_PORT_FTP_DATA);
	else
		return 0;	// ftp_server_tcp_data!=TCP_WRONG_CONNECTIONS
	if(ftp_server_tcp_data==TCP_WRONG_CONNECTIONS)	// still no connection
		return 0;
	#ifdef WEB_DEBUG_FTP
	if (ftp_debug_flag)
		printf("FTP Data Passive Open (TCP: %u)\r\n", ftp_server_tcp_data);
	#endif	// #ifdef WEB_DEBUG_FTP
	return 1;
	}
return 0;
}
*/

//*********************************************************************************
// Description	: Open a Data-Connection, see LIST, ... Command
// Input	   	: none
// Output      	: 0 - 
//              : 1 - 
// Indication	: open TCP/IP Data-channel
//*********************************************************************************
unsigned char ftp_server_data_start(void)
{
if(ftp_server_flag & FTP_FLAG_PASSIVE)
	{
/*
	if(ftp_server_tcp_data==TCP_WRONG_CONNECTIONS)
		ftp_server_tcp_data=tcp_passive_open(TCP_PORT_FTP_DATA);
	else
		return 0;	// ftp_server_tcp_data!=TCP_WRONG_CONNECTIONS
	if(ftp_server_tcp_data==TCP_WRONG_CONNECTIONS)	// still no connection
		return 0;
	#ifdef WEB_DEBUG_FTP
	if (ftp_debug_flag)
		printf("FTP Data Passive Open (TCP: %u)\r\n", ftp_server_tcp_data);
	#endif	// #ifdef WEB_DEBUG_FTP
*/
	}
else
	{
	if(ftp_server_tcp_data==TCP_WRONG_CONNECTIONS)
		ftp_server_tcp_data=tcp_active_open(ftp_server_data_ip, ftp_server_data_port, TCP_PORT_FTP_DATA);
	else
		return 0;	// ftp_server_tcp_data!=TCP_WRONG_CONNECTIONS
	if(ftp_server_tcp_data==TCP_WRONG_CONNECTIONS)	// still no connection
		return 0;
	#ifdef WEB_DEBUG_FTP
	if (ftp_debug_flag)
		printf("FTP Data Active Open (TCP: %u)\r\n", ftp_server_tcp_data);
	#endif	// #ifdef WEB_DEBUG_FTP
	ftp_server_reply(FTP_REPLY_150);
	}
return 1;
}

char flash *date_month[16]={
			""   ,"Jan","Feb","Mar",
			"Apr","May","Jun","Jul",
			"Aug","Sep","Oct","Nov",
			"Dec",""   ,""   ,"Jan"}; 

//*********************************************************************************
// Description	: reads the dir names and write to buffer
// Input	   	: dir_count - actual dir entry
//              : count  	- size of data inside of buffer
// Output      	: none
// Indication	: none
//*********************************************************************************
void ftp_server_list_dir_file(unsigned int *count, unsigned char start)
{
static unsigned char dir_count;
static unsigned char dir_file_state;
unsigned char file_find;
unsigned int Lva;
unsigned char data[22];
DIR_NAME_STRUCT dir_struct;
FILE_NAME_STRUCT file_struct;

if(start)
	{
	dir_count=0;
	dir_file_state=0;
	}
ftp_temp_buffer[0]=0;
if(dir_file_state==0)
	{
//	strcatf(ftp_temp_buffer, "total 123\r\n");
//	*count=11;
	dir_file_state=1;	
	}
if(dir_file_state==1)
	{
	for(Lva=dir_count;Lva<FILE_DIR_COUNT;Lva++)
		{
		if(dataflash_dir_search(0x0, &dir_count, &dir_struct))
			{
			strcatf(ftp_temp_buffer, "d--------- 1 ftp ftp      0 ");
			if(dir_struct.date.year==3)
				{
				sprintf(data, "%p %02u %02u:%02u ", date_month[dir_struct.date.month], dir_struct.date.day, 
											 dir_struct.date.hour, dir_struct.date.minute);
				(*count)+=13;
				}
			else
				{
				sprintf(data, "%p %02u %04u ", date_month[dir_struct.date.month], dir_struct.date.day, 
														(unsigned int)dir_struct.date.year+2000);
				(*count)+=12;
				}
			strcat(ftp_temp_buffer, data);				// add dir-date string
			strcat(ftp_temp_buffer, dir_struct.name);	// add dir name
			strcatf(ftp_temp_buffer, FTP_CRLF);			// add end sign
			(*count)+=28+strlen(dir_struct.name)+sizeof(FTP_CRLF);
			}
		dir_count++;
		if(dir_count>=FILE_DIR_COUNT)	
			dir_file_state=2;	
		if((*count)>(sizeof(ftp_temp_buffer)-(28+13+DIR_NAME_SIZE+sizeof(FTP_CRLF))))
			return;
		}
	}
if((dir_file_state==2)||(dir_file_state==3))
	{
	while(1)
		{
		if(dir_file_state==2)
			{
			file_find=dataflash_file_search(0x0, &file_struct, 0x0, SEARCH_FIRST);
			dir_file_state=3;	// to prevent overflow
			}
		else
			file_find=dataflash_file_search(0x0, &file_struct, 0x0, SEARCH_NEXT);
		if(file_find==0)
			{
			dir_file_state=4;
			return;
			}
		else
			{
			strcatf(ftp_temp_buffer, "---------- 1 ftp ftp ");
			sprintf(data, "%6lu ", (unsigned long)(file_struct.countpage-1)*FILE_DATA_PAGE_SIZE+file_struct.lastpage_byte);
			strcat(ftp_temp_buffer, data);
			sprintf(data, "%p %02u %02u:%02u ", date_month[file_struct.date.month], file_struct.date.day, 
											 file_struct.date.hour, file_struct.date.minute);
			(*count)+=13;	// length of string
			strcat(ftp_temp_buffer, data);				// add file-date string
			strcat(ftp_temp_buffer, file_struct.name);	// add file name
			strcatf(ftp_temp_buffer, FTP_CRLF);			// add end sign
			(*count)+=21+7+strlen(file_struct.name)+sizeof(FTP_CRLF);
			if((*count)>(sizeof(ftp_temp_buffer)-(21+7+13+FILE_NAME_SIZE+sizeof(FTP_CRLF))))
				return;
			}
		}
	}
if(dir_file_state==4)
	return;
}


//*********************************************************************************
// Description	: handle the LIST Command to write data
// Input	   	: start - 1==start the transfer; 0==end the transfer
// Output      	: 0 - 
//              : 1 - 
// Indication	: none
//*********************************************************************************
unsigned char ftp_server_list(unsigned char start)
{
static unsigned int count;
static unsigned char state;
TCP_STRUCTURE	*p_struct;                                    	

if(ftp_server_tcp_data==TCP_WRONG_CONNECTIONS)
	return 0;
if(start)
	{
	state=0;
	count=0;
	ftp_server_list_dir_file(&count, 1);
	}
if(state==1)
	{
	if(count==0)
		{
		ftp_server_list_dir_file(&count, 0);
		if(count==0)	// still Zero
			return 0;
		}
	}
p_struct=tcp_get_struct(ftp_server_tcp_data);
if((p_struct!=0)&&(p_struct->tcp_socket_status & SOCK_CONNECTED))
	{
	state=1;
	if(tcp_tx_buffer_write(ftp_server_tcp_data, ftp_temp_buffer, count, TCP_TX_BUFFER_WRITE_RAM_DATA))
		{
		#ifdef WEB_DEBUG_FTP
		if (ftp_debug_flag)
			printf("FTP DATA: %u Byte\r\n", count);
		#endif	// #ifdef WEB_DEBUG_FTP
		count=0;
		}
    }
return 1;
}


//*********************************************************************************
// Description	: handle the TYPE Command
// Input	   	: none
// Output      	: 0 - 
//              : 1 - 
// Indication	: none
//*********************************************************************************
unsigned char ftp_server_type(void)
{
unsigned char type;

if(ftp_server_parameter)
	{
	ftp_server_flag&=~FTP_FLAG_TYPE_MASK;	// delete all Type
	ftp_server_flag|=FTP_FLAG_TYPE_N;		// set default Type Non-print
	type=ftp_server_parameter[0];  			// read parameter
	switch(type)
		{
		case 'A': ftp_server_flag|=FTP_FLAG_TYPE_A; break;
		case 'I': ftp_server_flag|=FTP_FLAG_TYPE_I; break;
		case 'E': 
		case 'L': 
			ftp_server_reply(FTP_REPLY_504);	// "504 Command not implemented for that parameter"FTP_CRLF
			return 0;
		default:
			ftp_server_flag|=(FTP_FLAG_TYPE_A | FTP_FLAG_TYPE_N);	// set default Type
		}
	ftp_server_reply(FTP_REPLY_200);	// "200 Command okay"FTP_CRLF
	return 1;
	}
ftp_server_reply(FTP_REPLY_501);	// "501 Syntax error in parameters or argumants"FTP_CRLF
return 0;
}


//*********************************************************************************
// Description	: handle the PWD Command
// Input	   	: none
// Output      	: 0 - 
//              : 1 - 
// Indication	: none
//*********************************************************************************
unsigned char ftp_server_pwd(void)
{
unsigned char	data_buffer[60];
unsigned char	info_buffer[30];
#ifdef	DATAFLASH_FILE_ENABLE	
DIR_NAME_STRUCT dir_struct;
#endif

sprintf(info_buffer, "eTW_%u_%u_%u_%u:\\\\", ip_address[0], ip_address[1], ip_address[2], ip_address[3]);
#ifdef	DATAFLASH_FILE_ENABLE	
if(dataflash_dir_search(0x0, &directory_actual, &dir_struct))
	{
//	printf("----FTP  %s\r\n", dir_struct.name);
	sprintf(data_buffer, "%s\\\\", dir_struct.name);
	strncat(info_buffer, data_buffer, sizeof(info_buffer)-strlen(info_buffer)); 				// copy "data_buffer" to end of "info_buffer"
	}
#endif
sprintf(data_buffer, FTP_REPLY_257, info_buffer);	// "257 %p created"FTP_CRLF
if(tcp_tx_buffer_write(ftp_server_tcp_command, data_buffer, strlen(data_buffer), TCP_TX_BUFFER_WRITE_RAM_DATA))
	{
	#ifdef WEB_DEBUG_FTP
	if (ftp_debug_flag)
		printf("FTP PWD: %s\r\n", info_buffer);
	#endif	// #ifdef WEB_DEBUG_FTP
	return 1;
	}
ftp_server_reply(FTP_REPLY_550);	// "550 Requested action not taken, File unavailable"FTP_CRLF
return 0;
}


//*********************************************************************************
// Description	: handle the RETR Command to write data
// Input	   	: start - 1==start the transfer; 0==end the transfer
// Output      	: none
// Indication	: none
//*********************************************************************************
unsigned char ftp_server_retr_data(unsigned char start)
{
static unsigned int count;
TCP_STRUCTURE	*p_struct;                                    	

if(ftp_server_tcp_data==TCP_WRONG_CONNECTIONS)
	return 0;
if(start)
	{
	count=0;
	if(dataflash_file_open(ftp_server_parameter, &ftp_file_handle))
		{
		count=dataflash_file_read(ftp_file_handle, ftp_temp_buffer, sizeof(ftp_temp_buffer));
		}
	}
if(count==0)
	{
	if(ftp_file_handle!=FILE_HANDLE_DISABLE)
		{
		count=dataflash_file_read(ftp_file_handle, ftp_temp_buffer, sizeof(ftp_temp_buffer));
		}		
	if(count==0)	// still Zero
		{
		if(ftp_file_handle!=FILE_HANDLE_DISABLE)
			dataflash_file_close(&ftp_file_handle);
		return 0;
		}
	}
p_struct=tcp_get_struct(ftp_server_tcp_data);
if((p_struct!=0)&&(p_struct->tcp_socket_status & SOCK_CONNECTED))
	{
	if(tcp_tx_buffer_write(ftp_server_tcp_data, ftp_temp_buffer, count, TCP_TX_BUFFER_WRITE_RAM_DATA))
		{
		#ifdef WEB_DEBUG_FTP
		if (ftp_debug_flag)
			printf("FTP DATA: %u Byte\r\n", count);
		#endif	// #ifdef WEB_DEBUG_FTP
		count=0;
		}
    }
return 1;
}

//*********************************************************************************
// Description	: handle the STOR Command to write data
// Input	   	: start - 1==start the transfer; 0==end the transfer
// Output      	: none
// Indication	: none
//*********************************************************************************
unsigned char ftp_server_stor_data(unsigned char start)
{
static unsigned char state;
unsigned int 		tcp_data_count;
TCP_STRUCTURE		*p_struct;                                    	

p_struct=tcp_get_struct(ftp_server_tcp_data);
if(p_struct==0)
	return 0;
if(start)
	{
	state=0;
	if(dataflash_file_new(ftp_server_parameter))
		dataflash_file_open(ftp_server_parameter, &ftp_file_handle);
	else
		{
		if(dataflash_file_open(ftp_server_parameter, &ftp_file_handle))
			{
			dataflash_file_delete(ftp_file_handle);
			if(dataflash_file_new(ftp_server_parameter))
				dataflash_file_open(ftp_server_parameter, &ftp_file_handle);
			}
		}
	}
if(p_struct->tcp_socket_status & SOCK_CONNECTED)   	// check if somebody has connected to our TCP
	{
	state=1;
	if(p_struct->tcp_socket_status & SOCK_DATA_AVAILABLE)
		{
		tcp_data_count=sizeof(ftp_temp_buffer);
		tcp_rx_buffer_read(ftp_server_tcp_data, ftp_temp_buffer, &tcp_data_count, TCP_RX_BUFFER_READ_DATA);	// get size of buffer
		if(ftp_file_handle!=FILE_HANDLE_DISABLE)
			{
			if(!dataflash_file_write(ftp_file_handle, ftp_temp_buffer, tcp_data_count))
				{
				ftp_server_reply(FTP_REPLY_552);	// "552 Requested file action aborted, Exceeded storage allocation"FTP_CRLF
				dataflash_file_close(&ftp_file_handle);
				}
			}
		else
			ftp_server_reply(FTP_REPLY_550);	// "550 Requested action not taken, File unavailable"FTP_CRLF
		}
	}
else
	{
	if(state==1)
		{
		if(ftp_file_handle!=FILE_HANDLE_DISABLE)
			dataflash_file_close(&ftp_file_handle);
		return 0;
		}
	}
return 1;
}


//*********************************************************************************
// Description	: handle the DELE Command to delete file
// Input	   	: none
// Output      	: none
// Indication	: none
//*********************************************************************************
void ftp_server_dele(void)
{
if(ftp_file_handle==FILE_HANDLE_DISABLE)
	{
	if(dataflash_file_open(ftp_server_parameter, &ftp_file_handle))
		{
		dataflash_file_delete(ftp_file_handle);
		ftp_file_handle=FILE_HANDLE_DISABLE;
		ftp_server_reply(FTP_REPLY_250);	// "250 Requested file action okay"FTP_CRLF
		return;
		}
	}
ftp_server_reply(FTP_REPLY_550);	// "550 Requested action not taken, File unavailable"FTP_CRLF
}


// --------------------------------------------------------------------------------
// ftp-server state strings
// -------------------------------------------------------------------------------- 
#ifdef WEB_DEBUG_FTP
char flash *ftp_state_name[8]={
			"FTP_STATE_CLOSED", "FTP_STATE_USER_ID", 
			"FTP_STATE_PASSWORD", "FTP_STATE_COMMAND", 
			"FTP_STATE_ACCOUNT", "FTP_STATE_LIST",
			"FTP_STATE_RETR","FTP_STATE_STOR"};	
#endif

//*********************************************************************************
// Description	: FTP-Server
// Input	   	: none
// Output      	: none
// Indication	: none
//*********************************************************************************
void ftp_server_main(void)
{
#ifdef WEB_DEBUG_FTP
static FTP_STATE_MACHINE	temp_ftp_state_machine=FTP_STATE_CLOSED;
#endif	// #ifdef WEB_DEBUG_FTP
FTP_SERVER_GET_MODE new_ftp_command;
TCP_STRUCTURE	*p_struct;                                    	

#ifdef WEB_DEBUG_FTP
if (ftp_debug_flag)
	{
	if(temp_ftp_state_machine!=ftp_state_machine)
		{
		printf("FTP State: %p\r\n", ftp_state_name[ftp_state_machine]);
		temp_ftp_state_machine=ftp_state_machine;
		}
	}
#endif	// #ifdef WEB_DEBUG_FTP
p_struct=tcp_get_struct(ftp_server_tcp_command);
if((p_struct!=0)&&(p_struct->tcp_socket_status & SOCK_CONNECTED))	// check if somebody has connected to our TCP
	{
	new_ftp_command=ftp_server_get_command(p_struct);
	if(new_ftp_command==FTP_SERVER_GET_BREAK)		// break command from User
		ftp_state_machine=FTP_STATE_COMMAND; 
	switch(ftp_state_machine)
		{
		case FTP_STATE_CLOSED: 
				if(ftp_server_reply(FTP_REPLY_220))
					{
					memcpy(ftp_server_data_ip, p_struct->tcp_ip_remote, IP_ADR_SIZE);
					ftp_server_data_port=TCP_PORT_FTP_DATA;		
					ftp_state_machine=FTP_STATE_USER_ID; 
					#ifdef ICMP_ENABLE
					icmp_prepare_timestamp_request(p_struct->tcp_ip_remote, p_struct->tcp_mac_remote, 0);
					#endif	// #ifdef ICMP_ENABLE
					}
				break;
		case FTP_STATE_USER_ID: 
				if(!(new_ftp_command))
					break;
				if(strcmpf(ftp_server_command, FTP_COMMAND_USER)==0)
					{
					if(ftp_server_user())
						ftp_state_machine=FTP_STATE_PASSWORD;
					else 
						{
						ftp_server_reply(FTP_REPLY_501);
						tcp_close(ftp_server_tcp_command);
						}
					}
				break;
		case FTP_STATE_PASSWORD: 
				if(!(new_ftp_command))
					break;
				if(strcmpf(ftp_server_command, FTP_COMMAND_PASS)==0)
					{
					if(ftp_server_password())
						{
						#ifdef FTP_ACCOUNT_ENABLE		// enable account function
						ftp_state_machine=FTP_STATE_ACCOUNT; 
						#else
						ftp_state_machine=FTP_STATE_COMMAND; 
						#endif	// #ifdef FTP_ACCOUNT_ENABLE
						}
					else 
						{
						ftp_server_reply(FTP_REPLY_501);
						tcp_close(ftp_server_tcp_command);
						}
					}
				break;
		#ifdef FTP_ACCOUNT_ENABLE		// enable account function
		case FTP_STATE_ACCOUNT: 
				if(!(new_ftp_command))
					break;
				if(strcmpf(ftp_server_command, FTP_COMMAND_ACCT)==0)	// Account
					{
					if(ftp_server_account())
						ftp_state_machine=FTP_STATE_COMMAND; 
					else 
						{
						ftp_server_reply(FTP_REPLY_501);
						tcp_close(ftp_server_tcp_command);
						}
					}
				break;
		#endif	// #ifdef FTP_ACCOUNT_ENABLE
		case FTP_STATE_LIST:
				if(!(ftp_server_list(0)))	// if last data write?
					{
					if(ftp_server_reply(FTP_REPLY_226))	// "226 Closing data connection"FTP_CRLF
						{
						//tcp_abort(ftp_server_tcp_data);
						tcp_close(ftp_server_tcp_data);
						ftp_server_tcp_data=TCP_WRONG_CONNECTIONS;
						ftp_state_machine=FTP_STATE_COMMAND; 
						}
					}
				break;
		case FTP_STATE_RETR:
				if(!(ftp_server_retr_data(0)))	// if last data read?
					{
					if(ftp_server_reply(FTP_REPLY_226))	// "226 Closing data connection"FTP_CRLF
						{
						//tcp_abort(ftp_server_tcp_data);
						tcp_close(ftp_server_tcp_data);
						ftp_server_tcp_data=TCP_WRONG_CONNECTIONS;
						ftp_state_machine=FTP_STATE_COMMAND; 
						}
					}
				break;
		case FTP_STATE_STOR:
				if(!(ftp_server_stor_data(0)))	// if last data write?
					{
					if(ftp_server_reply(FTP_REPLY_226))	// "226 Closing data connection"FTP_CRLF
						{
						//tcp_abort(ftp_server_tcp_data);
						tcp_close(ftp_server_tcp_data);
						ftp_server_tcp_data=TCP_WRONG_CONNECTIONS;
						ftp_state_machine=FTP_STATE_COMMAND; 
						}
					}
				break;
		case FTP_STATE_COMMAND:
				if(ftp_file_handle!=FILE_HANDLE_DISABLE)
					{
					#ifdef WEB_DEBUG_FTP
					if (ftp_debug_flag)
						printf("FTP ERROR Close File: %u\r\n", ftp_file_handle);
					#endif	// #ifdef WEB_DEBUG_FTP
					if(!dataflash_file_close(&ftp_file_handle))
						{
						dataflash_file_close_all();
						ftp_file_handle=FILE_HANDLE_DISABLE;
						}
					}
				if(!(new_ftp_command))
					break;
				if(strcmpf(ftp_server_command, FTP_COMMAND_QUIT)==0)
					{
					ftp_server_reply(FTP_REPLY_221);	// "221 Service closing control connection"FTP_CRLF
					//tcp_abort(ftp_server_tcp_data);
					tcp_close(ftp_server_tcp_data);
					ftp_server_tcp_data=TCP_WRONG_CONNECTIONS;
					tcp_close(ftp_server_tcp_command);
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_ABOR)==0)
					{
					if(ftp_server_tcp_data!=TCP_WRONG_CONNECTIONS)
						{
						//tcp_abort(ftp_server_tcp_data);
						tcp_close(ftp_server_tcp_data);
						ftp_server_tcp_data=TCP_WRONG_CONNECTIONS;
						ftp_server_reply(FTP_REPLY_226);	// "226 Closing data connection"FTP_CRLF
						}
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_PORT)==0)
					{
					if(ftp_server_port())
						ftp_server_reply(FTP_REPLY_200);
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_TYPE)==0)
					{
					ftp_server_type();
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_RETR)==0)
					{
					if(ftp_server_data_start())
						{
						if(ftp_server_retr_data(1))
							ftp_state_machine=FTP_STATE_RETR; 
						else
							{
							if(ftp_server_reply(FTP_REPLY_226))	// "226 Closing data connection"FTP_CRLF
								{
								//tcp_abort(ftp_server_tcp_data);
								tcp_close(ftp_server_tcp_data);
								ftp_server_tcp_data=TCP_WRONG_CONNECTIONS;
								}
							}
						}
					else
						ftp_server_reply(FTP_REPLY_425);		//	"425 Can't open data connection"FTP_CRLF
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_STOR)==0)
					{
					if(ftp_server_data_start())
						{
						ftp_server_stor_data(1);
						ftp_state_machine=FTP_STATE_STOR; 
						}
					else
						ftp_server_reply(FTP_REPLY_425);		// "425 Can''t open data connection"FTP_CRLF
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_NOOP)==0)
					{
					ftp_server_reply(FTP_REPLY_200);
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_PWD)==0)
					{
					ftp_server_pwd();
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_SYST)==0)
					{
					ftp_server_reply(FTP_REPLY_215);	// "215 easyToWeb-Software FTZ Leipzig"FTP_CRLF
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_HELP)==0)
					{
					ftp_server_reply(FTP_REPLY_214);	// "214 easyToWeb-"PROJECT_NAME" "PROJECT_VERSION" "FTP_CRLF
					break;
					}
				/*
				if(strcmpf(ftp_server_command, FTP_COMMAND_PASV)==0)
					{
					if(!(ftp_server_pasv()))
						ftp_server_reply(FTP_REPLY_421);	// "421 Service not available, closing control connections"FTP_CRLF
					break;
					}
				*/
				if(strcmpf(ftp_server_command, FTP_COMMAND_LIST)==0)
					{
					if(ftp_server_data_start())
						{
						ftp_state_machine=FTP_STATE_LIST; 
						ftp_server_list(1);
						}
					else
						ftp_server_reply(FTP_REPLY_425);	// "425 Can''t open data connection"FTP_CRLF
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_NLST)==0)
					{
					if(ftp_server_data_start())
						{
						ftp_state_machine=FTP_STATE_LIST; 
						ftp_server_list(1);
						}
					else
						ftp_server_reply(FTP_REPLY_425);	// "425 Can''t open data connection"FTP_CRLF
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_DELE)==0)
					{
					ftp_server_dele();
					break;
					}
				/*
				if(strcmpf(ftp_server_command, FTP_COMMAND_MODE)==0)	// transfer mode (S)tream, (B)lock, (C)ompressed
					{
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_STRU)==0)	// structure (F)ile, (R)ecord, (P)age
					{
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_CWD)==0)		// change working directory
					{
					ftp_server_reply(FTP_REPLY_250);	// "250 Requested file action okay"FTP_CRLF
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_CDUP)==0)	// change to parent directory
					{
					ftp_server_reply(FTP_REPLY_200);	// "200 Command okay"FTP_CRLF
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_RMD)==0)		// Remove Directory
					{
					ftp_server_reply(FTP_REPLY_200);	// "200 Command okay"FTP_CRLF
					break;
					}
				if(strcmpf(ftp_server_command, FTP_COMMAND_MKD)==0)		// Make Directory
					{
					ftp_server_reply(FTP_REPLY_200);	// "200 Command okay"FTP_CRLF
					break;
					}
				*/
				ftp_server_reply(FTP_REPLY_502);		// "502 Command not implemented"FTP_CRLF
				#ifdef WEB_DEBUG_FTP
				if (ftp_debug_flag)
					printf("FTP Unsupported Command: %s\r\n", ftp_server_command);
				#endif	// #ifdef WEB_DEBUG_FTP
				break;
		}	// 	switch(ftp_state_machine)
	if(p_struct->tcp_socket_status & SOCK_DATA_AVAILABLE)	// check if remote TCP sent data
		tcp_rx_buffer_clear(ftp_server_tcp_command); 			// and throw it away
	}	// if(p_struct->tcp_socket_status & SOCK_CONNECTED) 
else
	{
	if(ftp_state_machine!=FTP_STATE_CLOSED)
		{
		//tcp_abort(ftp_server_tcp_data);
		tcp_close(ftp_server_tcp_data);
		ftp_server_tcp_data=TCP_WRONG_CONNECTIONS;
		tcp_close(ftp_server_tcp_command);
		}
	ftp_state_machine=FTP_STATE_CLOSED;
	}
}


#ifdef WEB_DEBUG_FTP
// ************************************************************************************************
/// \brief	    command handler for debug commands
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void ftp_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{

if (mode == DEBUG_HANDLER_MODE_INFO)
	{
	printf("WEB_DEBUG_FTP");
	if (ftp_debug_flag)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
	}
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
    // add output for 'help' command here
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
    {
	if (strncmpf(command, "ftp", 3)==0)
	    {
    	ftp_debug_flag ^= 0xFF;
    	if (ftp_debug_flag)
			putsf("WEB_DEBUG_FTP ON\r");
		else
			putsf("WEB_DEBUG_FTP OFF\r");
	    }
	}
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if(strncmpf(command, "-info", 2)==0)
		{
		printf("tcp_command: %u\r\n", ftp_server_tcp_command);
		printf("tcp_data   : %u\r\n", ftp_server_tcp_data);
		printf("command    : %s\r\n", ftp_server_command);
		printf("parameter  : %s\r\n", ftp_server_parameter);
		debug_print_ip("ip         ", ftp_server_data_ip);
		printf("port       : %u\r\n", ftp_server_data_port);
		printf("flag       : 0x%04x\r\n", ftp_server_flag);
		printf("state      : %p\r\n", ftp_state_name[ftp_state_machine]);
		printf("handle     : %u\r\n", ftp_file_handle);
		}
	if(strncmpf(command, "-pass", 2)==0)
		{
		}
	if(strncmpf(command, "-user", 2)==0)
		{
		}
	}
}
#endif	// #ifdef WEB_DEBUG_FTP
#endif	// #ifdef FTP_ENABLE