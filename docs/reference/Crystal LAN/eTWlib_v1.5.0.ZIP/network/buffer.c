// ************************************************************************************************
///
/// \file 			buffer.c
/// \brief			Buffer management for easyToWeb-Server
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// \par History
///					1.) 08.08.2003 Version 2.00
///					2.) 15.08.2003 Version 2.01
///						b.)	- buffer works now with pointer and size variables, see "BUFFER_FRAME"
///						a.)	- delete some macros and variables from TCP-Stack
///					3.) 12.11.2003 Version 2.02
///						a.)	- delete buffer "tx_rx_buffer"
///					4.) 16.06.2004 Version 2.04
///						a.)	- delete UDP and BOOTP-Buffer
///						--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <stdio.h>
#include <string.h>
#include <delay.h>
#include "device.h"
#include "ethernet.h"
#include "buffer.h"
#ifdef WEB_DEBUG_MEASURE			// enable time-measure debug functions, see measure.c
#include "measure.h"
#endif
#ifdef WEB_DEBUG
#include "web_debug.h"
#endif

#pragma regalloc-
BUFFER_FRAME	buffer_frame;					// internal data-structure
unsigned char	tx_frame2[TX_BUFFER2_SIZE];
unsigned int 	tx_frame2_size;					// bytes to send in tx_frame2
#pragma regalloc+


//*********************************************************************************
// Description	: must be called from user program periodically (the often - the better)
//              : handles buffer management
// Input   		: none
// Output  		: none
// Indication	: buffer main()-function
//*********************************************************************************
unsigned char buffer_process(void)
{
if(buffer_frame.gap<BUFFER_COUNT)
	{
	if(DEVICE_WRITE_READY(buffer_frame.datasize[buffer_frame.rtop]))	// NOTE: when using a very fast MCU, maybe
		{
		#ifdef WEB_DEBUG_MEASURE
		MEASURE_SETTIME(MEA_BUFFER_FRAME2_S)
		#endif
		DEVICE_WRITE_FRAME_DATA(buffer_frame.data[buffer_frame.rtop], buffer_frame.datasize[buffer_frame.rtop]);    
		#ifdef WEB_DEBUG_MEASURE
		MEASURE_SETTIME(MEA_BUFFER_FRAME2_E)
		#endif
		#ifdef WEB_DEBUG_BUFFER
		if(web_debug_flag & WEB_DEBUG_BUFFER_BIT)
			{
			printf("BUFFER write frame (%ubyte)\r\n", buffer_frame.datasize[buffer_frame.rtop]); 
			//debug_display_frame(buffer_frame.data[buffer_frame.rtop], buffer_frame.datasize[buffer_frame.rtop], 0);
			}
		#endif
		// --------------------------------------------------------------------------------
		// delete the actual command frame
		// -------------------------------------------------------------------------------- 
		buffer_frame.rtop++;
		if(buffer_frame.rtop==BUFFER_COUNT)
			buffer_frame.rtop=0;
		buffer_frame.gap++;
		return 1;
		}
	else
		{
		#ifdef WEB_DEBUG_BUFFER
		if(web_debug_flag & WEB_DEBUG_BUFFER_BIT)
			printf("BUFFER device not ready (%ubyte)\r\n", buffer_frame.datasize[buffer_frame.rtop]); 
		#endif
		}
	}
return 0;
}


//*********************************************************************************
// Description	: clears all buffer of os-interface
// Input		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void buffer_clear(void)
{
//memset(&buffer_frame, 0x0, sizeof(buffer_frame));		
buffer_frame.gap=BUFFER_COUNT;
}

//********************************************************************************
// Description	: test the buffer whether Data present
// Input		: none
// Output		: 1..x - Data present
//		  		: 0    - no Data present
// Indication	: none
//*********************************************************************************
unsigned char	buffer_data_available(void)
{
return(BUFFER_COUNT-buffer_frame.gap);
}

//*********************************************************************************
// Description	: check the size of transmit-buffer
// Input	 	: none
// Output  		: 1..x - size of free buffer
//		  		: 0    - buffer full
// Indication	: none
//*********************************************************************************
unsigned char	buffer_free(void)
{
return buffer_frame.gap;
}


//*********************************************************************************
// Description	: write a os-command to the os-command-buffer
// Input	 	: data 		- pointer to data
//      	 	: datasize  - size of data in byte
// Output  		: 1  - free entry
// 		  		: 0  - no free entry
// Indication	: none
//*********************************************************************************
unsigned char buffer_write_command(unsigned char *data, unsigned int datasize)
{
if(buffer_frame.gap>0)
	{
	#ifdef WEB_DEBUG_BUFFER
	if(web_debug_flag & WEB_DEBUG_BUFFER_BIT)
		printf("BUFFER write command: %u\r\n", buffer_frame.wtop); 
	#endif
	buffer_frame.data[buffer_frame.wtop]=data;
	buffer_frame.datasize[buffer_frame.wtop]=datasize;
	buffer_frame.wtop++;
	if(buffer_frame.wtop==BUFFER_COUNT)
		buffer_frame.wtop=0;
	buffer_frame.gap--;
	return 1;
	}
#ifdef WEB_DEBUG_BUFFER
if(web_debug_flag & WEB_DEBUG_BUFFER_BIT)
	putsf("BUFFER write command: Error\r"); 
#endif
return 0;
}

//*********************************************************************************
// Description	: wait until the data sent
// Input	 	: none
// Output  		: 1: OK
// 		  		: 0: either no data available or timeout
// Indication	: none
//*********************************************************************************
unsigned char buffer_process_wait(void)
{
unsigned char	counter_10ms_delay=10;
unsigned char	counter_10ms_old; 
unsigned int	data;
#ifdef WEB_DEBUG_BUFFER
unsigned char	skip_count=0; 
#endif

if(buffer_data_available())
	{
	// --------------------------------------------------------------------------------
	// delete old receive data
	// -------------------------------------------------------------------------------- 
	while(DEVICE_READ_READY() & DEVICE_READ_READY_RECEIVE)
		{
		#asm("wdr");	// Reset Watchdog
		#ifdef WEB_DEBUG_BUFFER
		skip_count++; 
		#endif
		DEVICE_RECEIVE_SKIP();
		}
	// --------------------------------------------------------------------------------
	// write data
	// -------------------------------------------------------------------------------- 
	while(buffer_data_available())
		{
		#asm("wdr");	// Reset Watchdog
		buffer_process();				// send the frame to Ethernet-Controller
		#ifdef WEB_DEBUG_BUFFER
		if(web_debug_flag & WEB_DEBUG_BUFFER_BIT)
			printf("BUFFER process wait, rx-skip %d\r\n", skip_count); 
		#endif
		}
	counter_10ms_old=(unsigned char)counter_10ms_16bit;
	// --------------------------------------------------------------------------------
	// wait until data sent
	// -------------------------------------------------------------------------------- 
	do
		{
		#asm("wdr");	// Reset Watchdog
		data=DEVICE_WRITE_COMPLETE();
		if(data & (DEVICE_WRITE_COMPLETE_OK | DEVICE_WRITE_COMPLETE_ERROR))
			break;
		if(counter_10ms_old!=(unsigned char)counter_10ms_16bit)
			{
			counter_10ms_old=(unsigned char)counter_10ms_16bit;
			if(counter_10ms_delay>0)
				counter_10ms_delay--;
			else
				break;
			}
		}
	while(1);
	#ifdef WEB_DEBUG_BUFFER
	if(web_debug_flag & WEB_DEBUG_BUFFER_BIT)
		printf("BUFFER write complete: 0x%x %d0ms\r\n", data, 10-counter_10ms_delay); 
	#endif
	if(!(data & DEVICE_WRITE_COMPLETE_ERROR))
		{
		return 1;
		}
	}
return 0;
}