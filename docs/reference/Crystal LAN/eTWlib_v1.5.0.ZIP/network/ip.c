// ************************************************************************************************
///
/// \file 			ip.c
/// \brief			Internet protocol implementation
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// \par History
/// 				1.) 30.07.2003 Version 2.00a
///	 					a.)	- 
/// 				2.) 20.08.2004 Version 2.04
/// 					a.)	- function "ip_checksum()" calculate the correct checksum with 
/// 	            		    odd Bytes
/// 				3.) 05.10.2004 Version 2.06
/// 				a.)	- function "ip_header_write()" writes the IP_VER_IHL_TOS_OFS with 
///								IP_TOS_MIN_DELAY 
///						--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef IP_ENABLE

#include <stdio.h>
#include <string.h>
#include "device.h"
#include "buffer.h"
#include "ethernet.h"
#include "ip.h"
#include "icmp.h"
#include "util.h"
#ifdef TCP_ENABLE
#include "tcp.h"
#endif
#ifdef UDP_ENABLE
#include "udp.h"
#endif
#ifdef BOOTP_ENABLE
#include "bootp.h"
#endif
#ifdef IPSEC_ENABLE
#include "ipsec.h"
#endif	// #ifdef IPSEC_ENABLE
#ifdef WEB_DEBUG_MEASURE			// enable time-measure debug functions, see measure.c
#include "measure.h"
#endif
#ifdef WEB_DEBUG
#include "debug.h"
#include "web_debug.h"
#endif

#pragma regalloc-
IP_HEADER_STRUCTURE	ip_header;                                    	
unsigned char ip_of_last_frame[IP_ADR_SIZE];	// 32 bit IP
unsigned char ip_address[IP_ADR_SIZE] =  IP_DEFAULT;
unsigned char ip_subnet_mask[IP_ADR_SIZE] = IP_SUBMASK_DEFAULT;
unsigned char ip_gateway[IP_ADR_SIZE] =	IP_GATEWAY_DEFAULT;
#pragma regalloc+

#pragma regalloc-
//*********************************************************************************
// Description	: handles an incoming frame that passed CS8900's address filter
//              :  (individual addressed = IA)
// Input   		: broadcast_flag - signals wether a broascast is available
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void ip_process_frame(unsigned char broadcast_flag)
{
#ifdef WEB_DEBUG_IP
static  unsigned int ip_count=0;
#endif
IP_HEADER_STRUCTURE	*p_ip_header;                                    	

#ifdef WEB_DEBUG_MEASURE
measure_flag=1;			// flag to switch to a new TIME_FRAME
#endif
#ifdef WEB_DEBUG_IP
ip_count++;
#endif
#ifdef IPSEC_ENABLE
if(!ipsec_input_frame())
	return;
#endif	// #ifdef IPSEC_ENABLE
p_ip_header=&ip_header;
(unsigned int)p_ip_header->ver_ihl=DEVICE_READ_IP_FRAME_16BIT_LE(); 	// read IP-Version and Lenght
if((p_ip_header->ver_ihl & 0xFF ) == SWAPB(IP_VER_IHL))		// IPv4, IHL=5 (20 Bytes Header); ignore Type Of Service
//if((p_ip_header->ver_ihl & 0xFF ) == 0x45)				// IPv4, IHL=5 (20 Bytes Header); ignore Type Of Service
	{											 
	p_ip_header->length = DEVICE_READ_IP_FRAME_16BIT();	// get IP frame's length
	#ifdef WEB_DEBUG_IP
	if(web_debug_flag & WEB_DEBUG_IP_BIT)
		{
		printf("IP(%u) Read-FRAME: %ubyte", ip_count, p_ip_header->length);
		if(broadcast_flag)
			printf(" Broadcast");
		putsf("\r");
		}
	#endif
	p_ip_header->ident=DEVICE_READ_IP_FRAME_16BIT();				// read identification
	p_ip_header->flags_frag_offset=DEVICE_READ_IP_FRAME_16BIT();	// read Flags and Fragment-Info
	if(!(p_ip_header->flags_frag_offset & (IP_FLAG_MOREFRAG | IP_FRAGOFS_MASK))) // only unfragm. frames
		{
		p_ip_header->protocol = (unsigned char)DEVICE_READ_IP_FRAME_16BIT();	// get protocol, ignore TTL
		DEVICE_READ_IP_FRAME_16BIT();				   		   		// ignore checksum
		DEVICE_READ_IP_FRAME_DATA(ip_of_last_frame, IP_ADR_SIZE);	// get source IP
		memcpy(p_ip_header->source, ip_of_last_frame, IP_ADR_SIZE);
		DEVICE_READ_IP_FRAME_DATA(p_ip_header->destination, IP_ADR_SIZE);	// get destination IP
		if(broadcast_flag)
			{
			#ifdef BOOTP_ENABLE
			if(p_ip_header->protocol==IP_UDP_PROT)
				bootp_answer();
			#ifdef WEB_DEBUG_IP
			if(web_debug_flag & WEB_DEBUG_IP_BIT)
				{
				printf("IP(%u) ", ip_count); 
				debug_print_ip("Address", p_ip_header->destination);
				}
			#endif	// #ifdef WEB_DEBUG_IP
			#endif	// #ifdef BOOTP_ENABLE
			}
		else 
			if(!memcmp(p_ip_header->destination, &ip_address[0], sizeof(ip_address)))	// is it for us?
				{
				switch(p_ip_header->protocol)
					{
					#ifdef ICMP_ENABLE
					case IP_ICMP_PROT : 
						icmp_process_frame(); 
						break; 
					#endif	// #ifdef ICMP_ENABLE
					#ifdef TCP_ENABLE
					case IP_TCP_PROT  : 
						#ifdef WEB_DEBUG_MEASURE
						measure_flag=1;			// flag to switch to a new TIME_FRAME
						#endif
						tcp_process_frame(); 
						break;
					#endif	// #ifdef TCP_ENABLE
					#ifdef UDP_ENABLE
					case IP_UDP_PROT  : 
						udp_process_frame();
						break;
					#endif	// #ifdef UDP_ENABLE
					default:
						#ifdef WEB_DEBUG_IP
						if(web_debug_flag & WEB_DEBUG_IP_BIT)
							printf("IP(%u) Protocol unsupported: 0x%04x\r\n", ip_count, p_ip_header->protocol); 
						#endif
					}
				}
			else	// if(!memcmp(&ip_destination[0], &ip_address[0], sizeof(ip_address)))	// is it for us?
				{
				#ifdef WEB_DEBUG_IP
				if(web_debug_flag & WEB_DEBUG_IP_BIT)
					{
					printf("IP(%u) ", ip_count); 
					debug_print_ip("Address wrong", p_ip_header->destination);
					}
				#endif
				#ifdef BOOTP_ENABLE
				if(p_ip_header->protocol==IP_UDP_PROT)
					bootp_answer();
				#endif
				}
		}      
	else	// if (!(data & (IP_FLAG_MOREFRAG | IP_FRAGOFS_MASK))) // only unfragm. frames
		{
		#ifdef WEB_DEBUG_IP
		if(web_debug_flag & WEB_DEBUG_IP_BIT)
			printf("IP(%u) Frame fragment: %u\r\n", ip_count, (p_ip_header->flags_frag_offset & IP_FRAGOFS_MASK)*8); 
		#endif
		}
	}
else	// if((data & 0xFF00 ) == IP_VER_IHL)
	{
	#ifdef WEB_DEBUG_IP
	p_ip_header->length = DEVICE_READ_IP_FRAME_16BIT();	// get IP frame's length
	if(web_debug_flag & WEB_DEBUG_IP_BIT)
		printf("IP(%u) Typ wrong: 0x%02x (%ubyte)\r\n", ip_count, p_ip_header->ver_ihl, p_ip_header->length); 
	#endif
	}
}


//*********************************************************************************
// Description	: write a IP-Header to data
// Input   		: eth_data    - pointer to buffer
//         		: ip_length   - length of IP-Frame 
//         		: ip_offset   - offse of IP-Frame necesary together with IPSEC
//         		: ip_protocol -  kond of IP-Protocol (TCP, UDP and so on)
//         		: ip_source      - pointer to Source-IP-Address
//         		: ip_destination - pointer to Destination IP-Address
// Output  		: 1 - OK 
//         		: ipsec_output_frame(eth_data+ETH_HEADER_SIZE, ip_length, ip_offset) ???
// Indication	: easyToWeb internal function
//*********************************************************************************
unsigned char ip_header_write(unsigned char *eth_data, unsigned int *ip_length, unsigned char *ip_offset, 
							  unsigned char ip_protocol, unsigned char *ip_source, unsigned char *ip_destination)
{
static unsigned int ip_write_frame_counter=0;

*ip_offset=IPSEC_OFFSET;
*(unsigned int *)(eth_data+IP_VER_IHL_TOS_OFS) = SWAPB(IP_VER_IHL);
HOST_NETWORK_ENDIAN_16BIT(eth_data+IP_TOTAL_LENGTH_OFS, ip_length);
HOST_NETWORK_ENDIAN_16BIT(eth_data+IP_IDENT_OFS, &ip_write_frame_counter);
//*(unsigned int *)(eth_data+IP_IDENT_OFS) = 0;
*(unsigned int *)(eth_data+IP_FLAGS_FRAG_OFS) = SWAPB(IP_FLAG_DONTFRAG);
//*(unsigned int *)(eth_data+IP_FLAGS_FRAG_OFS) = 0;
*(eth_data+IP_TTL_OFS) = IP_DEFAULT_TTL;
*(eth_data+IP_PROTOCOL_OFS) = ip_protocol;
*(unsigned int *)(eth_data+IP_HEAD_CHKSUM_OFS) = 0;
memcpy(eth_data+IP_SOURCE_OFS, ip_source, IP_ADR_SIZE);
memcpy(eth_data+IP_DESTINATION_OFS, ip_destination, IP_ADR_SIZE);
*(unsigned int *)(eth_data+IP_HEAD_CHKSUM_OFS) = ip_checksum(eth_data+IP_HEADER_START_OFS, IP_HEADER_SIZE, 0);
ip_write_frame_counter++;
#ifdef IPSEC_ENABLE
return ipsec_output_frame(eth_data+ETH_HEADER_SIZE, ip_length, ip_offset);
#else
return 1;	// generell OK
#endif	// #ifdef IPSEC_ENABLE
}
#endif	// #ifdef IP_ENABLE


//*********************************************************************************
// Description	: calculates the IP, TCP and ICMP checksums 
// Input   		: data    - pointer to data
//         		: count   - size of data
//         		: tcp_ip_remote - pointer to IP-Address
//				:	 		tcp_ip_remote!=0: the TCP pseudo-header will be included.
// Output  		: IP-Checksum
// Indication	: easyToWeb internal function
//*********************************************************************************
unsigned int ip_checksum(void *data, unsigned int count, unsigned char *tcp_ip_remote)
{
unsigned long	sum = 0;
unsigned int 	*p_data;

p_data=data;
if(tcp_ip_remote)		// if we've a TCP frame...
	{
	#ifdef IP_ENABLE
	sum += ((unsigned int)ip_address[1]<<8) | ip_address[0];
	sum += ((unsigned int)ip_address[3]<<8) | ip_address[2];
	sum += ((unsigned int)tcp_ip_remote[1]<<8) | tcp_ip_remote[0];
	sum += ((unsigned int)tcp_ip_remote[3]<<8) | tcp_ip_remote[2];
	sum += SWAPB(IP_TCP_PROT);
	sum +=(count >> 8) | (count << 8);	// TCP header length plus data length (SwapBytes(Count))
	#endif	// #ifdef IP_ENABLE
	}
while(count > 1)
	{					// sum words
	sum += *p_data;
	p_data++;
	count -= 2;
	}
if(count)							// add left-over byte, if any
	sum += (*p_data) &  0x00FF;
while(sum >> 16)					// fold 32-bit sum to 16 bits
	sum = (sum & 0xFFFF) + (sum >> 16);
return (unsigned int)~sum;
}


//*********************************************************************************
// \brief		compares 2 ip addresses
// @param[in]	ip1 - pointer to ip-address
// @param[in]	ip2 - pointer to ip-address
// @retval		0 - not equal
// @retval		1 - equal
//*********************************************************************************
unsigned char ip_compare(unsigned char* ip1, unsigned char* ip2)
{
return !strncmp(ip1, ip2, 4);
}

//*********************************************************************************
// \brief		compares 2 ip addresses
// @param[in]	ip1 - pointer to ip-address
// @param[in]	ip2 - pointer to ip-address in flash memory
// @retval		0 - not equal
// @retval		1 - equal
//*********************************************************************************
unsigned char ip_comparef(unsigned char* ip1, unsigned char flash* ip2)
{
return !strncmpf(ip1, ip2, 4);
}