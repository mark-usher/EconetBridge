// ************************************************************************************************
///
/// \file 			device.c
/// \brief			Connects TCP/IP stack with device drivers
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// \par History
///					1.) 08.08.2003 Version 2.00
///					2.) 08.08.2003 Version 2.01
///						a.)	- new macro "EASYTOWEB_VERSION" replaced "SOFTWARE_VERSION";
///					3.) 12.11.2003 Version 2.02
///						a.)	- "DEVICE_PPP" supports now "DEVICE_READ_FRAME_16BIT_LE()";
///					4.) 12.01.2004 Version 2.03
///						a.)	- new IPSec device-functions
///					5.) 24.06.2004 Version 2.04
///						a.)	- new "DEVICE_WRITE_COMPLETE()" function - checks the 
///						--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef DEVICE_CS8900
#include "device.h"
unsigned char mac_address[6] =		// "MAC_DEFAULT_1-MAC_DEFAULT_2-MAC_DEFAULT_3-MAC_DEFAULT_4-MAC_DEFAULT_5-MAC_DEFAULT_6"
	{
	MAC_DEFAULT_1, MAC_DEFAULT_2, MAC_DEFAULT_3,	// Bit47..24 Hersteller MAC 
	MAC_DEFAULT_4, MAC_DEFAULT_5, MAC_DEFAULT_6		// Bit23..0 laufende Nummer MAC
	};
#endif