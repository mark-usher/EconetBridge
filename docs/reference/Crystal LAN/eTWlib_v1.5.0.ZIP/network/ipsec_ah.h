// ************************************************************************************************
///
/// \file 			ipsec_ah.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Copyright (C) 2001-2004
///					This document is part of embedded IPsec
///					Niklaus Schild and Christian Scheurer, HTI Biel/Bienne
///					This file contains code from the OpenSSL Project<BR>
///					Christian Scheurer <http://www.christianscheurer.ch>
///					portions Copyright (c) 1998-2003 OpenSSL (www.openssl.org)
///					easyToWeb-AVR and CodeVisionAVR C-Compiler:
///					Udo Jakobza - FTZ Leipzig; 04107 Leipzig; W�chterstr. 13
///					jakobza@e-technik.htwk-leipzig.de
///
/// \par License    
///					Redistribution and use in source and binary forms, with or without 
///					modification, are permitted provided that the following conditions are met:
///
///					1. Redistributions of source code must retain the above copyright notice,
///					   this list of conditions and the following disclaimer.
///					2. Redistributions in binary form must reproduce the above copyright notice,
///					    this list of conditions and the following disclaimer in the documentation
///					   and/or other materials provided with the distribution.
///					3. The name of the author may not be used to endorse or promote products
///					   derived from this software without specific prior written permission.
///
///					THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
///					WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
///					MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
///					EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
///					EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
///					OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
///					INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
///					CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
///					IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
///					OF SUCH DAMAGE.
///
// ************************************************************************************************

#ifndef _IPSEC_AH_INCLUDED_
#define _IPSEC_AH_INCLUDED_

#include "project.h"		// Project configuration

#include "ipsec_sa.h"

// --------------------------------------------------------------------------------
// Authentication Header (AH) Transport-Mode, see IPSEC buffer "ipsec_rx_buffer"
// -------------------------------------------------------------------------------- 
#define IPSEC_AH_NEXT_HEADER_OFS	20		// AH Next Header (8bit)
#define IPSEC_AH_PAYLOAD_LENGTH_OFS	21		// AH Payload Length (8bit)
#define IPSEC_AH_RESERVED_OFS		22		// AH Reserved (16bit)
#define IPSEC_AH_SPI_OFS			24		// AH Security Parameter Index - SPI (32bit)
#define IPSEC_AH_SEQUENCE_OFS		28		// AH Sequence Number (32bit)
#define IPSEC_AH_AUTH_DATA_OFS		32		// AH Authenticatioon Data (96bit - 12Byte)
#define IPSEC_AH_PAYLOAD_OFS		44		// AH Payload Data - User Data

#define IPSEC_AH_LENGTH				12		// Length of AH without any Authentication Data
#define IPSEC_AH_AUTH_DATA_SIZE		12		// Defines the authentication data length in bytes (12 bytes for 96bit keys)
#define IPSEC_AH_HEADER_SIZE		(IPSEC_AH_LENGTH+IPSEC_AH_AUTH_DATA_SIZE)	// AH Length SPI+Sequence+Auth Data

//  --------------------------------------------------------------------------------
//	AH-Authentication Header structure (RFC2402)
//  -------------------------------------------------------------------------------- 
typedef struct
	{
	unsigned char next_header;	// type of next payload (protocol nr)
	unsigned char length;		// type of service
	unsigned int reserved;		// MUST be 0x0000 (reserved for future use)
	unsigned long spi;			// Security Parameter Index (0, 1..255 are special cases RFC2402, p.4)
	unsigned long sequence;		// sequence number (increasing strictly), used by anti-replay feature
	unsigned char ah_data[IPSEC_AH_AUTH_DATA_SIZE]; // ICV (Integrity Check Value), variable-length data. 12 bytes (96 bits) for HMAC-SHA1-96 and HMAC-MD5-96
	} AH_HEADER_STRUCTURE;


//  --------------------------------------------------------------------------------
//	Intput IP-AH structure
//  -------------------------------------------------------------------------------- 
typedef struct
	{
	IP_HEADER_STRUCTURE	ip;
	AH_HEADER_STRUCTURE	ah;
	unsigned char data;			// only a position to calculate the payload of AH Packet
	} TRANS_TUNNEL_IN_IP_AH;

//  --------------------------------------------------------------------------------
//	Transport Output IP-AH structure
//  -------------------------------------------------------------------------------- 
typedef struct
	{
	unsigned char  	offset[IPSEC_OFFSET-sizeof(AH_HEADER_STRUCTURE)];
	IP_HEADER_STRUCTURE	ip;
	AH_HEADER_STRUCTURE	ah;
	unsigned char data;			// only a position to calculate the payload of AH Packet
	} TRANSPORT_OUT_IP_AH;

//  --------------------------------------------------------------------------------
//	Tunnel Output IP-AH-IP structure
//  -------------------------------------------------------------------------------- 
typedef struct
	{
	#if((IPSEC_OFFSET-IPSEC_AH_HEADER_SIZE-IP_HEADER_SIZE)>0)
	unsigned char  	offset[IPSEC_OFFSET-IPSEC_AH_HEADER_SIZE-IP_HEADER_SIZE];
	#else
	#endif
	IP_HEADER_STRUCTURE	ip_out;
	AH_HEADER_STRUCTURE	ah;
	IP_HEADER_STRUCTURE	ip_in;
	unsigned char data;			// only a position to calculate the payload of AH Packet
	} TUNNEL_OUT_IP_AH_IP;


#pragma used+
unsigned char ipsec_ah_input_frame(SA_MEMORY sad_entry_mem *sa, unsigned char *rx_data, 
										unsigned int *rx_length, unsigned char *ip_offset);
unsigned char ipsec_ah_output_frame(SA_MEMORY sad_entry_mem *sa, unsigned char *ip_data, 
									unsigned int *ip_size, unsigned char *ip_offset);
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library ipsec_ah.c
#endif

#endif	// #ifndef _IPSEC_AH_INCLUDED_