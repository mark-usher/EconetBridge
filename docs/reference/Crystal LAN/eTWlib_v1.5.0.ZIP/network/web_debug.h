// ************************************************************************************************
///
/// \file 			web_debug.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#ifndef _WEB_DEBUG_INCLUDED_
#define _WEB_DEBUG_INCLUDED_

#include "project.h"

#ifdef WEB_DEBUG

#ifndef DEBUG
#error  define "DEBUG", see project.h !!!
#endif

//-----------------------------------------------------------------------------
//	definitions to switch on/off the debug info's via runtime
//  ---------------------------------------------------------------------------
#define WEB_DEBUG_BUFFER_BIT		0x0001
#define WEB_DEBUG_ETHERNET_BIT		0x0002
#define WEB_DEBUG_ARP_RARP_BIT		0x0004
#define WEB_DEBUG_IP_BIT			0x0008
#define WEB_DEBUG_ICMP_BIT			0x0010
#define WEB_DEBUG_UDP_BIT			0x0020
#define WEB_DEBUG_BOOTP_BIT			0x0040
#define WEB_DEBUG_HTTP_BIT			0x0080
#define WEB_DEBUG_TFTP_BIT			0x0100


#pragma used+
extern eeprom unsigned int web_debug_flag;				// web debug flag to switch on/off debug infos

void web_debug_init(void);
#pragma used-


#ifdef NETWORK_LIBRARY_ENABLE
#pragma library web_debug.c
#endif

#endif		// #ifdef WEB_DEBUG
#endif		// #ifndef _WEB_DEBUG_INCLUDED_