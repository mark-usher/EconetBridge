// ************************************************************************************************
///
/// \file 			ppp.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Wolfgang Lutsch, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \addtogroup Network_Stack
/// @{
/// \defgroup PPP
/// \addtogroup PPP
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define IP_REMOTE_DEFAULT		{192, 168, 0, 13}
#define PPP_SERVER_CLIENT_MODE	PPP_SERVER
#define PPP_MRU					512		// the Maximum-Receive-Unit in bytes
#define PPP_MTU			 		512		// the Maximum-Transmit-Unit in bytes
#define AT_DEVICE_MODEM
#define AT_DEVICE_BLUETOOTH
//@}
#endif

///	\def IP_REMOTE_DEFAULT
///
/// \def PPP_SERVER_CLIENT_MODE
///
/// \def PPP_MRU
///
/// \def PPP_MTU
///
/// \def AT_DEVICE_MODEM
///
/// \def AT_DEVICE_BLUETOOTH
///

#ifndef _PPP_INCLUDED_
#define _PPP_INCLUDED_

//-----------------------------------------------------------------------------
// type of PPP-implementation see "ppp_behaviour"
//-----------------------------------------------------------------------------
#define PPP_SERVER 				1
#define PPP_CLIENT 				2

#ifndef PPP_SERVER_CLIENT_MODE
#define PPP_SERVER_CLIENT_MODE	PPP_SERVER
#endif

//-----------------------------------------------------------------------------
// reserve RAM space for transmit & receive buffers
//-----------------------------------------------------------------------------
#ifndef PPP_MRU
#define PPP_MRU					512		///< the Maximum-Receive-Unit in bytes
#endif
#ifndef PPP_MTU
#define PPP_MTU					512		///< the Maximum-Transmit-Unit in bytes
#endif
#define PPP_HDLC_HEADER			4		///< Address(1)+Control(1)+Protocol(2)-Field
#define PPP_HDLC_TRAILER		2		///< FCS(2)

#define PPP_RX_BUFFER_START		((unsigned char*)ppp_rx_buffer)
#define PPP_RX_BUFFER_END		((unsigned char*)ppp_rx_buffer+PPP_HDLC_HEADER+PPP_MRU+PPP_HDLC_TRAILER)
#define PPP_TX_BUFFER_START		((unsigned char*)ppp_tx_buffer)

//-----------------------------------------------------------------------------
// define table to locate several datapackets
//-----------------------------------------------------------------------------
#define PPP_MAX_DATA_PACKETS	3
typedef struct
	{
	unsigned char* addr; 
	unsigned int size;
	} PPP_BUFFER_TABLE;

//-----------------------------------------------------------------------------
// HDLC frame format offsets
//-----------------------------------------------------------------------------
#define PPP_ADDRESS_OFS						0
#define PPP_CONTROL_OFS						1
#define PPP_PROTOCOL_OFS					0
#define PPP_CODE_OFS						2
#define PPP_ID_OFS							3
#define PPP_LENGTH_OFS						4
#define PPP_OPTIONS_OFS						6
#define PPP_FLAG_SEQUENZE					0x7e
#define PPP_CONTROL_ESCAPE					0x7d
#define PPP_ADDRESS					   		0xff
#define PPP_CONTROL							0x03
#define PPP_CE_BIT							0x20	// exclusiv OR with data after PPP_CONTROL_ESCAPE

//-----------------------------------------------------------------------------
// LCP & IPCP packet codes
//-----------------------------------------------------------------------------
#define PPP_CONFIGURE_REQUEST				1
#define PPP_CONFIGURE_ACK					2
#define PPP_CONFIGURE_NAK					3
#define PPP_CONFIGURE_REJECT				4
#define PPP_TERMINATE_REQUEST				5
#define PPP_TERMINATE_ACK					6
#define PPP_CODE_REJECT						7
#define PPP_PROTOCOL_REJECT					8
#define PPP_ECHO_REQUEST					9
#define PPP_ECHO_REPLY						10
#define PPP_DISCARD_REQUEST					11

//-----------------------------------------------------------------------------
// LCP Negotiation Options
//-----------------------------------------------------------------------------
#define LCP_MAX_RECEIVE_UNIT				1
#define LCP_ACCM							2
#define LCP_AUTHENTICATION_TYPE				3
#define LCP_QUALITY_PROTOCOL				4	// not supported
#define LCP_MAGIC_NUMBER					5
#define LCP_LINK_QUALITY_MONITORING			6
#define LCP_PROTOCOL_FIELD_COMP				7
#define LCP_ADR_CTL_FIELD_COMP				8

#define LCP_MAX_RECEIVE_UNIT_LEN			4	// see LCP_MAX_RECEIVE_UNIT
#define LCP_ACCM_LEN						6	// see LCP_ACCM
#define LCP_AUTHENTICATION_TYPE_LEN	   		4	// see LCP_AUTHENTICATION_TYPE
#define LCP_QUALITY_PROTOCOL_LEN			4	// see LCP_QUALITY_PROTOCOL
#define LCP_MAGIC_NUMBER_LEN				6	// see LCP_MAGIC_NUMBER
#define LCP_LINK_QUALITY_MONITORING_LEN		6	// see LCP_LINK_QUALITY_MONITORING
#define LCP_PROTOCOL_FIELD_COMP_LEN			2	// see LCP_PROTOCOL_FIELD_COMP
#define LCP_ADR_CTL_FIELD_COMP_LEN			2	// see LCP_ADR_CTL_FIELD_COMP

#define LCP_OPTIONS_DATA_OFS				2

//-----------------------------------------------------------------------------
// IPCP Negotiation Options
//-----------------------------------------------------------------------------
#define IPCP_IP_ADR      			   		3
#define IPCP_GATEWAY_81    			   		0x81
#define IPCP_GATEWAY_82    			   		0x82
#define IPCP_GATEWAY_83   			   		0x83
#define IPCP_GATEWAY_84    			   		0x84

#define IPCP_IP_ADR_LEN		      	   		6

#define IPCP_OPTIONS_DATA_OFS				2

//-----------------------------------------------------------------------------
// variable ppp_status
//-----------------------------------------------------------------------------
#define PPP_STATUS_UP						0x01
#define PPP_STATUS_RX_DATA			   		0x02

//-----------------------------------------------------------------------------
// variable ppp_rx_flag
//-----------------------------------------------------------------------------
#define PPP_RX_FLAG_FAIL					0x0001
#define PPP_RX_FLAG_MRU						0x0002
#define PPP_RX_FLAG_ACCM					0x0004
#define PPP_RX_FLAG_AUTH	            	0x0008      // Authenticate
#define PPP_RX_FLAG_PFC						0x0010		// see also LCP_PROTOCOL_FIELD_COMP
#define PPP_RX_FLAG_ACFC					0x0020		// see also LCP_ADR_CTL_FIELD_COMP
#define PPP_RX_FLAG_GATEWAY81				0x0040
#define PPP_RX_FLAG_GATEWAY82				0x0080
#define PPP_RX_FLAG_GATEWAY83				0x0100
#define PPP_RX_FLAG_GATEWAY84				0x0200

//-----------------------------------------------------------------------------
// define the Option Negotiation Automaton State Machine
//-----------------------------------------------------------------------------
typedef enum	// according to RFC1661
	{
	PPP_STATE_INITIAL,
	PPP_STATE_STARTING,
	PPP_STATE_CLOSED,
	PPP_STATE_STOPPED,
	PPP_STATE_CLOSING,
	PPP_STATE_STOPPING,
	PPP_STATE_REQUEST_SENT,
	PPP_STATE_ACK_RECEIVED,
	PPP_STATE_ACK_SENT,
	PPP_STATE_OPENED,
	PPP_STATE_UNREACHED
	} PPP_STATE_LCP_IPCP;

//-----------------------------------------------------------------------------
// the EVENTS
//-----------------------------------------------------------------------------
typedef enum			// according to RFC1661
	{									
	PPP_EVENT_UP,		// lower layer is Up
	PPP_EVENT_DOWN,		// lower layer is Down
	PPP_EVENT_OPEN,		// administrative Open
	PPP_EVENT_CLOSE,	// administrative Close
	PPP_EVENT_TO,		// Timeout with counter > 0 (TO+)
	PPP_EVENT_TO_EX,	// Timeout with counter expired (TO-)
	PPP_EVENT_RCR,		// Receive-Configure-Request RCR+ (good)
	PPP_EVENT_RCR_BAD,	// Receive-Configure-Request RCR- (bad)
	PPP_EVENT_RCA,		// Receive-Configure-Ack
	PPP_EVENT_RCN,		// Receive-Configure-Nak/Rej
	PPP_EVENT_RTR,		// Receive-Terminate-Request
	PPP_EVENT_RTA,		// Receive-Terminate-Ack
	PPP_EVENT_RUC,		// Receive-Unknown-Code
	PPP_EVENT_RXJ,		// Receive-Code-Reject or Receive-Protocol-Reject RXJ+ (permitted)
	PPP_EVENT_RXJ_CAT,	// RXJ- (catastrophic)
	PPP_EVENT_RXR,		// Receive-Echo-Request or Receive-Echo-Reply or Receive-Discard-Request
	PPP_EVENT_NONE,		// no event occured
	PPP_EVENT_UNREACHED	// start event to debug state machine
	} PPP_EVENT_TYPE;

//-----------------------------------------------------------------------------
// the Protocol-Types recognized by this implementiation
//-----------------------------------------------------------------------------
typedef enum			// according to RFC1661
	{									
	PPP_PROTOCOL_LCP,	// Link-Control-Protocol
	PPP_PROTOCOL_PAP,	// Password-Authentication-Protocol
	PPP_PROTOCOL_IPCP,	// IP-Control-Protocol
	PPP_PROTOCOL_IP,	// Internet-Protocol
	PPP_PROTOCOL_UNKNOWN         
	} PPP_PROTOCOL_TYPE;


//-----------------------------------------------------------------------------
// and finally the PPP-Phases
//-----------------------------------------------------------------------------
typedef enum			// Point-to-Point Protcol Phase Diagram according to RFC1661
	{
	PPP_PHASE_DEAD,					
	PPP_PHASE_ESTABLISH,
	PPP_PHASE_AUTHENTICATE,
	PPP_PHASE_NETWORK,
	PPP_PHASE_TERMINATE,
	PPP_PHASE_UNREACHED		// new state to debug
	} PPP_PHASE;


//-----------------------------------------------------------------------------
// definitions for FCS computation
//-----------------------------------------------------------------------------
#define PPP_INIT_FCS16	0xffff		// Initial FCS value
#define PPP_GOOD_FCS16	0xf0b8		// Good final FCS value


//-----------------------------------------------------------------------------
// external variables and functions
//-----------------------------------------------------------------------------
#pragma used+
//void 			ppp_pap_account(flash unsigned char* user, flash unsigned char* pwd);
void			ppp_main(void);
unsigned char	ppp_init_interface(void);
unsigned char	ppp_interface_available(void);
unsigned char	ppp_data_available(void);
void 			ppp_data_clear(void);
void 			ppp_receive_data(unsigned char data);

//-----------------------------------------------------------------------------
//	functions to connect the device-interface
//-----------------------------------------------------------------------------
unsigned int	ppp_ready(void);
unsigned char	ppp_write_ready(unsigned int count);
unsigned char	ppp_write_data(unsigned char *data, unsigned int count);
unsigned int	ppp_read_frame_16bit(void);
unsigned int 	ppp_read_frame_16bit_le(void);
void 			ppp_read_frame_dummy(unsigned int size);
void 			ppp_read_frame(void *dest, unsigned int size);
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library ppp.c
#endif

#endif 	// #ifndef _PPP_INCLUDED_

/// @}
/// @}