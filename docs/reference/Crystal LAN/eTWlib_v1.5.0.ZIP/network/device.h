// ************************************************************************************************
///
/// \file 			device.h
/// \brief			Connects TCP/IP stack with device drivers
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _DEVICE_INCLUDED_
#define _DEVICE_INCLUDED_

#include "project.h"		// Project configuration
#ifdef DEVICE_PPP
#include "ppp.h"
#endif
#ifdef DEVICE_CS8900
#include "cs8900.h"
#endif
#ifdef IPSEC_ENABLE
#include "ipsec.h"
#endif

// --------------------------------------------------------------------------------
// internal default MAC-address
// -------------------------------------------------------------------------------- 
#ifndef	MAC_DEFAULT_1
#define	MAC_DEFAULT_1			0x00				// Bit47..40 manufacturer MAC 
#define	MAC_DEFAULT_2			0x50				// Bit39..32 manufacturer MAC
#define	MAC_DEFAULT_3			0xc2    			// Bit31..24 manufacturer MAC (HTWK Leipzig)
#define	MAC_DEFAULT_4			0x21    			// Bit23..16 running number MAC
#define	MAC_DEFAULT_5			0x10    			// Bit15..08 running number MAC
#define	MAC_DEFAULT_6			0x00    			// Bit07..00 running number MAC
#endif

// --------------------------------------------------------------------------------
// with IPSEC-Funktions
// -------------------------------------------------------------------------------- 
#ifdef IPSEC_ENABLE
#define DEVICE_READ_IP_FRAME_16BIT()			ipsec_read_frame_16bit()			// High-Byte on High-Address(High-Part of 16bit Integer)
#define DEVICE_READ_IP_FRAME_16BIT_LE()			ipsec_read_frame_16bit_le()			// High-Byte on Low-Address(Low-Part of 16bit Integer)
#define DEVICE_READ_IP_FRAME_DUMMY(size)		ipsec_read_frame_dummy(size)
#define DEVICE_READ_IP_FRAME_DATA(dest, size)	ipsec_read_frame(dest, size)
#else
#ifdef DEVICE_CS8900
#define DEVICE_READ_IP_FRAME_16BIT()			cs8900_read_io_reg16_be(IO_PORT_TX_RX)// High-Byte on High-Address(High-Part of 16bit Integer)
#define DEVICE_READ_IP_FRAME_16BIT_LE()			cs8900_read_io_reg16_le(IO_PORT_TX_RX)// High-Byte on Low-Address(Low-Part of 16bit Integer)
#define DEVICE_READ_IP_FRAME_DUMMY(size)	 	cs8900_read_dummyframe(size)
#define DEVICE_READ_IP_FRAME_DATA(dest, size)	cs8900_read_frame(dest, size)
#endif	// #ifdef DEVICE_CS8900
#ifdef DEVICE_PPP
#define DEVICE_READ_IP_FRAME_16BIT()			ppp_read_frame_16bit()				
#define DEVICE_READ_IP_FRAME_16BIT_LE()			ppp_read_frame_16bit_le()
#define DEVICE_READ_IP_FRAME_DUMMY(size)	 	ppp_read_frame_dummy(size)
#define DEVICE_READ_IP_FRAME_DATA(dest, size)	ppp_read_frame(dest, size)
#endif	// #ifdef DEVICE_PPP
#endif	// #ifdef IPSEC_ENABLE

// --------------------------------------------------------------------------------
// CS8900 10Mbit Ethernetcontroller
// -------------------------------------------------------------------------------- 
#ifdef DEVICE_CS8900
#define DEVICE_INIT()							cs8900_init()
#define DEVICE_READ_READY()						cs8900_read_packetpage16_le(CS8900_PP_RX_EVENT)
#define DEVICE_READ_FRAME_16BIT()	   			cs8900_read_io_reg16_be(IO_PORT_TX_RX)// High-Byte on High-Address(High-Part of 16bit Integer)
#define DEVICE_READ_FRAME_16BIT_LE()			cs8900_read_io_reg16_le(IO_PORT_TX_RX)// High-Byte on Low-Address(Low-Part of 16bit Integer)
#define DEVICE_READ_FRAME_DUMMY(size)			cs8900_read_dummyframe(size)
#define DEVICE_READ_FRAME_DATA(dest, size)		cs8900_read_frame(dest, size)
#define DEVICE_READ_FRAME_STATUS()				cs8900_read_io_reg16_HB1ST(IO_PORT_TX_RX)
#define DEVICE_RECEIVE_SKIP()					cs8900_rx_skip()
#define DEVICE_WRITE_FRAME_DATA(source, size)	cs8900_write_frame(source, size)
#define DEVICE_WRITE_READY(framesize)			cs8900_transmit_ready(framesize)
#define DEVICE_WRITE_COMPLETE()					cs8900_read_packetpage16_le(CS8900_PP_TX_EVENT)

#define	DEVICE_READ_READY_RECEIVE				RX_OK			// 0x0100
#define	DEVICE_READ_READY_FRAME					RX_IA		    // 0x0400
#define	DEVICE_READ_READY_BROADCAST				RX_BROADCAST	// 0x0800

#define	DEVICE_WRITE_COMPLETE_OK		  		TX_OK			// 0x0100
#define	DEVICE_WRITE_COMPLETE_ERROR				(TX_LATE_COL | TX_JBR | TX_16_COL)			// 0x8600
#endif	// #ifdef DEVICE_CS8900

// --------------------------------------------------------------------------------
// PPP-Interface to Ethernet-Protocolls
// -------------------------------------------------------------------------------- 
#ifdef DEVICE_PPP
#define DEVICE_INIT()							ppp_init_interface()		
#define DEVICE_READ_READY()						ppp_ready()
#define DEVICE_READ_FRAME_16BIT()		        ppp_read_frame_16bit()
#define DEVICE_READ_FRAME_16BIT_LE()			ppp_read_frame_16bit_le()
#define DEVICE_READ_FRAME_STATUS()				
#define DEVICE_READ_FRAME_DUMMY(size)			ppp_read_frame_dummy(size)
#define DEVICE_READ_FRAME_DATA(dest, size)	    ppp_read_frame(dest, size)
//#define DEVICE_RECEIVE_SKIP()					ppp_read_frame_dummy(8)
#define DEVICE_WRITE_FRAME_DATA(source, size)	ppp_write_data(source, size)
#define DEVICE_WRITE_READY(framesize)			ppp_write_ready(framesize)
#define DEVICE_WRITE_COMPLETE()					DEVICE_WRITE_COMPLETE_OK

#define	DEVICE_READ_READY_RECEIVE				0x0100
#define	DEVICE_READ_READY_FRAME					0x0400
#define	DEVICE_READ_READY_BROADCAST				0x0800

#define	DEVICE_WRITE_COMPLETE_OK		  		0x0100
#define	DEVICE_WRITE_COMPLETE_ERROR				0x8600
#endif	// #ifdef DEVICE_PPP

// --------------------------------------------------------------------------------
// general dummy definitions
// -------------------------------------------------------------------------------- 
#ifndef DEVICE_INIT()
#define DEVICE_INIT()						
#endif

#ifndef DEVICE_READ_READY()
#define DEVICE_READ_READY()						
#endif

#ifndef DEVICE_READ_FRAME_16BIT()
#define DEVICE_READ_FRAME_16BIT()						
#endif

#ifndef DEVICE_READ_FRAME_16BIT_LE()
#define DEVICE_READ_FRAME_16BIT_LE()						
#endif

#ifndef DEVICE_READ_FRAME_STATUS()
#define DEVICE_READ_FRAME_STATUS()						
#endif

#ifndef DEVICE_READ_FRAME_DUMMY()
#define DEVICE_READ_FRAME_DUMMY()						
#endif

#ifndef DEVICE_READ_FRAME_DATA()
#define DEVICE_READ_FRAME_DATA()						
#endif

#ifndef DEVICE_RECEIVE_SKIP()
#define DEVICE_RECEIVE_SKIP()						
#endif

#ifndef DEVICE_WRITE_FRAME_DATA()
#define DEVICE_WRITE_FRAME_DATA()						
#endif

#ifndef DEVICE_WRITE_READY(framesize)
#define DEVICE_WRITE_READY(framesize)						
#endif

#pragma used+
#ifdef DEVICE_CS8900
extern unsigned char mac_address[6];	// "MAC_DEFAULT_1-MAC_DEFAULT_2-MAC_DEFAULT_3-MAC_DEFAULT_4-MAC_DEFAULT_5-MAC_DEFAULT_6"
#endif
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library device.c
#endif

#endif		// #ifndef _DEVICE_INCLUDED_