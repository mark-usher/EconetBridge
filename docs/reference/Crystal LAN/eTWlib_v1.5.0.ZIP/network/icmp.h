// ************************************************************************************************
///
/// \file 			icmp.h
/// \brief			ICMP protocol
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// \par History
/// 				1.) 08.08.2003 Version 2.00
/// 				2.) 13.08.2003 Version 2.01
/// 					a.)	- new macro "ICMP_ENABLE", see project.h inside of project-path
/// 				3.) 11.02.2004 Version 2.03
/// 					a.)	- supports now Type: "ICMP_DEST_UNREACHABLE"
///						--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#ifndef _ICMP_INCLUDED_
#define _ICMP_INCLUDED_

#include "project.h"		// Project configuration

// --------------------------------------------------------------------------------
// ICMP general definitions
// -------------------------------------------------------------------------------- 
#define ICMP_TYPE_CODE_OFS	IP_DATA_OFS + 0     // type of message
#define ICMP_CHKSUM_OFS		IP_DATA_OFS + 2     // checksum of ICMP-message (16 bit)
#define ICMP_IDENT_OFS		IP_DATA_OFS + 4     // Identifier number (16bit)
#define ICMP_SEQ_OFS		IP_DATA_OFS + 6     // sequence number (16bit)
#define ICMP_HEADER_SIZE	8

#ifndef ICMP_DATA_SIZE
#define ICMP_DATA_SIZE		56	   				// Linux uses this size
#endif

// --------------------------------------------------------------------------------
// ICMP Echo definitions
// -------------------------------------------------------------------------------- 
#define ICMP_ECHO_DATA_OFS 				IP_DATA_OFS + 8     // start of data field (0x61, ...)

// --------------------------------------------------------------------------------
// ICMP Timestamp definitions
// -------------------------------------------------------------------------------- 
#define ICMP_TIMESTAMP_ORIGINATE_OFS	IP_DATA_OFS + 8		// Originat Timestamp
#define ICMP_TIMESTAMP_RECEIVE_OFS		IP_DATA_OFS + 12	// Receive Timestamp
#define ICMP_TIMESTAMP_TRANSMIT_OFS		IP_DATA_OFS + 16	// Transmit Timestamp
#define ICMP_TIMESTAMP_SIZE				20					// 8 (Header)+ 12(Timestamp)

// --------------------------------------------------------------------------------
// ICMP Typnumber
// -------------------------------------------------------------------------------- 
#define ICMP_ECHO_REPLY	 			0				// Echo reply
#define ICMP_DEST_UNREACHABLE		3				// Destination Unreachable
#define ICMP_ECHO_REQUEST			8				// Echo request
#define ICMP_TIMESTAMP_REQUEST		13				// Timestamp request
#define ICMP_TIMESTAMP_REPLY		14				// Timestamp reply

// --------------------------------------------------------------------------------
// general constant to handle ICMP-Timestamp, later inside of a system file
// -------------------------------------------------------------------------------- 
#define CLOCKS_PER_SEC	1000

//  --------------------------------------------------------------------------------
//	ICMP-Header structure
//  -------------------------------------------------------------------------------- 
typedef struct
	{
	unsigned char	type;
	unsigned char	code;
	unsigned int 	checksum;	// 
	unsigned int 	ident;		// only available with Ping
	unsigned int	seq;		// only available with Ping
	} ICMP_HEADER_STRUCTURE;


#pragma used+

void icmp_prepare_echo_reply(unsigned char *ip_remote, unsigned char *mac_remote, unsigned int icmp_ident, unsigned int icmp_seq);
void icmp_prepare_echo_request(unsigned char *ip_remote, unsigned char *mac_remote, unsigned char pattern);
void icmp_prepare_timestamp_request(unsigned char *ip_remote, unsigned char *mac_remote, unsigned long time);
void icmp_process_frame(void);
#pragma used-

#ifdef 	NETWORK_LIBRARY_ENABLE
#pragma library icmp.c
#endif

#endif	// #ifndef _ICMP_INCLUDED_

