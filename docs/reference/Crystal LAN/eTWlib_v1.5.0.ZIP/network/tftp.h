// ************************************************************************************************
///
/// \file 			tftp.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Daniel Matthes<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _TFTP_INCLUDED_
#define _TFTP_INCLUDED_

// --------------------------------------------------------------------------------
// TFTP layer definitions
// -------------------------------------------------------------------------------- 
#define TFTP_HEADER_SIZE		2

// --------------------------------------------------------------------------------
// TFTP opcode definitions
// -------------------------------------------------------------------------------- 
#define TFTP_RRQ				0x0001       		// Read request
#define TFTP_WRQ                0x0002              // Write request
#define TFTP_DATA		        0x0003				// data
#define TFTP_ACK                0x0004              // Acknowledgment
#define TFTP_ERROR              0x0005              // Error
#define TFTP_OACK				0x0006				// Option acknowledgment	

// --------------------------------------------------------------------------------
// TFTP error definitions
// -------------------------------------------------------------------------------- 
#define TFTP_ERROR_NOT_DEF		0x0000				// Not defined, see error message (if any).
#define TFTP_ERROR_FILE_NOT_FND 0x0001              // File not found.
#define TFTP_ERROR_ACC_VLTION   0x0002				// Access violation.
#define TFTP_ERROR_DISK_FULL    0x0003              // Disk full or allocation exceeded.
#define TFTP_ERROR_ILL_OP		0x0004             	// Illegal TFTP operation.
#define TFTP_ERROR_UNKNOWN_ID   0x0005				// Unknown transfer ID.
#define TFTP_ERROR_FILE_EXISTS  0x0006              // File already exists.
#define TFTP_ERROR_NO_USER		0x0007              // No such user.
#define TFTP_ERROR_TER_TRANS    0x0008              // Terminate transfer due to option negotiation

#pragma used+
extern unsigned char 	tftp_ok;					// flag to signal the actual status of TFTP
void tftp_main(void);
void tftp_init(void);
unsigned char tftp_ack(unsigned char udp_connection,  unsigned int block_number);
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library tftp.c
#endif

#endif	// #ifndef _TFTP_INCLUDED_