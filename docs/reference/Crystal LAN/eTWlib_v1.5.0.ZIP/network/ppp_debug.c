// ************************************************************************************************
///
/// \file 			ppp_debug.c
/// \brief			Debug functions for ppp.c
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Wolfgang Lutsch, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef PPP_DEBUG

#include <stdio.h>
#include <string.h>
#include <mega128.h>
#include "board.h"
#include "ppp_debug.h"
#include "ppp.h"
#include "device.h"
#include "debug.h"


#pragma regalloc-
//-----------------------------------------------------------------------------
// Debug variables
//-----------------------------------------------------------------------------
PPP_EVENT_TYPE		last_ppp_event;
unsigned int 		ppp_frame_count=0;
eeprom unsigned char ppp_debug_flag = 0x00;	// default: debug output off
#pragma regalloc+

// local prototypes
void ppp_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);


// ************************************************************************************************
/// \brief		Registers debug handler
///
// ************************************************************************************************
void ppp_debug_init(void)
{
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &ppp_debug_handler;
p_struct.id_string = "ppp";
debug_register_handler(&p_struct);
}


//********************************************************************************
// Description	: prints the change of Event-Command
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_debug_print_event_change(void)
{
if(last_ppp_event!=ppp_event)
	{
	printf("PPP(%u) Event: %p\r\n", ppp_frame_count, ppp_event_name[ppp_event]);
	last_ppp_event=ppp_event;
	}
}


// ************************************************************************************************
/// \brief	    command handler for debug commands
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void ppp_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{

if (mode == DEBUG_HANDLER_MODE_INFO)
	{
	printf("PPP_DEBUG");
	if (ppp_debug_flag)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
	#ifdef DEVICE_PPP
	putsf("DEVICE_PPP\r");
	#endif
	}
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
    // add output for 'help' command here
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
    {
	if (strncmpf(command, "ppp", 3)==0)
	    {
    	ppp_debug_flag ^= 0xFF;
    	if (ppp_debug_flag)
			putsf("ATI_DEBUG ON\r");
		else
			putsf("ATI_DEBUG OFF\r");
	    }
	}
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-close", 4)==0)
		ppp_event = PPP_EVENT_CLOSE; 
	else if (strncmpf(command, "-open", 3)==0)
		ppp_event = PPP_EVENT_OPEN;
	else if (strncmpf(command, "-server", 3)==0)
		{
		ppp_behaviour = PPP_SERVER;
		ppp_init();
		}
	else if (strncmpf(command, "-client", 4)==0)
		{
		ppp_behaviour = PPP_CLIENT;
		ppp_init();
		}
	}
}

#endif	// #ifdef PPP_DEBUG