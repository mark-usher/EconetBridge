// ************************************************************************************************
///
/// \file 			ppp.c
/// \brief			PPP interface, see RFC1661
///
/// 				Opens a serial point-to-point link via standardmodem @ 9600bps
///					and provides a SAP for a TCP/IP stack
///
/// \todo			Test interaction of PPP and AT-Interface
/// \todo			More testing is needed.
/// \todo			use crc module for FCS calculation (Frame Check Sequence)
///
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		Wolfgang Lutsch, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <stdio.h>
#include <string.h>
#include <delay.h>
#include "board.h"
#include "device.h"
#include "ati.h"
#include "ppp.h"
#include "ethernet.h"
#ifdef IP_ENABLE
#include "ip.h"
#endif	// #ifdef IP_ENABLE
#ifdef WEB_DEBUG
#include "debug.h"
#include "web_debug.h"
#include "ppp_debug.h"
#endif

#pragma regalloc-
//-----------------------------------------------------------------------------
// status register
//-----------------------------------------------------------------------------
unsigned int 		ppp_rx_flag;
unsigned char 		ppp_status;

PPP_STATE_LCP_IPCP	lcp_automaton_state;			// for LCP
PPP_STATE_LCP_IPCP	ipcp_automaton_state;			// for IPCP

PPP_EVENT_TYPE		ppp_event;
PPP_PROTOCOL_TYPE	ppp_protocol_type;
PPP_PHASE			ppp_phase;

unsigned char 		ppp_behaviour = PPP_SERVER_CLIENT_MODE;

//-----------------------------------------------------------------------------
// flag to handle the IP-Request inside of "ppp_eval_ipcp_packet" and "ppp_send_configure_nak_reject"
//-----------------------------------------------------------------------------
unsigned char		ppp_ip_request;		

//-----------------------------------------------------------------------------
// Receive Buffer
//-----------------------------------------------------------------------------
unsigned char		ppp_rx_buffer[PPP_HDLC_HEADER+PPP_MRU+PPP_HDLC_TRAILER];
unsigned int		ppp_rx_buffersize;
unsigned char*		p_ppp_rx_buffer;

PPP_BUFFER_TABLE	ppp_rx_table_buffer[PPP_MAX_DATA_PACKETS]; // structure to handle the data pointer and size of packets in side of ppp_rx_buffer
unsigned char 		ppp_rx_table_write_index;	// index to write a packet entry of "ppp_table_buffer"
unsigned char 		ppp_rx_table_read_index;	// index to read a packet entry of "ppp_table_buffer"

unsigned char 		ppp_rx_new_packet_count;	// flag to signal a new packet, a new entry in "ppp_table_buffer"
unsigned char*		p_ppp_new_packet;		// pointer to new packet
unsigned int 		ppp_new_packet_size;	// size of new packet
unsigned char*		p_ppp_new_packet_data;	// pointer to new packet data
unsigned char*		p_ppp_new_packet_option;// pointer to new packet options
//-----------------------------------------------------------------------------
// public interface to reiceived data
//-----------------------------------------------------------------------------
unsigned char*		p_ppp_rx_data_packet;			// pointer to RX-Data-Packet
unsigned int		ppp_rx_data_packet_size=0;		// contains size of RX-Data-Packet

//-----------------------------------------------------------------------------
// Transmit Buffer
//-----------------------------------------------------------------------------
unsigned char		ppp_tx_buffer[PPP_HDLC_HEADER+PPP_MTU+PPP_HDLC_TRAILER];
unsigned char*		p_ppp_act_tx_buffer;
unsigned int 		ppp_tx_buffer_size;

//-----------------------------------------------------------------------------
// LCP Configuration Options
//-----------------------------------------------------------------------------
unsigned char ppp_remote_configure_req_id;
unsigned char ppp_remote_terminate_req_id;
unsigned char ppp_remote_max_receive_unit[2];
unsigned char ppp_remote_accm[4];
unsigned char ppp_remote_magic_number[4];
unsigned char ppp_local_configure_request_id;
unsigned char ppp_local_terminate_request_id;
//-----------------------------------------------------------------------------
// IPCP Configuration Options
//-----------------------------------------------------------------------------
unsigned char ppp_remote_ip[4];
unsigned char ppp_local_ip[4];
unsigned char ppp_gateway_81[4];
unsigned char ppp_gateway_82[4];
unsigned char ppp_gateway_83[4];
unsigned char ppp_gateway_84[4];
//-----------------------------------------------------------------------------
// PAP PeerID & Password
//-----------------------------------------------------------------------------
unsigned char peer_id[10];
unsigned char peer_id_length;
unsigned char password[10];
unsigned char password_length;
#pragma regalloc+

void ppp_init(void);
//-----------------------------------------------------------------------------
// the ACTIONS
//-----------------------------------------------------------------------------
void ppp_this_layer_up(void);						// tlu
void ppp_this_layer_down(void);						// tld
void ppp_this_layer_started(void);					// tls
void ppp_this_layer_finished(void);					// tlf
void ppp_initialize_restart_count(void); 			// irc
void ppp_zero_restart_count(void);					// zrc
void ppp_illegal_transition(void);		 			// illegal

void ppp_send_configure_request(PPP_PROTOCOL_TYPE prot);		// scr
void ppp_send_configure_ack(PPP_PROTOCOL_TYPE prot);			// sca
void ppp_send_configure_nak_reject(PPP_PROTOCOL_TYPE prot);		// scn
void ppp_send_terminate_req(void);						// str
void ppp_send_terminate_ack(void);						// sta
void ppp_send_code_reject(void);						// scj
void ppp_send_echo_reply(void);						// ser
void ppp_send_authenticate_request(void);

void ppp_packet_header(unsigned char packet_format, unsigned char id);
void ppp_transmit_buffer(unsigned char *pointer, unsigned int size);

void ppp_eval_rx_packet(void);
void ppp_eval_lcp_packet(void);
void ppp_disable_local_options(void);
void ppp_eval_pap_packet(void);
void ppp_eval_ipcp_packet(void);

//-----------------------------------------------------------------------------
// functions for processing the protocols
//-----------------------------------------------------------------------------
void ppp_lcp_process(void);
void ppp_ipcp_process(void);
void ppp_pap_process(void);

//-----------------------------------------------------------------------------
// definitions for FCS computation
//-----------------------------------------------------------------------------
unsigned int ppp_fcs16(unsigned int fcs, unsigned char* cp, unsigned int len);
flash unsigned int fcstab[256]={0x0000, 0x1189, 0x2312, 0x329b, 0x4624, 0x57ad, 0x6536, 0x74bf,
								0x8c48, 0x9dc1, 0xaf5a, 0xbed3, 0xca6c, 0xdbe5, 0xe97e, 0xf8f7,
								0x1081, 0x0108, 0x3393, 0x221a, 0x56a5, 0x472c, 0x75b7, 0x643e,
								0x9cc9, 0x8d40, 0xbfdb, 0xae52, 0xdaed, 0xcb64, 0xf9ff, 0xe876,
								0x2102, 0x308b, 0x0210, 0x1399, 0x6726, 0x76af, 0x4434, 0x55bd,
								0xad4a, 0xbcc3, 0x8e58, 0x9fd1, 0xeb6e, 0xfae7, 0xc87c, 0xd9f5,
								0x3183, 0x200a, 0x1291, 0x0318, 0x77a7, 0x662e, 0x54b5, 0x453c,
								0xbdcb, 0xac42, 0x9ed9, 0x8f50, 0xfbef, 0xea66, 0xd8fd, 0xc974,
								0x4204, 0x538d, 0x6116, 0x709f, 0x0420, 0x15a9, 0x2732, 0x36bb,
								0xce4c, 0xdfc5, 0xed5e, 0xfcd7, 0x8868, 0x99e1, 0xab7a, 0xbaf3,
								0x5285, 0x430c, 0x7197, 0x601e, 0x14a1, 0x0528, 0x37b3, 0x263a,
								0xdecd, 0xcf44, 0xfddf, 0xec56, 0x98e9, 0x8960, 0xbbfb, 0xaa72,
								0x6306, 0x728f, 0x4014, 0x519d, 0x2522, 0x34ab, 0x0630, 0x17b9,
								0xef4e, 0xfec7, 0xcc5c, 0xddd5, 0xa96a, 0xb8e3, 0x8a78, 0x9bf1,
								0x7387, 0x620e, 0x5095, 0x411c, 0x35a3, 0x242a, 0x16b1, 0x0738,
								0xffcf, 0xee46, 0xdcdd, 0xcd54, 0xb9eb, 0xa862, 0x9af9, 0x8b70,
								0x8408, 0x9581, 0xa71a, 0xb693, 0xc22c, 0xd3a5, 0xe13e, 0xf0b7,
								0x0840, 0x19c9, 0x2b52, 0x3adb, 0x4e64, 0x5fed, 0x6d76, 0x7cff,
								0x9489, 0x8500, 0xb79b, 0xa612, 0xd2ad, 0xc324, 0xf1bf, 0xe036,
								0x18c1, 0x0948, 0x3bd3, 0x2a5a, 0x5ee5, 0x4f6c, 0x7df7, 0x6c7e,
								0xa50a, 0xb483, 0x8618, 0x9791, 0xe32e, 0xf2a7, 0xc03c, 0xd1b5,
								0x2942, 0x38cb, 0x0a50, 0x1bd9, 0x6f66, 0x7eef, 0x4c74, 0x5dfd,
								0xb58b, 0xa402, 0x9699, 0x8710, 0xf3af, 0xe226, 0xd0bd, 0xc134,
								0x39c3, 0x284a, 0x1ad1, 0x0b58, 0x7fe7, 0x6e6e, 0x5cf5, 0x4d7c,
								0xc60c, 0xd785, 0xe51e, 0xf497, 0x8028, 0x91a1, 0xa33a, 0xb2b3,
								0x4a44, 0x5bcd, 0x6956, 0x78df, 0x0c60, 0x1de9, 0x2f72, 0x3efb,
								0xd68d, 0xc704, 0xf59f, 0xe416, 0x90a9, 0x8120, 0xb3bb, 0xa232,
								0x5ac5, 0x4b4c, 0x79d7, 0x685e, 0x1ce1, 0x0d68, 0x3ff3, 0x2e7a,
								0xe70e, 0xf687, 0xc41c, 0xd595, 0xa12a, 0xb0a3, 0x8238, 0x93b1,
								0x6b46, 0x7acf, 0x4854, 0x59dd, 0x2d62, 0x3ceb, 0x0e70, 0x1ff9,
								0xf78f, 0xe606, 0xd49d, 0xc514, 0xb1ab, 0xa022, 0x92b9, 0x8330,
								0x7bc7, 0x6a4e, 0x58d5, 0x495c, 0x3de3, 0x2c6a, 0x1ef1, 0x0f78};


/*
//*********************************************************************************
// Description	: prepares user-name and password
// Input	   	: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_pap_account(flash unsigned char* user, flash unsigned char* pwd)
{
strcpyf(peer_id, user); 
strcpyf(password, pwd); 
}
*/

#ifdef PPP_DEBUG
char flash *ppp_phase_name[6]={
				"DEAD", "ESTABLISH", "AUTHENTICATE", "NETWORK",
				"TERMINATE", "UNREACHED"};
char flash *ppp_state_name[11]={
				"INITIAL", "STARTING", "CLOSED", "STOPPED",
				"CLOSING", "STOPPING", "REQUEST_SENT", "ACK_RECEIVED",
				"ACK_SENT", "ACK_OPENED","UNREACHED"};
char flash *ppp_event_name[18]={
				"UP", "DOWN", "OPEN", "CLOSE",
				"TO+", "TO-", "RCR+", "RCR-",
				"RCA", "RCN", "RTR", "RTA",
				"RUC", "RXJ+", "RXJ-", "RXR",
				"NONE", "UNREACHED"};
#endif

//*********************************************************************************
// Description	: Service Data Unit 
// Input	   	: none
// Output  		: none
// Indication	: must be called from user program periodically (the often - the better)
//                handles PPP-connnection
//*********************************************************************************
void ppp_main(void)
{
#ifdef PPP_DEBUG
static PPP_PHASE			last_ppp_phase=PPP_PHASE_UNREACHED;
static PPP_STATE_LCP_IPCP   last_ipcp_auto_state=PPP_STATE_UNREACHED;
static PPP_STATE_LCP_IPCP   last_lcp_auto_state=PPP_STATE_UNREACHED;
#endif

#if defined(AT_DEVICE_MODEM) || defined(AT_DEVICE_BLUETOOTH)
ati_state_machine();
#endif
switch(ppp_phase)
	{
	//-------------------------------------------------------------------------------------------------------
	case PPP_PHASE_DEAD: 	// Dead-Phase
	if(ppp_event==PPP_EVENT_OPEN)
	  	{
		ppp_event=PPP_EVENT_NONE;					// EventReg zur�cksetzen
		lcp_automaton_state = PPP_STATE_STARTING;	// Open-Event veranlasst Initial->Starting �bergang
		#if defined(AT_DEVICE_MODEM) || defined(AT_DEVICE_BLUETOOTH)
		switch(ati_get_device_mode(ATI_ANSWER_HIDE))
			{
			case ATI_MODE_ONLINE_ENTERING:
					lcp_automaton_state = PPP_STATE_INITIAL;
					ppp_event = PPP_EVENT_OPEN;
					break;
			case ATI_MODE_ONLINE:	
					ppp_event = PPP_EVENT_UP;
					break;      
			default:
					ppp_event = PPP_EVENT_DOWN;
			}
		#endif	// #if defined(AT_DEVICE_MODEM) || defined(AT_DEVICE_BLUETOOTH)
		switch(ppp_event)
			{
			case PPP_EVENT_DOWN:
				ppp_init();
			    break;
			case PPP_EVENT_UP:
			    ppp_phase = PPP_PHASE_ESTABLISH;
			    break;
			}
		}
		break;
	//-------------------------------------------------------------------------------------------------------
	case PPP_PHASE_ESTABLISH:	//	Establish-Phase		
		if(ppp_rx_flag & PPP_RX_FLAG_FAIL)
			{
			ppp_rx_flag &= ~PPP_RX_FLAG_FAIL;
			ppp_init();
			ppp_phase = PPP_PHASE_DEAD;
			}
		else
			{
			if(lcp_automaton_state!=PPP_STATE_OPENED)
				{
				ppp_lcp_process();
				ppp_event = PPP_EVENT_NONE;
				if(ppp_rx_new_packet_count > 0)		// wenn ein Datenpacket empfangen wurde
					{		
					ppp_eval_rx_packet();			// wird es ausgewertet
					if(ppp_protocol_type!=PPP_PROTOCOL_LCP)		// Events der Auswertung werden zur�ckgesetzt
						ppp_event = PPP_EVENT_NONE;	// falls es sich nicht um ein LCP packet gehandelt hat
					}
				}
			else if(lcp_automaton_state==PPP_STATE_OPENED)
				{
				if(ppp_rx_flag & PPP_RX_FLAG_AUTH)
					{
					ppp_phase = PPP_PHASE_AUTHENTICATE;
					ppp_event = PPP_EVENT_NONE;
					}
				else
					{
					ipcp_automaton_state = PPP_STATE_STARTING;
					ppp_phase = PPP_PHASE_NETWORK;
					ppp_event = PPP_EVENT_UP;
					}// end if(ppp_rx_flag & PPP_RX_FLAG_AUTH)
				}// end if(lcp_automaton_state!=PPP_STATE_OPENED)
			}// end if(ppp_rx_flag & PPP_RX_FLAG_FAIL)
		break;
	//-------------------------------------------------------------------------------------------------------
	case PPP_PHASE_AUTHENTICATE: //	Authenticate-Phase
		while((ppp_event!=PPP_EVENT_UP)&!(ppp_rx_flag & PPP_RX_FLAG_FAIL))
			{
			ppp_pap_process();
			if(ppp_rx_new_packet_count > 0)
				{		// wenn ein Datenpacket empfangen wurde
				ppp_eval_rx_packet();			// wird es ausgewertet
				if(ppp_protocol_type==PPP_PROTOCOL_LCP)
					{
					ppp_lcp_process();
					ppp_event=PPP_EVENT_NONE;
					}
				}
			}
		if(ppp_rx_flag & PPP_RX_FLAG_FAIL)
			{
			ppp_rx_flag &= ~PPP_RX_FLAG_FAIL;
			ppp_event = PPP_EVENT_CLOSE;
			ppp_phase = PPP_PHASE_TERMINATE;
			}
		else if(ppp_event==PPP_EVENT_UP)
			{
			ipcp_automaton_state = PPP_STATE_STARTING;
			ppp_phase = PPP_PHASE_NETWORK;
			}
		break;
	//-------------------------------------------------------------------------------------------------------
	case PPP_PHASE_NETWORK:	//	Network-Phase
		if((ppp_event==PPP_EVENT_CLOSE)||(ppp_rx_flag & PPP_RX_FLAG_FAIL))
			{
			ppp_phase = PPP_PHASE_TERMINATE;
			ppp_event = PPP_EVENT_CLOSE;
			}
		else
			{
			ppp_ipcp_process();
			ppp_event = PPP_EVENT_NONE;
			if(ppp_rx_new_packet_count > 0)
				{
				ppp_eval_rx_packet();
				if(ppp_protocol_type==PPP_PROTOCOL_LCP)
					{
					ppp_lcp_process();
					if(ppp_event==PPP_EVENT_RCR || ppp_event==PPP_EVENT_RCR_BAD)
						{
						ppp_phase = PPP_PHASE_ESTABLISH;
						ipcp_automaton_state = PPP_STATE_INITIAL;
						}
					else
						{
						if(ppp_event==PPP_EVENT_RTR)
							ppp_phase = PPP_PHASE_TERMINATE;
						else
							ppp_event = PPP_EVENT_NONE;
						}
					}
				}	// if(ppp_rx_new_packet_count > 0)
			}
		break;
	//-------------------------------------------------------------------------------------------------------
	case PPP_PHASE_TERMINATE:	//	Terminate-Phase
	    if(ppp_event==PPP_EVENT_CLOSE)
	    	{          // aktive Trennung der Verbindung
			while((ppp_event!=PPP_EVENT_RTA)&!(ppp_rx_flag & PPP_RX_FLAG_FAIL))
				{
				ppp_lcp_process(); // TerminateRequest versenden
				if(ppp_rx_new_packet_count > 0)
					{
					ppp_eval_rx_packet();	
					if(ppp_protocol_type!=PPP_PROTOCOL_LCP)
						ppp_event=PPP_EVENT_NONE;
					}
				}
		    } //end if(ppp_event)
		#if defined(AT_DEVICE_MODEM) || defined(AT_DEVICE_BLUETOOTH)
		ati_disconnect();
		#endif	// #if defined(AT_DEVICE_MODEM) || defined(AT_DEVICE_BLUETOOTH)
		ppp_init();
		#ifdef PPP_DEBUG
		if (ppp_debug_flag)
			putsf("PPP connection closed\r");
		#endif
		break;
	} //switch(ppp_phase)
#ifdef PPP_DEBUG
if (ppp_debug_flag)
	{
	if(last_ppp_phase!=ppp_phase)
		{
		printf("PPP(%u) Phase: %p\r\n", ppp_frame_count, ppp_phase_name[ppp_phase]);
		last_ppp_phase=ppp_phase;
		}
	if(last_ipcp_auto_state!=ipcp_automaton_state)
		{
		printf("PPP(%u) IPCP-State: %p\r\n", ppp_frame_count, ppp_state_name[ipcp_automaton_state]);
		last_ipcp_auto_state=ipcp_automaton_state;
		}
	if(last_lcp_auto_state!=lcp_automaton_state)
		{
		printf("PPP(%u) LCP-State: %p\r\n", ppp_frame_count, ppp_state_name[lcp_automaton_state]);
		last_lcp_auto_state=lcp_automaton_state;
		}
	ppp_debug_print_event_change();
	}
#endif	// #ifdef PPP_DEBUG
} //end main()


//*********************************************************************************
// Description	: init the PPP-functions
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_init(void)
{
unsigned char i;

#ifdef PPP_DEBUG
ppp_debug_init();
#endif

switch(ppp_behaviour)
	{
	case PPP_SERVER:
		ppp_phase = PPP_PHASE_ESTABLISH;
		lcp_automaton_state = PPP_STATE_STOPPED;
		#ifdef PPP_DEBUG
		if (ppp_debug_flag)
			putsf("PPP SERVER Mode waiting for incoming connection request ..\r");
		#endif
		break;
	case PPP_CLIENT:
		ppp_phase = PPP_PHASE_DEAD;
		lcp_automaton_state = PPP_STATE_INITIAL;
		#ifdef PPP_DEBUG
		if (ppp_debug_flag)
			putsf("PPP CLIENT Mode\r");
		#endif
		break;
	}
ipcp_automaton_state = PPP_STATE_INITIAL;
ppp_event = PPP_EVENT_NONE;
ppp_status = 0;
p_ppp_rx_buffer = PPP_RX_BUFFER_START;
ppp_rx_buffersize = 0;
p_ppp_act_tx_buffer = PPP_TX_BUFFER_START;
ppp_tx_buffer_size = 0;
ppp_rx_table_write_index = 0;
ppp_rx_table_read_index = 0;
ppp_rx_new_packet_count = 0;
ppp_rx_flag = PPP_RX_FLAG_MRU+PPP_RX_FLAG_ACCM+PPP_RX_FLAG_PFC+PPP_RX_FLAG_ACFC+
					PPP_RX_FLAG_GATEWAY81+PPP_RX_FLAG_GATEWAY82+PPP_RX_FLAG_GATEWAY83+PPP_RX_FLAG_GATEWAY84;
ppp_local_configure_request_id = 1;
ppp_local_terminate_request_id = 1;
for(i=0; i<4; i++)
	{
	ppp_remote_ip[i]=0; 
	ppp_local_ip[i]=0;
	ppp_gateway_81[i]=0; 
	ppp_gateway_82[i]=0; 
	ppp_gateway_83[i]=0; 
	ppp_gateway_84[i]=0;
	}
#ifdef IP_ENABLE
memcpy(&ppp_local_ip[0], &ip_address[0], sizeof(ppp_local_ip));	// init Local IP
#endif	// #ifdef IP_ENABLE
ppp_rx_data_packet_size=0;		// contains size of RX-Data-Packet
}

//*********************************************************************************
// Description	: init the PPP-functions + Modem- or Bluetooth-Interface
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
unsigned char ppp_init_interface(void)
{
#if defined(AT_DEVICE_MODEM) || defined(AT_DEVICE_BLUETOOTH)
ati_init();
#endif
ppp_init();
return 1;
}


//*********************************************************************************
// Description	: Option Negotiation Automaton for Link-Control-Protocol
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_lcp_process(void)
{
switch(ppp_event)	// which event occured?
	{
	case PPP_EVENT_UP:	// lower layer is Up
		switch(lcp_automaton_state)
			{
			case PPP_STATE_INITIAL:
				lcp_automaton_state = PPP_STATE_CLOSED; break;
			case PPP_STATE_STARTING:
				ppp_initialize_restart_count();
				ppp_send_configure_request(PPP_PROTOCOL_LCP);
				lcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			default: ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_DOWN:	// lower layer is Down
		switch(lcp_automaton_state)
			{
			case PPP_STATE_STOPPED:	ppp_this_layer_started(); break;
			case PPP_STATE_OPENED:	ppp_this_layer_down(); break;
			}
		if(lcp_automaton_state==PPP_STATE_CLOSED || lcp_automaton_state==PPP_STATE_CLOSING)
			{
			lcp_automaton_state = PPP_STATE_INITIAL;
			}
		else if((lcp_automaton_state==PPP_STATE_STOPPED)||
		        (lcp_automaton_state==PPP_STATE_STOPPING)||
		        (lcp_automaton_state==PPP_STATE_REQUEST_SENT)||
		        (lcp_automaton_state==PPP_STATE_ACK_RECEIVED)||
		        (lcp_automaton_state==PPP_STATE_ACK_SENT)||
		        (lcp_automaton_state==PPP_STATE_OPENED))
			{
			lcp_automaton_state = PPP_STATE_STARTING;
			}
		else
			{
			ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_OPEN:	// administrative Open
		switch(lcp_automaton_state)
			{
			case PPP_STATE_INITIAL:
				ppp_this_layer_started();
				lcp_automaton_state = PPP_STATE_STARTING; break;
			case PPP_STATE_CLOSED:
				ppp_initialize_restart_count();
				ppp_send_configure_request(PPP_PROTOCOL_LCP);
				lcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			case PPP_STATE_CLOSING: lcp_automaton_state = PPP_STATE_STOPPING; break;
			}
		break;
	case PPP_EVENT_CLOSE:	// administrative Close
		if(lcp_automaton_state==PPP_STATE_STARTING)
			{
			ppp_this_layer_finished();
			lcp_automaton_state = PPP_STATE_INITIAL;
			}
		else if (lcp_automaton_state==PPP_STATE_STOPPED)
			{
			lcp_automaton_state = PPP_STATE_CLOSED;
			}
		else if (lcp_automaton_state==PPP_STATE_STOPPING || 
		         lcp_automaton_state==PPP_STATE_REQUEST_SENT || 
		         lcp_automaton_state==PPP_STATE_ACK_RECEIVED || 
		         lcp_automaton_state==PPP_STATE_ACK_SENT || 
		         lcp_automaton_state==PPP_STATE_OPENED)
			{
			if(lcp_automaton_state==PPP_STATE_OPENED) ppp_this_layer_down();
			if(lcp_automaton_state==PPP_STATE_REQUEST_SENT || 
			   lcp_automaton_state==PPP_STATE_ACK_RECEIVED || 
			   lcp_automaton_state==PPP_STATE_ACK_SENT || 
			   lcp_automaton_state==PPP_STATE_OPENED)
				{
				ppp_initialize_restart_count();
				ppp_send_terminate_req();
				}
			lcp_automaton_state = PPP_STATE_CLOSING;
			}
		break;
	case PPP_EVENT_TO:	// Timeout with counter > 0
		if(lcp_automaton_state==PPP_STATE_CLOSING || lcp_automaton_state==PPP_STATE_STOPPING)
			{
			ppp_send_terminate_req();
			}
		else if(lcp_automaton_state==PPP_STATE_REQUEST_SENT || 
		        lcp_automaton_state==PPP_STATE_ACK_RECEIVED || 
		        lcp_automaton_state==PPP_STATE_ACK_SENT)
			{
			ppp_send_configure_request(PPP_PROTOCOL_LCP);
			if(lcp_automaton_state==PPP_STATE_ACK_RECEIVED) 
				lcp_automaton_state = PPP_STATE_REQUEST_SENT;
			}
		else
			{
			ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_TO_EX:	// Timeout with counter expired
		if(lcp_automaton_state==PPP_STATE_CLOSING || 
		   lcp_automaton_state==PPP_STATE_STOPPING || 
		   lcp_automaton_state==PPP_STATE_REQUEST_SENT || 
		   lcp_automaton_state==PPP_STATE_ACK_RECEIVED || 
		   lcp_automaton_state==PPP_STATE_ACK_SENT)
			{
			ppp_this_layer_finished();
			if(lcp_automaton_state==PPP_STATE_CLOSING)
				{
				lcp_automaton_state = PPP_STATE_CLOSED;
				}
			else
				{
				lcp_automaton_state = PPP_STATE_STOPPED;
				}
			}
		else
			{
			ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RCR:	// Receive-Configure-Request (good)
		switch(lcp_automaton_state)
			{
			case PPP_STATE_CLOSED: ppp_send_terminate_ack(); break;
			case PPP_STATE_STOPPED:
				ppp_initialize_restart_count();
				ppp_send_configure_request(PPP_PROTOCOL_LCP);
				ppp_send_configure_ack(PPP_PROTOCOL_LCP);
				lcp_automaton_state = PPP_STATE_ACK_SENT; break;
			case PPP_STATE_CLOSING: break;
			case PPP_STATE_STOPPING: break;
			case PPP_STATE_REQUEST_SENT:
				ppp_send_configure_ack(PPP_PROTOCOL_LCP);
				lcp_automaton_state = PPP_STATE_ACK_SENT; break;
			case PPP_STATE_ACK_RECEIVED:
				ppp_send_configure_ack(PPP_PROTOCOL_LCP);
				//ppp_this_layer_up();
				lcp_automaton_state = PPP_STATE_OPENED; break;
			case PPP_STATE_ACK_SENT:
				ppp_send_configure_ack(PPP_PROTOCOL_LCP); break;
			case PPP_STATE_OPENED:
				ppp_this_layer_down();
				ppp_send_configure_request(PPP_PROTOCOL_LCP);
				ppp_send_configure_ack(PPP_PROTOCOL_LCP);
				lcp_automaton_state = PPP_STATE_ACK_SENT; break;
			default:
				ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RCR_BAD:	// Receive-Configure-Request (bad)
		switch(lcp_automaton_state)
			{
			case PPP_STATE_CLOSED: ppp_send_terminate_ack(); break;
			case PPP_STATE_STOPPED:
				ppp_initialize_restart_count();
				ppp_send_configure_request(PPP_PROTOCOL_LCP);
				ppp_send_configure_nak_reject(PPP_PROTOCOL_LCP);
				lcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			case PPP_STATE_CLOSING: break;
			case PPP_STATE_STOPPING: break;
			case PPP_STATE_REQUEST_SENT:
				ppp_send_configure_nak_reject(PPP_PROTOCOL_LCP); break;
			case PPP_STATE_ACK_RECEIVED:
				ppp_send_configure_nak_reject(PPP_PROTOCOL_LCP); break;
			case PPP_STATE_ACK_SENT:
				ppp_send_configure_nak_reject(PPP_PROTOCOL_LCP);
				lcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			case PPP_STATE_OPENED:
				ppp_this_layer_down();
				ppp_send_configure_request(PPP_PROTOCOL_LCP);
				ppp_send_configure_nak_reject(PPP_PROTOCOL_LCP);
				lcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			default:
				ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RCA:	// Receive-Configure-Ack
		switch(lcp_automaton_state)
			{
			case PPP_STATE_CLOSED: ppp_send_terminate_ack(); break;
			case PPP_STATE_STOPPED: ppp_send_terminate_ack(); break;
			case PPP_STATE_CLOSING: break;
			case PPP_STATE_STOPPING: break;
			case PPP_STATE_REQUEST_SENT:
				ppp_initialize_restart_count();
				lcp_automaton_state = PPP_STATE_ACK_RECEIVED; break;
			case PPP_STATE_ACK_RECEIVED:
				ppp_send_configure_request(PPP_PROTOCOL_LCP);
				lcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			case PPP_STATE_ACK_SENT:
				ppp_initialize_restart_count();
				//ppp_this_layer_up();
				lcp_automaton_state = PPP_STATE_OPENED; break;
			case PPP_STATE_OPENED:
				ppp_this_layer_down();
				ppp_send_configure_request(PPP_PROTOCOL_LCP);
				lcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			default:
				ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RCN:	// Receive-Configure-Nak/Rej
		if(lcp_automaton_state==PPP_STATE_CLOSED || lcp_automaton_state==PPP_STATE_STOPPED)
			{
			ppp_send_terminate_ack();
			}
		else if(lcp_automaton_state==PPP_STATE_REQUEST_SENT || 
		        lcp_automaton_state==PPP_STATE_ACK_RECEIVED || 
		        lcp_automaton_state==PPP_STATE_ACK_SENT || 
		        lcp_automaton_state==PPP_STATE_OPENED)
			{
			if(lcp_automaton_state==PPP_STATE_REQUEST_SENT || lcp_automaton_state==PPP_STATE_ACK_SENT)
				{
				ppp_initialize_restart_count();
				}
			else if(lcp_automaton_state==PPP_STATE_OPENED)
				{
				ppp_this_layer_down();
				}
			ppp_send_configure_request(PPP_PROTOCOL_LCP);
			if(!(lcp_automaton_state==PPP_STATE_ACK_SENT))
				lcp_automaton_state=PPP_STATE_REQUEST_SENT;
			}
		else if(lcp_automaton_state==PPP_STATE_INITIAL || lcp_automaton_state==PPP_STATE_STARTING)
			{
			ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RTR:	// Receive-Terminate-Request
		if(!(lcp_automaton_state==PPP_STATE_INITIAL || lcp_automaton_state==PPP_STATE_STARTING))
			{
			if(lcp_automaton_state==PPP_STATE_OPENED)
				{
				ppp_status &= ~PPP_STATUS_UP;		// reset flag to signal this layer is no longer
				//ppp_this_layer_down();
				ppp_zero_restart_count();
				}
			ppp_send_terminate_ack();
			if(lcp_automaton_state==PPP_STATE_ACK_RECEIVED || lcp_automaton_state==PPP_STATE_ACK_SENT)
				{
				lcp_automaton_state = PPP_STATE_REQUEST_SENT;
				}
			else if(lcp_automaton_state==PPP_STATE_OPENED)
				{
				lcp_automaton_state = PPP_STATE_STOPPING;
				}
			}
		else
			{
			ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RTA:	// Receive-Terminate-Ack
		switch(lcp_automaton_state)
			{
			case PPP_STATE_CLOSING:
				ppp_this_layer_finished();
				lcp_automaton_state = PPP_STATE_CLOSED; break;
			case PPP_STATE_STOPPING:
				ppp_this_layer_finished();
				lcp_automaton_state = PPP_STATE_STOPPED; break;
			case PPP_STATE_ACK_RECEIVED:
				lcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			case PPP_STATE_OPENED:
				ppp_this_layer_down();
				ppp_send_configure_request(PPP_PROTOCOL_LCP);
				lcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			}
			if(lcp_automaton_state==PPP_STATE_INITIAL || lcp_automaton_state==PPP_STATE_STARTING)
				ppp_illegal_transition();
			break;
	case PPP_EVENT_RUC:	// Receive-Unknown-Code
		if(!(lcp_automaton_state==PPP_STATE_INITIAL || lcp_automaton_state==PPP_STATE_STARTING))
			{
			ppp_send_code_reject();
			}
		else
			{
			ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RXJ:	// Receive-Code-Reject or Receive-Protocol-Reject (permitted)
		if(lcp_automaton_state==PPP_STATE_INITIAL || lcp_automaton_state==PPP_STATE_STARTING)
			ppp_illegal_transition();
		break;
	case PPP_EVENT_RXJ_CAT:	// Receive-Code-Reject or Receive-Protocol-Reject (catastrophic)
		if(lcp_automaton_state==PPP_STATE_INITIAL || 
		   lcp_automaton_state==PPP_STATE_STARTING || 
		   lcp_automaton_state==PPP_STATE_OPENED)
			{
			if(lcp_automaton_state==PPP_STATE_OPENED)
				{
				ppp_this_layer_down();
				ppp_initialize_restart_count();
				ppp_send_terminate_req();
				lcp_automaton_state = PPP_STATE_STOPPING;
				}
			else
				{
				ppp_illegal_transition();
				}
			}
		else
			{
			ppp_this_layer_finished();
			if(lcp_automaton_state==PPP_STATE_CLOSING)
				lcp_automaton_state = PPP_STATE_CLOSED;
			else
				lcp_automaton_state = PPP_STATE_STOPPED;
			}
		break;
	case PPP_EVENT_RXR:	// Receive-Echo-Request or Receive-Echo-Reply or Receive-Discard-Request
		if(lcp_automaton_state==PPP_STATE_OPENED)
			ppp_send_echo_reply();
		if(lcp_automaton_state==PPP_STATE_INITIAL || lcp_automaton_state==PPP_STATE_STARTING)
			ppp_illegal_transition();
		break;
	}	// switch(ppp_event)	// which event occured?
}//end ppp_lcp_process()


//*********************************************************************************
// Description	: do Authentication stuff
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_pap_process(void)
{
ppp_send_authenticate_request();
}

//*********************************************************************************
// Description	: Option Negotiation Automaton for Internet-Protocol-Control-Protocol
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_ipcp_process(void)
{
switch(ppp_event)	// which event occured?
	{
	case PPP_EVENT_UP:	// lower layer is Up
		switch(ipcp_automaton_state)
			{
			case PPP_STATE_INITIAL:
				ipcp_automaton_state = PPP_STATE_CLOSED; break;
			case PPP_STATE_STARTING:
				ppp_initialize_restart_count();
				ppp_send_configure_request(PPP_PROTOCOL_IPCP);
				ipcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			default: ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_DOWN:	// lower layer is Down
		switch(ipcp_automaton_state)
			{
			case PPP_STATE_STOPPED:	ppp_this_layer_started(); break;
			case PPP_STATE_OPENED:	ppp_this_layer_down(); break;
			}
		if(ipcp_automaton_state==PPP_STATE_CLOSED || ipcp_automaton_state==PPP_STATE_CLOSING)
			{
			ipcp_automaton_state = PPP_STATE_INITIAL;
			}
		else if(ipcp_automaton_state==PPP_STATE_STOPPED || 
		        ipcp_automaton_state==PPP_STATE_STOPPING || 
		        ipcp_automaton_state==PPP_STATE_REQUEST_SENT || 
		        ipcp_automaton_state==PPP_STATE_ACK_RECEIVED || 
		        ipcp_automaton_state==PPP_STATE_ACK_SENT || 
		        ipcp_automaton_state==PPP_STATE_OPENED)
			{
			ipcp_automaton_state = PPP_STATE_STARTING;
			}
		else
			{
			ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_OPEN:	// administrative Open
		switch(ipcp_automaton_state)
			{
			case PPP_STATE_INITIAL:
				ppp_this_layer_started();
				ipcp_automaton_state = PPP_STATE_STARTING; break;
			case PPP_STATE_CLOSED:
				ppp_initialize_restart_count();
				ppp_send_configure_request(PPP_PROTOCOL_IPCP);
				ipcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			case PPP_STATE_CLOSING: ipcp_automaton_state = PPP_STATE_STOPPING; break;
			}
		break;
	case PPP_EVENT_CLOSE:	// administrative Close
		if(ipcp_automaton_state==PPP_STATE_STARTING)
			{
			ppp_this_layer_finished();
			ipcp_automaton_state = PPP_STATE_INITIAL;
			}
		else if (ipcp_automaton_state==PPP_STATE_STOPPED)
			{
			ipcp_automaton_state = PPP_STATE_CLOSED;
			}
		else if (ipcp_automaton_state==PPP_STATE_STOPPING || 
		         ipcp_automaton_state==PPP_STATE_REQUEST_SENT || 
		         ipcp_automaton_state==PPP_STATE_ACK_RECEIVED || 
		         ipcp_automaton_state==PPP_STATE_ACK_SENT || 
		         ipcp_automaton_state==PPP_STATE_OPENED)
			{
			if(ipcp_automaton_state==PPP_STATE_OPENED)
				ppp_this_layer_down();
			if(ipcp_automaton_state==PPP_STATE_REQUEST_SENT || 
			   ipcp_automaton_state==PPP_STATE_ACK_RECEIVED || 
			   ipcp_automaton_state==PPP_STATE_ACK_SENT || 
			   ipcp_automaton_state==PPP_STATE_OPENED)
				{
				ppp_initialize_restart_count();
				ppp_send_terminate_req();
				}
			ipcp_automaton_state = PPP_STATE_CLOSING;
			}
		break;
	case PPP_EVENT_TO:	// Timeout with counter > 0
		if(ipcp_automaton_state==PPP_STATE_CLOSING || ipcp_automaton_state==PPP_STATE_STOPPING)
			{
			ppp_send_terminate_req();
			}
		else if(ipcp_automaton_state==PPP_STATE_REQUEST_SENT || 
		        ipcp_automaton_state==PPP_STATE_ACK_RECEIVED || 
		        ipcp_automaton_state==PPP_STATE_ACK_SENT)
			{
			ppp_send_configure_request(PPP_PROTOCOL_IPCP);
			if(ipcp_automaton_state==PPP_STATE_ACK_RECEIVED)
				ipcp_automaton_state = PPP_STATE_REQUEST_SENT;
			}
		else
			{
			ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_TO_EX:	// Timeout with counter expired
		if(ipcp_automaton_state==PPP_STATE_CLOSING || 
		   ipcp_automaton_state==PPP_STATE_STOPPING || 
		   ipcp_automaton_state==PPP_STATE_REQUEST_SENT || 
		   ipcp_automaton_state==PPP_STATE_ACK_RECEIVED || 
		   ipcp_automaton_state==PPP_STATE_ACK_SENT)
			{
			ppp_this_layer_finished();
			if(ipcp_automaton_state==PPP_STATE_CLOSING)
				{
				ipcp_automaton_state = PPP_STATE_CLOSED;
				}
			else
				{
				ipcp_automaton_state = PPP_STATE_STOPPED;
				}
			}
		else
			{
			ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RCR:	// Receive-Configure-Request (good)
		switch(ipcp_automaton_state)
			{
			case PPP_STATE_CLOSED: ppp_send_terminate_ack(); break;
			case PPP_STATE_STOPPED:
				ppp_initialize_restart_count();
				ppp_send_configure_request(PPP_PROTOCOL_IPCP);
				ppp_send_configure_ack(PPP_PROTOCOL_IPCP);
				ipcp_automaton_state = PPP_STATE_ACK_SENT; break;
			case PPP_STATE_CLOSING: break;
			case PPP_STATE_STOPPING: break;
			case PPP_STATE_REQUEST_SENT:
				ppp_send_configure_ack(PPP_PROTOCOL_IPCP);
				ipcp_automaton_state = PPP_STATE_ACK_SENT; break;
			case PPP_STATE_ACK_RECEIVED:
				ppp_send_configure_ack(PPP_PROTOCOL_IPCP);
				ppp_this_layer_up();
				ipcp_automaton_state = PPP_STATE_OPENED; break;
			case PPP_STATE_ACK_SENT:
				ppp_send_configure_ack(PPP_PROTOCOL_IPCP); break;
			case PPP_STATE_OPENED:
				ppp_this_layer_down();
				ppp_send_configure_request(PPP_PROTOCOL_IPCP);
				ppp_send_configure_ack(PPP_PROTOCOL_IPCP);
				ipcp_automaton_state = PPP_STATE_ACK_SENT; break;
			default:
				ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RCR_BAD:	// Receive-Configure-Request (bad)
		switch(ipcp_automaton_state)
			{
			case PPP_STATE_CLOSED: ppp_send_terminate_ack(); break;
			case PPP_STATE_STOPPED:
				ppp_initialize_restart_count();
				ppp_send_configure_request(PPP_PROTOCOL_IPCP);
				ppp_send_configure_nak_reject(PPP_PROTOCOL_IPCP);
				ipcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			case PPP_STATE_CLOSING: break;
			case PPP_STATE_STOPPING: break;
			case PPP_STATE_REQUEST_SENT:
				ppp_send_configure_nak_reject(PPP_PROTOCOL_IPCP); break;
			case PPP_STATE_ACK_RECEIVED:
				ppp_send_configure_nak_reject(PPP_PROTOCOL_IPCP); break;
			case PPP_STATE_ACK_SENT:
				ppp_send_configure_nak_reject(PPP_PROTOCOL_IPCP);
				ipcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			case PPP_STATE_OPENED:
				ppp_this_layer_down();
				ppp_send_configure_request(PPP_PROTOCOL_IPCP);
				ppp_send_configure_nak_reject(PPP_PROTOCOL_IPCP);
				ipcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			default:
				ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RCA:	// Receive-Configure-Ack
		switch(ipcp_automaton_state)
			{
			case PPP_STATE_CLOSED: ppp_send_terminate_ack(); break;
			case PPP_STATE_STOPPED: ppp_send_terminate_ack(); break;
			case PPP_STATE_CLOSING: break;
			case PPP_STATE_STOPPING: break;
			case PPP_STATE_REQUEST_SENT:
				ppp_initialize_restart_count();
				ipcp_automaton_state = PPP_STATE_ACK_RECEIVED; break;
			case PPP_STATE_ACK_RECEIVED:
				ppp_send_configure_request(PPP_PROTOCOL_IPCP);
				ipcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			case PPP_STATE_ACK_SENT:
				ppp_initialize_restart_count();
				ppp_this_layer_up();
				ipcp_automaton_state = PPP_STATE_OPENED; break;
			case PPP_STATE_OPENED:
				ppp_this_layer_down();
				ppp_send_configure_request(PPP_PROTOCOL_IPCP);
				ipcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			default:
				ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RCN:	// Receive-Configure-Nak/Rej
		if(ipcp_automaton_state==PPP_STATE_CLOSED || ipcp_automaton_state==PPP_STATE_STOPPED)
			{
			ppp_send_terminate_ack();
			}
		else if(ipcp_automaton_state==PPP_STATE_REQUEST_SENT || 
		        ipcp_automaton_state==PPP_STATE_ACK_RECEIVED || 
		        ipcp_automaton_state==PPP_STATE_ACK_SENT || 
		        ipcp_automaton_state==PPP_STATE_OPENED)
			{
			if(ipcp_automaton_state==PPP_STATE_REQUEST_SENT || ipcp_automaton_state==PPP_STATE_ACK_SENT)
				{
				ppp_initialize_restart_count();
				}
			else if(ipcp_automaton_state==PPP_STATE_OPENED)
				{
				ppp_this_layer_down();
				}
			ppp_send_configure_request(PPP_PROTOCOL_IPCP);
			if(!(ipcp_automaton_state==PPP_STATE_ACK_SENT))
				ipcp_automaton_state=PPP_STATE_REQUEST_SENT;
			}
		else if(ipcp_automaton_state==PPP_STATE_INITIAL || ipcp_automaton_state==PPP_STATE_STARTING)
			{
			ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RTR:	// Receive-Terminate-Request
		if(!(ipcp_automaton_state==PPP_STATE_INITIAL || ipcp_automaton_state==PPP_STATE_STARTING))
			{
			if(ipcp_automaton_state==PPP_STATE_OPENED)
				{
				ppp_status &= ~PPP_STATUS_UP;		// reset flag to signal this layer is no longer
				//ppp_this_layer_down();
				ppp_zero_restart_count();
				}
			ppp_send_terminate_ack();
			if(ipcp_automaton_state==PPP_STATE_ACK_RECEIVED || ipcp_automaton_state==PPP_STATE_ACK_SENT)
				{
				ipcp_automaton_state = PPP_STATE_REQUEST_SENT;
				}
			else if(ipcp_automaton_state==PPP_STATE_OPENED)
				{
				ipcp_automaton_state = PPP_STATE_STOPPING;
				}
			}
		else
			{
			ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RTA:	// Receive-Terminate-Ack
		switch(ipcp_automaton_state)
			{
			case PPP_STATE_CLOSING:
				ppp_this_layer_finished();
				ipcp_automaton_state = PPP_STATE_CLOSED; break;
			case PPP_STATE_STOPPING:
				ppp_this_layer_finished();
				ipcp_automaton_state = PPP_STATE_STOPPED; break;
			case PPP_STATE_ACK_RECEIVED:
				ipcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			case PPP_STATE_OPENED:
				ppp_this_layer_down();
				ppp_send_configure_request(PPP_PROTOCOL_IPCP);
				ipcp_automaton_state = PPP_STATE_REQUEST_SENT; break;
			}
		if(ipcp_automaton_state==PPP_STATE_INITIAL || ipcp_automaton_state==PPP_STATE_STARTING)
			ppp_illegal_transition();
		break;
	case PPP_EVENT_RUC:	// Receive-Unknown-Code
		if(!(ipcp_automaton_state==PPP_STATE_INITIAL || ipcp_automaton_state==PPP_STATE_STARTING))
			{
			ppp_send_code_reject();
			}
		else
			{
			ppp_illegal_transition();
			}
		break;
	case PPP_EVENT_RXJ:	// Receive-Code-Reject or Receive-Protocol-Reject (permitted)
		if(ipcp_automaton_state==PPP_STATE_INITIAL || ipcp_automaton_state==PPP_STATE_STARTING)
			ppp_illegal_transition();
		break;
	case PPP_EVENT_RXJ_CAT:	// Receive-Code-Reject or Receive-Protocol-Reject (catastrophic)
		if(ipcp_automaton_state==PPP_STATE_INITIAL || 
		   ipcp_automaton_state==PPP_STATE_STARTING || 
		   ipcp_automaton_state==PPP_STATE_OPENED)
			{
			if(ipcp_automaton_state==PPP_STATE_OPENED)
				{
				ppp_this_layer_down();
				ppp_initialize_restart_count();
				ppp_send_terminate_req();
				ipcp_automaton_state = PPP_STATE_STOPPING;
				}
			else
				{
				ppp_illegal_transition();
				}
			}
		else
			{
			ppp_this_layer_finished();
			if(ipcp_automaton_state==PPP_STATE_CLOSING)
				ipcp_automaton_state = PPP_STATE_CLOSED;
			else
				ipcp_automaton_state = PPP_STATE_STOPPED;
			}
		break;
	case PPP_EVENT_RXR:	// Receive-Echo-Request or Receive-Echo-Reply or Receive-Discard-Request
		if(ipcp_automaton_state==PPP_STATE_OPENED)
			ppp_send_echo_reply();
		if(ipcp_automaton_state==PPP_STATE_INITIAL || ipcp_automaton_state==PPP_STATE_STARTING)
			ppp_illegal_transition();
		break;
	}	// switch(ppp_event)	// which event occured?
}//end ppp_ipcp_process()

#ifdef PPP_DEBUG
char flash *ppp_protocol_name[5]={
				"LCP", "PAP", "IPCP", "IP", "UNKNOWN"};
#endif

//*********************************************************************************
// Description	: evaluates the received PPP packet and decides which event has occured
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_eval_rx_packet(void)
{
ppp_event = PPP_EVENT_NONE;
p_ppp_new_packet = ppp_rx_table_buffer[ppp_rx_table_read_index].addr;
ppp_new_packet_size = ppp_rx_table_buffer[ppp_rx_table_read_index].size;
p_ppp_new_packet_data = p_ppp_new_packet;
#ifdef PPP_DEBUG
ppp_frame_count++;
#endif
if(ppp_fcs16(PPP_INIT_FCS16, p_ppp_new_packet_data, ppp_new_packet_size)==PPP_GOOD_FCS16)
	{
	// FCS war erfolgreich, hier nun LCP packet auswerten
	//--------------
	if(p_ppp_new_packet_data[PPP_ADDRESS_OFS]==PPP_ADDRESS && p_ppp_new_packet_data[PPP_CONTROL_OFS]==PPP_CONTROL)
		{
		// wenn die Address-and-Control-Field-Compression nicht aktiv ist, d.h.
		// Address-and-Control-Field mit �bertragen werden
		// wird der Buffer Pointer um 2 erh�ht und zeigt demnach auf das protocol field
		p_ppp_new_packet_data += 2;
		}
	// only valid protocol types will be evaluated
	// c021 : Link Control Protocol
	// c023 : Password Authentication Protocol
	// 8021 : IP Control Protocol
	// 0021 || 21 : Internet Protocol
	if(p_ppp_new_packet_data[PPP_PROTOCOL_OFS]==0xC0 && p_ppp_new_packet_data[PPP_PROTOCOL_OFS+1]==0x21)
		ppp_protocol_type = PPP_PROTOCOL_LCP;
	else if(p_ppp_new_packet_data[PPP_PROTOCOL_OFS]==0xC0 && p_ppp_new_packet_data[PPP_PROTOCOL_OFS+1]==0x23)
		ppp_protocol_type = PPP_PROTOCOL_PAP;
	else if(p_ppp_new_packet_data[PPP_PROTOCOL_OFS]==0x80 && p_ppp_new_packet_data[PPP_PROTOCOL_OFS+1]==0x21)
		ppp_protocol_type = PPP_PROTOCOL_IPCP;
	else if((p_ppp_new_packet_data[PPP_PROTOCOL_OFS]==0x00 && p_ppp_new_packet_data[PPP_PROTOCOL_OFS+1]==0x21)||(p_ppp_new_packet_data[PPP_PROTOCOL_OFS]==0x21))
		{
		if(p_ppp_new_packet_data[PPP_PROTOCOL_OFS]==0x21)
			{
			p_ppp_new_packet_data++;					// only a ONE Byte Protocol-Header
			ppp_new_packet_size-=(1+PPP_HDLC_TRAILER);	// Protocol(1), FCS(2)
	        }
		else
			{
			p_ppp_new_packet_data+=2;					// a TWO Byte Protocol-Header
			ppp_new_packet_size-=(2+PPP_HDLC_TRAILER);	// Protocol(2), FCS(2)
			}
		ppp_protocol_type = PPP_PROTOCOL_IP;
		}
	else
		{
		ppp_protocol_type = PPP_PROTOCOL_UNKNOWN;
		ppp_event = PPP_EVENT_RUC;
		}
	#ifdef PPP_DEBUG
	if (ppp_debug_flag)
		{
		printf("PPP-R(%u) %p-%uByte\r\n", ppp_frame_count, ppp_protocol_name[ppp_protocol_type], ppp_new_packet_size);
		if(ppp_protocol_type!=PPP_PROTOCOL_IP)
			debug_display_mem_hex(p_ppp_new_packet, ppp_new_packet_size, 0);
		}
	#endif
	switch(ppp_protocol_type)
		{
		case PPP_PROTOCOL_LCP: ppp_eval_lcp_packet(); break;
		case PPP_PROTOCOL_PAP: ppp_eval_pap_packet(); break;
		case PPP_PROTOCOL_IPCP: ppp_eval_ipcp_packet(); break;
		case PPP_PROTOCOL_IP:  
				if((ipcp_automaton_state==PPP_STATE_OPENED)&&(lcp_automaton_state==PPP_STATE_OPENED)&&(ppp_status & PPP_STATUS_UP))
					{
					if((ppp_status & PPP_STATUS_RX_DATA)==0)
						{
			            ppp_status |= PPP_STATUS_RX_DATA;		  		// set RXDataAvailable bit
			            p_ppp_rx_data_packet = p_ppp_new_packet_data;	// init SAP-pointer
			            ppp_rx_data_packet_size = ppp_new_packet_size;	// init SAP-Size value
						#ifdef PPP_DEBUG
						if (ppp_debug_flag)
							{
							//printf("PPP data: %uByte\r\n", ppp_new_packet_size);
							//web_debug_display_frame(p_ppp_rx_data_packet, ppp_rx_data_packet_size);
							}
						#endif
			            }
					else
						{
						#ifdef PPP_DEBUG
						if (ppp_debug_flag)
							printf("PPP-R(%u) data lost: %uByte\r\n", ppp_frame_count, ppp_new_packet_size);
						#endif
						}
					}
				break;
		}
	}// end FCS
// wenn die FCS nicht erfolgreich war, wird das empfangene PPP packet einfach ignoriert
ppp_rx_table_read_index++;
if(ppp_rx_table_read_index > (PPP_MAX_DATA_PACKETS-1))
	ppp_rx_table_read_index=0;
ppp_rx_new_packet_count--;		// decrement received packet counter for one packet was evaluated
#ifdef PPP_DEBUG
if (ppp_debug_flag)
	ppp_debug_print_event_change();
#endif
}

#ifdef PPP_DEBUG
char flash *ppp_packet_code_name[12]={
				""                , "CONFIG_REQUEST", "CONFIG_ACK"   , "CONFIG_NAK", 
				"CONFIG_REJECT"   , "TERMINATE_REQUEST", "TERMINATE_ACK", "CODE_REJECT",
				"PROTOCOL_REJECT" , "ECHO_REQUEST"  , "ECHO_REPLY"   , "DISCARD_REQUEST"};

char flash *ppp_lcp_options_name[9]={
				"UNSUPPORTED", "MAX_RECEIVE_UNIT", "ACCM"   , "AUTH_TYPE", 
				"QUALITY_PROTOCOL", "MAGIC_NUMBER", "LINK_QUALITY_MON", "PROTOCOL_FIELD_COMP",
				"ADR_CTL_FIELD_COMP"};
#endif

//*********************************************************************************
// Description	: evaluates the LCP-PPP packet and decides which event has occured
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_eval_lcp_packet(void)
{
#ifdef PPP_DEBUG
if (ppp_debug_flag)
	printf("PPP-R(%u) LCP %p ", ppp_frame_count, ppp_packet_code_name[p_ppp_new_packet_data[PPP_CODE_OFS]]);
#endif
switch(p_ppp_new_packet_data[PPP_CODE_OFS])
	{
    case PPP_CONFIGURE_REQUEST:
		ppp_remote_configure_req_id = p_ppp_new_packet_data[PPP_ID_OFS];
		p_ppp_new_packet_data += PPP_OPTIONS_OFS;
		p_ppp_new_packet_option = p_ppp_new_packet_data;	// for further
		while(p_ppp_new_packet_data < p_ppp_new_packet+(ppp_new_packet_size-2))
			{
			#ifdef PPP_DEBUG
			if (ppp_debug_flag)
				{
				if(*p_ppp_new_packet_data<9)
					printf("%p ", ppp_lcp_options_name[*p_ppp_new_packet_data]);
				else
					printf("%p ", ppp_lcp_options_name[0]);
				}
			#endif
			switch(*p_ppp_new_packet_data)
				{
				case LCP_MAX_RECEIVE_UNIT: // Maximum_Receive_Unit
					ppp_remote_max_receive_unit[0] = p_ppp_new_packet_data[LCP_OPTIONS_DATA_OFS];
					ppp_remote_max_receive_unit[1] = p_ppp_new_packet_data[LCP_OPTIONS_DATA_OFS+1];
					p_ppp_new_packet_data+=LCP_MAX_RECEIVE_UNIT_LEN;
					break;
				case LCP_ACCM: // Async-Control-Character-Map
					memcpy(&ppp_remote_accm[0], &p_ppp_new_packet_data[LCP_OPTIONS_DATA_OFS], sizeof(ppp_remote_accm));
					p_ppp_new_packet_data+=LCP_ACCM_LEN;
					break;
				case LCP_AUTHENTICATION_TYPE: // Authentication-Type
					if(p_ppp_new_packet_data[LCP_OPTIONS_DATA_OFS]==0xc0 && p_ppp_new_packet_data[LCP_OPTIONS_DATA_OFS+1]==0x23)
						ppp_rx_flag |= PPP_RX_FLAG_AUTH;
					else
						ppp_event = PPP_EVENT_RCR_BAD;
					p_ppp_new_packet_data+=LCP_AUTHENTICATION_TYPE_LEN;
					break;
				case LCP_MAGIC_NUMBER: // Magic-Number
					memcpy(&ppp_remote_magic_number[0], &p_ppp_new_packet_data[LCP_OPTIONS_DATA_OFS], sizeof(ppp_remote_magic_number));
					p_ppp_new_packet_data+=LCP_MAGIC_NUMBER_LEN;
					break;
				case LCP_LINK_QUALITY_MONITORING:	// Link-Quality-Monitoring
					break;		
				case LCP_PROTOCOL_FIELD_COMP: // Protocol-Field-Compression
					ppp_rx_flag |= PPP_RX_FLAG_PFC;
					p_ppp_new_packet_data+=LCP_PROTOCOL_FIELD_COMP_LEN; break;
				case LCP_ADR_CTL_FIELD_COMP: // Address-and-Control-Field-Compression
					ppp_rx_flag |= PPP_RX_FLAG_ACFC;
					p_ppp_new_packet_data+=LCP_ADR_CTL_FIELD_COMP_LEN; break;
				default:
					p_ppp_new_packet_data+=p_ppp_new_packet_data[1];
					ppp_event = PPP_EVENT_RCR_BAD;
				}// end switch(*pRxBuffer)
			}//end while
		if(ppp_event!=PPP_EVENT_RCR_BAD) ppp_event = PPP_EVENT_RCR;
		break;
	case PPP_CONFIGURE_ACK: ppp_event=PPP_EVENT_RCA; break;
	case PPP_CONFIGURE_NAK:
		ppp_disable_local_options();
		break;
    case PPP_CONFIGURE_REJECT:
		ppp_disable_local_options();
		break;
	case PPP_TERMINATE_REQUEST:
		ppp_remote_terminate_req_id = p_ppp_new_packet_data[PPP_ID_OFS];
		ppp_event=PPP_EVENT_RTR; 
		break;
	case PPP_TERMINATE_ACK: ppp_event=PPP_EVENT_RTA; break;
    case PPP_CODE_REJECT: ppp_event = PPP_EVENT_RXJ; break;
    case PPP_PROTOCOL_REJECT: ppp_event = PPP_EVENT_RXJ; break;
    case PPP_ECHO_REQUEST: ppp_event = PPP_EVENT_RXR; break;
    case PPP_ECHO_REPLY: ppp_event = PPP_EVENT_RXR; break;
    case PPP_DISCARD_REQUEST: ppp_event = PPP_EVENT_RXR; break;
    default: ppp_event=PPP_EVENT_RUC;
	}	// switch(p_ppp_new_packet_data[PPP_CODE_OFS])
#ifdef PPP_DEBUG
if (ppp_debug_flag)
	{
	putsf("\r");
	ppp_debug_print_event_change();
	}
#endif
}// end ppp_eval_lcp_packet()


//*********************************************************************************
// Description	: 
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_disable_local_options(void)
{
p_ppp_new_packet_data += PPP_OPTIONS_OFS;
while(p_ppp_new_packet_data < p_ppp_new_packet+(ppp_new_packet_size-2))
	{
	switch(*p_ppp_new_packet_data)
		{
		case LCP_MAX_RECEIVE_UNIT: // Maximum_Receive_Unit
			ppp_rx_flag &= ~PPP_RX_FLAG_MRU;
            p_ppp_new_packet_data+=LCP_MAX_RECEIVE_UNIT_LEN; break;
		case LCP_ACCM: // Async-Control-Character-Map
			ppp_rx_flag &= ~PPP_RX_FLAG_ACCM;
			p_ppp_new_packet_data+=LCP_ACCM_LEN; break;
		case LCP_PROTOCOL_FIELD_COMP: // Protocol-Field-Compression
			ppp_rx_flag &= ~PPP_RX_FLAG_PFC;
			p_ppp_new_packet_data+=LCP_PROTOCOL_FIELD_COMP_LEN; break;
		case LCP_ADR_CTL_FIELD_COMP: // Address-and-Control-Field-Compression
			ppp_rx_flag &= ~PPP_RX_FLAG_ACFC;
			p_ppp_new_packet_data+=LCP_ADR_CTL_FIELD_COMP_LEN; break;
		default:
			p_ppp_new_packet_data+=p_ppp_new_packet_data[1];
		}// end switch(*pRxBuffer)
	}//end while
ppp_event=PPP_EVENT_RCN;
}// end ppp_disable_local_options()


//*********************************************************************************
// Description	: 
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_eval_pap_packet(void)
{
#ifdef PPP_DEBUG
if (ppp_debug_flag)
	printf("PPP-R(%u) PAP %p\r\n", ppp_frame_count, ppp_packet_code_name[p_ppp_new_packet_data[PPP_CODE_OFS]]);
#endif
if(p_ppp_new_packet_data[PPP_CODE_OFS]==PPP_CONFIGURE_ACK)
	ppp_event = PPP_EVENT_UP;
}


//*********************************************************************************
// Description	: 
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_eval_ipcp_packet(void)
{
#ifdef PPP_DEBUG
if (ppp_debug_flag)
	printf("PPP-R(%u) IPCP %p ", ppp_frame_count, ppp_packet_code_name[p_ppp_new_packet_data[PPP_CODE_OFS]]);
#endif
switch(p_ppp_new_packet_data[PPP_CODE_OFS])
	{
	case PPP_CONFIGURE_REQUEST:
		ppp_remote_configure_req_id = p_ppp_new_packet_data[PPP_ID_OFS];
		p_ppp_new_packet_data += PPP_OPTIONS_OFS;
		p_ppp_new_packet_option = p_ppp_new_packet_data;	// for further
		while(p_ppp_new_packet_data < p_ppp_new_packet+(ppp_new_packet_size-2))
			{
			#ifdef PPP_DEBUG
			if (ppp_debug_flag)
				{
				if(*p_ppp_new_packet_data==IPCP_IP_ADR)
					debug_print_ip(0x0, &p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS]);
				else
					printf("0x%02x ", *p_ppp_new_packet_data);
				}
			#endif
			if(*p_ppp_new_packet_data==IPCP_IP_ADR)
				{
				if(p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS]==0 && 
				   p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS+1]==0 && 
				   p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS+2]==0 && 
				   p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS+3]==0)
					{
					ppp_ip_request = 1;
					ppp_event = PPP_EVENT_RCR_BAD;
					}
				memcpy(&ppp_remote_ip[0], &p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS], sizeof(ppp_remote_ip));
				p_ppp_new_packet_data+=IPCP_IP_ADR_LEN;
				}
			else
				{
				p_ppp_new_packet_data+=p_ppp_new_packet_data[1];	// add length of options
				ppp_ip_request = 0;
				ppp_event = PPP_EVENT_RCR_BAD;
				}
			}//end while
		if(ppp_event!=PPP_EVENT_RCR_BAD) ppp_event = PPP_EVENT_RCR;
		break;
	case PPP_CONFIGURE_ACK: ppp_event=PPP_EVENT_RCA; break;
	case PPP_CONFIGURE_NAK:
		p_ppp_new_packet_data += PPP_OPTIONS_OFS;
		while(p_ppp_new_packet_data < p_ppp_new_packet+(ppp_new_packet_size-2))
			{
			#ifdef PPP_DEBUG
			if (ppp_debug_flag)
				{
				if(*p_ppp_new_packet_data==IPCP_IP_ADR ||
				   *p_ppp_new_packet_data==IPCP_GATEWAY_81 ||
				   *p_ppp_new_packet_data==IPCP_GATEWAY_82 ||
				   *p_ppp_new_packet_data==IPCP_GATEWAY_83 ||
				   *p_ppp_new_packet_data==IPCP_GATEWAY_84)
				   	{
					debug_print_ip(0x0, &p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS]);
					}
				else
					printf("0x%02x ", *p_ppp_new_packet_data);
				}
			#endif
			switch(*p_ppp_new_packet_data)
				{
				case IPCP_IP_ADR:
					memcpy(&ppp_local_ip[0], &p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS], sizeof(ppp_local_ip));
					p_ppp_new_packet_data+=IPCP_IP_ADR_LEN; 
					break;
				case IPCP_GATEWAY_81:
					memcpy(&ppp_gateway_81[0], &p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS], sizeof(ppp_gateway_81));
					p_ppp_new_packet_data+=IPCP_IP_ADR_LEN;
					break;
				case IPCP_GATEWAY_82:
					memcpy(&ppp_gateway_82[0], &p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS], sizeof(ppp_gateway_82));
					p_ppp_new_packet_data+=IPCP_IP_ADR_LEN;
					break;
				case IPCP_GATEWAY_83:
					memcpy(&ppp_gateway_83[0], &p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS], sizeof(ppp_gateway_83));
					p_ppp_new_packet_data+=IPCP_IP_ADR_LEN;
					break;
				case IPCP_GATEWAY_84:
					memcpy(&ppp_gateway_84[0], &p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS], sizeof(ppp_gateway_84));
					p_ppp_new_packet_data+=IPCP_IP_ADR_LEN;
					break;
				default:
					p_ppp_new_packet_data+=p_ppp_new_packet_data[1];
				}// end switch(*pRxBuffer)
			}//end while
		ppp_event=PPP_EVENT_RCN;
		break;
	case PPP_CONFIGURE_REJECT:
		p_ppp_new_packet_data += PPP_OPTIONS_OFS;
		while(p_ppp_new_packet_data < p_ppp_new_packet+(ppp_new_packet_size-2))
			{
			#ifdef PPP_DEBUG
			if (ppp_debug_flag)
				{
				if(*p_ppp_new_packet_data==IPCP_IP_ADR ||
				   *p_ppp_new_packet_data==IPCP_GATEWAY_81 ||
				   *p_ppp_new_packet_data==IPCP_GATEWAY_82 ||
				   *p_ppp_new_packet_data==IPCP_GATEWAY_83 ||
				   *p_ppp_new_packet_data==IPCP_GATEWAY_84)
				   	{
					debug_print_ip(0x0, &p_ppp_new_packet_data[IPCP_OPTIONS_DATA_OFS]);
					}
				else
					printf("0x%02x ", *p_ppp_new_packet_data);
				}
			#endif
			switch(*p_ppp_new_packet_data)
				{
				case IPCP_GATEWAY_81:
					ppp_rx_flag &= ~PPP_RX_FLAG_GATEWAY81;
					p_ppp_new_packet_data+=IPCP_IP_ADR_LEN; break;
				case IPCP_GATEWAY_82:
					ppp_rx_flag &= ~PPP_RX_FLAG_GATEWAY82;
					p_ppp_new_packet_data+=IPCP_IP_ADR_LEN; break;
				case IPCP_GATEWAY_83:
					ppp_rx_flag &= ~PPP_RX_FLAG_GATEWAY83;
					p_ppp_new_packet_data+=IPCP_IP_ADR_LEN; break;
				case IPCP_GATEWAY_84:
					ppp_rx_flag &= ~PPP_RX_FLAG_GATEWAY84;
					p_ppp_new_packet_data+=IPCP_IP_ADR_LEN; break;
				default:
					p_ppp_new_packet_data+=p_ppp_new_packet_data[1];
				}// end switch(*pRxBuffer)
			}//end while
		ppp_event=PPP_EVENT_RCN;
		break;
	case PPP_TERMINATE_REQUEST:
		ppp_remote_terminate_req_id = p_ppp_new_packet_data[PPP_ID_OFS];
		ppp_event=PPP_EVENT_RTR;
		break;
	case PPP_TERMINATE_ACK: ppp_event=PPP_EVENT_RTA; break;
	case PPP_CODE_REJECT: ppp_event = PPP_EVENT_RXJ; break;
	default: ppp_event=PPP_EVENT_RUC;
	}	// switch(p_ppp_new_packet_data[PPP_CODE_OFS])
#ifdef PPP_DEBUG
if (ppp_debug_flag)
	putsf("\r");
#endif
}// end ppp_eval_ipcp_packet


//*********************************************************************************
// Description	: tli: This-Layer-Up
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_this_layer_up(void)
{                  
ppp_status |= PPP_STATUS_UP;		// set flag to signal this layer is Up
#ifdef PPP_DEBUG
if (ppp_debug_flag)
	printf("PPP(%u) connection established\r\n", ppp_frame_count);
#endif
}

//*********************************************************************************
// Description	: tld: This-Layer-Down
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_this_layer_down(void)
{                
ppp_status &= ~PPP_STATUS_UP;		// reset flag to signal this layer is no longer
ppp_event = PPP_EVENT_DOWN;
#ifdef PPP_DEBUG
if (ppp_debug_flag)
	printf("PPP(%u) connection down\r\n", ppp_frame_count);
#endif
}

//*********************************************************************************
// Description	: tls
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_this_layer_started(void)
{
}			

//*********************************************************************************
// Description	: tlf
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_this_layer_finished(void)
{
}			

//*********************************************************************************
// Description	: irc
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_initialize_restart_count(void)
{
}

//*********************************************************************************
// Description	: zrc
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_zero_restart_count(void)
{
}


//*********************************************************************************
// Description	: 
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_illegal_transition(void)
{
#ifdef PPP_DEBUG
if (ppp_debug_flag)
	printf("PPP(%u) Illegal Transaction\r\n", ppp_frame_count);
#endif
}


//*********************************************************************************
// Description	: 
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_send_configure_request(PPP_PROTOCOL_TYPE prot)
{
p_ppp_act_tx_buffer = PPP_TX_BUFFER_START;
p_ppp_act_tx_buffer += PPP_OPTIONS_OFS+2;
ppp_tx_buffer_size = PPP_OPTIONS_OFS+2;
  
switch(prot)
	{
    case PPP_PROTOCOL_LCP:
		if(ppp_rx_flag & PPP_RX_FLAG_MRU)
	      	{
    	    *p_ppp_act_tx_buffer++ = LCP_MAX_RECEIVE_UNIT;
        	*p_ppp_act_tx_buffer++ = LCP_MAX_RECEIVE_UNIT_LEN;
	        *p_ppp_act_tx_buffer++ = ((PPP_MRU >> 8) & 0x00ff);	// high part of MRU
    	    *p_ppp_act_tx_buffer++ = (PPP_MRU & 0x00ff);			// low part of MRU
        	ppp_tx_buffer_size+=LCP_MAX_RECEIVE_UNIT_LEN;
			}
		if(ppp_rx_flag & PPP_RX_FLAG_ACCM)
	      	{
    	    *p_ppp_act_tx_buffer++ = LCP_ACCM;
        	*p_ppp_act_tx_buffer++ = LCP_ACCM_LEN;
	        *p_ppp_act_tx_buffer++ = 0x00;
    	    *p_ppp_act_tx_buffer++ = 0x0A;
        	*p_ppp_act_tx_buffer++ = 0x00;
	        *p_ppp_act_tx_buffer++ = 0x00;
    	    ppp_tx_buffer_size+=LCP_ACCM_LEN;
			}
		if(ppp_rx_flag & PPP_RX_FLAG_PFC)
			{
			*p_ppp_act_tx_buffer++ = LCP_PROTOCOL_FIELD_COMP;
			*p_ppp_act_tx_buffer++ = LCP_PROTOCOL_FIELD_COMP_LEN;
			ppp_tx_buffer_size+=LCP_PROTOCOL_FIELD_COMP_LEN;
			}
		if(ppp_rx_flag & PPP_RX_FLAG_ACFC)
			{
			*p_ppp_act_tx_buffer++ = LCP_ADR_CTL_FIELD_COMP;
			*p_ppp_act_tx_buffer++ = LCP_ADR_CTL_FIELD_COMP_LEN;
			ppp_tx_buffer_size+=LCP_ADR_CTL_FIELD_COMP_LEN;
			}
		break;
	case PPP_PROTOCOL_IPCP:
		*p_ppp_act_tx_buffer++ = IPCP_IP_ADR;
        *p_ppp_act_tx_buffer++ = IPCP_IP_ADR_LEN;
		memcpy(p_ppp_act_tx_buffer, ppp_local_ip, sizeof(ppp_local_ip));
		p_ppp_act_tx_buffer+=4;
        ppp_tx_buffer_size+=IPCP_IP_ADR_LEN;
		if(ppp_rx_flag & PPP_RX_FLAG_GATEWAY81)
			{
			*p_ppp_act_tx_buffer++ = IPCP_GATEWAY_81;
			*p_ppp_act_tx_buffer++ = IPCP_IP_ADR_LEN;
			memcpy(p_ppp_act_tx_buffer, ppp_gateway_81, sizeof(ppp_gateway_81));
			p_ppp_act_tx_buffer+=4;
			ppp_tx_buffer_size+=IPCP_IP_ADR_LEN;
			}
		if(ppp_rx_flag & PPP_RX_FLAG_GATEWAY82)
			{
			*p_ppp_act_tx_buffer++ = IPCP_GATEWAY_82;
	        *p_ppp_act_tx_buffer++ = IPCP_IP_ADR_LEN;
			memcpy(p_ppp_act_tx_buffer, ppp_gateway_82, sizeof(ppp_gateway_82));
			p_ppp_act_tx_buffer+=4;
        	ppp_tx_buffer_size+=IPCP_IP_ADR_LEN;
			}
		if(ppp_rx_flag & PPP_RX_FLAG_GATEWAY83)
			{
	        *p_ppp_act_tx_buffer++ = IPCP_GATEWAY_83;
    	    *p_ppp_act_tx_buffer++ = IPCP_IP_ADR_LEN;
			memcpy(p_ppp_act_tx_buffer, ppp_gateway_83, sizeof(ppp_gateway_83));
			p_ppp_act_tx_buffer+=4;
	        ppp_tx_buffer_size+=IPCP_IP_ADR_LEN;
    		}
		if(ppp_rx_flag & PPP_RX_FLAG_GATEWAY84)
			{
	        *p_ppp_act_tx_buffer++ = IPCP_GATEWAY_84;
    	    *p_ppp_act_tx_buffer++ = IPCP_IP_ADR_LEN;
			memcpy(p_ppp_act_tx_buffer, ppp_gateway_84, sizeof(ppp_gateway_84));
			p_ppp_act_tx_buffer+=4;
	        ppp_tx_buffer_size+=IPCP_IP_ADR_LEN;
    		}
		break;
	} // switch(prot)
ppp_protocol_type = prot;
ppp_packet_header(PPP_CONFIGURE_REQUEST, ppp_local_configure_request_id++);
ppp_transmit_buffer((unsigned char *)ppp_tx_buffer, ppp_tx_buffer_size);
}//end ppp_send_configure_request()


//*********************************************************************************
// Description	: 
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_send_configure_ack(PPP_PROTOCOL_TYPE prot)
{
p_ppp_act_tx_buffer = PPP_TX_BUFFER_START;
p_ppp_act_tx_buffer += PPP_OPTIONS_OFS+2;
ppp_tx_buffer_size = PPP_OPTIONS_OFS+2;
  
while(p_ppp_new_packet_option < p_ppp_new_packet+(ppp_new_packet_size-2))
	{
    *p_ppp_act_tx_buffer++ = *p_ppp_new_packet_option++;
     ppp_tx_buffer_size++;
	}
ppp_protocol_type = prot;
ppp_packet_header(PPP_CONFIGURE_ACK, ppp_remote_configure_req_id);
ppp_transmit_buffer((unsigned char *)ppp_tx_buffer, ppp_tx_buffer_size);
}//end ppp_send_configure_ack()


//*********************************************************************************
// Description	: 
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_send_configure_nak_reject(PPP_PROTOCOL_TYPE prot)
{
unsigned int i;
unsigned char PacketCode=PPP_CONFIGURE_REJECT;
unsigned char ip_remote[IP_ADR_SIZE]=IP_REMOTE_DEFAULT;
  
p_ppp_act_tx_buffer = PPP_TX_BUFFER_START;
p_ppp_act_tx_buffer += PPP_OPTIONS_OFS+2;
ppp_tx_buffer_size = PPP_OPTIONS_OFS+2;
  
switch(prot)
	{
    case PPP_PROTOCOL_LCP:
		while(p_ppp_new_packet_option < p_ppp_new_packet+(ppp_new_packet_size-2))
      		{
	        switch(*p_ppp_new_packet_option)
				{
				case LCP_MAX_RECEIVE_UNIT:	// Maximum_Receive_Unit
            		p_ppp_new_packet_option+=LCP_MAX_RECEIVE_UNIT_LEN; break;
          		case LCP_ACCM: 				// Async-Control-Character-Map
            		p_ppp_new_packet_option+=LCP_ACCM_LEN; break;
         		case LCP_AUTHENTICATION_TYPE:	// Authentication-Type
            		if(p_ppp_new_packet_option[LCP_OPTIONS_DATA_OFS]==0xc0 && p_ppp_new_packet_option[LCP_OPTIONS_DATA_OFS+1]==0x23)
            			{
              			p_ppp_new_packet_option+=LCP_AUTHENTICATION_TYPE_LEN;
            			}
            		else
            			{
		            	*p_ppp_act_tx_buffer++ = LCP_AUTHENTICATION_TYPE;
        			    *p_ppp_act_tx_buffer++ = LCP_AUTHENTICATION_TYPE_LEN;
		     	        *p_ppp_act_tx_buffer++ = 0xc0;
              			*p_ppp_act_tx_buffer++ = 0x23;
              			ppp_tx_buffer_size+=LCP_AUTHENTICATION_TYPE_LEN;
              			PacketCode = PPP_CONFIGURE_NAK;               // Configure-Nak
              			p_ppp_new_packet_option = p_ppp_new_packet+(ppp_new_packet_size-2);
						}
					break;
				case LCP_MAGIC_NUMBER:						// Magic-Number
					p_ppp_new_packet_option+=LCP_MAGIC_NUMBER_LEN; break;
				case LCP_PROTOCOL_FIELD_COMP: 				// Protocol-Field-Compression
					p_ppp_new_packet_option+=LCP_PROTOCOL_FIELD_COMP_LEN; break;
				case LCP_ADR_CTL_FIELD_COMP:				// Address-and-Control-Field-Compression
					p_ppp_new_packet_option+=LCP_ADR_CTL_FIELD_COMP_LEN; break;
				default:
					for(i=0; i<p_ppp_new_packet_option[1]; i++)
						{
						*p_ppp_act_tx_buffer++ = p_ppp_new_packet_option[i];
						ppp_tx_buffer_size++;
						}
				p_ppp_new_packet_option+=p_ppp_new_packet_option[1];
				}// end switch(*p_ppp_new_packet_option)
			}//end while
		break;
	case PPP_PROTOCOL_IPCP:
		while(p_ppp_new_packet_option < p_ppp_new_packet+(ppp_new_packet_size-2))
			{
			switch(*p_ppp_new_packet_option)
				{
				case IPCP_IP_ADR:
					if(ppp_ip_request)
						{
						*p_ppp_act_tx_buffer++ = IPCP_IP_ADR;		// write parameter
						*p_ppp_act_tx_buffer++ = IPCP_IP_ADR_LEN;
						memcpy(p_ppp_act_tx_buffer, ip_remote, IP_ADR_SIZE);
						p_ppp_act_tx_buffer+=IP_ADR_SIZE;
						ppp_tx_buffer_size+=IPCP_IP_ADR_LEN;
						PacketCode = PPP_CONFIGURE_NAK;		// Configure-Nak
						p_ppp_new_packet_option = p_ppp_new_packet+(ppp_new_packet_size-2);
						}
					else
						{
						p_ppp_new_packet_option+=IPCP_IP_ADR_LEN;
						}
					break;
				default:
					for(i=0; i<p_ppp_new_packet_option[1]; i++)
						{
						*p_ppp_act_tx_buffer++ = p_ppp_new_packet_option[i];
						ppp_tx_buffer_size++;
						}
				p_ppp_new_packet_option+=p_ppp_new_packet_option[1];
				} // end switch(*p_ppp_new_packet_option)
			} //end while
		break;
	} //end switch(ppp_protocol_type)
ppp_protocol_type = prot;
ppp_packet_header(PacketCode,ppp_remote_configure_req_id);
ppp_transmit_buffer((unsigned char *)ppp_tx_buffer, ppp_tx_buffer_size);
}//end ppp_send_configure_nak_reject()


//*********************************************************************************
// Description	: 
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_send_terminate_req(void)
{
ppp_tx_buffer_size = 8;
ppp_packet_header(PPP_TERMINATE_REQUEST, ppp_local_terminate_request_id++);
ppp_transmit_buffer((unsigned char *)ppp_tx_buffer, ppp_tx_buffer_size);
}//end ppp_send_terminate_req()

//*********************************************************************************
// Description	: 
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_send_terminate_ack(void)
{
ppp_tx_buffer_size = 8;
ppp_packet_header(PPP_TERMINATE_ACK, ppp_remote_terminate_req_id);
ppp_transmit_buffer((unsigned char *)ppp_tx_buffer, ppp_tx_buffer_size);
}//end ppp_send_terminate_ack()


//*********************************************************************************
// Description	: 
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_send_code_reject(void)
{
unsigned char PacketCode;
  
p_ppp_act_tx_buffer = PPP_TX_BUFFER_START;
p_ppp_act_tx_buffer += PPP_OPTIONS_OFS+2;
ppp_tx_buffer_size = PPP_OPTIONS_OFS+2;
p_ppp_new_packet_option = p_ppp_new_packet;
if((p_ppp_new_packet_option[0]==PPP_ADDRESS) && (p_ppp_new_packet_option[1]==PPP_CONTROL))
	p_ppp_new_packet_option+=2;
if(ppp_protocol_type==PPP_PROTOCOL_LCP||ppp_protocol_type==PPP_PROTOCOL_PAP||ppp_protocol_type==PPP_PROTOCOL_IPCP)
	{
	PacketCode = PPP_CODE_REJECT;
	p_ppp_new_packet_option+=2;
	}
else if(ppp_protocol_type==PPP_PROTOCOL_UNKNOWN)
	{
	ppp_protocol_type = PPP_PROTOCOL_LCP;
	PacketCode = PPP_PROTOCOL_REJECT;
	}
while(p_ppp_new_packet_option < p_ppp_new_packet+(ppp_new_packet_size-2))
	{
	*p_ppp_act_tx_buffer++ = *p_ppp_new_packet_option++;
	ppp_tx_buffer_size++;
	}
ppp_packet_header(PacketCode,ppp_local_configure_request_id++);
ppp_transmit_buffer((unsigned char *)ppp_tx_buffer, ppp_tx_buffer_size);
}//end ppp_send_code_reject()


//*********************************************************************************
// Description	: 
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_send_echo_reply(void)
{
}//end ppp_send_echo_reply()

//*********************************************************************************
// Description	: 
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_send_authenticate_request(void)
{
unsigned char i;
ppp_protocol_type = PPP_PROTOCOL_PAP;
p_ppp_act_tx_buffer = PPP_TX_BUFFER_START;
p_ppp_act_tx_buffer += PPP_OPTIONS_OFS+2;
ppp_tx_buffer_size = PPP_OPTIONS_OFS+2;
*p_ppp_act_tx_buffer++ = peer_id_length;
ppp_tx_buffer_size++;
for(i=0; i<peer_id_length; i++,ppp_tx_buffer_size++)
	{
	*p_ppp_act_tx_buffer++ = peer_id[i];
	}
*p_ppp_act_tx_buffer++ = password_length;
ppp_tx_buffer_size++;
for(i=0; i<password_length; i++, ppp_tx_buffer_size++)
	{
	*p_ppp_act_tx_buffer++ = password[i];
	}
ppp_packet_header(PPP_CONFIGURE_REQUEST, ppp_local_configure_request_id++);
ppp_transmit_buffer((unsigned char *)ppp_tx_buffer, ppp_tx_buffer_size);
}// end ppp_send_authenticate_request()

//*********************************************************************************
// Description	: Calculate a new fcs given the current fcs and the new data.
// Input   		: fcs: the defined PPP_INIT_FCS16
//				  cp: pointer to the serial data stream
//				  len: length of the data buffer in bytes
// Output  		: new fcs (16bit)
// Indication	: none
//*********************************************************************************
unsigned int ppp_fcs16(unsigned int fcs, unsigned char* cp, unsigned int len)
{
while(len--)
	fcs = (fcs >> 8) ^ fcstab[(fcs ^ *cp++) & 0xff];
return (fcs);
}//end ppp_fcs16()


//*********************************************************************************
// Description	: format the PPP-Packet header
// Input   		: packet_format: see PPP_CONFIGURE_REQUEST and so on
//				  id: 
// Output  		: none
// Indication	: none
//*********************************************************************************
void ppp_packet_header(unsigned char packet_format, unsigned char id)
{
p_ppp_act_tx_buffer = PPP_TX_BUFFER_START;
p_ppp_act_tx_buffer[PPP_ADDRESS_OFS] = PPP_ADDRESS;
p_ppp_act_tx_buffer[PPP_CONTROL_OFS] = PPP_CONTROL;
p_ppp_act_tx_buffer+=2;
switch(ppp_protocol_type)
	{
	case PPP_PROTOCOL_LCP:
			p_ppp_act_tx_buffer[PPP_PROTOCOL_OFS] = 0xc0;
			p_ppp_act_tx_buffer[PPP_PROTOCOL_OFS+1] = 0x21;
			break;
	case PPP_PROTOCOL_IPCP:
			p_ppp_act_tx_buffer[PPP_PROTOCOL_OFS] = 0x80;
			p_ppp_act_tx_buffer[PPP_PROTOCOL_OFS+1] = 0x21;
			break;
	case PPP_PROTOCOL_PAP:
			p_ppp_act_tx_buffer[PPP_PROTOCOL_OFS] = 0xc0;
			p_ppp_act_tx_buffer[PPP_PROTOCOL_OFS+1] = 0x23;
			break;
	}
p_ppp_act_tx_buffer[PPP_CODE_OFS] = packet_format;
p_ppp_act_tx_buffer[PPP_ID_OFS] = id;
p_ppp_act_tx_buffer[PPP_LENGTH_OFS] = (((ppp_tx_buffer_size-PPP_HDLC_HEADER) >> 8) & 0x00ff);	// MSB of TXBuffersize
p_ppp_act_tx_buffer[PPP_LENGTH_OFS+1] = ((ppp_tx_buffer_size-PPP_HDLC_HEADER) & 0x00ff);		// LSB of TXBuffersize
}

//*********************************************************************************
// Description	: checks whether PPP-connection OK
// Input	   	: none
// Output   	: 1: PPP-conection OK
// 				  0: PPP-connection no available
// Indication	: none
//*********************************************************************************
void	ppp_transmit_buffer(unsigned char *pointer, unsigned int size)
{
unsigned int i=0, fcs;

// Frame Check Sequenz berechnen und an das Datenpacket anh�ngen
fcs = ppp_fcs16(PPP_INIT_FCS16, pointer, size);
fcs ^= 0xffff;   // complement
pointer[size] = (fcs & 0x00ff); 
pointer[size+1] = ((fcs >> 8) & 0x00ff);

uart1_putchar(PPP_FLAG_SEQUENZE);
while(i < size+PPP_HDLC_TRAILER)
	{
	if(pointer[i] < 0x20 || pointer[i] == PPP_FLAG_SEQUENZE || pointer[i] == PPP_CONTROL_ESCAPE)
		{
		uart1_putchar(PPP_CONTROL_ESCAPE);
		pointer[i] ^= PPP_CE_BIT;
		}
	uart1_putchar(pointer[i++]);
	}
uart1_putchar(PPP_FLAG_SEQUENZE);
}

//*********************************************************************************
// Description	: checks whether PPP-connection OK
// Input	   	: none
// Output   	: 1: PPP-conection OK
// 				  0: PPP-connection no available
// Indication	: none
//*********************************************************************************
unsigned char ppp_interface_available(void)
{
if(ppp_status & PPP_STATUS_UP)
	return 1;
return 0;
}


//*********************************************************************************
// Description	: checks whether PPP-data available
// Input	   	: none
// Output   	: 1: data available
// 				  0: no data available
// Indication	: none
//*********************************************************************************
unsigned char ppp_data_available(void)
{
if(ppp_status & PPP_STATUS_RX_DATA)
	return 1;
return 0;
}


//*********************************************************************************
// Description	: clears the receive PPP-data
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
void ppp_data_clear(void)
{
ppp_status &= ~PPP_STATUS_RX_DATA;		// reset flag
ppp_rx_data_packet_size=0;			// delete the rest of data (1Byte)
}


//*********************************************************************************
// Description	: reads 16bit data from PPP-data-buffer
// Input	   	: data: pointer to 16bit data
// Output   	: 1: data available
// 				  0: no data available
// 				  *data: read data
// Indication	: none
//*********************************************************************************
unsigned char ppp_data_read16(unsigned int *data)
{
*data=0;
if(ppp_rx_data_packet_size>1)
	{
	*data=*p_ppp_rx_data_packet;
	*data<<=8;
	p_ppp_rx_data_packet++;
	*data|=*p_ppp_rx_data_packet;
	p_ppp_rx_data_packet++;
	ppp_rx_data_packet_size-=2;
	return 1;
	}
ppp_data_clear();
return 0;
}


//*********************************************************************************
// Description	: reads 8bit data from PPP-data-buffer
// Input	   	: data: pointer to 16bit data
// Output   	: 1: data available
// 				  0: no data available
// 				  *data: read data
// Indication	: none
//*********************************************************************************
unsigned char ppp_data_read8(unsigned char *data)
{
*data=0;
if(ppp_rx_data_packet_size)
	{
	*data=*p_ppp_rx_data_packet;
	p_ppp_rx_data_packet++;
	ppp_rx_data_packet_size--;
	return 1;
	}
ppp_data_clear();
return 0;
}

//*********************************************************************************
// Description	: checks whether PPP-data available
// Input	   	: none
// Output   	: 1: data available
// 				  0: no data available
// Indication	: none
//*********************************************************************************
unsigned char ppp_transmit_data(unsigned int packetSize)
{
if((ipcp_automaton_state==PPP_STATE_OPENED)&&(lcp_automaton_state==PPP_STATE_OPENED)&&(ppp_status & PPP_STATUS_UP))
	{
	p_ppp_act_tx_buffer = PPP_TX_BUFFER_START;
	p_ppp_act_tx_buffer[PPP_ADDRESS_OFS] = PPP_ADDRESS;
	p_ppp_act_tx_buffer[PPP_CONTROL_OFS] = PPP_CONTROL;
	p_ppp_act_tx_buffer+=2;
	p_ppp_act_tx_buffer[PPP_PROTOCOL_OFS] = 0x00;
	p_ppp_act_tx_buffer[PPP_PROTOCOL_OFS+1] = 0x21;
	ppp_transmit_buffer(PPP_TX_BUFFER_START, packetSize+PPP_HDLC_HEADER);
//	web_debug_display_frame(PPP_TX_BUFFER_START, packetSize+PPP_HDLC_HEADER);
	return 1;
	}
return 0;
}


//*********************************************************************************
// Description	: data available
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
unsigned char ppp_write_ready(unsigned int count)
{
if(count<PPP_MTU)
	return 1;
return 0;
}

//*********************************************************************************
// Description	: data available
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
unsigned char ppp_write_data(unsigned char *data, unsigned int count)
{
unsigned int length;

data+=ETH_HEADER_SIZE;		// add offset of Ethernet-Header
count-=ETH_HEADER_SIZE;		// without the Ethernet-Header 
if(count>PPP_MTU)
	length=PPP_MTU;
else
	length=count;
memcpy(((unsigned char*)ppp_tx_buffer+PPP_HDLC_HEADER), data, length);
return ppp_transmit_data(length);
}

//*********************************************************************************
// Description	: data available
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
unsigned int ppp_ready(void)
{
if((ppp_status & PPP_STATUS_UP)&&  		// see ppp_interface_available()
   (ppp_status & PPP_STATUS_RX_DATA))	// see ppp_data_available()
		return (DEVICE_READ_READY_RECEIVE | DEVICE_READ_READY_FRAME);
return 0;
}


//*********************************************************************************
// Description	: reads 16bit data from ppp-receive-buffer
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
unsigned int ppp_read_frame_16bit(void)
{
unsigned int data;

ppp_data_read16(&data);
return data;
}


//*********************************************************************************
// Description	: reads 16bit data from ppp-receive-buffer
// Input	   	: none
// Output   	: none
// Indication	: with Little-Endian
//*********************************************************************************
unsigned int ppp_read_frame_16bit_le(void)
{
unsigned char data_low;
unsigned int data_high;

ppp_data_read8(&data_low);
ppp_data_read8(&(unsigned char*)data_high);
data_high<<=8;
data_high|=data_low;
return data_high;
}

//*********************************************************************************
// Description	: reads "size" count data from ppp-receive-buffer
// Input	   	: 1.) size : 8bit count of data
// Output   	: none
// Indication	: none
//*********************************************************************************
void ppp_read_frame_dummy(unsigned int size)
{
unsigned char data;

while(size)
	{
	ppp_data_read8(&data);
	size--;
	#asm("wdr");			// Reset Watchdog
	}
}			


//*********************************************************************************
// Description	: reads a frame of data from PPP
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
void ppp_read_frame(void *dest, unsigned int size)
{
unsigned char	*p_data;

p_data=dest;
while(size)
	{
	ppp_data_read8(p_data);
    p_data++;
	size--;
	#asm("wdr");			// Reset Watchdog
	}
}			


#define MODEM_ESC_CTL			0x01	// set when a Control Escape Byte was received
//*********************************************************************************
// Description	: function to handle modem-receive
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
void ppp_receive_data(unsigned char data)
{
static unsigned char escape_control=0;		// set Control Escape Flag

switch(data)
	{
	case PPP_FLAG_SEQUENZE:		// Flag Sequence
		if(ppp_rx_buffersize == 0)
			{              //if NO data was received
			ppp_rx_table_buffer[ppp_rx_table_write_index].addr = p_ppp_rx_buffer;
			}
		else
			{							// else if data was received
			ppp_rx_new_packet_count++;		// increment received packet counter
			ppp_rx_table_buffer[ppp_rx_table_write_index++].size = ppp_rx_buffersize;
			if(ppp_rx_table_write_index > (PPP_MAX_DATA_PACKETS-1))
				ppp_rx_table_write_index=0;
			ppp_rx_buffersize = 0;
			ppp_rx_table_buffer[ppp_rx_table_write_index].addr = p_ppp_rx_buffer;
			}
		break;
	case PPP_CONTROL_ESCAPE:			// Control Escape Octet
		escape_control=MODEM_ESC_CTL;	// set Control Escape Flag
		break;
	default:							// all the other bytes
		*p_ppp_rx_buffer = data;		// take value from UART-input-register
		if(escape_control)
			{
			*p_ppp_rx_buffer ^= PPP_CE_BIT;	// toggle (xor) EscBit (BIT5) if previous byte was an Control Escape Byte
			escape_control=0;				// reset Control Escape Flag
			}
		*p_ppp_rx_buffer++;
		if(p_ppp_rx_buffer >= PPP_RX_BUFFER_END)
			{
			p_ppp_rx_buffer = PPP_RX_BUFFER_START;	  //set pointer to begin of RXbuffer
			while(ppp_rx_table_buffer[ppp_rx_table_write_index].addr < PPP_RX_BUFFER_END)
				*p_ppp_rx_buffer++ = *ppp_rx_table_buffer[ppp_rx_table_write_index].addr++;
			ppp_rx_table_buffer[ppp_rx_table_write_index].addr = PPP_RX_BUFFER_START;
			}
		ppp_rx_buffersize++;
	}// end switch(data)
}// end RX_UART1() interrupt