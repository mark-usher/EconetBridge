// ************************************************************************************************
///
/// \file 			ipsec_sa.c
/// \brief			IPSec Security Association
///
///					Function:	This module contains the Security Association code
///					Here we implement the Security Association concept from RFC 2401.
///					Both SPD and SAD are implemented.
///					At the time we do not support IKE and SA bundling. For having maximum 
///					flexibility two physically different tables (SPD and SAD) were implemented. 
///					They both provide functions to manipulate the database during run-time, 
///					so that a later IKE or SA-bundling could be implemented.
///					The SPD contains the selector fields on which each IP packet needs to be
///					checked. After outbound packets found their SPD entry, they can access the 
///					SA via the SA pointer.
///					Inbound packets can access their SA directly by applying the SPI to the SAD 
///					(by performing an SAD lookup).
///					Each IPsec enabled device needs to have its own set of SPD and SAD for each,
///					inbound and outbound processing. 
///
///					Implementation:
///					To be independent of any memory allocation we store the data from the tables
///					in a statically allocated array. Because entries can be added and removed, 
///					a more flexible method for creating the table is needed. The table itself is 
///					implemented with a doubly linked list. 
///					The data is stored in the array records, but the sequence is determined by the
///					linked-list structure. 
///
///					One database consists of two objects:
///					-# database structure: 		spd_table_mem inbound_spd_table ;
///					-# array for storing data:	spd_entry_mem inbound_spd_data[size] ;
///
///					The 1st object holds the structure of the database (linked-list) while the
///					second one is memory for storing the objects.
///
///					Notes:
///					To create and use a database you should guaranty the following sequence.
///					-# ipsec_sa_load_database(): to initialize the tables
///					-# ipsec_sa_spd_add(): to fill up as many records as the size (usually 
///											IPSEC_MAX_SA_ENTRIES) permits 
///					-# ipsec_sa_spd_del(): to remove entries if required
///					-# ipsec_sa_spd_lookup(): to check packets for a matching entry
///					-# ipsec_sa_release_database(): to clean up
///
///
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		This document is part of embedded IPsec
///					Niklaus Schild and Christian Scheurer, HTI Biel/Bienne
///					This file contains code from the OpenSSL Project<BR>
///					Niklaus Schild <n.schild@gmx.ch> <BR>
///					portions Copyright (c) 1998-2003 OpenSSL (www.openssl.org)
///					easyToWeb-AVR and CodeVisionAVR C-Compiler:
///					Udo Jakobza - FTZ Leipzig; 04107 Leipzig; W�chterstr. 13
///					jakobza@e-technik.htwk-leipzig.de
///
/// \par License    
///					Redistribution and use in source and binary forms, with or without 
///					modification, are permitted provided that the following conditions are met:
///
///					1. Redistributions of source code must retain the above copyright notice,
///					   this list of conditions and the following disclaimer.
///					2. Redistributions in binary form must reproduce the above copyright notice,
///					    this list of conditions and the following disclaimer in the documentation
///					   and/or other materials provided with the distribution.
///					3. The name of the author may not be used to endorse or promote products
///					   derived from this software without specific prior written permission.
///
///					THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
///					WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
///					MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
///					EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
///					EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
///					OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
///					INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
///					CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
///					IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
///					OF SUCH DAMAGE.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef	IPSEC_ENABLE

#include <string.h>
#include "icmp.h"
#include "ip.h"
#include "ipsec_sa.h"
#include "debug.h"
#include "ipsec_sa_debug.h"
#include "ipsec_sa.h"
#ifdef TCP_ENABLE
#include "tcp.h"
#endif
#ifdef UDP_ENABLE
#include "udp.h"
#endif

#pragma regalloc-
#ifdef WEB_DEBUG_IPSEC
unsigned int ipsec_sa_spd_count=0;
unsigned int ipsec_sa_sad_count=0;
#endif
#pragma regalloc+

// --------------------------------------------------------------------------------
// Sequence-Number Table inside of SRAM
// -------------------------------------------------------------------------------- 
sad_seq_table	inbound_seq_table;
sad_seq_table	outbound_seq_table;

// --------------------------------------------------------------------------------
// SAD INBOUND configuration data either EEPROM or SRAM
// -------------------------------------------------------------------------------- 
SA_MEMORY sad_table_mem inbound_sad_default = {{
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x300, 
 IP_IPSEC_AH_PROT,
 IPSEC_TRANSPORT, 
 0, 0, 1450, 
 0,
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 0, 0, 0, 0, 0}, 
 IPSEC_HMAC_MD5,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf, 0, 0, 0, 0},
 &inbound_seq_table.seq[0], &inbound_seq_table.bitmap[0],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x301, 
 IP_IPSEC_AH_PROT,
 IPSEC_TRANSPORT, 
 0, 0, 1450, 
 0,
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 0, 0, 0, 0, 0}, 
 IPSEC_HMAC_SHA1,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf,0xac,0xab,0xef,0xfe},
 &inbound_seq_table.seq[1], &inbound_seq_table.bitmap[1],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x302, 
 IP_IPSEC_AH_PROT,
 IPSEC_TUNNEL, 
 0, 0, 1450, 
 0,
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 0, 0, 0, 0, 0}, 
 IPSEC_HMAC_MD5,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf, 0, 0, 0, 0},
 &inbound_seq_table.seq[2], &inbound_seq_table.bitmap[2],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x303, 
 IP_IPSEC_AH_PROT,
 IPSEC_TUNNEL, 
 0, 0, 1450, 
 0,
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 0, 0, 0, 0, 0}, 
 IPSEC_HMAC_SHA1,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf,0xac,0xab,0xef,0xfe},
 &inbound_seq_table.seq[3], &inbound_seq_table.bitmap[3],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x304, 
 IP_IPSEC_ESP_PROT,
 IPSEC_TRANSPORT, 
 0, 0, 1450, 
 IPSEC_3DES,
 {0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23}, 
 IPSEC_HMAC_MD5,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf, 0, 0, 0, 0},
 &inbound_seq_table.seq[4], &inbound_seq_table.bitmap[4],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x305, 
 IP_IPSEC_ESP_PROT,
 IPSEC_TRANSPORT, 
 0, 0, 1450, 
 IPSEC_3DES,
 {0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23}, 
 IPSEC_HMAC_SHA1,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf,0xac,0xab,0xef,0xfe},
 &inbound_seq_table.seq[5], &inbound_seq_table.bitmap[5],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x306, 
 IP_IPSEC_ESP_PROT,
 IPSEC_TUNNEL, 
 0, 0, 1450, 
 IPSEC_3DES,
 {0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23}, 
 IPSEC_HMAC_MD5,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf, 0, 0, 0, 0},
 &inbound_seq_table.seq[6], &inbound_seq_table.bitmap[6],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x307, 
 IP_IPSEC_ESP_PROT,
 IPSEC_TUNNEL, 
 0, 0, 1450, 
 IPSEC_3DES,
 {0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23}, 
 IPSEC_HMAC_SHA1,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf,0xac,0xab,0xef,0xfe},
 &inbound_seq_table.seq[7], &inbound_seq_table.bitmap[7],
 IPSEC_SA_FREE,
 0}
}};


// --------------------------------------------------------------------------------
// SAD OUTBOUND configuration data either EEPROM or SRAM
// -------------------------------------------------------------------------------- 
SA_MEMORY sad_table_mem outbound_sad_default = {{
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x300, 
 IP_IPSEC_AH_PROT,
 IPSEC_TRANSPORT, 
 0, 0, 1450, 
 0,
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 0, 0, 0, 0, 0}, 
 IPSEC_HMAC_MD5,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf, 0, 0, 0, 0},
 &outbound_seq_table.seq[0], &outbound_seq_table.bitmap[0],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x301, 
 IP_IPSEC_AH_PROT,
 IPSEC_TRANSPORT, 
 0, 0, 1450, 
 0,
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 0, 0, 0, 0, 0}, 
 IPSEC_HMAC_SHA1,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf,0xac,0xab,0xef,0xfe},
 &outbound_seq_table.seq[1], &outbound_seq_table.bitmap[1],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x302, 
 IP_IPSEC_AH_PROT,
 IPSEC_TUNNEL, 
 0, 0, 1450, 
 0,
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 0, 0, 0, 0, 0}, 
 IPSEC_HMAC_MD5,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf, 0, 0, 0, 0},
 &outbound_seq_table.seq[2], &outbound_seq_table.bitmap[2],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x303, 
 IP_IPSEC_AH_PROT,
 IPSEC_TUNNEL, 
 0, 0, 1450, 
 0,
 {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 , 0, 0, 0, 0, 0}, 
 IPSEC_HMAC_SHA1,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf,0xac,0xab,0xef,0xfe},
 &outbound_seq_table.seq[3], &outbound_seq_table.bitmap[3],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x304, 
 IP_IPSEC_ESP_PROT,
 IPSEC_TRANSPORT, 
 0, 0, 1450, 
 IPSEC_3DES,
 {0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23}, 
 IPSEC_HMAC_MD5,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf, 0, 0, 0, 0},
 &outbound_seq_table.seq[4], &outbound_seq_table.bitmap[4],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x305, 
 IP_IPSEC_ESP_PROT,
 IPSEC_TRANSPORT, 
 0, 0, 1450, 
 IPSEC_3DES,
 {0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23}, 
 IPSEC_HMAC_SHA1,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf,0xac,0xab,0xef,0xfe},
 &outbound_seq_table.seq[5], &outbound_seq_table.bitmap[5],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x306, 
 IP_IPSEC_ESP_PROT,
 IPSEC_TUNNEL, 
 0, 0, 1450, 
 IPSEC_3DES,
 {0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23}, 
 IPSEC_HMAC_MD5,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf, 0, 0, 0, 0},
 &outbound_seq_table.seq[6], &outbound_seq_table.bitmap[6],
 IPSEC_SA_FREE,
 0},
{{192,168,1,21}, 
 {255,255,255,255}, 
 0x307, 
 IP_IPSEC_ESP_PROT,
 IPSEC_TUNNEL, 
 0, 0, 1450, 
 IPSEC_3DES,
 {0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23, 0x23,0x23,0x23,0x23}, 
 IPSEC_HMAC_SHA1,  
 {0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf,0xac,0xab,0xef,0xfe},
 &outbound_seq_table.seq[7], &outbound_seq_table.bitmap[7],
 IPSEC_SA_FREE,
 0}
}};

// --------------------------------------------------------------------------------
// SPD INBOUND configuration data either EEPROM or SRAM
// -------------------------------------------------------------------------------- 
SA_MEMORY spd_table_mem inbound_spd_default = {{
//    source                            destination                          ports      protocol          policy        SA  
//    address          mask             address                mask        src  dest                              
{{192,168,  1,  0}, {255,255,255,  0}, {192,168,  1,  21}, {255,255,255,255},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &inbound_sad_default.entry[0], IPSEC_SA_FREE, 0},
{{192,168,  1,  0}, {255,255,255,  0}, {192,168,  1,  21}, {255,255,255,255},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &inbound_sad_default.entry[1], IPSEC_SA_FREE, 0},
{{192,168,  1,  0}, {255,255,255,  0}, {192,168,  1,  21}, {255,255,255,255},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &inbound_sad_default.entry[2], IPSEC_SA_FREE, 0},
{{192,168,  1,  0}, {255,255,255,  0}, {192,168,  1,  21}, {255,255,255,255},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &inbound_sad_default.entry[3], IPSEC_SA_FREE, 0},
{{192,168,  1,  0}, {255,255,255,  0}, {192,168,  1,  21}, {255,255,255,255},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &inbound_sad_default.entry[4], IPSEC_SA_FREE, 0},
{{192,168,  1,  0}, {255,255,255,  0}, {192,168,  1,  21}, {255,255,255,255},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &inbound_sad_default.entry[5], IPSEC_SA_FREE, 0},
{{192,168,  1,  0}, {255,255,255,  0}, {192,168,  1,  21}, {255,255,255,255},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &inbound_sad_default.entry[6], IPSEC_SA_FREE, 0},
{{192,168,  1,  0}, {255,255,255,  0}, {192,168,  1,  21}, {255,255,255,255},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &inbound_sad_default.entry[7], IPSEC_SA_FREE, 0},
{{192,168,  1,  0}, {255,255,255,  0}, {192,168,  1,  21}, {255,255,255,255},  0,  0, IP_TCP_PROT      , POLICY_BYPASS , NULL, IPSEC_SA_FREE, 0},
{{192,168,  1,  0}, {255,255,255,  0}, {192,168,  1,  21}, {255,255,255,255},  0,  0, IP_TCP_PROT      , POLICY_APPLY  , &inbound_sad_default.entry[0], IPSEC_SA_FREE, 0},
{{192,168,  1,  0}, {255,255,255,  0}, {192,168,  1,  21}, {255,255,255,255},  0,  0, IP_TCP_PROT      , POLICY_APPLY  , &inbound_sad_default.entry[7], IPSEC_SA_FREE, 0},
{{192,168,  1,  0}, {255,255,255,  0}, {192,168,  1,  21}, {255,255,255,255},  0,  0, IP_ICMP_PROT     , POLICY_BYPASS , NULL, IPSEC_SA_USED, 0}
}};


// --------------------------------------------------------------------------------
// SPD OUTBOUND configuration data either EEPROM or SRAM
// -------------------------------------------------------------------------------- 
SA_MEMORY spd_table_mem outbound_spd_default = {{
//    source                            destination                          ports      protocol          policy        SA  
//    address          mask             address                mask        src  dest                              
{{192,168,  1,  21}, {255,255,255,255}, {192,168,  1,  0}, {255,255,255,  0},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &outbound_sad_default.entry[0], IPSEC_SA_FREE, 0},
{{192,168,  1,  21}, {255,255,255,255}, {192,168,  1,  0}, {255,255,255,  0},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &outbound_sad_default.entry[1], IPSEC_SA_FREE, 0},
{{192,168,  1,  21}, {255,255,255,255}, {192,168,  1,  0}, {255,255,255,  0},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &outbound_sad_default.entry[2], IPSEC_SA_FREE, 0},
{{192,168,  1,  21}, {255,255,255,255}, {192,168,  1,  0}, {255,255,255,  0},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &outbound_sad_default.entry[3], IPSEC_SA_FREE, 0},
{{192,168,  1,  21}, {255,255,255,255}, {192,168,  1,  0}, {255,255,255,  0},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &outbound_sad_default.entry[4], IPSEC_SA_FREE, 0},
{{192,168,  1,  21}, {255,255,255,255}, {192,168,  1,  0}, {255,255,255,  0},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &outbound_sad_default.entry[5], IPSEC_SA_FREE, 0},
{{192,168,  1,  21}, {255,255,255,255}, {192,168,  1,  0}, {255,255,255,  0},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &outbound_sad_default.entry[6], IPSEC_SA_FREE, 0},
{{192,168,  1,  21}, {255,255,255,255}, {192,168,  1,  0}, {255,255,255,  0},  0,  0, IP_ICMP_PROT     , POLICY_APPLY  , &outbound_sad_default.entry[7], IPSEC_SA_FREE, 0},
{{192,168,  1,  21}, {255,255,255,255}, {192,168,  1,  0}, {255,255,255,  0},  0,  0, IP_TCP_PROT      , POLICY_BYPASS , NULL, IPSEC_SA_FREE, 0},
{{192,168,  1,  21}, {255,255,255,255}, {192,168,  1,  0}, {255,255,255,  0},  0,  0, IP_TCP_PROT      , POLICY_APPLY  , &outbound_sad_default.entry[0], IPSEC_SA_FREE, 0},
{{192,168,  1,  21}, {255,255,255,255}, {192,168,  1,  0}, {255,255,255,  0},  0,  0, IP_TCP_PROT      , POLICY_APPLY  , &outbound_sad_default.entry[7], IPSEC_SA_FREE, 0},
{{192,168,  1,  21}, {255,255,255,255}, {192,168,  1,  0}, {255,255,255,  0},  0,  0, IP_ICMP_PROT     , POLICY_BYPASS , NULL, IPSEC_SA_USED, 0}
}};

// --------------------------------------------------------------------------------
// Default SPD Entry to handle the first connections
// -------------------------------------------------------------------------------- 
flash spd_entry_fl spd_default_flash =
{IPSEC_SPD_DEF_SRC, IPSEC_SPD_DEF_SRC_MASK, IPSEC_SPD_DEF_DEST, IPSEC_SPD_DEF_DEST_MASK, 
IPSEC_SPD_DEF_SRC_PORT,  IPSEC_SPD_DEF_DEST_PORT, IPSEC_SPD_DEF_PROTOCOL | (IPSEC_SPD_DEF_POLICY<<8), 0xaa55, IPSEC_SA_USED};


// --------------------------------------------------------------------------------
// This structure holds sets of databases used by one network interface. Each successful call of 
// ipsec_sa_load_database() will return a pointer to an entry of this structure array. One entry holds
// pointers to a inbound and outbound SPD and SAD table.  
// -------------------------------------------------------------------------------- 
SA_MEMORY db_set_netif	db_sets={&inbound_spd_default, &outbound_spd_default,
						&inbound_sad_default, &outbound_sad_default};


//---------------------------------------------------------------------------------
// Database functions
//---------------------------------------------------------------------------------

//*********************************************************************************
// Description	: This function initializes the database set, allocated in a per-network manner.
//                -# First the function gets a free entry (set of structs) out of the db_sets table.
//                -# Then it sets the pointer of this struct members.
//                -# On all entries in the table which are not already filled are set to IPSEC_SA_FREE.
//                -# In the last and most ugly part of this function tables are linked together so that the linked
//                   list is setup properly.
// Input   		: 
//           @param inbound_spd_data 	pointer to a table where inbound Security Policies will be stored
//           @param outbound_spd_data pointer to a table where outbound Security Policies will be stored
//           @param inbound_sad_data 	pointer to a table where inbound Security Associations will be stored
//           @param outbound_sad_data pointer to a table where outbound Security Associations will be stored
//
// Output  		: @return pointer to the initialized set of DB's if the setup was successful
//                @return NULL if loading failed
// Indication	: 
// The data which is passed by the pointers should not be used by other functions except the 
// ones of the SA-module. The data passed can be viewed as a place where the SA-module can store its
// data (Security Policies or Security Associations). 
// The tables which are passed to the function can already be filled up with static configuration
// data. You can use the SPD_ENTRY and the SAD_ENTRY macro to do this in a nice way.
//*********************************************************************************
SA_MEMORY db_set_netif	*ipsec_sa_load_database(spd_table *inbound_spd_data, spd_table *outbound_spd_data, 
  										sad_table *inbound_sad_data, sad_table *outbound_sad_data)
{
//WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) load_database inbound_spd=%x, outbound_spd=%x, inbound_sad=%x, outbound_sad=%x\r\n", 
//						inbound_spd_data, outbound_spd_data, inbound_sad_data, outbound_sad_data));
#ifdef IPSEC_SA_MEMORY_SRAM
if(inbound_spd_data)
	memcpy(db_sets.inbound_spd, inbound_spd_data, sizeof(db_sets.inbound_spd));
if(outbound_spd_data)
	memcpy(db_sets.outbound_spd, outbound_spd_data, sizeof(db_sets.outbound_spd));
if(inbound_sad_data)
	memcpy(db_sets.inbound_sad, inbound_sad_data, sizeof(db_sets.inbound_sad));
if(outbound_sad_data)
	memcpy(db_sets.outbound_sad, outbound_sad_data, sizeof(db_sets.outbound_sad));
#else
// index points now the a free entry which is filled with the initialization data
if(inbound_spd_data)
	util_memcpy2e(db_sets.inbound_spd, inbound_spd_data, sizeof(db_sets.inbound_spd));
if(outbound_spd_data)
	util_memcpy2e(db_sets.outbound_spd, outbound_spd_data, sizeof(db_sets.outbound_spd));
if(inbound_sad_data)
	util_memcpy2e(db_sets.inbound_sad, inbound_sad_data, sizeof(db_sets.inbound_sad));
if(outbound_sad_data)
	util_memcpy2e(db_sets.outbound_sad, outbound_sad_data, sizeof(db_sets.outbound_sad));
#endif	// IPSEC_SA_MEMORY_SRAM
return &db_sets;
}

//*********************************************************************************
// Description	: This function is used to release the structure allocated in ipsec_sa_load_database().
// Input	   	: none
// Output     	: none
// Indication	: The tables which were allocated in ipsec_sa_load_database() can now be freely used.
//*********************************************************************************
void ipsec_sa_release_database(void)
{
WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) release_database\r\n"));
ipsec_sa_spd_flush(db_sets.inbound_spd, 0x0);
ipsec_sa_spd_flush(db_sets.outbound_spd, 0x0);
ipsec_sa_sad_flush(db_sets.inbound_sad);
ipsec_sa_sad_flush(db_sets.outbound_sad);
}

//---------------------------------------------------------------------------------
// SPD functions
//---------------------------------------------------------------------------------
//*********************************************************************************
// Description	: Gives back a pointer to the next free entry from the given SPD table.
// Input	   	: @param table pointer to the SPD table 
// Output     	: @return pointer to the free entry if one was found
//                @return NULL if no free entry was found
// Indication	: none
//*********************************************************************************
SA_MEMORY spd_entry_mem *ipsec_sa_spd_get_free(SA_MEMORY spd_table_mem *table)
{
unsigned char index;

// find first free entry
for(index = 0; index < IPSEC_MAX_SPD_ENTRIES; index++)
	{
	if(table->entry[index].use_flag == IPSEC_SA_FREE)
		{
		WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) spd_get_free entry=0x%x\r\n", &table->entry[index]));
		return &table->entry[index];
		}
	}
WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) spd_get_free - no entry table=0x%x\r\n", table));
return NULL;
}

//*********************************************************************************
// Description	: Adds a Security Policy to an SPD table.
//                -# This function first gets an empty entry out of the table passed by ipsec_sa_load_database().
//                -# If a free place was found, then the function arguments are copied to the appropriate place. 
// Input	   	: @param src		IP source address
//                @param src_net	Netmask for the source address
//                @param dst		IP destination address
//                @param dst_net	Netmask for the destination address
//                @param proto		Transport protocol 
//                @param src_port	Source Port
//                @param dst_port	Destination Port
//                @param policy	The policy defining how the packet matching the entry must be processed
//                @param table		Pointer to the SPD table
// Output     	: @return A pointer to the added entry when adding was successful
//                @return NULL when the entry could not have been added (no free entry or duplicate) 
// Indication	: 
// The SPD entries are added to a statically allocated array of SPD structs. The size
// is defined by IPSEC_MAX_SPD_ENRIES, so there cannot be added more entries added as this
// constant. 
// The order of the entries within the table is not the same as the order within the array. 
// The "table functionality" is implemented in a linked-list, so one must follow the links of 
// the structure to get to the next entry.
//*********************************************************************************
SA_MEMORY spd_entry_mem *ipsec_sa_spd_add(spd_entry *new_entry, SA_MEMORY spd_table_mem *table)
{
SA_MEMORY spd_entry_mem *free_entry ;

free_entry = ipsec_sa_spd_get_free(table);
if(free_entry == NULL) 
	{
	WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) spd_add no entry\r\n"));
	return NULL ;
	}
// add the fields to the entry
new_entry->use_flag = IPSEC_SA_USED;
#ifdef IPSEC_SA_MEMORY_SRAM
memcpy(free_entry, new_entry, sizeof(spd_entry_mem));
#else
//web_debug_display_frame((unsigned char*)new_entry, sizeof(spd_entry), sizeof(spd_entry));
util_memcpy2e(free_entry, new_entry, sizeof(spd_entry_mem));
#endif
WEB_DEBUG_IPSEC_SA_MSG_SPD(("IPSEC-SA(xx) spd_add:\r\n"), free_entry);
return free_entry;
}

//*********************************************************************************
// Description	: Adds a Security Association to a Security Police.
// Input	   	: @param entry 	pointer to the SPD entry where the SA should be added
//                @param sa		a pointer to the SA which is added to the SPD
// Output     	: none
// Indication	: none
//*********************************************************************************
void ipsec_sa_spd_add_sa(SA_MEMORY spd_entry_mem *entry, SA_MEMORY sad_entry_mem *sa)
{
entry->sa = sa;
WEB_DEBUG_IPSEC_SA_MSG_SAD(("IPSEC-SA(xx) spd_add_sa: 0x%x\r\n", entry), sa);
}


//*********************************************************************************
// Description	: Deletes an Security Policy from an SPD table.
// Input	   	: @param entry Pointer to the SPD entry which needs to be deleted
//                @param table Pointer to the SPD table
// Output     	: 
// @return IPSEC_STATUS_SUCCESS	entry was deleted properly
// @return IPSEC_STATUS_FAILURE entry could not be deleted because not found a pointer
// Indication	: This function is simple. If the pointer is within the range of the 
//                table, then the entry is cleared. If the pointer does not match, 
//                nothing happens.
//*********************************************************************************
unsigned char ipsec_sa_spd_del(SA_MEMORY spd_entry_mem *entry, SA_MEMORY spd_table_mem *table)
{
unsigned char index;

for(index = 0; index < IPSEC_MAX_SPD_ENTRIES; index++)
	{
	if(table->entry[index] == entry)
		{
		entry->use_flag=IPSEC_SA_FREE;	// clear entry
		WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) spd_del OK entry=0x%x, table=0x%x\r\n", entry, table));
		return 1;
		}
	}
WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) spd_del ERROR entry=0x%x, table=0x%x\r\n", entry, table));
return 0;
}


//*********************************************************************************
// Description	: simple function to check the IP-Address with Submask
// Input	   	: @param ip 		pointer to Input IP-Address
//                @param address	pointer to SA IP-Address
//                @param mask		pointer to Submask
// Output     	: @return 0	mismatch
//                @return 1	IP-Address OK
// Indication	: none
//*********************************************************************************
unsigned char ipsec_sa_ip_addr_maskcmp(unsigned char *ip, SA_MEMORY unsigned char *address, SA_MEMORY unsigned char *mask)
{
if(!(((ip[0] ^ address[0]) & mask[0])|| 
    ((ip[1] ^ address[1]) & mask[1])||
    ((ip[2] ^ address[2]) & mask[2])||
    ((ip[3] ^ address[3]) & mask[3])))
	return 1;
return 0;
}



//*********************************************************************************
// Description	: Returns an pointer to an SPD entry which matches the packet.
//                Inbound packets must be checked against the inbound SPD and outbound
//                packets must be checked against the outbound SPD.
// Input	   	: @param	header			Pointer to an IP packet which is checked
//                @param 	inner_header	Pointer to the Data of IP-Frame (UDP, TCP, ICMP ..)
//                @param 	table			Pointer to the SPD inbound/outbound table
// Output     	: @return 	Pointer to the matching SPD entry
//                @return 	NULL if no entry matched 
// Indication	: This function checks all the selector fields of the SPD table. 
//                The port numbers are only checked if the protocol is TCP or UDP.
//                An entry which has a value of 0 is the same as the '*' which means 
//                everything.
//*********************************************************************************
SA_MEMORY spd_entry_mem	*ipsec_sa_spd_lookup(IP_HEADER_STRUCTURE *header, void *inner_header, 
							SA_MEMORY spd_table_mem *table, unsigned char mode)
{
#ifdef WEB_DEBUG_IPSEC			// enable IPSec debug functions, see ipsec.c
flash unsigned char *in_out_string;
#endif
unsigned char 			index;
SA_MEMORY spd_entry_mem	*tmp_entry;
#ifdef TCP_ENABLE
TCP_HEADER_STRUCTURE	*tcp_header;
#endif
#ifdef UDP_ENABLE
UDP_HEADER_STRUCTURE	*udp_header;
#endif
#ifdef ICMP_ENABLE
ICMP_HEADER_STRUCTURE	*icmp_header;
#endif

#ifdef WEB_DEBUG_IPSEC			// enable IPSec debug functions, see ipsec.c
if(mode)
	in_out_string="OUT";
else
	in_out_string="IN";
#endif
// compare and return when all fields match
for(index = 0; index < IPSEC_MAX_SPD_ENTRIES; index++)
	{
	tmp_entry=table->entry[index];	// set entry
	if(tmp_entry->use_flag == IPSEC_SA_USED)
		{
		if((ipsec_sa_ip_addr_maskcmp(header->source, tmp_entry->src, tmp_entry->src_netaddr))&&
		   (ipsec_sa_ip_addr_maskcmp(header->destination, tmp_entry->dest, tmp_entry->dest_netaddr))&&
		   (header->protocol == tmp_entry->protocol))
			{
			#ifdef TCP_ENABLE
			tcp_header=(TCP_HEADER_STRUCTURE*)inner_header;
			if(header->protocol == IP_TCP_PROT)	  		// Transmission Control Protocol
				{
				if(((tmp_entry->src_port==0)||(tmp_entry->src_port==tcp_header->src))&&
				   ((tmp_entry->dest_port==0)||(tmp_entry->dest_port==tcp_header->dest)))
					{
					WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-%p-SA(%u) spd_lookup TCP entry: %u\r\n", in_out_string, ipsec_sa_spd_count, index));
					return tmp_entry;
					}
				else
					{
					//WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-%p-SA(%u) TCP-Src:%u/%u TCP-Dest:%u/%u\r\n", in_out_string,
					//	ipsec_sa_spd_count, tcp_header->src, tmp_entry->src_port, tcp_header->dest, tmp_entry->dest_port));
					}
				}
			#endif	// #ifdef TCP_ENABLE
			#ifdef UDP_ENABLE
			udp_header=(UDP_HEADER_STRUCTURE*)inner_header;
			if(header->protocol == IP_UDP_PROT)	// User Datagram Protocol
				{
				if(((tmp_entry->src_port==0)||(tmp_entry->src_port==udp_header->src))&&
				   ((tmp_entry->dest_port==0)||(tmp_entry->dest_port==udp_header->dest)))
					{
					WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-%p-SA(%u) spd_lookup UDP entry: %u\r\n", in_out_string, ipsec_sa_spd_count, index));
					return tmp_entry;
					}
				} 
			#endif	// #ifdef UDP_ENABLE
			#ifdef ICMP_ENABLE
			icmp_header=(ICMP_HEADER_STRUCTURE*)inner_header;
			if(header->protocol == IP_ICMP_PROT)	// Internet Control Message Protocol
				{
				WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-%p-SA(%u) spd_lookup ICMP entry: %u\r\n", in_out_string, ipsec_sa_spd_count, index));
				return tmp_entry;
				}
			#endif	// #ifdef ICMP_ENABLE
			//WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(%u) spd_lookup no protocol\r\n", ipsec_sa_spd_count));
			}
		}
	}
WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-%p-SA(%u) spd_lookup NO hit\r\n", in_out_string, ipsec_sa_spd_count));
return NULL ;
}


//*********************************************************************************
// Description	: Returns an pointer to an SPD entry of inbound-table, see "ipsec_sa_spd_lookup"
// Input	   	: @param	header			Pointer to an IP packet which is checked
//                @param 	inner_header	Pointer to the Data of IP-Frame (UDP, TCP, ICMP ..)
// Output     	: @return 	Pointer to the matching SPD entry
//                @return 	NULL if no entry matched 
// Indication	: see "ipsec_sa_spd_lookup"
//*********************************************************************************
SA_MEMORY spd_entry_mem *ipsec_sa_spd_lookup_in(IP_HEADER_STRUCTURE *header, void *inner_header)
{
#ifdef WEB_DEBUG_IPSEC
ipsec_sa_spd_count=ipsec_in_count;
#endif
return ipsec_sa_spd_lookup(header, inner_header, db_sets.inbound_spd, 0);
}

//*********************************************************************************
// Description	: Returns an pointer to an SPD entry of outbound-table, see "ipsec_sa_spd_lookup"
// Input	   	: @param	header			Pointer to an IP packet which is checked
//                @param 	inner_header	Pointer to the Data of IP-Frame (UDP, TCP, ICMP ..)
// Output     	: @return 	Pointer to the matching SPD entry
//                @return 	NULL if no entry matched 
// Indication	: see "ipsec_sa_spd_lookup"
//*********************************************************************************
SA_MEMORY spd_entry_mem *ipsec_sa_spd_lookup_out(IP_HEADER_STRUCTURE *header, void *inner_header)
{
#ifdef WEB_DEBUG_IPSEC
ipsec_sa_spd_count=ipsec_out_count;
#endif
return ipsec_sa_spd_lookup(header, inner_header, db_sets.outbound_spd, 1);
}

//*********************************************************************************
// Description	: Flushes an SPD table and sets a new default entry. The default 
//                entry allows to keep a door open for IKE.
// Input	   	: @param table			pointer to the SPD table
//                @param def_entry 		pointer to the default entry
// Output     	: @return IPSEC_STATUS_SUCCESS if the flush was successful
//                @return IPSEC_STATUS_FAILURE if the flush failed
// Indication	: none
//*********************************************************************************
void ipsec_sa_spd_flush(SA_MEMORY spd_table_mem *table, flash spd_entry_fl *def_entry)
{
unsigned char	index;
spd_entry		free_entry_buffer;

for(index = 0; index < IPSEC_MAX_SPD_ENTRIES; index++)
	table->entry[index].use_flag = IPSEC_SA_FREE;	// clear entry
if(def_entry)
	{
	memcpyf(&free_entry_buffer, def_entry, sizeof(spd_entry_mem));
	// add the fields to the entry
	ipsec_sa_spd_add(&free_entry_buffer, table);
	}
WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) spd_flush table:0x%x\r\n", table));
}



//---------------------------------------------------------------------------------
// SAD functions
//---------------------------------------------------------------------------------


//*********************************************************************************
// Description	: Gives back a pointer to the next free entry from the given SA table.
// Input	   	: @param	table			pointer to the SA table 
// Output     	: @return	pointer to the free entry if one was found
//                @return	NULL if no free entry was found
// Indication	: none
//*********************************************************************************
SA_MEMORY sad_entry_mem *ipsec_sa_sad_get_free(SA_MEMORY sad_table_mem *table)
{
unsigned char index;

// find first free entry
for(index = 0; index < IPSEC_MAX_SAD_ENTRIES; index++)
	{
	if(table->entry[index].use_flag == IPSEC_SA_FREE)
		{
		WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) sad_get_free entry=0x%x\r\n", &table->entry[index]));
		return &table->entry[index];
		}
	}
WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) sad_get_free - no entry table=0x%x\r\n", table));
return NULL;
}


//*********************************************************************************
// Description	: Adds an Security Association to an SA table.
//                -# This function first gets an empty entry out of the table passed 
//                   by ipsec_sa_load_database().
//                -# If a free place was found, then the function arguments are copied 
//                   to the appropriate place. 
// Input	   	: @param entry		pointer to the SA structure which will be copied into the table
//                @param table		pointer to the table where the SA is added
// Output     	: @return A pointer to the added entry when adding was successful
//                @return NULL when the entry could not have been added (no free entry or duplicate) 
// Indication	: 
// The SA entries are added to a statically allocated array of SAD structs. The size
// is defined by IPSEC_MAX_SAD_ENTRIES, so there cannot be added more entries added as this
// constant. 
// The order of the entries within the table is not the same as the order within the array. 
// The "table functionality" is implemented in a linked-list, so one must follow the links of 
// the structure to get to the next entry.
//*********************************************************************************
SA_MEMORY sad_entry_mem *ipsec_sa_sad_add(sad_entry *entry, SA_MEMORY sad_table_mem *table) 
{
SA_MEMORY sad_entry_mem 	*free_entry;

free_entry = ipsec_sa_sad_get_free(table);
if(free_entry == NULL) 
	{
	WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) sad_add no entry\r\n"));
	return NULL;
	}
// copy the fields
free_entry->use_flag = IPSEC_SA_USED;
#ifdef IPSEC_SA_MEMORY_SRAM
memcpy(free_entry, entry, sizeof(sad_entry_mem));
#else
util_memcpy2e(free_entry, entry, sizeof(sad_entry_mem));
#endif
WEB_DEBUG_IPSEC_SA_MSG_SAD(("IPSEC-SA(xx) sad_add:\r\n"), free_entry);
return free_entry ;
}


//*********************************************************************************
// Description	: Deletes an Security Association from an SA table.
// Input	   	: @param entry Pointer to the SA entry which needs to be deleted
//                @param table Pointer to the SA table
// Output     	: @return IPSEC_STATUS_SUCCESS	entry was deleted properly
//                @return IPSEC_STATUS_FAILURE	entry could not be deleted because not found, or invalid pointer
// Indication	: This function is simple. If the pointer is within the range of the 
//                table, then the entry is cleared. If the pointer does not match, 
//                nothing happens.
//*********************************************************************************
unsigned char ipsec_sa_sad_del(SA_MEMORY sad_entry_mem *entry, SA_MEMORY sad_table_mem *table) 
{
unsigned char 	index;

for(index = 0; index < IPSEC_MAX_SAD_ENTRIES; index++)
	{
	if(table->entry[index] == entry)
		{
		table->entry[index].use_flag=IPSEC_SA_FREE;	// clear entry
		WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) sad_del OK entry=0x%x, table=0x%x\r\n", entry, table));
		return 1;
		}
	}
WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) sad_del ERROR entry=0x%x, table=0x%x\r\n", entry, table));
return 0;
}


//*********************************************************************************
// Description	: Gives back a pointer to a SA matching the SA selectors.
//                It simply loops over all entries and returns the first match.
// Input	   	: @param dest	destination IP address
//                @param proto	IPsec protocol
//                @param spi	Security Parameters Index
//                @param table	pointer to the SAD table
// Output     	: @return pointer to the SA entry if one matched
//                @return NULL if no matching entry was found
// Indication	: For incoming packets the IPsec packet must be checked against the inbound SAD and
//                for outgoing packets the packet must be checked against the outbound SAD.
//                This function is simple. If the pointer is within the range of the 
//*********************************************************************************
SA_MEMORY sad_entry_mem *ipsec_sa_sad_lookup(unsigned char *dest, unsigned char proto, unsigned long spi, SA_MEMORY sad_table_mem *table)
{
unsigned char 			index;
SA_MEMORY sad_entry_mem	*tmp_entry;

// compare and return when all fields match
for(index = 0; index < IPSEC_MAX_SPD_ENTRIES; index++)
	{
	tmp_entry=table->entry[index];	// set entry
	if(tmp_entry->use_flag == IPSEC_SA_USED)
		{
		if((ipsec_sa_ip_addr_maskcmp(dest, tmp_entry->dest, tmp_entry->dest_netaddr))&&
		   (tmp_entry->protocol == proto)&&
		   (tmp_entry->spi == spi))
			{
			WEB_DEBUG_IPSEC_SA_MSG_SAD(("IPSEC-SA(%u) sad_lookup:%u\r\n", ipsec_sa_sad_count, index), tmp_entry);
			return tmp_entry ;
			}
		}
	}
WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(%u) sad_lookup NO hit\r\n", ipsec_sa_sad_count));
return NULL ;
}


//*********************************************************************************
// Description	: Gives back a pointer to a SA matching the SA inbound-table.
//                It simply loops over all entries and returns the first match.
// Input	   	: @param dest	destination IP address
//                @param proto	IPsec protocol
//                @param spi	Security Parameters Index
// Output     	: @return pointer to the SA entry if one matched
//                @return NULL if no matching entry was found
// Indication	: checks against the inbound SAD
//*********************************************************************************
SA_MEMORY sad_entry_mem *ipsec_sa_sad_lookup_in(unsigned char *dest, unsigned char proto, unsigned long spi)
{
#ifdef WEB_DEBUG_IPSEC
ipsec_sa_sad_count=ipsec_in_count;
#endif
return ipsec_sa_sad_lookup(dest, proto, spi, db_sets.inbound_sad);
}

//*********************************************************************************
// Description	: Flushes an SAD table.
// Input	   	: @param table	pointer to the SAD table
// Output     	: @return IPSEC_STATUS_SUCCESS if the flush was successful
// Indication	: none
//*********************************************************************************
void ipsec_sa_sad_flush(SA_MEMORY sad_table_mem *table)
{
unsigned char 	index;

for(index = 0; index < IPSEC_MAX_SAD_ENTRIES; index++)
	{
	table->entry[index].use_flag=IPSEC_SA_FREE;	// clear entry
	if(table->entry[index].seq!=NULL)
		*table->entry[index].seq=0;
	if(table->entry[index].bitfield!=NULL)
		*table->entry[index].bitfield=0;
	}
WEB_DEBUG_IPSEC_SA_MSG(("IPSEC-SA(xx) sad_flush table:0x%x\r\n", table));
}

#endif	// #ifdef	IPSEC_ENABLE
