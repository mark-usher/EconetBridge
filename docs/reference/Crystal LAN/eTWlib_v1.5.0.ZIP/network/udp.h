// ************************************************************************************************
///
/// \file 			udp.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _UDP_INCLUDED_
#define _UDP_INCLUDED_

// --------------------------------------------------------------------------------
// include header-files
// -------------------------------------------------------------------------------- 
#include "project.h"			// Project configuration
#include "ip.h"
#include "ethernet.h"
#ifdef IPSEC_ENABLE
#include "ipsec.h"
#endif

// --------------------------------------------------------------------------------
// UDP Port definitions
// -------------------------------------------------------------------------------- 
#define UDP_PORT_BOOTP_SERVER		67			// Bootstrap-Protocol Client to Server
#define UDP_PORT_BOOTP_CLIENT		68			// Bootstrap-Protocol Server to Client
#define UDP_PORT_TFTP				69			// Trivial-File-Transfer-Protocol	

// --------------------------------------------------------------------------------
// UDP layer definitions
// -------------------------------------------------------------------------------- 
#define UDP_SRCPORT_OFS				IP_DATA_OFS + 0     // Source Port (16 bit)
#define UDP_DESTPORT_OFS			IP_DATA_OFS + 2     // Destination Port (16 bit)
#define UDP_LEN_OFS					IP_DATA_OFS + 4     // frame-length (16 bit)
#define UDP_CHKSUM_OFS				IP_DATA_OFS + 6     // Checksum (16 bit)
#define UDP_DATA_OFS				IP_DATA_OFS + 8     // UDP-Frame Data
#define UDP_HEADER_SIZE				8
#define UDP_ALL_HEADER_SIZE			(ETH_HEADER_SIZE+IP_HEADER_SIZE+IPSEC_ADD_SIZE+UDP_HEADER_SIZE)

#ifndef UDP_TX_DATA_SIZE
#define	UDP_TX_DATA_SIZE	  		50			// default transmit data size
#endif

#ifndef UDP_RX_DATA_SIZE
#define	UDP_RX_DATA_SIZE			50			// default receive data size
#endif

#ifndef UDP_MAX_CONNECTIONS
#define UDP_MAX_CONNECTIONS			1
#endif

#if(UDP_MAX_CONNECTIONS==0)
#error ERROR: UDP no "UDP_MAX_CONNECTIONS" !!!
#endif

#define UDP_WRONG_CONNECTIONS		0xFF  	   	// no UDP connections available

// --------------------------------------------------------------------------------
// see variable "udp_flags"
// -------------------------------------------------------------------------------- 
#define UDP_FLAG_OPEN 				0x01		// no connection
#define UDP_FLAG_PASSIVE				0x02		// server connection
#define UDP_FLAG_ACTIVE		 		0x04		// client connection
#define UDP_FLAG_BIND				0x08		// transmit buffer full and ready to transmit
#define UDP_DATA_AVAILABLE			0x10		// new receive-data available
#define UDP_TX_BUF_FREE				0x20		// user may fill buffer
#define UDP_TX_BUF_HALF_FULL		0x40		// some place inside of UDP-TX--Buffer
#define UDP_TX_BUF_FULL				0x80		// transmit buffer full and ready to transmit


//  --------------------------------------------------------------------------------
//	UDP-Header structure
//  -------------------------------------------------------------------------------- 
typedef struct{
	unsigned int port_src;		// source port number
	unsigned int port_dest;		// destination port number
	unsigned int length;		// length of UDP header and data
	unsigned int checksum;		// checksum
} UDP_HEADER_STRUCTURE;

//  --------------------------------------------------------------------------------
//	UDP-Buffer structure
//  -------------------------------------------------------------------------------- 
typedef struct{
	unsigned char			udp_flags;					// flag to signal new data with correct IP and Port
	unsigned int 			udp_port_local;				// UDP ports
	unsigned int 			udp_port_remote;
	unsigned char			udp_ip_remote[IP_ADR_SIZE];	// ip remote address
	unsigned char			udp_mac_remote[6];			// MAC of this UDP-session
	unsigned int 			udp_tx_data_count;			// count of UDP-data bytes to send
	unsigned int 			udp_tx_all_count;			// count of all UDP-data bytes to send
	unsigned char 			udp_tx_frame[UDP_ALL_HEADER_SIZE + UDP_TX_DATA_SIZE];	// pointer to header + data
	unsigned char 			*udp_tx_data_position;	 	// pointer to data
	unsigned int 			udp_rx_data_count;			// number of bytes rec'd
	unsigned char 			udp_rx_frame[UDP_RX_DATA_SIZE];// space for incoming UDP-data
} UDP_STRUCTURE;                                    	

#pragma used+
void			udp_init(void);
UDP_STRUCTURE 	*udp_get_struct(unsigned char udp_connection);
unsigned char	udp_open(unsigned int udp_local_port, unsigned char *dest_mac_address, unsigned char *dest_ip_address, 
							unsigned int dest_port, unsigned char udp_flag);
void			udp_close(unsigned char udp_connection);
unsigned int 	udp_tx_buffer_prepare(unsigned char udp_connection, unsigned char *data, unsigned int datalen);// initiate transfer after TxBuffer is filled
void			udp_rx_buffer_release(unsigned char udp_connection);
void			udp_main(void);
unsigned char 	udp_bind(unsigned char udp_connection, unsigned char *dest_mac_address, unsigned char *dest_ip_address);
void		 	udp_unbind(unsigned char udp_connection);
void			udp_process_frame(void);

#ifdef WEB_DEBUG_UDP
void			udp_info(unsigned int port_number);
#endif

#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library udp.c
#endif

#endif	// #ifndef _UDP_INCLUDED_

