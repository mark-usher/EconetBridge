// *********************************************************************************
///
/// \file ip2serial.c
///
///  Network virtual terminal described in RFC2217
///  easyToUse with virtual com port redirector HW VSP from HW-group
///  http://www.hw-group.com/download/sw/HW_VirtualSerialPort.zip
///
///
/// \par Created
///					01.09.2005
/// \date	 		$LastChangedDate: 2007-04-16 09:16:49 +0200 (Mo, 16 Apr 2007) $
/// \version 		$Rev: 664 $
///	\author  		Thomas Kellner
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// *********************************************************************************
#include "project.h"

#ifdef IP2SERIAL_ENABLE
#include "nvt.h"
#include "tcp.h"
#include "systimer.h"


#pragma regalloc-
unsigned char               ip2serial_telnet_server_tcp[IP2SERIAL_CONNECTION_MAX]={TCP_WRONG_CONNECTIONS,TCP_WRONG_CONNECTIONS};
T_IP2SERIAL_STRUCT          ip2serial_struct[IP2SERIAL_CONNECTION_MAX];
#ifdef IP2SERIAL_DEBUG
#ifdef IP2SERIAL_TELNET_NVT_ENABLE
unsigned char               debug_nvt_option_buffer[NVT_OPTION_BUFFER_SIZE];
#endif
eeprom unsigned char        ip2serial_debug_flag = 0x00;	// default: debug output off
#endif
#pragma regalloc+


// *********************************************************************************
/// \brief       get pointer to ip2serial structure
/// \return      pointer to ip2serial structure
// *********************************************************************************
T_IP2SERIAL_STRUCT *ip2serial_get_struct(unsigned char conn_id)
{
return &ip2serial_struct[conn_id];
}


// *********************************************************************************
/// \brief                  set ip2serial config data
/// \param[in] p_struct     pointer to ip2serial config structure
/// \param[in] conn_id      id of ip2serial connection
// *********************************************************************************
void ip2serial_set_config_struct(T_IP2SERIAL_CONFIG_STRUCT *p_struct, unsigned char conn_id)
{
if(conn_id>=IP2SERIAL_CONNECTION_MAX)
    return;
memcpy(&ip2serial_struct[conn_id].cfg, p_struct, sizeof(T_IP2SERIAL_CONFIG_STRUCT));
}


// *********************************************************************************
/// \brief                  check availability of connection
/// \param[in] conn_id      id of ip2serial connection
/// \return                 0: failed; 1: connection availabe
// *********************************************************************************
unsigned char ip2serial_connection_enabled(unsigned char conn_id)
{
if(conn_id<IP2SERIAL_CONNECTION_MAX)
    {
    if(ip2serial_struct[conn_id].cfg.connection_status&IP2SERIAL_CONN_ENABLE_BIT)
        return 1;
    }
return 0;
}


// *********************************************************************************
/// \brief                      timeout handler for ip2serial connection data write
/// \param[in] conn_id          id of ip2serial connection
/// \param[in] access_type      specifies to reset or check the connection timeout
/// \return                     timeout status: 1 - timeout; 0 - no timeout
// *********************************************************************************
unsigned char ip2serial_conn_timeout(unsigned char access_type, unsigned char conn_id)
{
static unsigned int counter_ms_old[IP2SERIAL_CONNECTION_MAX];

if(access_type==IP2SERIAL_TIMEOUT_CHECK)
    {
    if((systimer_cnt-counter_ms_old[conn_id])<ip2serial_struct[conn_id].cfg.timeout_ms)
        return 0;
    else
        return 1;
    }
else if(access_type==IP2SERIAL_TIMEOUT_RESET)
    {
    counter_ms_old[conn_id] = systimer_cnt;
    }
return 0;
}


// *********************************************************************************
/// \brief                  set tcp local window size of ip2serial connection to zero
/// \param[in] conn_id      id of ip2serial connection
// *********************************************************************************
void ip2serial_tcp_window_size_zero(unsigned char conn_id)
{
TCP_STRUCTURE *p_struct;

// call of function will not cause the following transferred windowsize but the next
// must be called after tcp_rx_buffer_clear()
p_struct = tcp_get_struct(conn_id);
if(p_struct)
    p_struct->tcp_window_local = 0;     // set new window size to zero
#ifdef IP2SERIAL_DEBUG
if(ip2serial_debug_flag & IP2SERIAL_DEBUG_BIT)
    putsf("IP2SERIAL tx zero window\r");
#endif
}


// *********************************************************************************
/// \brief                  close ip2serial connection
/// \param[in] conn_id      id of ip2serial connection
// *********************************************************************************
void ip2serial_conn_close(unsigned char conn_id)
{
TCP_STRUCTURE *p_struct;

p_struct = tcp_get_struct(ip2serial_telnet_server_tcp[conn_id]);
if(p_struct!=0x0)
    {
    if((p_struct->tcp_flags & TCP_FLAG_OPEN) || (p_struct->tcp_socket_status & SOCK_READY_CONNECT) || !(p_struct->tcp_state_machine==CLOSED))
        tcp_close(ip2serial_telnet_server_tcp[conn_id]);
    }
}


// *********************************************************************************
/// \brief                  init ip2serial connection
/// \param[in] conn_id      id of ip2serial connection
/// \return                 0: failed; 1: success
// *********************************************************************************
unsigned char ip2serial_conn_init(unsigned char conn_id)
{
TCP_STRUCTURE *p_struct;

if(conn_id>=IP2SERIAL_CONNECTION_MAX)
    return 0;
ip2serial_telnet_server_tcp[conn_id] = tcp_passive_open(ip2serial_struct[conn_id].cfg.local_port);
if(ip2serial_telnet_server_tcp[conn_id]==TCP_WRONG_CONNECTIONS)   // set port we want to listen to
    return 0;
p_struct = tcp_get_struct(ip2serial_telnet_server_tcp[conn_id]);
p_struct->tcp_max_window_size = IP2SERIAL_TCP_MAX_WINDOW_SIZE;
tcp_rx_buffer_clear(ip2serial_telnet_server_tcp[conn_id]);   // init tcp_structure element tcp_window_local with tcp_max_window_size
return 1;
}


// *********************************************************************************
/// \brief                  change tcp-port of a connection
/// \param[in] conn_id      id of ip2serial connection
/// \return                 0: failed; 1: success
// *********************************************************************************
unsigned char ip2serial_conn_change(unsigned char conn_id)
{
TCP_STRUCTURE *p_struct;

if((ip2serial_struct[conn_id].cfg.connection_status&IP2SERIAL_CONN_PORT_CHANGE_BIT)==0)
    return 0;
ip2serial_conn_close(conn_id);
p_struct = tcp_get_struct(ip2serial_telnet_server_tcp[conn_id]);
if(p_struct==0x0)
    return 0;
if(p_struct->tcp_socket_status!=0)
    return 0;
if(ip2serial_conn_init(conn_id))
    ip2serial_struct[conn_id].cfg.connection_status &= ~IP2SERIAL_CONN_PORT_CHANGE_BIT;
return 1;
}


// *********************************************************************************
/// \brief		processes nvt commands
// *********************************************************************************
//unsigned char ip2serial_nvt_comport_option(unsigned char nvt_option_buffer, unsigned char Lvb)
//{
//return 0;
//}


#ifdef IP2SERIAL_TELNET_NVT_ENABLE
// *********************************************************************************
/// \brief		         filters nvt commands from rx-data
/// \param[in] p_data    pointer to rx-buffer
/// \param[in] size      size of data in rx-buffer
/// \param[out] p_dest   pointer to new rx-buffer, contents rx-data without nvt data
/// \return              real size of data without nvt data
// *********************************************************************************
unsigned int ip2serial_process_nvt_data(unsigned char *p_dest, unsigned char *p_data, unsigned int size)
{
T_TELNET_NVT_STATUS nvt_status=NVT_CMD_INIT, nvt_status_old=NVT_CMD_INIT;
unsigned int        Lva=0, Lvd=0;

printf("IP2SERIAL ip2serial_process_nvt_data() nvt data (size: %u):\r\n", size);
debug_display_mem_hex(p_data, size, 0);
for(Lva=0;Lva<size;Lva++)
    {
	#ifdef IP2SERIAL_DEBUG
//	if(ip2serial_debug_flag & IP2SERIAL_DEBUG_BIT)
	    {
	    if(nvt_status!=nvt_status_old)
	        {
	        nvt_status_old = nvt_status;
           	printf("IP2SERIAL ip2serial_process_nvt_data() nvt_status: %u\r\n", nvt_status);
           	}
        }
	#endif
    if(p_data[Lva]==NVT_CMD_IAC)
        {
        if((Lva+1<size) && (p_data[Lva+1]==NVT_CMD_IAC))
            nvt_status = NVT_CMD_NONE;
        else
            nvt_status = NVT_CMD_START;
        }
    switch(nvt_status)
        {
        case(NVT_CMD_INIT):
            break;
        case(NVT_CMD_NONE):
            p_dest[Lvd++] = p_data[Lva++]; break;   // override next character
        case(NVT_CMD_START):
            switch(p_data[Lva])
                {
/*
                case(NVT_CMD_NOP):      break;
                case(NVT_CMD_DM):       break;
                case(NVT_CMD_BRK):      break;
                case(NVT_CMD_IP):       break;
                case(NVT_CMD_AO):       break;
                case(NVT_CMD_AYT):      break;
                case(NVT_CMD_EC):       break;
                case(NVT_CMD_EL):       break;
                case(NVT_CMD_GA):       break;
                case(NVT_CMD_WILL):     break;
                case(NVT_CMD_WONT):     break;
                case(NVT_CMD_DO):       break;
                case(NVT_CMD_DONT):     break;
*/
                case(NVT_CMD_SB):       nvt_status = NVT_CMD_SUBNEG; break;
                case(NVT_CMD_SE):       nvt_status = NVT_CMD_INIT; break;
                default:                nvt_status = NVT_CMD_INIT;
                }
            break;
        case(NVT_CMD_SUBNEG):
            switch(p_data[Lva])
                {
                case(NVT_OPTN_CP):      nvt_status = NVT_CMD_COMPORT_OPTION; break;
                default:                nvt_status = NVT_CMD_INIT;
                }
            break;
        case(NVT_CMD_COMPORT_OPTION):
            switch(p_data[Lva])
                {
                case(NVT_CAS_BAUDRATE): break;
                case(NVT_CAS_DATASIZE): break;
                case(NVT_CAS_PARITY):   break;
                case(NVT_CAS_STOPSIZE): break;
                default:                nvt_status = NVT_CMD_INIT;
                }
            nvt_status = NVT_CMD_INIT;
            break;
        default:
        }
    }   // for()
return Lvd;
}
#endif   //#ifdef IP2SERIAL_TELNET_NVT_ENABLE


// *********************************************************************************
/// \brief                  get tcp socket status of connection
/// \param[in] conn_id      id of ip2serial connection
// *********************************************************************************
unsigned char ip2serial_tcp_socket_status(unsigned char conn_id)
{
TCP_STRUCTURE   *p_struct;
unsigned char   sock=0;

p_struct = tcp_get_struct(ip2serial_telnet_server_tcp[conn_id]);
if(p_struct!=0)
    sock = p_struct->tcp_socket_status;
return sock;
}


// *********************************************************************************
/// \brief                  check packetsize and tx-timeout
/// \param[in] conn_id      id of ip2serial connection
// *********************************************************************************
unsigned char ip2serial_write_suspend(unsigned char conn_id, unsigned int size)
{

if((size>ip2serial_struct[conn_id].cfg.packetsize) || ip2serial_conn_timeout(IP2SERIAL_TIMEOUT_CHECK, conn_id))
    return 0;   // do not suspend
else
    return 1;
}


// *********************************************************************************
/// \brief                  get size of received bytes in tcp rx buffer
/// \param[in] conn_id      id of ip2serial connection
// *********************************************************************************
unsigned int ip2serial_get_rx_count(unsigned char conn_id)
{
unsigned int tcp_data_size=0;

if((ip2serial_tcp_socket_status(conn_id) & SOCK_CONNECTED) && (ip2serial_tcp_socket_status(conn_id) & SOCK_DATA_AVAILABLE))
    tcp_rx_buffer_read(ip2serial_telnet_server_tcp[conn_id], 0x0, &tcp_data_size, TCP_RX_BUFFER_GET_SIZE);
return tcp_data_size;
}


// *********************************************************************************
/// \brief                  get remaining size of tcp tx buffer
/// \param[in] conn_id      id of ip2serial connection
// *********************************************************************************
unsigned int ip2serial_get_tx_gap(unsigned char conn_id)
{
unsigned int tcp_data_size=0;

if(ip2serial_tcp_socket_status(conn_id) & SOCK_CONNECTED)
    tcp_data_size = tcp_tx_buffer_write(ip2serial_telnet_server_tcp[conn_id], 0x0, 0, TCP_TX_BUFFER_GET_SIZE);
return tcp_data_size;
}


// *********************************************************************************
/// \brief                  receive data from tcp
/// \param[in] conn_id      id of ip2serial connection
// *********************************************************************************
void ip2serial_read_data(unsigned char conn_id, unsigned char *p_data, unsigned int size)
{
unsigned int tcp_data_size=0;
unsigned char *p_tcp_data;

if((ip2serial_tcp_socket_status(conn_id) & SOCK_CONNECTED) && (ip2serial_tcp_socket_status(conn_id) & SOCK_DATA_AVAILABLE))
    {
    p_tcp_data = tcp_rx_buffer_read(ip2serial_telnet_server_tcp[conn_id], 0x0, &tcp_data_size, TCP_RX_BUFFER_GET_SIZE);
    #ifdef IP2SERIAL_STATISTIC
    ip2serial_struct[conn_id].stat.rx_count += tcp_data_size;
    #endif
    #ifdef IP2SERIAL_DEBUG
    if(ip2serial_debug_flag & IP2SERIAL_DEBUG_BIT)
        printf("IP2SERIAL (%u) RX read %u bytes\r\n", conn_id+1, tcp_data_size);
    #endif
    if(tcp_data_size>size)
        {
        #ifdef IP2SERIAL_DEBUG
        if(ip2serial_debug_flag & IP2SERIAL_DEBUG_BIT)
            printf("IP2SERIAL (%u) RX lost %u bytes\r\n", conn_id+1, tcp_data_size-size);
        #endif
        #ifdef IP2SERIAL_STATISTIC
        ip2serial_struct[conn_id].stat.rx_lost += tcp_data_size - size;
        #endif
        tcp_data_size = size;
        }
    #ifdef IP2SERIAL_TELNET_NVT_ENABLE
    tcp_data_size = ip2serial_process_nvt_data(p_data, p_tcp_data, tcp_data_size);
    #else
    memcpy(p_data, p_tcp_data, tcp_data_size);
    #endif
    tcp_rx_buffer_clear(ip2serial_telnet_server_tcp[conn_id]);	// clear and throw it away
    // zero window should be set if not enough place in buffer for incoming rx data
    if(ip2serial_struct[conn_id].fp_buffer_get_tx_gap(conn_id)<=IP2SERIAL_TCP_MAX_WINDOW_SIZE*3)
        ip2serial_tcp_window_size_zero(conn_id);        // call after tcp_rx_buffer_clear()!
    }
}


// *********************************************************************************
/// \brief                  transmit data to tcp
/// \param[in] conn_id      id of ip2serial connection
// *********************************************************************************
void ip2serial_write_data(unsigned char conn_id, unsigned char *p_data, unsigned int size)
{

if(ip2serial_tcp_socket_status(conn_id) & SOCK_CONNECTED)
    {
    tcp_tx_buffer_write(ip2serial_telnet_server_tcp[conn_id], p_data, size, TCP_TX_BUFFER_WRITE_RAM_DATA);
    #ifdef IP2SERIAL_STATISTIC
    ip2serial_struct[conn_id].stat.tx_count += size;
    #endif
    #ifdef IP2SERIAL_DEBUG
    if(ip2serial_debug_flag & IP2SERIAL_DEBUG_BIT)
        printf("IP2SERIAL (%u) TX wrote %u bytes\r\n", conn_id+1, size);
    #endif
    ip2serial_conn_timeout(IP2SERIAL_TIMEOUT_RESET, conn_id);
    }
}


// *********************************************************************************
/// \brief                  server receives/transmits data from/to tcp
/// \param[in] conn_id      id of ip2serial connection
// *********************************************************************************
void ip2serial_telnet_server(unsigned char conn_id)
{
unsigned char buffer[IP2SERIAL_TCP_MAX_WINDOW_SIZE];
unsigned int size;

// receive from tcp to buffer
size = ip2serial_get_rx_count(conn_id);
if(size>ip2serial_struct[conn_id].fp_buffer_get_tx_gap(conn_id))
    size = ip2serial_struct[conn_id].fp_buffer_get_tx_gap(conn_id);
if(size>IP2SERIAL_TCP_MAX_WINDOW_SIZE)
    size = IP2SERIAL_TCP_MAX_WINDOW_SIZE;
if(size)
    {
    ip2serial_read_data(conn_id, buffer, size);
    ip2serial_struct[conn_id].fp_buffer_write(conn_id, buffer, size);
    }
// transmit from buffer to tcp
size = ip2serial_struct[conn_id].fp_buffer_get_rx_count(conn_id);
if(size>ip2serial_get_tx_gap(conn_id))
    size = ip2serial_get_tx_gap(conn_id);
if(size>IP2SERIAL_TCP_MAX_WINDOW_SIZE)
    size = IP2SERIAL_TCP_MAX_WINDOW_SIZE;
if(size)
    {
    if(ip2serial_write_suspend(conn_id, size))
        return;
    ip2serial_struct[conn_id].fp_buffer_read(conn_id, buffer, size);
    ip2serial_write_data(conn_id, buffer, size);
    // todo: increase tx_lost if necessary
    }
}


// *********************************************************************************
/// \brief      init routine
/// \return     1: failed; 0: success
// *********************************************************************************
unsigned char ip2serial_init(void)
{
unsigned char Lva;
#ifdef IP2SERIAL_DEBUG
T_DEBUG_HANDLER_STRUCT p_struct;

p_struct.fp_handler = &ip2serial_debug_handler;
p_struct.id_string = "i2s-";
debug_register_handler(&p_struct);
#endif
for(Lva=0;Lva<IP2SERIAL_CONNECTION_MAX;Lva++)
    {
    if(!ip2serial_conn_init(Lva))
        return 0;   // error
    }
return 1;
}


// *********************************************************************************
/// \brief      main routine
// *********************************************************************************
void ip2serial_main(void)
{
unsigned char Lva;

for(Lva=0;Lva<IP2SERIAL_CONNECTION_MAX;Lva++)
    {
    if(ip2serial_tcp_socket_status(Lva) & SOCK_CONNECTED)
        ip2serial_telnet_server(Lva);
    ip2serial_conn_change(Lva);
    }
}


#ifdef IP2SERIAL_DEBUG
// *********************************************************************************
/// \brief                  debug command handler
/// \param[in] command      pointer to command string
/// \param[in] mode         mode of debug command
// *********************************************************************************
void ip2serial_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
unsigned int param1;

if(mode==DEBUG_HANDLER_MODE_INFO)
    {
    printf("IP2SERIAL_DEBUG");
	if(ip2serial_debug_flag & IP2SERIAL_DEBUG_BIT)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
	}
else if(mode==DEBUG_HANDLER_MODE_HELP)
    {
//    ip2serial_debug_cmd_list();
    // add output for 'help' command here
    }
else if(mode==DEBUG_HANDLER_MODE_SWITCH)
	{
	if(strncmpf(command, "i2s", strlenf("i2s"))==0)
	    {
    	ip2serial_debug_flag ^= IP2SERIAL_DEBUG_BIT;
        printf("IP2SERIAL_DEBUG");
    	if (ip2serial_debug_flag & IP2SERIAL_DEBUG_BIT)
    		putsf(" ON\r");
    	else
    		putsf(" OFF\r");
	    }
	}
// if(mode==DEBUG_HANDLER_MODE_CMD)
else if(strncmpf(command, "cfg", 3)==0)
    {
	param1 = debug_get_int_parameter(command);
    if((param1==IP2SERIAL_CONNECTION_1) || (param1==IP2SERIAL_CONNECTION_2))
        {
        printf("IP2SERIAL config data, ip2s-conn%u\r\n", param1+1);
        printf("conn_status:   %u\r\n", ip2serial_struct[param1].cfg.connection_status);
        printf("local_port:    %u\r\n", ip2serial_struct[param1].cfg.local_port);
        printf("packet_size:   %u\r\n", ip2serial_struct[param1].cfg.packetsize);
        printf("timeout_ms:    %u\r\n", ip2serial_struct[param1].cfg.timeout_ms);
        printf("protocol:      %u\r\n", ip2serial_struct[param1].cfg.protocol);
        }
    }
#ifdef IP2SERIAL_STATISTIC
else if(strncmpf(command, "stat", 4)==0)
    {
	param1 = debug_get_int_parameter(command);
    if((param1==IP2SERIAL_CONNECTION_1) || (param1==IP2SERIAL_CONNECTION_2))
        {
        printf("IP2SERIAL status data, ip2s-conn%u\r\n", param1+1);
        printf("rx-count:   %u\r\n", ip2serial_struct[param1].stat.rx_count);
        printf("tx-count:   %u\r\n", ip2serial_struct[param1].stat.tx_count);
        printf("rx-lost:    %u\r\n", ip2serial_struct[param1].stat.rx_lost);
        printf("tx-lost:    %u\r\n", ip2serial_struct[param1].stat.tx_lost);
        ip2serial_struct[param1].stat.rx_count = 0;
        ip2serial_struct[param1].stat.tx_count = 0;
        ip2serial_struct[param1].stat.rx_lost = 0;
        ip2serial_struct[param1].stat.tx_lost = 0;
        }
    }
#endif
#ifdef IP2SERIAL_TELNET_NVT_ENABLE
else if(strncmpf(command, "nvt", 3)==0)
	{
    putsf("IP2SERIAL ip2serial_process_nvt_data() nvt_option_buffer:\r");
    debug_display_mem_hex(debug_nvt_option_buffer, NVT_OPTION_BUFFER_SIZE, 0);
	}
#endif
}
#endif   // #ifdef IP2SERIAL_DEBUG
#endif   // #ifdef IP2SERIAL_ENABLE
