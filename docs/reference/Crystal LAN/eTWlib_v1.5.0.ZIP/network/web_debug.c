// ************************************************************************************************
///
/// \file 			web_debug.c
/// \brief			General debug functions for the network stack
///
/// \date	 		$LastChangedDate: 2007-03-28 10:43:12 +0200 (Mi, 28 Mrz 2007) $
/// \version 		$Rev: 660 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
/// \par History
///					1.) 08.08.2003 Version 2.00
///					2.) 08.08.2003 Version 2.01
///						a.)	- function "web_debug_info(..)" supports now the macros "PROJECT_NAME",
///							"PROJECT_VERSION" and "EASYTOWEB_VERSION"
///					3.) 11.08.2003 Version 2.01
///						a.)	- start of implementation of FTP-Server
///					4.) 26.08.2003 Version 2.01
///						a.)	- use now "cs8900_debug_do_cmd()" inside of "web_debug_command()"
///					5.) 02.09.2003 Version 2.01
///						a.)	- variable "web_debug_cmd" only visible inside of web_debug.c
///						b.)	- variable "web_debug_flag" switch OFF all debug infos
///						c.)	- function "web_debug_string2ip" and "web_debug_integer" with
///					           pointer to command-string;
///					6.) 23.09.2003 Version 2.02
///						a.)	- add debug functions for file system, see dataflash_file.c
///					7.) 08.10.2003 Version 2.02
///						a.)	- add debug functions for FTP functions, see ftp_server.c
///					8.) 23.10.2003 Version 2.02
///						a.)	- rename the terminal commands "ip-addr" to "ip", "gateway-addr" to 
///							"gateway" and "submask-addr" to "submask" ;
///					9.) 11.11.2003 Version 2.02
///						a.)	- disable the terminal command "endian"
///						b.)	- new terminal command "help" and "time"
///					10.) 19.11.2003 Version 2.03
///						a.)	- function web_debug_command() has now a return value
///					          you can use the command-string for your own command-handler
///					11.) 24.11.2003 Version 2.03
///						a.)	- wrong commands inside of web_debug_do_cmd()
///					12.) 02.12.2003 Version 2.03
///						a.)	- the commands "ip", "gateway" and "submask" display the actual
///					          value, if use without parameter; example "ip" displays the actual 
///							  ip-address
///					13.) 26.02.2004 Version 2.03
///						a.)	- web_debug_print_mac() prints MAC-Address to debug channel
///					14.) 30.04.2004 Version 2.04
///						a.)	- web_debug_ds2430_info() supports now the second DS2430A of eTW-AIO
///						b.)	- rename web_debug_ds2430_info() to web_debug_1wire_info()
///					15.) 21.01.2005 Version 2.06
///						a.)	- divide the file web_debug.c in debug.c and web_debug.c
///						--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef WEB_DEBUG

#include <string.h>
#include "board.h"
#include <stdio.h>
#include "debug.h"
#include "web_debug.h"
#ifdef DS2431_ENABLE
#include "ds2431.h"
#else
#include <ds2430.h>
#endif
#ifdef ARP_ENABLE
#include "arp_rarp.h"
#endif
#include "device.h"
#include "buffer.h"
#ifdef ICMP_ENABLE
#include "icmp.h"
#endif
#include "tcp.h"

#pragma regalloc-
eeprom unsigned int	web_debug_flag = 0x0000;		  	///< all web debug flag switch OFF (eeprom variable needs about 24byte more code)
#pragma regalloc+

// prototypes
void web_debug_1wire_info(void);
void web_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);
void web_debug_display_addresses(void);

// ************************************************************************************************
/// \brief	    Registers Web-debug handler with debug framework
///
// ************************************************************************************************
void web_debug_init(void)
{
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &web_debug_handler;
p_struct.id_string = "web";
debug_register_handler(&p_struct);
}


// ************************************************************************************************
/// \brief		displays all infos around easyToWeb-AVR
///
/// @param[in]	info_string - additional information to application
// ************************************************************************************************
void web_debug_info(void)
{
#ifndef DS2430_WRITE_PROM
web_debug_1wire_info();
web_debug_display_addresses();
#endif
putsf("---- easyToWeb-Software ----\r");
#ifdef ETHERNET_ENABLE
putsf("ETHERNET_ENABLE\r");
#endif
#ifdef ARP_ENABLE
putsf("ARP_ENABLE\r");
#endif
#ifdef IP_ENABLE
putsf("IP_ENABLE\r");
#endif
#ifdef ICMP_ENABLE
putsf("ICMP_ENABLE\r");
#endif
#ifdef UDP_ENABLE
putsf("UDP_ENABLE\r");
#endif
#ifdef BOOTP_ENABLE
putsf("BOOTP_ENABLE\r");
#endif
#ifdef TFTP_ENABLE
putsf("TFTP_ENABLE\r");
#endif
#ifdef TCP_ENABLE
putsf("TCP_ENABLE\r");
#endif
#ifdef HTTP_ENABLE
putsf("HTTP_ENABLE\r");
#endif
}


// ************************************************************************************************
/// \brief		displays all infos to WEB-DEBUG options
///
// ************************************************************************************************
void web_debug_debug_info(void)
{
putsf("---- easyToWeb-Software-Debug ----\r");
#ifdef WEB_DEBUG
putsf("WEB_DEBUG\r");
#endif
#ifdef WEB_DEBUG_MEASURE
putsf("WEB_DEBUG_MEASURE\r");
#endif
#ifdef WEB_DEBUG_BUFFER
printf("WEB_DEBUG_BUFFER");
if(web_debug_flag & WEB_DEBUG_BUFFER_BIT)
	putsf(" ON\r");
else
	putsf(" OFF\r");
#endif
#ifdef WEB_DEBUG_ETHERNET
printf("WEB_DEBUG_ETHERNET");
if(web_debug_flag & WEB_DEBUG_ETHERNET_BIT)
	putsf(" ON\r");
else
	putsf(" OFF\r");
#endif
#ifdef WEB_DEBUG_ARP
printf("WEB_DEBUG_ARP");
if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
	putsf(" ON\r");
else
	putsf(" OFF\r");
#endif
#ifdef WEB_DEBUG_RARP
printf("WEB_DEBUG_RARP");
if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
	putsf(" ON\r");
else
	putsf(" OFF\r");
#endif
#ifdef WEB_DEBUG_IP
printf("WEB_DEBUG_IP");
if(web_debug_flag & WEB_DEBUG_IP_BIT)
	putsf(" ON\r");
else
	putsf(" OFF\r");
#endif
#ifdef WEB_DEBUG_ICMP
printf("WEB_DEBUG_ICMP");
if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
	putsf(" ON\r");
else
	putsf(" OFF\r");
#endif
#ifdef WEB_DEBUG_UDP
printf("WEB_DEBUG_UDP");
if(web_debug_flag & WEB_DEBUG_UDP_BIT)
	putsf(" ON\r");
else
	putsf(" OFF\r");
#endif
#ifdef WEB_DEBUG_BOOTP
printf("WEB_DEBUG_BOOTP");
if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
	putsf(" ON\r");
else
	putsf(" OFF\r");
#endif
#ifdef WEB_DEBUG_TFTP
printf("WEB_DEBUG_TFTP");
if(web_debug_flag & WEB_DEBUG_TFTP_BIT)
	putsf(" ON\r");
else
	putsf(" OFF\r");
#endif
#ifdef WEB_DEBUG_HTTP
printf("WEB_DEBUG_HTTP");
if(web_debug_flag & WEB_DEBUG_HTTP_BIT)
	putsf(" ON\r");
else
	putsf(" OFF\r");
#endif
}


// ************************************************************************************************
/// \brief		Test und read ID-Code of 1-WIRE-Devices
///
// ************************************************************************************************
void web_debug_1wire_info(void)
{
unsigned char Lva=0, Lvb, dev_1wire, crc;
unsigned char romcodes_1wire[BOARD_MAX_1WIRE_DEVICES,9];

dev_1wire = board_read_mac(romcodes_1wire, 0x0);
if(dev_1wire)
	{
	printf("%u-1WIRE-DEVICE:\r\n", dev_1wire);
	while(Lva<dev_1wire)
		{
		crc=w1_dow_crc8(&romcodes_1wire[Lva,0], 7);
		if(crc==romcodes_1wire[Lva,7])
			{
			printf("(%u)BIT07..00 - Family Code  : 0x%02x", Lva, romcodes_1wire[Lva,0]);
			#ifdef DS2431_ENABLE
			if(romcodes_1wire[Lva,0]==DS2431_FAMILY_CODE)	// found DS2431
				printf(" - DS2431", Lva, romcodes_1wire[0,0]);
			#else
			if(romcodes_1wire[Lva,0]==DS2430_FAMILY_CODE)	// found DS2430A
				printf(" - DS2430A", Lva, romcodes_1wire[0,0]);
			#endif
			printf("\r\n");
			printf("(%u)BIT56..08 - Serial Number: 0x", Lva);
			for (Lvb=6;Lvb>0;Lvb--)
				printf("%02x",romcodes_1wire[Lva,Lvb]);
			putsf("\r");
			printf("(%u)BIT63..57 - CRC          : 0x%02x\r\n", Lva, romcodes_1wire[Lva,7]);
			}
		else
			printf("(%u)CRC-Error: 0x%02x/0x%02x\r", Lva, romcodes_1wire[Lva,7], crc);
		Lva++;
		}
	}
else
	putsf("1-WIRE-DEVICE ERROR!!\r");
}


// ************************************************************************************************
/// \brief		displays all Ethernetaddresses
///
///				see variables ip_address, ip_subnet_mask, ip_gateway
// ************************************************************************************************
void web_debug_display_addresses(void)
{
#ifdef DEVICE_CS8900
if(board_read_mac(0x0, 0x0))
    #ifdef DS2431_ENABLE
	putsf("MAC-Address from DS2431 WRITE PROTECTED EEPROM:\r");
	#else
	putsf("MAC-Address from DS2430 PROM:\r");
	#endif
else
	putsf("Default-MAC-Address:\r");
debug_print_mac("MAC    ", mac_address);
#endif	//#ifdef DEVICE_CS8900
#ifdef IP_ENABLE
	#ifdef BOOTP_ENABLE
		if(bootp_ok)
			putsf("BOOTP-Data:\r");
		else
			#ifdef ENABLE_IP_FROM_EEPROM
			putsf("IP, SUBMASK and GATEWAY from EEPROM:\r");
			#elif defined (ENABLE_IP_FROM_EEPROM)
			putsf("IP, SUBMASK and GATEWAY from DS2430A:\r");
			#else
			putsf("Default-IP, -SUBMASK and -GATEWAY:\r");
			#endif
	#else
		#ifdef ENABLE_IP_FROM_EEPROM
		putsf("IP, SUBMASK and GATEWAY from EEPROM:\r");
		#elif defined (ENABLE_IP_FROM_EEPROM)
		putsf("IP, SUBMASK and GATEWAY from DS2430A:\r");
		#else
		putsf("Default-IP, -SUBMASK and -GATEWAY:\r");
		#endif
	#endif	// #ifdef BOOTP_ENABLE
	debug_print_ip("IP     ", ip_address);
	debug_print_ip("SUBMASK", ip_subnet_mask);
	debug_print_ip("GATEWAY", ip_gateway);
#endif	// #ifdef IP_ENABLE
}


// ************************************************************************************************
/// \brief		Switch on/off the debug info via runtime
///
/// @param[in]	command - pointer to debug command
/// @retval		0 - found no parameter
/// @retval		1 - toggle the tuntime debug mode
// ************************************************************************************************
void web_debug_switch(unsigned char *command)
{
if (strncmpf(command, "buffer", 4)==0)
	{
	#ifdef WEB_DEBUG_BUFFER
	web_debug_flag^=WEB_DEBUG_BUFFER_BIT;
	if(web_debug_flag & WEB_DEBUG_BUFFER_BIT)
		putsf("WEB_DEBUG_BUFFER ON\r");
	else
		putsf("WEB_DEBUG_BUFFER OFF\r");
	#else
	putsf("NO WEB_DEBUG_BUFFER\r");
	#endif	// #ifdef WEB_DEBUG_BUFFER
	}
else if (strncmpf(command, "ethernet", 4)==0)
	{
	#ifdef WEB_DEBUG_ETHERNET
	web_debug_flag^=WEB_DEBUG_ETHERNET_BIT;
	if(web_debug_flag & WEB_DEBUG_ETHERNET_BIT)
		putsf("WEB_DEBUG_ETHERNET ON\r");
	else
		putsf("WEB_DEBUG_ETHERNET OFF\r");
	#else
	putsf("NO WEB_DEBUG_ETHERNET\r");
	#endif	// #ifdef WEB_DEBUG_ETHERNET
	}
else if ((strncmpf(command, "arp", 3)==0)||(strncmpf(command, "rarp", 4)==0))
	{
	#if defined(WEB_DEBUG_ARP)||defined(WEB_DEBUG_RARP)
	web_debug_flag^=WEB_DEBUG_ARP_RARP_BIT;
	if(web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)
		putsf("WEB_DEBUG_ARP_RARP ON\r");
	else
		putsf("WEB_DEBUG_ARP_RARP OFF\r");
	#else
	putsf("NO WEB_DEBUG_ARP_RARP\r");
	#endif	// #if defined(WEB_DEBUG_ARP)||defined(WEB_DEBUG_RARP)
	}
else if (strncmpf(command, "ip", 2)==0)
	{
	#ifdef WEB_DEBUG_IP
	web_debug_flag^=WEB_DEBUG_IP_BIT;
	if(web_debug_flag & WEB_DEBUG_IP_BIT)
		putsf("WEB_DEBUG_IP ON\r");
	else
		putsf("WEB_DEBUG_IP OFF\r");
	#else
	putsf("NO WEB_DEBUG_IP\r");
	#endif	// #ifdef WEB_DEBUG_IP
	}
else if (strncmpf(command, "icmp", 4)==0)
	{
	#ifdef WEB_DEBUG_ICMP
	web_debug_flag^=WEB_DEBUG_ICMP_BIT;
	if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
		putsf("WEB_DEBUG_ICMP ON\r");
	else
		putsf("WEB_DEBUG_ICMP OFF\r");
	#else
	putsf("NO WEB_DEBUG_ICMP\r");
	#endif	// #ifdef WEB_DEBUG_ICMP
	}
else if (strncmpf(command, "udp", 3)==0)
	{
	#ifdef WEB_DEBUG_UDP
	web_debug_flag^=WEB_DEBUG_UDP_BIT;
	if(web_debug_flag & WEB_DEBUG_UDP_BIT)
		putsf("WEB_DEBUG_UDP ON\r");
	else
		putsf("WEB_DEBUG_UDP OFF\r");
	#else
	putsf("NO WEB_DEBUG_UDP\r");
	#endif	// #ifdef WEB_DEBUG_UDP
	}
else if (strncmpf(command, "bootp", 3)==0)
	{
	#ifdef WEB_DEBUG_BOOTP
	web_debug_flag^=WEB_DEBUG_BOOTP_BIT;
	if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
		putsf("WEB_DEBUG_BOOTP ON\r");
	else
		putsf("WEB_DEBUG_BOOTP OFF\r");
	#else
	putsf("NO WEB_DEBUG_BOOTP\r");
	#endif	// #ifdef WEB_DEBUG_BOOTP
	}
else if (strncmpf(command, "tftp", 3)==0)
	{
	#ifdef WEB_DEBUG_TFTP
	web_debug_flag^=WEB_DEBUG_TFTP_BIT;
	if(web_debug_flag & WEB_DEBUG_TFTP_BIT)
		putsf("WEB_DEBUG_TFTP ON\r");
	else
		putsf("WEB_DEBUG_TFTP OFF\r");
	#else
	putsf("NO WEB_DEBUG_TFTP\r");
	#endif	// #ifdef WEB_DEBUG_TFTP
	}
else if (strncmpf(command, "http", 4)==0)
	{
	#ifdef WEB_DEBUG_HTTP
	web_debug_flag^=WEB_DEBUG_HTTP_BIT;
	if(web_debug_flag & WEB_DEBUG_HTTP_BIT)
		putsf("WEB_DEBUG_HTTP ON\r");
	else
		putsf("WEB_DEBUG_HTTP OFF\r");
	#else
	putsf("NO WEB_DEBUG_HTTP\r");
	#endif	// #ifdef WEB_DEBUG_HTTP
	}
}


// ************************************************************************************************
/// \brief		Help infos to the terminal commands
///
// ************************************************************************************************
void web_debug_help(void)
{
putsf("\"info\" - all informations to the system (protocolls, debug)\r");
putsf("\"init\" - init the device (Ethernet, Modem)\r");
putsf("\"debug <xxx>\" - enable/disable runtime debug (example: \"debug ip\")\r");
#ifdef IP_ENABLE
putsf("\"web-ip <xxx.xxx.xxx.xxx>\" - new ip address (example: \"ip 192.168.0.5\")\r");
putsf("\"web-submask <xxx.xxx.xxx.xxx>\" - new submask (example: \"ip 255.255.255.0\")\r");	// 91-this is max. length of line
putsf("\"web-gateway <xxx.xxx.xxx.xxx>\" - new gateway address (example: \"ip 192.168.0.100\")\r");
#endif	// #ifdef IP_ENABLE
#ifdef WEB_DEBUG_MEASURE
putsf("\"web-measure\" - display all measure data\r");
#endif	// WEB_DEBUG_MEASURE
#ifdef ICMP_ENABLE
putsf("\"web-ping <xxx.xxx.xxx.xxx>\" - send a ping (example: \"ping 192.168.0.1\")\r");
#endif	// #ifdef ICMP_ENABLE
#if defined(BOOTP_ENABLE)&& defined(WEB_DEBUG_BOOTP)
putsf("\"web-bootp\" - displays the BootP infos\r");
#endif
#if defined(UDP_ENABLE)&& defined(WEB_DEBUG_UDP)
putsf("\"web-udp-info\" - displays the UDP infos\r");
#endif
#if defined(ARP_ENABLE)&& defined(WEB_DEBUG_ARP)
putsf("\"web-arp\" - starts a ARP Request (example: \"arp 192.168.0.1\")\r");
#endif
#if defined(RARP_ENABLE)&& defined(WEB_DEBUG_RARP)
putsf("\"web-rarp\" - starts a RARP Request (example: \"rarp 00:50:c2:21:10:c0\")\r");
#endif
}


// ************************************************************************************************
/// \brief		Displays the time of easyToWeb-Software
///
///				see variable "day_counter" and "second_counter"
// ************************************************************************************************
void web_debug_time(void)
{
unsigned long sec_buffer;
unsigned char data;

printf("day : %u\r\n", day_counter);
#asm("cli");	 	// Global disable interrupts
sec_buffer=second_counter;
#asm("sei");	 	// Global enable interrupts
data=(unsigned char)(sec_buffer/3600);
printf("time: %02u:", data);
sec_buffer-=(unsigned long)data*3600;
data=(unsigned char)(sec_buffer/60);
printf("%02u:", data);
sec_buffer-=(unsigned int)data*60;
printf("%02u\r\n", (unsigned char)sec_buffer);
}


#ifdef ICMP_ENABLE
// ************************************************************************************************
/// \brief		makes a ping to <ip>
///
/// @param[in]	ip - pointer to IP-Address
// ************************************************************************************************
void web_debug_ping(unsigned char *ip)
{
unsigned char	c_delay=200;
unsigned char	c_old;

#ifdef ARP_ENABLE
arp_prepare_request(ip, ARP_REQUEST_IP);
memset(ip_of_last_frame, 0x0, IP_ADR_SIZE);	// clear last IP-Address
#endif
c_old = (unsigned char)counter_10ms_16bit;
while (1)
	{
	#asm("wdr");		// Reset Watchdog
	#ifdef DEVICE_PPP
	ppp_main();
	if(DEVICE_READ_READY())
		{
		#ifdef IP_ENABLE
		ip_process_frame(0);
		#endif
		ppp_data_clear();
		}
	#else
	ethernet_process();		 	// handle network and easyToWeb-stack events
	buffer_process();			// handles the buffer management
	#endif	// #ifdef DEVICE_PPP
	idle();	  		 	// every time with IDLE-Mode
	#ifdef ARP_ENABLE
	if (!memcmp(ip_of_last_frame, ip, IP_ADR_SIZE))
		{
		icmp_prepare_echo_request(ip, mac_of_last_frame, 0xae);
		return;
		}
	#else
	icmp_prepare_echo_request(ip, 0, 0xae);	// send ping without knowing the MAC address
	#endif
	if (c_old != (unsigned char)counter_10ms_16bit)
		{
		c_old = (unsigned char)counter_10ms_16bit;
		if (c_delay > 0)
			c_delay--;
		else
			break;	// timeout
		}
	}
}
#endif	// #ifdef ICMP_ENABLE



// ************************************************************************************************
/// \brief	    command handler for debug commands
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void web_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
#ifdef IP_ENABLE
unsigned char 	result;
#endif
#if defined(ARP_ENABLE)&& defined(WEB_DEBUG_ARP)|| defined(IP_ENABLE)
unsigned char	ip[4];			// see debug_string2ip()
#endif
#if defined(UDP_ENABLE)&& defined(WEB_DEBUG_UDP)
signed int data;
#endif

if (mode == DEBUG_HANDLER_MODE_INFO)
	{
	web_debug_info();
	web_debug_debug_info();
	}
else if (mode == DEBUG_HANDLER_MODE_HELP)
	web_debug_help();
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
	web_debug_switch(command);
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-init", 5)==0)
		{
		DEVICE_INIT();
		return;
		}
	if (strncmpf(command, "-time", 5)==0)
		{
		web_debug_time();
		return;
		}
	#ifdef IP_ENABLE
	if (strncmpf(command, "-ip", 3)==0)
		{
		if(debug_string2ip(command, ip, 0x0)!=0)
			{
			debug_print_ip("old IP", ip_address);
			memcpy(ip_address, ip, sizeof(ip_address));
			debug_print_ip("new IP", ip_address);
			#ifdef ENABLE_IP_FROM_EEPROM
			debug_print_ip_ee("old eeprom IP", eeprom_ip);
			util_memcpy2e(eeprom_ip, ip, sizeof(eeprom_ip));	// our internet protocol (IP) address
			debug_print_ip_ee("new eeprom IP", eeprom_ip);
	        #endif
			}
		else
			debug_print_ip("IP", ip_address);
		return;
		}
	if (strncmpf(command, "-submask", 4)==0)
		{
		if(debug_string2ip(command, ip, 0x0)!=0)
			{
			debug_print_ip("old SUBMASK", ip_subnet_mask);
			memcpy(ip_subnet_mask, ip, sizeof(ip_subnet_mask));
			debug_print_ip("new SUBMASK", ip_subnet_mask);
			#ifdef ENABLE_IP_FROM_EEPROM
			debug_print_ip_ee("old eeprom SUBMASK", eeprom_submask);
			util_memcpy2e(eeprom_submask, ip, sizeof(eeprom_submask));	// subnet mask
			debug_print_ip_ee("new eeprom SUBMASK", eeprom_submask);
			#endif
			}
		else
			debug_print_ip("SUBMASK", ip_subnet_mask);
		return;
		}
	if (strncmpf(command, "-gateway", 4)==0)
		{
		if(debug_string2ip(command, ip, 0x0)!=0)
			{
			debug_print_ip("old GATEWAY", ip_gateway);
			memcpy(ip_gateway, ip, sizeof(ip_gateway));
			debug_print_ip("new GATEWAY", ip_gateway);
			#ifdef ENABLE_IP_FROM_EEPROM
			debug_print_ip_ee("old eeprom GATEWAY", eeprom_gateway);
			util_memcpy2e(eeprom_gateway, ip, sizeof(eeprom_gateway));	// standard gateway
			debug_print_ip_ee("new eeprom GATEWAY", eeprom_gateway);
			#endif
			}
		else
			debug_print_ip("GATEWAY", ip_gateway);
		return;
		}
	if (strncmpf(command, "-save-ip", 5)==0)
		{
		debug_print_ip("IP", ip_address);
		result =  board_store_ip_addresses(ip_address, ip_subnet_mask, ip_gateway);
		printf("board_store_ip_addresses() return: %1u\r\n", result);
		debug_print_ip("IP", ip_address);
		result =  board_load_ip_addresses(ip_address, ip_subnet_mask, ip_gateway);
		printf("board_load_ip_addresses() return: %1u\r\n", result);
		debug_print_ip("IP", ip_address);
		return;
		}
	#endif	// #ifdef IP_ENABLE
	#ifdef WEB_DEBUG_MEASURE
	if (strncmpf(command, "-measure", 5)==0)
		{
		measure_diplay();
		return;
		}
	#endif	// #ifdef WEB_DEBUG_MEASURE
	#ifdef ICMP_ENABLE
	if (strncmpf(command, "-ping", 3)==0)
		{
		if (debug_string2ip(command, ip, 0x0) != 0)
			{
			if ((web_debug_flag & WEB_DEBUG_ICMP_BIT)==0)
				putsf("enable icmp-debug with \"debug icmp\" to display the data\r");
			web_debug_ping(ip);
			}
		}
	#endif	// #ifdef ICMP_ENABLE
	#if defined(BOOTP_ENABLE)&& defined(WEB_DEBUG_BOOTP)
	if (strncmpf(command, "-bootp", 4)==0)
		{
		bootp_display();
		}
	#endif
	#if defined(UDP_ENABLE)&& defined(WEB_DEBUG_UDP)
	if (strncmpf(command, "-udp-info", 4)==0)
		{
		data=debug_get_int_parameter(command);
		if(data==-1)
			data=0;
		if(data>=UDP_MAX_CONNECTIONS)
			data=(UDP_MAX_CONNECTIONS-1);
		udp_info(data);
		}
	#endif
	#if defined(ARP_ENABLE)&& defined(WEB_DEBUG_ARP)
	if (strncmpf(command, "-arp", 4)==0)
		{
		if(debug_string2ip(command, ip, 0x0)!=0)
			{
			if((web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)==0)
				putsf("enable arp-debug with \"debug arp\" to display the data\r");
			arp_prepare_request(ip, ARP_REQUEST_IP);
			}
		}
	#endif
	#if defined(RARP_ENABLE)&& defined(WEB_DEBUG_RARP)
	if (strncmpf(command, "-rarp", 5)==0)
		{
		if((web_debug_flag & WEB_DEBUG_ARP_RARP_BIT)==0)
			putsf("enable rarp-debug with \"debug rarp\" to display the data\r");
		rarp_prepare_request();
		}
	#endif
	}
}
#endif		// #ifdef WEB_DEBUG