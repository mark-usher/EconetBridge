// ************************************************************************************************
///
/// \file 			tcp.c
/// \brief			Implementation of TCP
///
/// \date	 		$LastChangedDate: 2007-08-13 18:41:59 +0200 (Mo, 13 Aug 2007) $
/// \version 		$Rev: 676 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// \par History
///					1.) 03.11.2003 Version 2.02
///						a.)	- function tcp_handle_retransmission() displays the data frames 
///			                inside of Debug-Mode (debug tcp ON);
///					2.) 08.01.2004 Version 2.03
///						a.)	- add some debug informations;
///						b.)	- big Error inside of "tcp_process_frame()"
///			                the Passive Open doesn't work together with "tcp_abort()" and 
///			                therefore a new Connection with a other "tcp_sorce_port" doesn't 
///			                work - some new Commands to break a Passive Connection
///					3.) 25.02.2004 Version 2.03
///						a.)	- functions "tcp_prepare_frame()" and "tcp_prepare_data_frame()" use
///			                now the IP-function "ip_header_write()" 
///					4.) 16.06.2004 Version 2.04
///						a.)	- new function "tcp_get_struct()" checks the TCP-Connection Handler
///			    	5.) 29.06.2004
///			          	a.) - new macro ADD_PSH_TO_PAYLOAD adds PSH-Flag to each payload packet
///			                otherwise problems with delays in some windows-tcp/ip-stacks occur
///			      	6.) 02.07.2004      
///			        	a.) - rename macro "ADD_PSH_TO_PAYLOAD" to "TCP_ADD_PSH_FLAG"
///			     	7.) 19.08.2004      
///			          	a.) - new function "tcp_alive_enable()" and "tcp_alive_disable()"
///			              	- enbale with Macro "TCP_ALIVE_ENABLE"
///						--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef _DOXYGEN_PARSER_
#define TCP_ENABLE
#endif

#ifdef TCP_ENABLE

#include <stdio.h>
#include <string.h>
#include "util.h"
#include "board.h"
#include "device.h"
#include "ethernet.h"
#include "buffer.h"
#include "ip.h"
#ifdef IPSEC_ENABLE
#include "ipsec.h"
#endif
#include "arp_rarp.h"
#include "icmp.h"
#include "tcp.h"
#ifdef WEB_DEBUG_MEASURE			// enable time-measure debug functions, see measure.c
#include "measure.h"
#endif
#ifdef TCP_DEBUG
#include "debug.h"
#include "tcp_debug.h"
#endif

#pragma regalloc-
TCP_STRUCTURE 	tcp_struct[TCP_MAX_CONNECTIONS];
unsigned int 	tcp_isn_high_number;	  		// upper word of our Initial Sequence Number
#ifdef TCP_DEBUG
unsigned int 	tcp_rw_frame_count=0;
#endif
#pragma regalloc+

// local prototyps
void 			tcp_tx_buffer_ack(TCP_STRUCTURE *p_struct, unsigned long tcp_ack);
void 			tcp_rx_buffer_read_frame(unsigned char tcp_connection, 
										unsigned int tcp_data_count, unsigned long tcp_sequence);
void 			tcp_prepare_frame(unsigned char tcp_connection, unsigned int tcp_code);
unsigned char 	tcp_prepare_data_frame(unsigned char tcp_connection, TCP_DATA_FRAME_MODE mode, 
										unsigned char act_tx_buffer);
void 			tcp_start_retry_timer(TCP_STRUCTURE *p_struct);
void 			tcp_start_wait_timer(TCP_STRUCTURE	*p_struct);
void 			tcp_stop_timer(TCP_STRUCTURE *p_struct);
void 			tcp_handle_retransmission(unsigned char tcp_connection);
void 			tcp_handle_timeout(TCP_STRUCTURE	*p_struct);
void 			tcp_close_flags(unsigned char tcp_connection);
void 			tcp_connect_flags(unsigned char tcp_connection);
unsigned char 	tcp_tx_buffer_free(TCP_STRUCTURE *p_struct);
void 			tcp_generate_isn(TCP_STRUCTURE *p_struct, TCP_GENERATE_ISN_MODE mode);

#define DATA_OFS_MASK			0xF000              // number of 32 bit words in the TCP Header
#define TCP_CODE_FIN			0x0001
#define TCP_CODE_SYN			0x0002
#define TCP_CODE_RST			0x0004
#define TCP_CODE_PSH			0x0008
#define TCP_CODE_ACK			0x0010
#define TCP_CODE_URG			0x0020
#ifdef TCP_ALIVE_ACTIVE_ENABLE
#define TCP_CODE_ACK_ALIVE		0x0810				// new ACK-Typ to handle the Alive-ACK
#endif

//*********************************************************************************
// Description	: checks the connection-Number and calculate the address to TCP-Structure
// Input   		: tcp_connection - 
// Output  		: TCP_STRUCTURE  - address to tcp-structure
// Indication	: easyToWeb-API function
//*********************************************************************************
TCP_STRUCTURE *tcp_get_struct(unsigned char tcp_connection)
{
if((tcp_connection!=TCP_WRONG_CONNECTIONS)&&(tcp_connection<TCP_MAX_CONNECTIONS))
	return &tcp_struct[tcp_connection];
return 0x0;
}


//*********************************************************************************
// Description	: initializes ONE Entry of TCP-Stack
// Input   		: none
// Output  		: none
// Indication	: internal easyToWeb function
//*********************************************************************************
void tcp_init_entry(TCP_STRUCTURE *p_struct)
{
unsigned int window_size_temp;

window_size_temp = p_struct->tcp_max_window_size;	// rescue max window size value, before init
memset(p_struct, 0x0, sizeof(TCP_STRUCTURE));
p_struct->tcp_state_machine=CLOSED;
p_struct->tcp_socket_status = SOCK_PASSIVE_OPEN | SOCK_DISCONNECTED;	// disconnect
p_struct->tcp_socket_error=SOCK_ERR_OK;
p_struct->tcp_rx.gap = TCP_RX_BUFFER_SIZE;
if(window_size_temp==0)
    window_size_temp=TCP_MAX_WINDOW_SIZE;           // set default value
p_struct->tcp_max_window_size = window_size_temp;   // restore max window size value
p_struct->tcp_window_local = p_struct->tcp_max_window_size;	// max. length of TCP-data we accept
#ifdef TCP_DEBUG
p_struct->last_tcp_socket_error=SOCK_ERR_OK;
p_struct->last_tcp_state_machine=TCP_UNREACHED;
#endif
memset(p_struct->tcp_ip_remote, 0xff, IP_ADR_SIZE);
#ifdef TCP_ALIVE_ACTIVE_ENABLE
p_struct->tcp_alive_time=TCP_ALIVE_DEFAULT_TIME;
#endif
}

//*********************************************************************************
// Description	: initializes the TCP-Stack
// Input   		: none
// Output  		: none
// Indication	: easyToWeb-API function
//*********************************************************************************
void tcp_init(void)
{
unsigned char 			Lva;
TCP_STRUCTURE*			p_struct;                                    	

#ifdef TCP_DEBUG
tcp_debug_init();
#endif

p_struct = &tcp_struct[0];                                    	
for (Lva=0; Lva<TCP_MAX_CONNECTIONS; Lva++)
	{
	tcp_init_entry(p_struct);
	p_struct++;                                    	
	}
}

//*********************************************************************************
// Description	: init the "tcp_connection"
// Input   		: tcp_connection - actual TCP-connection
// Output  		: none
// Indication	: easyToWeb-API function
//*********************************************************************************
void tcp_init_connection(unsigned char tcp_connection)
{
TCP_STRUCTURE	*p_struct;                                    	

p_struct=tcp_get_struct(tcp_connection);
if(p_struct)
	{
	tcp_init_entry(p_struct);
	}
}

//*********************************************************************************
// Description	: passive first open of TCP-stack
// Input   		: tcp_local_port - actual tcp port
// Output  		: actual "tcp_connection", see TCP_MAX_CONNECTIONS
// Indication	: easyToWeb-API function
//*********************************************************************************
unsigned char tcp_passive_open(unsigned int tcp_local_port)
{
unsigned char Lva;
TCP_STRUCTURE	*p_struct;                                    	

p_struct=&tcp_struct[0];                                    	
for(Lva=0;Lva<TCP_MAX_CONNECTIONS; Lva++)
	{
	if(!(p_struct->tcp_flags & TCP_FLAG_OPEN)&&
	   !(p_struct->tcp_socket_status & SOCK_READY_CONNECT)&&
	   (p_struct->tcp_state_machine==CLOSED))
		{
		tcp_init_entry(p_struct);					// init all entries of TCP-Data
		p_struct->tcp_flags=TCP_FLAG_PASSIVE | TCP_FLAG_OPEN;	// let's do a passive open!
		p_struct->tcp_state_machine=LISTEN;
		p_struct->tcp_socket_status=SOCK_READY_CONNECT | SOCK_PASSIVE_OPEN | SOCK_DISCONNECTED;		// reset, socket now available
		p_struct->tcp_port_local = tcp_local_port;	// set port we want to listen to
		#ifdef TCP_DEBUG
		if (tcp_debug_flag)
			printf("TCP-O(%u,x) Passive Open: %u\r\n", Lva, tcp_local_port);
		#endif	// #ifdef TCP_DEBUG
		return Lva;
		}
	p_struct++;
	}
#ifdef TCP_DEBUG
if (tcp_debug_flag)
	printf("TCP-O(x,x) Passive Open: %u ERROR\r\n", tcp_local_port);
#endif
return TCP_WRONG_CONNECTIONS;
}


//*********************************************************************************
// Description	: passive re-open of TCP-stack
// Input   		: tcp_connection - actual TCP-connection
// Output  		: none
// Indication	: listen on "tcp_struct[tcp_connection].tcp_local_port" 
//				: for an incoming connection) 
//*********************************************************************************
void tcp_passive_reopen(unsigned char tcp_connection)
{
TCP_STRUCTURE	*p_struct;                                    	
unsigned int temp_tcp_local_port;

if(tcp_get_struct(tcp_connection))
	{
	p_struct=&tcp_struct[tcp_connection];                                    	
	if(!(p_struct->tcp_flags & TCP_FLAG_OPEN)&&
		(p_struct->tcp_flags & TCP_FLAG_PASSIVE)&&
	   !(p_struct->tcp_socket_status & SOCK_READY_CONNECT)&&
   	    (p_struct->tcp_state_machine==CLOSED))
		{
		temp_tcp_local_port=p_struct->tcp_port_local;			// save port who we want to listen to
		tcp_init_entry(p_struct);								// init all entries of TCP-Data
		p_struct->tcp_flags=TCP_FLAG_PASSIVE | TCP_FLAG_OPEN;	// let's do a passive open!
		p_struct->tcp_state_machine=LISTEN;
		p_struct->tcp_socket_status=SOCK_READY_CONNECT | SOCK_PASSIVE_OPEN | SOCK_DISCONNECTED;	// reset, socket now passive open
		p_struct->tcp_port_local = temp_tcp_local_port;		// set port we want to listen to
		#ifdef TCP_DEBUG
		if (tcp_debug_flag)
			printf("TCP-O(%u,x) Passive Reopen: %u\r\n", tcp_connection, p_struct->tcp_port_local);
		#endif
		}
	}
}


//*********************************************************************************
// Description	: does an active open (tries to establish a connection between
//              : tcp_port_local' and 'tcp_port_remote
// Input   		: dest_ip_address - pointer to 
//         		: dest_port 	- 
//         		: source_port 	- 
// Output  		: none
// Indication	: easyToWeb-API function
//*********************************************************************************
unsigned char tcp_active_open(unsigned char *dest_ip_address, unsigned int dest_port, unsigned int source_port)
{
unsigned char 	Lva;
TCP_STRUCTURE	*p_struct;                                    	
#ifdef ARP_CACHE_ENABLE
unsigned char	*mac_adr;
#endif

p_struct=&tcp_struct[0];                                    	
for(Lva=0;Lva<TCP_MAX_CONNECTIONS; Lva++)
	{
	if(!(p_struct->tcp_flags & TCP_FLAG_OPEN)&&
	   ((p_struct->tcp_state_machine==CLOSED)||(p_struct->tcp_state_machine==LISTEN)))
		{
		//  --------------------------------------------------------------------------------
		//	Reset TCP-Struct-Entry
		//  -------------------------------------------------------------------------------- 
		tcp_init_entry(p_struct);						 			// init all entries of TCP-Data
		p_struct->tcp_flags = TCP_FLAG_ACTIVE | TCP_FLAG_OPEN;		// let's do an active open!
		//  --------------------------------------------------------------------------------
		//	Calculate ARP-Entry
		//  -------------------------------------------------------------------------------- 
		#ifdef ARP_ENABLE
		#ifdef ARP_CACHE_ENABLE
		mac_adr=arp_cache(dest_ip_address, 0x0);
		if(mac_adr!=0)
			{
			memcpy(p_struct->tcp_mac_remote, mac_adr, 6);				// save mac address
			p_struct->tcp_flags |= TCP_FLAG_IP_ADDR_RESOLVED;
			}
		else
			{
			arp_prepare_request(dest_ip_address, ARP_REQUEST_IP);	 	// ask for MAC by sending a broadcast
			p_struct->tcp_last_frame_sent = TCP_ARP_REQUEST;
			tcp_start_retry_timer(p_struct);
			}
		#else
		arp_prepare_request(dest_ip_address, ARP_REQUEST_IP);	 	// ask for MAC by sending a broadcast
		p_struct->tcp_last_frame_sent = TCP_ARP_REQUEST;
		tcp_start_retry_timer(p_struct);
		#endif	// #ifdef ARP_CACHE_ENABLE
		#endif	// #ifdef ARP_ENABLE
		//  --------------------------------------------------------------------------------
		//	Set new value
		//  -------------------------------------------------------------------------------- 
		p_struct->tcp_socket_status = SOCK_READY_CONNECT | SOCK_ACTIVE_OPEN | SOCK_DISCONNECTED;	// reset, socket now active
		p_struct->tcp_port_local = source_port;			// set port we want to listen to
		p_struct->tcp_port_remote = dest_port;			// destination port of data
		memcpy(p_struct->tcp_ip_remote, dest_ip_address, IP_ADR_SIZE);
		#ifdef TCP_DEBUG
		if (tcp_debug_flag)
			{
			printf("TCP-O(%u,x) Active Open: %u ", Lva, dest_port);
			debug_print_ip("", dest_ip_address);
			}
		#endif	// #ifdef TCP_DEBUG
		return Lva;
		}
	p_struct++;
	}
#ifdef TCP_DEBUG
if (tcp_debug_flag)
	printf("TCP-O(x,x) Active Open: %u ERROR\r\n", dest_port);
#endif
return TCP_WRONG_CONNECTIONS;
}


//*********************************************************************************
// Description	: closes an open connection
// Input   		: tcp_connection - number of tcp-connection
// Output  		: none
// Indication	: easyToWeb-API function
//*********************************************************************************
void tcp_close(unsigned char tcp_connection)
{
TCP_STRUCTURE	*p_struct;                                    	

if(tcp_get_struct(tcp_connection))
	{
	p_struct=&tcp_struct[tcp_connection];                                    	
	switch(p_struct->tcp_state_machine)
		{
		case LISTEN   :
		case SYN_SENT :
			tcp_close_flags(tcp_connection);	// reset all flags, stop retransmission..., but data available
			p_struct->tcp_socket_status = 0;
			break;
		case SYN_RCVD :
		case ESTABLISHED :
			p_struct->tcp_socket_status|= SOCK_DISCONNECTING;	// under disconnect
			p_struct->tcp_flags |= TCP_FLAG_CLOSE_REQUESTED;
			break;
		default:
			#ifdef TCP_DEBUG
			if (tcp_debug_flag)
				printf("TCP-T(%u,x) \"tcp_close\" wrong state: %p\r\n", tcp_connection, tcp_state_name[p_struct->tcp_state_machine]); 
			#endif
			break;
		}
	}
}


//*********************************************************************************
// Description	: abort an open connection
// Input   		: tcp_connection - number of tcp-connection
// Output  		: none
// Indication	: easyToWeb-API function
//*********************************************************************************
void tcp_abort(unsigned char tcp_connection)
{
TCP_STRUCTURE	*p_struct;

if(tcp_get_struct(tcp_connection))
	{
	p_struct=&tcp_struct[tcp_connection];                                    	
	switch(p_struct->tcp_state_machine)
		{
		case LISTEN   :
		case SYN_SENT :
			tcp_close(tcp_connection);
			break;
		case SYN_RCVD :
		case ESTABLISHED :
			p_struct->tcp_socket_status|= SOCK_DISCONNECTING;	// under disconnect
			p_struct->tcp_flags |= TCP_FLAG_ABORT;
			break;
		default:
			#ifdef TCP_DEBUG
			if (tcp_debug_flag)
				printf("TCP-T(%u,x) \"tcp_abort\" wrong state: %p\r\n", tcp_connection, tcp_state_name[p_struct->tcp_state_machine]); 
			#endif
			break;
		}
	}
}


//*********************************************************************************
// Description	: reads the actual error code
// Input   		: tcp_connection - number of tcp-connection
// Output  		: RETURN: error code, see "SOCK_ERR_xxx"
// Indication	: none
//*********************************************************************************
unsigned char tcp_get_error(unsigned char tcp_connection)
{
TCP_STRUCTURE	*p_struct;
unsigned char	error=0;

if(tcp_get_struct(tcp_connection))
	{
	p_struct=&tcp_struct[tcp_connection];                                    	
	error=p_struct->tcp_socket_error;
	#ifdef TCP_DEBUG
	p_struct->last_tcp_socket_error=p_struct->tcp_socket_error;
	#endif
	p_struct->tcp_socket_error=SOCK_ERR_OK;
	}
return error;
}

#ifdef TCP_ALIVE_ACTIVE_ENABLE
//*********************************************************************************
// Description	: sets the time of Alive-Funktion of TCP-Stack
// Input   		: tcp_connection - index to TCP-Connection
//              : alive_time	 - *50ms timeout until check the connection
//              :                  if "alive_time"==0 than "TCP_ALIVE_DEFAULT_TIME"
// Output  		: none
// Indication	: easyToWeb-API function
// 				: NOTE: the alive_time will limeted to TCP_ALIVE_MIN_TIME and TCP_ALIVE_MAX_TIME
//*********************************************************************************
void tcp_alive_set_time(unsigned char tcp_connection, unsigned int alive_time)
{
TCP_STRUCTURE	*p_struct;

if(tcp_get_struct(tcp_connection))
	{
	p_struct=&tcp_struct[tcp_connection];                                    	
	if(alive_time==0)
		alive_time=TCP_ALIVE_DEFAULT_TIME;
	if(alive_time<TCP_ALIVE_MIN_TIME)
		alive_time=TCP_ALIVE_MIN_TIME;
	if(alive_time>TCP_ALIVE_MAX_TIME)
		alive_time=TCP_ALIVE_MAX_TIME;
	p_struct->tcp_alive_time=alive_time;
	#ifdef TCP_DEBUG
	if (tcp_debug_flag)
		printf("TCP-A(%u,x) Alive time (%u0ms)\r\n", tcp_connection, alive_time*5); 
	#endif
	}
}


//*********************************************************************************
// Description	: enables the Alive-Funktion of TCP-Stack
// Input   		: tcp_connection - index to TCP-Connection
// Output  		: none
// Indication	: easyToWeb-API function
//*********************************************************************************
void tcp_alive_enable(unsigned char tcp_connection)
{
TCP_STRUCTURE	*p_struct;

if(tcp_get_struct(tcp_connection))
	{
	p_struct=&tcp_struct[tcp_connection];                                    	
	p_struct->tcp_alive_delay=p_struct->tcp_alive_time;
	p_struct->tcp_alive_timeout_delay=(unsigned int)(TCP_ALIVE_TIMEOUT_FACTOR*p_struct->tcp_alive_time);
	p_struct->tcp_alive_50ms_bit=0;
	p_struct->tcp_alive_flag=TCP_ALIVE_FLAG_ENABLE;
	if(p_struct->tcp_state_machine == ESTABLISHED)	// TCP-state OK than open TCP-Alive
		p_struct->tcp_alive_flag|=TCP_ALIVE_FLAG_OPEN;
	#ifdef TCP_DEBUG
	if (tcp_debug_flag)
		{
		printf("TCP-A(%u,x) Alive enable ", tcp_connection); 
		if(p_struct->tcp_alive_flag & TCP_ALIVE_FLAG_OPEN)
			printf("+ open "); 
		printf("(%u0ms; timeout:%u0ms)\r\n", p_struct->tcp_alive_time*5, p_struct->tcp_alive_timeout_delay*5); 
		}
	#endif
	}
}


//*********************************************************************************
// Description	: disables the Alive-Funktion of TCP-Stack
// Input   		: tcp_connection -  index to TCP-Connection
// Output  		: none
// Indication	: easyToWeb-API function
//*********************************************************************************
void tcp_alive_disable(unsigned char tcp_connection)
{
if(tcp_get_struct(tcp_connection))
	{
	tcp_struct[tcp_connection].tcp_alive_flag=0;
	#ifdef TCP_DEBUG
	if (tcp_debug_flag)
		printf("TCP-A(%u,x) Alive disable\r\n", tcp_connection); 
	#endif
	}
}

//*********************************************************************************
// Description	: function to handle the Alive-Funktion
// Input   		: tcp_connection -  index to TCP-Connection
// Output  		: none
// Indication	: internal easyToWeb function
//*********************************************************************************
void tcp_alive_main(unsigned char tcp_connection)
{
TCP_STRUCTURE *p_struct;

p_struct=&tcp_struct[tcp_connection];                                    	
if(p_struct->tcp_alive_flag & TCP_ALIVE_FLAG_OPEN)
	{
	if(p_struct->tcp_alive_50ms_bit)
		{
		p_struct->tcp_alive_50ms_bit=0;	// disable 50ms Bit
		if(p_struct->tcp_alive_timeout_delay)
			p_struct->tcp_alive_timeout_delay--;
		else
			{
			#ifdef TCP_DEBUG
			if (tcp_debug_flag)
				printf("TCP-A(%u,x) Alive Close\r\n", tcp_connection); 
			#endif
			p_struct->tcp_alive_flag=0;
			tcp_close(tcp_connection);
			}
		if(p_struct->tcp_alive_delay)
			p_struct->tcp_alive_delay--;
		else
			{
			tcp_prepare_frame(tcp_connection, TCP_CODE_ACK_ALIVE);	// ACK a retransmission
			p_struct->tcp_alive_delay=p_struct->tcp_alive_time;
			}
		}
	}
}
#endif // #ifdef TCP_ALIVE_ACTIVE_ENABLE

//*********************************************************************************
// Description	: clears TCP-RX Buffer and allows easyToWeb to store new data
// Input   		: tcp_connection - number of tcp-connection
// Output  		: none
// Indication	: easyToWeb-API function
//*********************************************************************************
void tcp_rx_buffer_clear(unsigned char tcp_connection)
{
TCP_STRUCTURE	*p_struct;

p_struct=tcp_get_struct(tcp_connection);
if(p_struct)
	{
	p_struct->tcp_socket_status &= ~SOCK_DATA_AVAILABLE;
	p_struct->tcp_rx.wtop=0;
	p_struct->tcp_rx.rtop=0;
	p_struct->tcp_rx.gap=TCP_RX_BUFFER_SIZE;	// rx data-buffer empty
    p_struct->tcp_window_local=p_struct->tcp_max_window_size;	// max. length of TCP-data we accept
	}
}

//*********************************************************************************
// Description	: reads the TCP-data from DEVICE and handle the ACK-Frames
// Input   		: tcp_connection - index to TCP-Connection
//         		: *dest_data - pointer read-buffer
//                             with dest_data==0x0 it doesn't copy the data but sets the internal variables 
//         		: *tcp_data_count - size of data to read or
//                                  delivers with *tcp_data_count==0 the actual size of RX-Data
// Output  		: none
// Indication	: easyToWeb API function
//*********************************************************************************
unsigned char  *tcp_rx_buffer_read(unsigned char tcp_connection, unsigned char *data_dest, unsigned int *tcp_data_count, 
                                      TCP_RX_BUFFER_READ_MODE read_mode)
{
TCP_STRUCTURE	*p_struct;                                    	
unsigned int temp;

p_struct=tcp_get_struct(tcp_connection);
if(p_struct)
	{
	if(p_struct->tcp_socket_status & SOCK_DATA_AVAILABLE)
		{
		if(tcp_data_count==0x0)
			return 0x0;
		else if(read_mode==TCP_RX_BUFFER_GET_SIZE)
			{
			*tcp_data_count=(TCP_RX_BUFFER_SIZE-p_struct->tcp_rx.gap);		// data-count 
			return &p_struct->tcp_rx.data_frame[p_struct->tcp_rx.rtop];
			}
		else if((read_mode==TCP_RX_BUFFER_READ_DATA)||(read_mode==TCP_RX_BUFFER_SET_DATA))
			{
			if((read_mode==TCP_RX_BUFFER_READ_DATA)&&(data_dest==0x0))
				return 0x0;
			if(*tcp_data_count>(TCP_RX_BUFFER_SIZE-p_struct->tcp_rx.gap))
				*tcp_data_count=(TCP_RX_BUFFER_SIZE-p_struct->tcp_rx.gap);
			temp=TCP_RX_BUFFER_SIZE-p_struct->tcp_rx.rtop;	
			if(temp<*tcp_data_count)		// found overflow
				{
				if(read_mode==TCP_RX_BUFFER_READ_DATA)
					{
					memcpy(data_dest, &p_struct->tcp_rx.data_frame[p_struct->tcp_rx.rtop], temp);	// read data
					data_dest+=temp;
					}
				p_struct->tcp_rx.rtop=0;
				temp=(*tcp_data_count-temp);
				}
			else
				temp=*tcp_data_count;	// set full size
			if(read_mode==TCP_RX_BUFFER_READ_DATA)
				memcpy(data_dest, &p_struct->tcp_rx.data_frame[p_struct->tcp_rx.rtop], temp);	// read data
			p_struct->tcp_rx.rtop+=temp;
			p_struct->tcp_rx.gap+=*tcp_data_count;	
			#ifdef TCP_DEBUG
			if (tcp_debug_flag)
				if(read_mode==TCP_RX_BUFFER_READ_DATA)
					printf("TCP-R(%u,%u) buffer_read: %u/%u\r\n", tcp_connection, tcp_rw_frame_count, *tcp_data_count, TCP_RX_BUFFER_SIZE-p_struct->tcp_rx.gap);
			#endif
    		if(p_struct->tcp_rx.wtop==p_struct->tcp_rx.rtop)	// if buffer empty
				{
				p_struct->tcp_rx.wtop=0;
				p_struct->tcp_rx.rtop=0;
				p_struct->tcp_rx.gap=TCP_RX_BUFFER_SIZE;	// rx data-buffer empty?
				p_struct->tcp_socket_status &= ~SOCK_DATA_AVAILABLE;
				}
            if(p_struct->tcp_rx.gap<p_struct->tcp_max_window_size)
				p_struct->tcp_window_local=p_struct->tcp_rx.gap;
			else if(p_struct->tcp_rx.gap>=p_struct->tcp_max_window_size)
				p_struct->tcp_window_local=p_struct->tcp_max_window_size;
			return &p_struct->tcp_rx.data_frame[p_struct->tcp_rx.rtop];
			}
		}
	}
return 0x0;
}


//*********************************************************************************
// Description	: check the data-length and and store in 'TCP_TX_BUF'
// Input   		: tcp_connection   	 -  index to TCP-Connection
//				: rem_data 	 		 - pointer to data
//				: flash_data 		 - pointer to data
// 		   		: datalen 			 - length of data
// Output  		: 0 				 - no connection or no buffer
// 		  		: 1..TCP_TX_BUFFER_SIZE - size of data to buffer
// Indication	: internal function
//*********************************************************************************
unsigned int tcp_tx_buffer_write_internal(unsigned char tcp_connection, unsigned char *ram_data, flash unsigned char *flash_data, 
                                           unsigned int datalen, TCP_TX_BUFFER_WRITE_MODE write_mode)
{
static unsigned char last_tx_buffer=0;
static unsigned char last_tx_age=0;
TCP_STRUCTURE  		*p_struct;                                    	
unsigned char 		temp_count, Lva;
unsigned int 		temp_datalen, block_datalen;
TCP_TX_BUFFER_STRUCTURE *p_tx_buffer;

if(tcp_get_struct(tcp_connection))
	{
	p_struct=&tcp_struct[tcp_connection];                                    	
	if((p_struct->tcp_state_machine == ESTABLISHED)||
	   (p_struct->tcp_state_machine == CLOSE_WAIT))
   		{
		temp_datalen=0;
		for(temp_count=0;temp_count<TCP_TX_BUFFER_COUNT; temp_count++)
			{
			p_tx_buffer=&p_struct->tcp_tx[temp_count];
			if((p_tx_buffer->flags & TCP_TX_FLAG_FREE)||
			   (p_tx_buffer->flags & TCP_TX_FLAG_HALF_FULL))
				{
				if(!(p_tx_buffer->flags & TCP_TX_FLAG_HALF_FULL))
					{
					p_tx_buffer->data_position=&p_tx_buffer->data_frame[TCP_DATA_OFS]; 	// pointer to tcp-data
					p_tx_buffer->data_count=0;		// the tx-buffer is realy empthy
					}
				temp_datalen+=TCP_TX_SEGMENT_SIZE-p_tx_buffer->data_count;
				}
			}
		if(write_mode==TCP_TX_BUFFER_GET_SIZE)
			return temp_datalen;
		else if((write_mode==TCP_TX_BUFFER_WRITE_FLASH_DATA)||(write_mode==TCP_TX_BUFFER_WRITE_RAM_DATA)||(write_mode==TCP_TX_BUFFER_SET_DATA))
			{
			if(datalen==0)
				return 0; 
			if((write_mode==TCP_TX_BUFFER_WRITE_FLASH_DATA)&&(flash_data==0x0))
				{
				#ifdef TCP_DEBUG
				if (tcp_debug_flag)
					printf("TCP-D(%u,%u) buffer_write: no flash buffer\r\n", tcp_connection, tcp_rw_frame_count);
				#endif
				return 0;
				}
			if((write_mode==TCP_TX_BUFFER_WRITE_RAM_DATA)&&(ram_data==0x0))
				{
				#ifdef TCP_DEBUG
				if (tcp_debug_flag)
					printf("TCP-D(%u,%u) buffer_write: no ram buffer\r\n", tcp_connection, tcp_rw_frame_count);
				#endif
				return 0;
				}
			if(datalen>temp_datalen)
				datalen=temp_datalen;
			temp_datalen=datalen;
			temp_count=0;
			while(temp_count<TCP_TX_BUFFER_COUNT)
				{
				if(last_tx_buffer>=TCP_TX_BUFFER_COUNT)
					last_tx_buffer=0;
				p_tx_buffer=&p_struct->tcp_tx[last_tx_buffer];
				if((p_tx_buffer->flags & TCP_TX_FLAG_FREE)||
				   (p_tx_buffer->flags & TCP_TX_FLAG_HALF_FULL))
					{
					block_datalen=temp_datalen;
					if(block_datalen>(TCP_TX_SEGMENT_SIZE-p_tx_buffer->data_count))
						block_datalen=TCP_TX_SEGMENT_SIZE-p_tx_buffer->data_count;
					if(write_mode==TCP_TX_BUFFER_WRITE_RAM_DATA)
						{
						memcpy(p_tx_buffer->data_position, ram_data, block_datalen);
						ram_data+=block_datalen;
						}
					if(write_mode==TCP_TX_BUFFER_WRITE_FLASH_DATA)
						{
						memcpyf(p_tx_buffer->data_position, flash_data, block_datalen);
						flash_data+=block_datalen;
						}
					#ifdef TCP_DEBUG
					if (tcp_debug_flag)
						printf("TCP-D(%u,%u) buffer_write: %uByte\r\n", tcp_connection, tcp_rw_frame_count, block_datalen);
					#endif
					temp_datalen-=block_datalen;
					p_tx_buffer->data_position+=block_datalen;
					p_tx_buffer->data_count+= block_datalen;				// bytes to xfer
					if(p_tx_buffer->data_count & 0x01)
						*p_tx_buffer->data_position=0x0;			// set last databyte to Null
					p_tx_buffer->flags &= ~TCP_TX_FLAG_FREE;		// Buffer no free
					p_tx_buffer->flags |= TCP_TX_FLAG_FULL;			// occupy tx-buffer
					if(p_tx_buffer->data_count<TCP_TX_SEGMENT_SIZE)
						p_tx_buffer->flags |= TCP_TX_FLAG_HALF_FULL;
					else
						p_tx_buffer->flags &= ~TCP_TX_FLAG_HALF_FULL;	// TX-Buffer is full
					//  --------------------------------------------------------------------------------
					//	Calculate the AGE-Parameter of TX-Buffer
					//  -------------------------------------------------------------------------------- 
					if(last_tx_age==0)
						{
						for(Lva=0;Lva<TCP_TX_BUFFER_COUNT;Lva++)
							{
							if(p_struct->tcp_tx[Lva].flags & TCP_TX_FLAG_FULL)
								p_struct->tcp_tx[Lva].age+=TCP_TX_BUFFER_AGE_OVER;
							}
						last_tx_age=TCP_TX_BUFFER_AGE_OVER;
						}
					p_tx_buffer->age=last_tx_age;	// set new age of buffer
					last_tx_age++;
					if(temp_datalen==0)
						return datalen;
					}
				last_tx_buffer++;
				temp_count++;
				} // while(temp_count<TCP_TX_BUFFER_COUNT)
			}
		}
	}
return 0;
}


//*********************************************************************************
// Description	: check the data-length and and store in 'TCP_TX_BUF'
// Input   		: tcp_connection   	 -  index to TCP-Connection
//				: ram_data 			 - pointer to RAM-data
// 		   		: datalen 			 - length of data
// Output  		: 0 				 - no connection or no buffer
// 		  		: 1..TCP_TX_BUFFER_SIZE - size of data to buffer
// Indication	: easyToWeb-API function
//*********************************************************************************
unsigned int tcp_tx_buffer_write(unsigned char tcp_connection, unsigned char *ram_data, unsigned int datalen, 
                                       TCP_TX_BUFFER_WRITE_MODE write_mode)
{
return tcp_tx_buffer_write_internal(tcp_connection, ram_data, 0x0, datalen, write_mode);
}


//*********************************************************************************
// Description	: check the data-length and and store in 'TCP_TX_BUF'
// Input   		: tcp_connection   	 -  index to TCP-Connection
//				: flash_data 		 - pointer to FLASH-data
// 		   		: datalen 			 - length of data
// Output  		: 0 				 - no connection or no buffer
// 		  		: 1..TCP_TX_BUFFER_SIZE - size of data to buffer
// Indication	: easyToWeb-API function
//*********************************************************************************
unsigned int tcp_tx_buffer_write_f(unsigned char tcp_connection, flash unsigned char *flash_data, unsigned int datalen,
                                       TCP_TX_BUFFER_WRITE_MODE write_mode)
{
return tcp_tx_buffer_write_internal(tcp_connection, 0x0, flash_data, datalen, write_mode);
}


#ifdef TCP_DEBUG
char flash *tcp_state_name[12]={
				"CLOSED", "LISTEN", "SYN_SENT", "SYN_RCVD",	
				"ESTABLISHED", "FIN_WAIT_1", "FIN_WAIT_2", "CLOSE_WAIT",			
				"CLOSING", "LAST_ACK", "TIME_WAIT", "UNREACHED"};
#endif
//*********************************************************************************
// Description	: must be called from user program periodically (the often - the better)
//              : handles network, TCP/IP-stack and user events
// Input   		: none
// Output  		: none
// Indication	: TCP 'main()'- internal function
//*********************************************************************************
void tcp_main(void)
{
#ifdef TCP_TX_DELAY_ENABLE
static unsigned char tcp_data_delay=0;			// wait until reach the delay value
#endif
static unsigned char tcp_connection=0;			// start with first tcp-connection
static unsigned char tcp_tx_buffer_count=0;		// start with first tcp-tx-buffer
unsigned char temp_count;
TCP_STRUCTURE	*p_struct;                                    	

temp_count = 0;
while (temp_count<TCP_MAX_CONNECTIONS)
	{
	tcp_connection++;
	if (tcp_connection >= TCP_MAX_CONNECTIONS)
		tcp_connection = 0;
	tcp_passive_reopen(tcp_connection);		// listen for incoming TCP-connection
	p_struct = &tcp_struct[tcp_connection];                                    	
	if (p_struct->tcp_flags & TCP_FLAG_OPEN)
		break;
	temp_count++;
	}
if (temp_count >= TCP_MAX_CONNECTIONS)	
	return;		// no open TCP-Connections
if (p_struct->tcp_flags & TCP_FLAG_OPEN)
	{
	#ifdef TCP_TX_DELAY_ENABLE
	tcp_data_delay++;
	if(tcp_data_delay==TCP_TX_DELAY_COUNT)
		{
		tcp_data_delay=0;
		tcp_prepare_data_frame(tcp_connection, TCP_DATA_FRAME_1ST_SEND, TCP_TX_BUFFER_UNDEF);
		}
	#else
	tcp_prepare_data_frame(tcp_connection, TCP_DATA_FRAME_1ST_SEND, TCP_TX_BUFFER_UNDEF);
	#endif
	//--------------------------------------------------------------------------------
	//	check, if retansmit a CTRL-Frame
	//-------------------------------------------------------------------------------- 
	if(p_struct->tcp_flags & TCP_FLAG_TIMER_CTRL_RETRANSMIT)
		{
		if(p_struct->tcp_timer >= TCP_RETRY_TIMEOUT)
			{
			p_struct->tcp_timer = 0;					// set a new timeout
			if(p_struct->tcp_retry_counter)	  			// if retry-count>0
				{
				p_struct->tcp_retry_counter--;
				tcp_handle_retransmission(tcp_connection);	// resend last frame
				}
			else
				{
				tcp_stop_timer(p_struct);
				tcp_close_flags(tcp_connection);	// reset all flags, stop retransmission..., but data available
				tcp_handle_timeout(p_struct);
				}
			}
		}
	//--------------------------------------------------------------------------------
	//	check, if retransmit a Data-Frame
	//-------------------------------------------------------------------------------- 
	temp_count=0;
	while(temp_count<TCP_TX_BUFFER_COUNT)
		{
		tcp_tx_buffer_count++;
		if(tcp_tx_buffer_count>=TCP_TX_BUFFER_COUNT)
			tcp_tx_buffer_count=0;
		if(p_struct->tcp_tx[tcp_tx_buffer_count].flags & TCP_TX_FLAG_RETRANSMIT)
			{
			if(p_struct->tcp_tx[tcp_tx_buffer_count].timer >= TCP_RETRY_TIMEOUT)
				{
				p_struct->tcp_tx[tcp_tx_buffer_count].timer = 0;
				if(p_struct->tcp_tx[tcp_tx_buffer_count].retry_counter) 			// if retry-count>0
					{
					if(tcp_prepare_data_frame(tcp_connection, TCP_DATA_FRAME_RETRANSMIT, tcp_tx_buffer_count))
						{
						#ifdef TCP_DEBUG
						p_struct->tcp_tx_repeat_data+=p_struct->tcp_tx[tcp_tx_buffer_count].data_count;	// count of repeated transmit data, see function tcp_process_frame()
						#endif
						p_struct->tcp_tx[tcp_tx_buffer_count].retry_counter--;
						}
					}
				else
					{
					p_struct->tcp_tx[tcp_tx_buffer_count].flags &= ~TCP_TX_FLAG_RETRANSMIT;
					tcp_close_flags(tcp_connection);	// reset all flags, stop retransmission..., but data available
					p_struct->tcp_socket_error|=SOCK_ERR_TCP_TIMEOUT;
					}
				}
			}
		temp_count++;
		}
	//--------------------------------------------------------------------------------
	//	check, if Timeout of FIN-Frame arrive
	//-------------------------------------------------------------------------------- 
	if(p_struct->tcp_flags & TCP_FLAG_TIMER_RUNNING)
		{
		if(p_struct->tcp_timer >= TCP_FIN_TIMEOUT)
			{
			#ifdef TCP_DEBUG
			if (tcp_debug_flag)
				printf("TCP-T(%u,%u) FIN Timeout (State: %p)\r\n", tcp_connection, tcp_rw_frame_count, tcp_state_name[p_struct->tcp_state_machine]); 
			#endif
			tcp_close_flags(tcp_connection);	// reset all flags, stop retransmission..., but data available
			p_struct->tcp_socket_error|=SOCK_ERR_TCP_TIMEOUT;
			}
		}
	switch(p_struct->tcp_state_machine)
		{
		case CLOSED :
		case LISTEN :
			if((p_struct->tcp_flags & TCP_FLAG_ACTIVE)&&  			// stack has to open a connection?
			   (p_struct->tcp_flags & TCP_FLAG_IP_ADDR_RESOLVED))	// IP resolved?
				{
				tcp_generate_isn(p_struct, TCP_GENERATE_ISN_1ST);
				p_struct->tcp_sequence_ack = 0;						// we don't know what to ACK!
				tcp_prepare_frame(tcp_connection, TCP_CODE_SYN);   	// send SYN frame
				p_struct->tcp_last_frame_sent = TCP_SYN_FRAME;
				tcp_start_retry_timer(p_struct);					// we NEED a retry-timeout
				p_struct->tcp_state_machine = SYN_SENT;
				}
			break;
		case SYN_RCVD :
		case ESTABLISHED :
			#ifdef TCP_ALIVE_ACTIVE_ENABLE
			tcp_alive_main(tcp_connection);
			#endif
			if((p_struct->tcp_flags & TCP_FLAG_CLOSE_REQUESTED)&&	  		// user has initated a close?
			   (p_struct->tcp_sequence_next==p_struct->tcp_sequence_unack)&&// all CTRL ACKed?
				tcp_tx_buffer_free(p_struct))								// user may fill buffer
				{
				p_struct->tcp_sequence_unack++;
				tcp_prepare_frame(tcp_connection, TCP_CODE_FIN | TCP_CODE_ACK);
				p_struct->tcp_last_frame_sent = TCP_FIN_FRAME;
				tcp_start_retry_timer(p_struct);
				p_struct->tcp_state_machine = FIN_WAIT_1;
				}
			if((p_struct->tcp_flags & TCP_FLAG_ABORT)&&	  					// user has initated a abort?
			   (p_struct->tcp_sequence_next==p_struct->tcp_sequence_unack)&&// all CTRL ACKed?
				tcp_tx_buffer_free(p_struct))								// user may fill buffer
				{
				#ifdef TCP_DEBUG
				if (tcp_debug_flag)
					printf("TCP-X(%u,%u) Abort\r\n", tcp_connection, tcp_rw_frame_count); 
				#endif
				tcp_prepare_frame(tcp_connection, TCP_CODE_FIN);
				tcp_close_flags(tcp_connection);	// reset all flags, stop retransmission..., but data available
				}
			break;
		case CLOSE_WAIT :
  			if((p_struct->tcp_sequence_next==p_struct->tcp_sequence_unack)&&// all CTRL ACKed?
				tcp_tx_buffer_free(p_struct))								// user may fill buffer
				{
				p_struct->tcp_sequence_unack++;								// count FIN as a byte
				tcp_prepare_frame(tcp_connection, TCP_CODE_FIN | TCP_CODE_ACK);	// we NEED a retry-timeout
				p_struct->tcp_last_frame_sent = TCP_FIN_FRAME;	 			// time to say goodbye...
				tcp_start_retry_timer(p_struct);
				p_struct->tcp_state_machine = LAST_ACK;
				}
			break;
		}
	#ifdef TCP_DEBUG
	if (tcp_debug_flag)
		{
		if(p_struct->last_tcp_state_machine!=p_struct->tcp_state_machine)
			{
			printf("TCP-S(%u,%u) State-M: %p\r\n", tcp_connection, tcp_rw_frame_count, tcp_state_name[p_struct->tcp_state_machine]);
			p_struct->last_tcp_state_machine=p_struct->tcp_state_machine;
			}
		}
	#endif	// #ifdef TCP_DEBUG
	}	// if(p_struct->tcp_flags & TCP_FLAG_OPEN)
#ifdef TCP_DEBUG
if (tcp_debug_flag)
	{
	if(p_struct->tcp_socket_error!=p_struct->last_tcp_socket_error)
		{
		printf("TCP-E(%u,%u) Socket Error: ", tcp_connection, tcp_rw_frame_count);
		tcp_debug_display_socket_error(p_struct);
		}
	}
#endif
}


//*********************************************************************************
// Description	: we've just rec'd an TCP-frame (Transmission Control Protocol)
//              : this function mainly implements the TCP state machine according to RFC793
// Input   		: none
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_process_frame(void)
{
unsigned int	tcp_source_port;		// tcp source port
unsigned int	tcp_dest_port;			// tcp destination port
unsigned long	tcp_sequence;			// tcp sequence number
unsigned long	tcp_ack;				// tcp acknowledge number
unsigned int	tcp_code;				// TCP code and header length
unsigned char	tcp_header_size;		// real TCP header length
unsigned int	tcp_data_count;	 		// real number of data
unsigned char	tcp_connection;	 		// pointer to TCP-databuffer
TCP_STRUCTURE	*p_struct;                                    	
#ifdef TCP_DEBUG
unsigned char	tcp_option_frame_buffer[40];	// max. TCP-Options (0xf-0x5)==10*4Byte
#endif	// #ifdef TCP_DEBUG
    
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_TCP_S)
#endif	// #ifdef WEB_DEBUG_MEASURE
#ifdef TCP_DEBUG
tcp_rw_frame_count++;
#endif	// #ifdef TCP_DEBUG
tcp_source_port = DEVICE_READ_IP_FRAME_16BIT();		// get ports
tcp_dest_port = DEVICE_READ_IP_FRAME_16BIT();
p_struct=&tcp_struct[0];                                    	
for(tcp_connection=0;tcp_connection<TCP_MAX_CONNECTIONS; tcp_connection++)
	{
	if(p_struct->tcp_flags & TCP_FLAG_OPEN)
		{
		if(p_struct->tcp_flags & TCP_FLAG_ACTIVE)
			{
			if((tcp_dest_port==p_struct->tcp_port_local)&&(tcp_source_port==p_struct->tcp_port_remote)&&
			   (!memcmp(ip_of_last_frame, p_struct->tcp_ip_remote, IP_ADR_SIZE)))
				break;	// is it for us?
			}
		else if(p_struct->tcp_flags & TCP_FLAG_PASSIVE)
			{
			if(tcp_dest_port==p_struct->tcp_port_local)
				{
				if(!memcmpf(p_struct->tcp_ip_remote, IP_FFFFFFFF, IP_ADR_SIZE))	// ip-address ok?
					{
					// found a new connection and save all remote informations
					memcpy(p_struct->tcp_ip_remote, ip_of_last_frame, IP_ADR_SIZE);	// save ip address
					p_struct->tcp_port_remote=tcp_source_port;					// save port number
					#ifndef DEVICE_PPP
					memcpy(p_struct->tcp_mac_remote, mac_of_last_frame, 6);		// save mac address
					#endif
					#ifdef TCP_DEBUG
					if (tcp_debug_flag)
						printf("TCP-O(%u,%u) Open: %u\r\n", tcp_connection, tcp_rw_frame_count, p_struct->tcp_port_local);
					#endif	// #ifdef TCP_DEBUG
					}
				if((tcp_source_port==p_struct->tcp_port_remote)&&
				   (!memcmp(ip_of_last_frame, p_struct->tcp_ip_remote, IP_ADR_SIZE)))
					break;			// is it for us?
				}
			}
		}
	p_struct++;                                    	
	}
if(tcp_connection>=TCP_MAX_CONNECTIONS)
	{
	#ifdef WEB_DEBUG_MEASURE
	MEASURE_SETTIME(MEA_TCP_E1)
	#endif	// #ifdef WEB_DEBUG_MEASURE
	#ifdef TCP_DEBUG
	if (tcp_debug_flag)
		{
		printf("TCP-E(x,%u) %u.%u.%u.%u / %u / %u\r\n", tcp_rw_frame_count, ip_of_last_frame[0], ip_of_last_frame[1], 
												ip_of_last_frame[2], ip_of_last_frame[3], tcp_dest_port, tcp_source_port); 
		p_struct=&tcp_struct[0];                                    	
		for(tcp_connection=0;tcp_connection<TCP_MAX_CONNECTIONS; tcp_connection++)
			{
			printf("TCP-E(%u,%u) %u.%u.%u.%u / %u / %u", tcp_connection, tcp_rw_frame_count, p_struct->tcp_ip_remote[0], p_struct->tcp_ip_remote[1], 
					p_struct->tcp_ip_remote[2], p_struct->tcp_ip_remote[3], p_struct->tcp_port_local, p_struct->tcp_port_remote); 
			tcp_debug_display_flags(p_struct);
			p_struct++;
			}
		}
	#endif	// #ifdef TCP_DEBUG
	return;
	}
tcp_sequence = DEVICE_READ_IP_FRAME_16BIT();	// get segment sequence nr.
tcp_sequence<<=16;				
tcp_sequence |= DEVICE_READ_IP_FRAME_16BIT();
tcp_ack = DEVICE_READ_IP_FRAME_16BIT();	   		// get segment acknowledge nr.
tcp_ack<<=16;
tcp_ack |= DEVICE_READ_IP_FRAME_16BIT();
tcp_code = DEVICE_READ_IP_FRAME_16BIT();   		// get control bits, header length...
tcp_header_size = (unsigned char)((tcp_code & DATA_OFS_MASK) >> 10);	// header length in bytes
tcp_data_count = ip_header.length - IP_HEADER_SIZE - tcp_header_size;	// seg. text length
p_struct->tcp_window_remote = DEVICE_READ_IP_FRAME_16BIT();   			// get actual remote window size
DEVICE_READ_IP_FRAME_DUMMY(4);					// ignore checksum, urgent pointer
if(tcp_data_count > p_struct->tcp_rx.gap)
		{
		#ifdef WEB_DEBUG_MEASURE
		MEASURE_SETTIME(MEA_TCP_E2)
		#endif
		#ifdef TCP_DEBUG
		if (tcp_debug_flag)
			printf("TCP-E(%u,%u) Frame too long: %u\r\n", tcp_connection, tcp_rw_frame_count, tcp_data_count); 
		#endif
		return;									// packet too large for us :...-(
		}
#ifdef TCP_DEBUG
if (tcp_debug_flag)
	{
	printf("TCP-R(%u,%u) ", tcp_connection, tcp_rw_frame_count);
	if (tcp_code & TCP_CODE_FIN)
		printf("FIN,");
	if (tcp_code & TCP_CODE_SYN)
		printf("SYN,");
	if (tcp_code & TCP_CODE_RST)
		printf("RST,");
	if (tcp_code & TCP_CODE_PSH)
		printf("PSH,");
	if (tcp_code & TCP_CODE_ACK)
		printf("ACK,");
	if (tcp_code & TCP_CODE_URG)
		printf("URG,");
	printf(" - %lu:%lu, %uByte\r\n", tcp_sequence, tcp_ack, tcp_data_count);
	}
#endif
if(tcp_header_size > TCP_HEADER_SIZE)			// ignore options if any
	{
	tcp_header_size-=TCP_HEADER_SIZE;
	#ifndef TCP_DEBUG
	DEVICE_READ_IP_FRAME_DUMMY(tcp_header_size);
	#else
	if (tcp_debug_flag)
		{
		if(tcp_header_size>sizeof(tcp_option_frame_buffer))
			tcp_header_size=sizeof(tcp_option_frame_buffer);
		DEVICE_READ_IP_FRAME_DATA(tcp_option_frame_buffer, tcp_header_size);
		printf("TCP-R(%u,%u) Option: %uByte  ", tcp_connection, tcp_rw_frame_count, tcp_header_size); 
		debug_display_mem_ascii(tcp_option_frame_buffer, tcp_header_size,0);
		}
	else
		DEVICE_READ_IP_FRAME_DUMMY(tcp_header_size);
	#endif
	}
#ifdef TCP_ALIVE_ACTIVE_ENABLE
p_struct->tcp_alive_timeout_delay=(unsigned int)(TCP_ALIVE_TIMEOUT_FACTOR*p_struct->tcp_alive_time);
p_struct->tcp_alive_delay=p_struct->tcp_alive_time;
#endif
switch(p_struct->tcp_state_machine)							// implement the TCP state machine
	{
	case CLOSED :
		if (!(tcp_code & TCP_CODE_RST))
			{
			if(tcp_code & TCP_CODE_ACK)						// make the reset sequence
				{											// acceptable to the other
				p_struct->tcp_sequence_next = tcp_ack;		// TCP
				tcp_prepare_frame(tcp_connection, TCP_CODE_RST);
				p_struct->tcp_socket_status &= SOCK_DATA_AVAILABLE;	// clear all socket-flags but data available
				}
			else
				{
				p_struct->tcp_sequence_next = 0;
				p_struct->tcp_sequence_ack = tcp_sequence + tcp_data_count;
				if(tcp_code & (TCP_CODE_SYN | TCP_CODE_FIN))
					p_struct->tcp_sequence_ack++;
				tcp_prepare_frame(tcp_connection, TCP_CODE_RST | TCP_CODE_ACK);
				}
			}
		break;
	case LISTEN :
		if(tcp_code & TCP_CODE_RST)				// ignore segment containing RST
			{
			p_struct->tcp_socket_error|= SOCK_ERR_TCP;	// TCP error
			tcp_close_flags(tcp_connection);	// reset all flags, stop retransmission..., but data available
			}
		else
			{
			if(tcp_code & TCP_CODE_ACK)					   	// reset a bad acknowledgement
				{
				p_struct->tcp_socket_error|= SOCK_ERR_TCP;	// TCP error
				p_struct->tcp_sequence_next = tcp_ack;
				tcp_prepare_frame(tcp_connection, TCP_CODE_RST);
				tcp_close_flags(tcp_connection);	// reset all flags, stop retransmission..., but data available
				}
			else if(tcp_code & TCP_CODE_SYN)
				{
				tcp_generate_isn(p_struct, TCP_GENERATE_ISN_1ST);
				p_struct->tcp_sequence_ack = tcp_sequence + 1; 		// get remote ISN, next byte we expect
				tcp_prepare_frame(tcp_connection, TCP_CODE_SYN | TCP_CODE_ACK);
				p_struct->tcp_last_frame_sent = TCP_SYN_ACK_FRAME;
				tcp_start_retry_timer(p_struct);
				p_struct->tcp_state_machine = SYN_RCVD;
				}
			}
		break;
	case SYN_SENT :
		if(tcp_code & TCP_CODE_ACK)	 	// ACK field significant?
			{
			if(tcp_code & TCP_CODE_RST)	// RST -> reset connection
				{
				tcp_close_flags(tcp_connection);	// reset all flags, stop retransmission..., but data available
				p_struct->tcp_socket_error|=SOCK_ERR_CONN_RESET;
				break;						// drop segment
				}
			else if(tcp_ack!=p_struct->tcp_sequence_unack)
				{
				p_struct->tcp_socket_error|= SOCK_ERR_TCP_ACK;	// wrong TCP-ACK
				#ifdef TCP_DEBUG
				if (tcp_debug_flag)
					printf("TCP-E(%u,%u) wrong ACK:%lu (expected:%lu)\r\n", tcp_connection, tcp_rw_frame_count, tcp_ack, p_struct->tcp_sequence_unack); 
				#endif
				tcp_sequence=p_struct->tcp_sequence_next;	// save old seq_next
				p_struct->tcp_sequence_next = tcp_ack;
				tcp_prepare_frame(tcp_connection, TCP_CODE_RST);
				p_struct->tcp_sequence_next=tcp_sequence;	// restore old seq_next
				break;			// drop segment
				}
			}
		if(tcp_code & TCP_CODE_SYN)	// SYN??
			{
			p_struct->tcp_sequence_ack = tcp_sequence;	// get opponents ISN
			#ifdef TCP_DEBUG
			p_struct->tcp_irs_number=tcp_sequence;
			#endif
			p_struct->tcp_sequence_ack++;				// inc. by one...
			if(tcp_code & TCP_CODE_ACK)
				{
				tcp_stop_timer(p_struct);			// stop retransmission, other TCP got our SYN
				p_struct->tcp_sequence_next = p_struct->tcp_sequence_unack;	// advance our sequence number
				tcp_prepare_frame(tcp_connection, TCP_CODE_ACK);			// ACK this ISN
				tcp_connect_flags(tcp_connection);
				}
			else
				{
				tcp_stop_timer(p_struct);
				tcp_prepare_frame(tcp_connection, TCP_CODE_SYN | TCP_CODE_ACK);			// our SYN isn't ACKed yet,
				p_struct->tcp_last_frame_sent = TCP_SYN_ACK_FRAME;		// now continue with sending
				tcp_start_retry_timer(p_struct);						// SYN_ACK frames
				p_struct->tcp_state_machine = SYN_RCVD;
				}
			}
		break;
	default :	// 	not(CLOSED, LISTEN, SYN_SENT)
		if(tcp_code & TCP_CODE_RST)
			{
			tcp_close_flags(tcp_connection);				// reset all flags, stop retransmission..., but data available
			p_struct->tcp_socket_error|=SOCK_ERR_CONN_RESET;// indicate an error to user
			break;
	    	}
		if(tcp_code & TCP_CODE_SYN)	// doesn't support "Two-Way-Handshake"
			{
			tcp_prepare_frame(tcp_connection, TCP_CODE_RST);// is NOT allowed here! send a reset,
			tcp_close_flags(tcp_connection);				// reset all flags, stop retransmission..., but data available
			p_struct->tcp_socket_error|= SOCK_ERR_REMOTE;	// fatal error!
			break;							
			}
		if(!(tcp_code & TCP_CODE_ACK))
			{
			p_struct->tcp_socket_error|= SOCK_ERR_TCP;	// TCP error
			break;								// drop segment if the ACK bit is off
			}
		#ifdef TCP_ALIVE_PASSIVE_ENABLE
		if((tcp_data_count==1)&&((tcp_sequence+1)==p_struct->tcp_sequence_ack))	// with 1 Byte Date - TCP-Alive-Packet
			{
			#ifdef TCP_DEBUG
			if (tcp_debug_flag)
				printf("TCP-A(%u,%u) Passive-Alive-ACK\r\n", tcp_connection, tcp_rw_frame_count); 
			#endif
			tcp_prepare_frame(tcp_connection, TCP_CODE_ACK);	// ACK a retransmission
			break;			// drop if it's not the segment we expect
			}
		#endif // #ifdef TCP_ALIVE_PASSIVE_ENABLE
		if(tcp_sequence>p_struct->tcp_sequence_ack)		// if ACK-Frame of last TCP-Dataframe lost???
			{
			p_struct->tcp_socket_error|= SOCK_ERR_TCP_SEQ; 		// wrong sequenz
			#ifdef TCP_DEBUG
			if (tcp_debug_flag)
				printf("TCP-E(%u,%u) frame lost SEQ:%lu (expected:%lu)\r\n", tcp_connection, tcp_rw_frame_count, tcp_sequence, p_struct->tcp_sequence_ack); 
			#endif // #ifdef TCP_DEBUG
			}
		if(tcp_ack>p_struct->tcp_sequence_unack)		// is our last data sent not ACKed?
			{
			p_struct->tcp_socket_error|= SOCK_ERR_TCP_ACK;		// wrong TCP-ACK
			tcp_prepare_frame(tcp_connection, TCP_CODE_ACK);	// ACK with last
			#ifdef TCP_DEBUG
			if (tcp_debug_flag)
				printf("TCP-E(%u,%u) wrong ACK:%lu (expected:%lu)\r\n", tcp_connection, tcp_rw_frame_count, tcp_ack, p_struct->tcp_sequence_unack); 
			#endif
			break;		// break, doesn't support defragment of TCP-Frames
			}
		if(tcp_ack<p_struct->tcp_sequence_unack)		// if our last data sent not ACKed?
			{
			if(p_struct->tcp_state_machine==ESTABLISHED)
				tcp_tx_buffer_ack(p_struct, tcp_ack);
			}
		else if(tcp_ack==p_struct->tcp_sequence_unack)		// is our last data sent not ACKed?
			{
			tcp_stop_timer(p_struct);					// stop retransmission
			p_struct->tcp_sequence_next = p_struct->tcp_sequence_unack;	// advance our sequence number
			switch(p_struct->tcp_state_machine)	 		// change state if necessary
				{
				case ESTABLISHED:						// ACK of data
					tcp_tx_buffer_ack(p_struct, tcp_ack);
					break;
				case SYN_RCVD:								// ACK of our SYN?
					tcp_connect_flags(tcp_connection);
					break;
				case FIN_WAIT_1: 
					p_struct->tcp_state_machine = FIN_WAIT_2; 
					break;							// ACK of our FIN?
				case CLOSING:
					p_struct->tcp_state_machine = TIME_WAIT; 
					break;							// ACK of our FIN?
				case LAST_ACK:						// ACK of our FIN?
					tcp_close_flags(tcp_connection);// reset all flags, stop retransmission..., but data available
					break;
				case TIME_WAIT:
					tcp_prepare_frame(tcp_connection, TCP_CODE_ACK);	// ACK a retransmission of remote FIN
					p_struct->tcp_timer = 0;						    // restart TIME_WAIT timeout
					break;
				}
			} //if(tcp_ack==p_struct->tcp_sequence_unack)
		if(((p_struct->tcp_state_machine==ESTABLISHED)||
		   (p_struct->tcp_state_machine==FIN_WAIT_1)||
		   (p_struct->tcp_state_machine==FIN_WAIT_2))&&
		   (tcp_data_count))							  		 	// data available?
		   	{
			tcp_rx_buffer_read_frame(tcp_connection, tcp_data_count, tcp_sequence);
		   	}
		if(tcp_code & TCP_CODE_FIN)				// FIN??
			{
			switch(p_struct->tcp_state_machine)
				{
				case SYN_RCVD:
				case ESTABLISHED:
					p_struct->tcp_state_machine = CLOSE_WAIT;
					break;
				case FIN_WAIT_1:										// if our FIN was ACKed, we automatically
					p_struct->tcp_state_machine = CLOSING;				// enter FIN_WAIT_2 (look above) and therefore
					p_struct->tcp_socket_status &= SOCK_DATA_AVAILABLE;	// clear all flags but data available
					p_struct->tcp_socket_status|= SOCK_DISCONNECTING;	// under disconnect
					break;
				case FIN_WAIT_2:
					tcp_start_wait_timer(p_struct);
					p_struct->tcp_state_machine = TIME_WAIT;
					p_struct->tcp_socket_status &= SOCK_DATA_AVAILABLE;	// clear all flags but data available
					p_struct->tcp_socket_status|= SOCK_DISCONNECTING;	// under disconnect
					break;
				case TIME_WAIT :
					p_struct->tcp_timer = 0;		// restart timer
					break;
				}
			p_struct->tcp_sequence_ack++;					// ACK remote's FIN flag
			tcp_prepare_frame(tcp_connection, TCP_CODE_ACK);
			}
	} // switch(p_struct->tcp_state_machine)
#ifdef TCP_DEBUG
if (tcp_debug_flag)
	{
	if(p_struct->last_tcp_state_machine!=p_struct->tcp_state_machine)
		{
		printf("TCP-S(%u,%u) State-P: %p\r\n", tcp_connection, tcp_rw_frame_count, tcp_state_name[p_struct->tcp_state_machine]);
		p_struct->last_tcp_state_machine=p_struct->tcp_state_machine;
		}
	if(p_struct->tcp_socket_error!=p_struct->last_tcp_socket_error)
		{
		printf("TCP-E(%u,%u) Socket Error: ", tcp_connection, tcp_rw_frame_count);
		tcp_debug_display_socket_error(p_struct);
		}
	}
#endif	// #ifdef TCP_DEBUG
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_TCP_E3)
#endif
}


//*********************************************************************************
// Description	: ACK the TX-Buffer entry
// Input   		: p_struct - pointer tp TCP-Data
//         		: tcp_ack  - ack value from remote station
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_tx_buffer_ack(TCP_STRUCTURE *p_struct, unsigned long tcp_ack)
{
static unsigned long last_tcp_ack=0;
unsigned char	temp_count, overflow=0;

temp_count=0;
if(last_tcp_ack>tcp_ack)
	overflow=1;
while(temp_count<TCP_TX_BUFFER_COUNT)
	{
	if(p_struct->tcp_tx[temp_count].flags & TCP_TX_FLAG_SENT)	// if true, give the frame buffer back
		{
		if(((overflow==0)&&(tcp_ack>=p_struct->tcp_tx[temp_count].unack))||		// is our last data sent ACKed?
		   ((overflow)&&(tcp_ack<=p_struct->tcp_tx[temp_count].unack)))
//		if((tcp_ack<=p_struct->tcp_tx[temp_count].unack)&&		// is our last data sent ACKed?
//		   (tcp_ack>p_struct->tcp_tx[temp_count].next))
			{
			p_struct->tcp_tx[temp_count].flags = TCP_TX_FLAG_FREE;	// set CLEAR-Bit
			#ifdef TCP_DEBUG
			p_struct->tcp_tx_ok_data+=p_struct->tcp_tx[temp_count].data_count;	// count of all receive data, see function tcp_rx_buffer_read_frame()
			#endif
			}
		}
	temp_count++;
	} // while(temp_count<TCP_TX_BUFFER_COUNT)
last_tcp_ack=tcp_ack;	// save last ack
}


//*********************************************************************************
// Description	: reads the TCP-data from DEVICE and handle the ACK-Frames
// Input   		: tcp_connection - index to TCP-Connection
//         		: tcp_data_count - the tcp_code-field is passed as an argument 
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_rx_buffer_read_frame(unsigned char tcp_connection, unsigned int tcp_data_count, unsigned long tcp_sequence)
{
TCP_STRUCTURE	*p_struct;
unsigned int temp;                                    	

p_struct=&tcp_struct[tcp_connection];                                    	
if(tcp_sequence<p_struct->tcp_sequence_ack)			// if ACK-Frame of last TCP-Dataframe lost???
	{
	#ifdef TCP_DEBUG
	if (tcp_debug_flag)
		printf("TCP-E(%u,%u) repeat ACK:%lu (expected:%lu)\r\n", tcp_connection, tcp_rw_frame_count, tcp_sequence, p_struct->tcp_sequence_ack); 
	#endif // #ifdef TCP_DEBUG
	}
else if(tcp_sequence>p_struct->tcp_sequence_ack)	// if ACK-Frame of last TCP-Dataframe lost???
	{
	#ifdef TCP_DEBUG
	p_struct->tcp_rx_wrong_data+=tcp_data_count;	// count the wrong data
	p_struct->tcp_rx_lost_data+=(tcp_sequence-p_struct->tcp_sequence_ack);	// count the lost data
	#endif
	}
else if(p_struct->tcp_rx.gap>=tcp_data_count)	// rx data-buffer empty?
	{
	p_struct->tcp_socket_status |= SOCK_DATA_AVAILABLE;	// indicate the new data to user
	p_struct->tcp_sequence_ack += tcp_data_count; 	   	// set the next ACK number
	#ifdef TCP_DEBUG
	p_struct->tcp_rx_ok_data+=tcp_data_count;			// count of all receive data, see function tcp_rx_buffer_read_frame()
	#endif
	temp=TCP_RX_BUFFER_SIZE-p_struct->tcp_rx.wtop;	
	if(temp<tcp_data_count)		// found overflow
		{
		DEVICE_READ_IP_FRAME_DATA(&p_struct->tcp_rx.data_frame[p_struct->tcp_rx.wtop], temp);	// read data
		p_struct->tcp_rx.wtop=0;
		p_struct->tcp_rx.gap-=temp;	
		tcp_data_count-=temp;
		#ifdef TCP_DEBUG
		if (tcp_debug_flag)
			printf("TCP-R(%u,%u) RX-Buffer overflow:%u\r\n", tcp_connection, tcp_rw_frame_count, tcp_data_count); 
		#endif // #ifdef TCP_DEBUG
		}
	DEVICE_READ_IP_FRAME_DATA(&p_struct->tcp_rx.data_frame[p_struct->tcp_rx.wtop], tcp_data_count);	// read data
	p_struct->tcp_rx.wtop+=tcp_data_count;
	p_struct->tcp_rx.gap-=tcp_data_count;	
    if(p_struct->tcp_rx.gap<p_struct->tcp_max_window_size)
		p_struct->tcp_window_local=p_struct->tcp_rx.gap;
	}
tcp_prepare_frame(tcp_connection, TCP_CODE_ACK);		// ACK rec'd data
}


//*********************************************************************************
// Description	: prepares the tcp_struct[tcp_connection].tcp_tx_data-buffer to send 
//              : a general TCP frame
// Input   		: tcp_connection - index to TCP-Connection
//         		: tcp_code 		 - the tcp_code-field is passed as an argument 
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_prepare_frame(unsigned char tcp_connection, unsigned int tcp_code)
{
TCP_STRUCTURE	*p_struct;                                    	
unsigned char	ip_offset;
unsigned int tcp_tx_count;

p_struct=&tcp_struct[tcp_connection];                                    	
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_TCP_FRAME_S)
#endif
if((tcp_code==TCP_CODE_ACK)&&(!tcp_tx_buffer_free(p_struct)))		// if ACK and Data, then use Data-Frame
	{
	if(tcp_prepare_data_frame(tcp_connection, TCP_DATA_FRAME_1ST_SEND, TCP_TX_BUFFER_UNDEF))
		return;
	}	
// TCP
HOST_NETWORK_ENDIAN_16BIT(&p_struct->tcp_tx_ctrl_frame[TCP_SRCPORT_OFS], &p_struct->tcp_port_local);
HOST_NETWORK_ENDIAN_16BIT(&p_struct->tcp_tx_ctrl_frame[TCP_DESTPORT_OFS], &p_struct->tcp_port_remote);
#ifdef TCP_ALIVE_ACTIVE_ENABLE
if(tcp_code==TCP_CODE_ACK_ALIVE)
	p_struct->tcp_sequence_next--;
#endif
HOST_NETWORK_ENDIAN_32BIT(&p_struct->tcp_tx_ctrl_frame[TCP_SEQNR_OFS], &p_struct->tcp_sequence_next);
#ifdef TCP_ALIVE_ACTIVE_ENABLE
if(tcp_code==TCP_CODE_ACK_ALIVE)
	p_struct->tcp_sequence_next++;
#endif
HOST_NETWORK_ENDIAN_32BIT(&p_struct->tcp_tx_ctrl_frame[TCP_ACKNR_OFS], &p_struct->tcp_sequence_ack);
HOST_NETWORK_ENDIAN_16BIT(&p_struct->tcp_tx_ctrl_frame[TCP_WINDOW_OFS], &p_struct->tcp_window_local);
*(unsigned int *)&p_struct->tcp_tx_ctrl_frame[TCP_CHKSUM_OFS] = 0;             // initalize checksum
*(unsigned int *)&p_struct->tcp_tx_ctrl_frame[TCP_URGENT_OFS] = 0;
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_TCP_CHECKSUM_S2)
#endif
if(tcp_code & TCP_CODE_SYN)                    // if SYN, we want to use the MSS option
	{
	*(unsigned int *)&p_struct->tcp_tx_ctrl_frame[TCP_DATA_CODE_OFS] = SWAPB(0x6000 | tcp_code);	// TCP header length = 24
    *(unsigned int *)&p_struct->tcp_tx_ctrl_frame[TCP_DATA_OFS] = SWAPB(TCP_OPT_MSS);				// MSS option
    *(unsigned int *)&p_struct->tcp_tx_ctrl_frame[TCP_DATA_OFS + 2] = SWAPB(p_struct->tcp_max_window_size);	// max. length of TCP-data we accept
    *(unsigned int *)&p_struct->tcp_tx_ctrl_frame[TCP_CHKSUM_OFS] = ip_checksum(&p_struct->tcp_tx_ctrl_frame[TCP_SRCPORT_OFS], 
    													TCP_HEADER_SIZE + TCP_OPT_MSS_SIZE, p_struct->tcp_ip_remote);
	tcp_tx_count = IP_HEADER_SIZE + TCP_HEADER_SIZE + TCP_OPT_MSS_SIZE;
	}
else
	{
	*(unsigned int *)&p_struct->tcp_tx_ctrl_frame[TCP_DATA_CODE_OFS] = SWAPB(0x5000 | (0x0FFF & tcp_code));   // TCP header length = 20
	#ifdef TCP_ALIVE_ACTIVE_ENABLE
	if(tcp_code==TCP_CODE_ACK_ALIVE)
		{
	    p_struct->tcp_tx_ctrl_frame[TCP_DATA_OFS] = 0xCC;		// set Alive-Byte
	    *(unsigned int *)&p_struct->tcp_tx_ctrl_frame[TCP_CHKSUM_OFS] = ip_checksum(&p_struct->tcp_tx_ctrl_frame[TCP_SRCPORT_OFS], 
    																TCP_HEADER_SIZE + 1, p_struct->tcp_ip_remote);
		tcp_tx_count = IP_HEADER_SIZE + TCP_HEADER_SIZE + 1;
	    }
	else
	#endif // #ifdef TCP_ALIVE_ACTIVE_ENABLE
		{
    	*(unsigned int *)&p_struct->tcp_tx_ctrl_frame[TCP_CHKSUM_OFS] = ip_checksum(&p_struct->tcp_tx_ctrl_frame[TCP_SRCPORT_OFS], 
    																TCP_HEADER_SIZE, p_struct->tcp_ip_remote);
		tcp_tx_count = IP_HEADER_SIZE + TCP_HEADER_SIZE;
		}
	}
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_TCP_CHECKSUM_E2)
#endif
// IP   
if(ip_header_write(p_struct->tcp_tx_ctrl_frame, &tcp_tx_count, &ip_offset, IP_TCP_PROT, ip_address, p_struct->tcp_ip_remote)==0)
	{
	#if defined(TCP_DEBUG)&&defined(IPSEC_ENABLE)
	if (tcp_debug_flag)
		{
		printf("TCP-E(%u,%u) IP-Error\r\n", tcp_connection, tcp_rw_frame_count);
		debug_display_mem_hex(p_struct->tcp_tx_ctrl_frame, tcp_tx_count+IPSEC_OFFSET+ETH_HEADER_SIZE, 0);
		}
	#endif
	return;
	}
// Ethernet
#ifdef ETHERNET_ENABLE
memcpy(&p_struct->tcp_tx_ctrl_frame[(unsigned char)(ETH_DA_OFS+ip_offset)], p_struct->tcp_mac_remote, 6);
memcpy(&p_struct->tcp_tx_ctrl_frame[(unsigned char)(ETH_SA_OFS+ip_offset)], &mac_address[0], 6);
*(unsigned int *)&p_struct->tcp_tx_ctrl_frame[(unsigned char)(ETH_TYPE_OFS+ip_offset)] = SWAPB(IP_FRAME);
#else
memset(&p_struct->tcp_tx_ctrl_frame[(unsigned char)(ETH_DA_OFS+ip_offset)], 0x0, ETH_HEADER_SIZE);
#endif	//#ifdef ETHERNET_ENABLE
tcp_tx_count+= ETH_HEADER_SIZE;
if(buffer_write_command(p_struct->tcp_tx_ctrl_frame+ip_offset, tcp_tx_count))
	{
	#ifdef WEB_DEBUG_MEASURE
	MEASURE_SETTIME(MEA_TCP_FRAME_E)
	#endif	//	#ifdef WEB_DEBUG_MEASURE
	#ifdef TCP_DEBUG
	tcp_rw_frame_count++;
	if (tcp_debug_flag)
		printf("TCP-W(%u,%u) Ctrl: ", tcp_connection, tcp_rw_frame_count);
	#endif
	}
else
	{
	#ifdef TCP_DEBUG
	if (tcp_debug_flag)
		printf("TCP-W(%u,%u) ERROR Ctrl: ", tcp_connection, tcp_rw_frame_count);
	#endif
	}
#ifdef TCP_DEBUG
if (tcp_debug_flag)
	{
	if(tcp_code & TCP_CODE_FIN)
		printf("FIN,");
	if(tcp_code & TCP_CODE_SYN)
		printf("SYN,");
	if(tcp_code & TCP_CODE_RST)
		printf("RST,");
	if(tcp_code & TCP_CODE_PSH)
		printf("PSH,");
	if(tcp_code & TCP_CODE_ACK)
		printf("ACK,");
	if(tcp_code & TCP_CODE_URG)
		printf("URG,");
	#ifdef TCP_ALIVE_ACTIVE_ENABLE
	if(tcp_code==TCP_CODE_ACK_ALIVE)
		{
		printf("ALIVE,");
		printf(" - %lu:%lu, 1Byte\r\n", p_struct->tcp_sequence_next-1, p_struct->tcp_sequence_ack);
		}
    else
	#endif // #ifdef TCP_ALIVE_ACTIVE_ENABLE
		printf(" - %lu:%lu\r\n", p_struct->tcp_sequence_next, p_struct->tcp_sequence_ack);
	}
#endif
}


//*********************************************************************************
// Description	: prepares the tx_frame1-buffer to send a payload-packet
// Input   		: tcp_connection - index to TCP-Connection
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
unsigned char tcp_prepare_data_frame(unsigned char tcp_connection, TCP_DATA_FRAME_MODE mode, unsigned char act_tx_buffer)
{
TCP_STRUCTURE		*p_struct;                                    	
TCP_TX_BUFFER_STRUCTURE *p_tx_buffer;
unsigned char		ip_offset;
unsigned int		tcp_tx_data_all_count;
unsigned char		temp_count, min_age;

p_struct=&tcp_struct[tcp_connection];                                    	
if(act_tx_buffer==TCP_TX_BUFFER_UNDEF)
	{
	// min_age=0;	// not nessecary because it start with "(act_tx_buffer==TCP_TX_BUFFER_UNDEF)" 
	for(temp_count=0;temp_count<TCP_TX_BUFFER_COUNT;temp_count++)
		{
		if(p_struct->tcp_tx[temp_count].flags & TCP_TX_FLAG_FULL)
			{
			if((p_struct->tcp_tx[temp_count].age<min_age)||(act_tx_buffer==TCP_TX_BUFFER_UNDEF))
				{
				min_age=p_struct->tcp_tx[temp_count].age;
				act_tx_buffer=temp_count;
				}
			}
		}
	if(act_tx_buffer==TCP_TX_BUFFER_UNDEF)	
		return 0;		// no filled buffers
	}
p_tx_buffer=&p_struct->tcp_tx[act_tx_buffer];
if(p_tx_buffer->data_count>p_struct->tcp_window_remote)
	return 0;		// no window to send the data
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_TCP_DATA_S)
#endif
// TCP
HOST_NETWORK_ENDIAN_16BIT(&p_tx_buffer->data_frame[TCP_SRCPORT_OFS], &p_struct->tcp_port_local);
HOST_NETWORK_ENDIAN_16BIT(&p_tx_buffer->data_frame[TCP_DESTPORT_OFS], &p_struct->tcp_port_remote);
if(mode==TCP_DATA_FRAME_1ST_SEND)
	p_tx_buffer->next= p_struct->tcp_sequence_next;
HOST_NETWORK_ENDIAN_32BIT(&p_tx_buffer->data_frame[TCP_SEQNR_OFS], &p_tx_buffer->next);
HOST_NETWORK_ENDIAN_32BIT(&p_tx_buffer->data_frame[TCP_ACKNR_OFS], &p_struct->tcp_sequence_ack);
#ifdef TCP_ADD_PSH_FLAG
*(unsigned int *)&p_tx_buffer->data_frame[TCP_DATA_CODE_OFS] = SWAPB(0x5000 | TCP_CODE_ACK | TCP_CODE_PSH);   // TCP header length = 20
#else
*(unsigned int *)&p_tx_buffer->data_frame[TCP_DATA_CODE_OFS] = SWAPB(0x5000 | TCP_CODE_ACK);   // TCP header length = 20
#endif
HOST_NETWORK_ENDIAN_16BIT(&p_tx_buffer->data_frame[TCP_WINDOW_OFS], &p_struct->tcp_window_local);
*(unsigned int *)&p_tx_buffer->data_frame[TCP_CHKSUM_OFS] = 0; 
*(unsigned int *)&p_tx_buffer->data_frame[TCP_URGENT_OFS] = 0;
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_TCP_CHECKSUM_S2)
#endif
*(unsigned int *)&p_tx_buffer->data_frame[TCP_CHKSUM_OFS] = ip_checksum(&p_tx_buffer->data_frame[TCP_SRCPORT_OFS], 
											TCP_HEADER_SIZE + p_tx_buffer->data_count, p_struct->tcp_ip_remote);
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_TCP_CHECKSUM_E2)
#endif
// IP   
tcp_tx_data_all_count = IP_HEADER_SIZE + TCP_HEADER_SIZE + p_tx_buffer->data_count;
if(ip_header_write(p_tx_buffer->data_frame, &tcp_tx_data_all_count, &ip_offset, IP_TCP_PROT, ip_address, p_struct->tcp_ip_remote)==0)
	{
	#if defined(TCP_DEBUG)&&defined(IPSEC_ENABLE)
	if (tcp_debug_flag)
		{
		printf("TCP-E(%u,%u) IP-Error\r\n", tcp_connection, tcp_rw_frame_count);
		debug_display_mem_hex(p_tx_buffer->data_frame, tcp_tx_data_all_count+IPSEC_OFFSET+ETH_HEADER_SIZE, 0);
		}
	#endif
	return 0;
	}
// Ethernet
#ifdef ETHERNET_ENABLE
memcpy(&p_tx_buffer->data_frame[(unsigned char)(ETH_DA_OFS+ip_offset)], p_struct->tcp_mac_remote, 6);
memcpy(&p_tx_buffer->data_frame[(unsigned char)(ETH_SA_OFS+ip_offset)], mac_address, 6);
*(unsigned int *)&p_tx_buffer->data_frame[(unsigned char)(ETH_TYPE_OFS+ip_offset)] = SWAPB(IP_FRAME);
#else
memset(&p_tx_buffer->data_frame[(unsigned char)(ETH_DA_OFS+ip_offset)], 0x0, ETH_HEADER_SIZE);
#endif	//#ifdef ETHERNET_ENABLE
tcp_tx_data_all_count+= ETH_HEADER_SIZE;
// General
if(buffer_write_command(p_tx_buffer->data_frame+ip_offset, tcp_tx_data_all_count))
	{
	if(mode==TCP_DATA_FRAME_1ST_SEND)
		{
		p_struct->tcp_sequence_unack+= p_tx_buffer->data_count;		// advance UNAcknowledge Sequence-number
		p_struct->tcp_sequence_next = p_struct->tcp_sequence_unack;		// advance our sequence number
		p_tx_buffer->unack= p_struct->tcp_sequence_unack;
		p_tx_buffer->flags &= ~(TCP_TX_FLAG_FULL | TCP_TX_FLAG_HALF_FULL);	// occupy tx-buffer
		p_tx_buffer->flags |= (TCP_TX_FLAG_SENT | TCP_TX_FLAG_RETRANSMIT);	// set SENT-Bit
		p_tx_buffer->timer = 0;
		p_tx_buffer->retry_counter = TCP_MAX_RETRYS;
		}
	#ifdef WEB_DEBUG_MEASURE
	MEASURE_SETTIME(MEA_TCP_DATA_E)
	#endif
	#ifdef TCP_DEBUG
	tcp_rw_frame_count++;
	if (tcp_debug_flag)
		{
		printf("TCP-W(%u,%u) ", tcp_connection, tcp_rw_frame_count);
		if(mode==TCP_DATA_FRAME_RETRANSMIT)
			printf("Data-Retransmit");
		else
			{
			printf("Data, ACK");
//			printf("TCP-W(%u,%u) Check:0x%x\r\n", tcp_connection, tcp_rw_frame_count, *(unsigned int *)&p_tx_buffer->data_frame[TCP_CHKSUM_OFS]);
//			debug_display_mem_hex(&p_tx_buffer->data_frame[TCP_SRCPORT_OFS], 
//			                      TCP_HEADER_SIZE + p_tx_buffer->data_count, 0);
			}
		printf(" - %lu:%lu, %uByte\r\n", p_tx_buffer->next, p_struct->tcp_sequence_ack, p_tx_buffer->data_count);
		}
	#endif
	return 1;
	}
else
	{
	#ifdef TCP_DEBUG
	if (tcp_debug_flag)
		{
		printf("TCP-W(%u,%u) ERROR Data - %lu:%lu, %uByte\r\n", tcp_connection, tcp_rw_frame_count, 
						p_struct->tcp_sequence_next, p_struct->tcp_sequence_ack, p_tx_buffer->data_count);
		}
	#endif
	}
return 0;
}


//*********************************************************************************
// Description	: checks the ARP-function
// Input   		: new_mac - pointer to 
// Output  		: none
// Indication	: internal easyToWeb-function (see file arp_process_frame.arp.c)
//*********************************************************************************
void tcp_arp_resolved(unsigned char *new_mac)
{
unsigned char Lva;
TCP_STRUCTURE	*p_struct;                                    	

p_struct=&tcp_struct[0];                                    	
for(Lva=0;Lva<TCP_MAX_CONNECTIONS; Lva++)
	{
	if((p_struct->tcp_flags & (TCP_FLAG_ACTIVE | TCP_FLAG_IP_ADDR_RESOLVED)) == TCP_FLAG_ACTIVE)
		{
		if(!memcmp(ip_of_last_frame, p_struct->tcp_ip_remote, IP_ADR_SIZE))
			{
			tcp_stop_timer(p_struct);			// OK, now we've the MAC we wanted ;-)
			p_struct->tcp_flags |= TCP_FLAG_IP_ADDR_RESOLVED;
			memcpy(p_struct->tcp_mac_remote, new_mac, 6);		// save mac address
			}
		}
	p_struct++;                                    	
	}
}

//*********************************************************************************
// Description	: starts the timer as a retry-timer (used for retransmission-timeout)
// Input   		: p_struct - pointer to tcp-structure
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_start_retry_timer(TCP_STRUCTURE *p_struct)
{
p_struct->tcp_timer = 0;
p_struct->tcp_retry_counter = TCP_MAX_RETRYS;
p_struct->tcp_flags |= (TCP_FLAG_TIMER_RUNNING | TCP_FLAG_TIMER_CTRL_RETRANSMIT);
}

//*********************************************************************************
// Description	: starts the timer as a 'TIME_WAIT'-timer (used to finish a TCP-session)
// Input   		: p_struct - pointer to tcp-structure
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_start_wait_timer(TCP_STRUCTURE *p_struct)
{
p_struct->tcp_timer = 0;
p_struct->tcp_flags |= TCP_FLAG_TIMER_RUNNING;
p_struct->tcp_flags &= ~TCP_FLAG_TIMER_CTRL_RETRANSMIT;  
}

//*********************************************************************************
// Description	: stops the timer
// Input   		: p_struct - pointer to tcp-structure
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_stop_timer(TCP_STRUCTURE *p_struct)
{
p_struct->tcp_flags &= ~(TCP_FLAG_TIMER_RUNNING | TCP_FLAG_TIMER_CTRL_RETRANSMIT);
}

#ifdef TCP_DEBUG
char flash *tcp_retransmit_name[5]={
				  "NONE", "ARP_REQUEST", "SYN_FRAME", 
				  "SYN_ACK_FRAME", "FIN_FRAME"};
#endif
//*********************************************************************************
// Description	: if a retransmission-timeout occured, check which packet to resend.
// Input   		: tcp_connection - index to tcp-structure
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_handle_retransmission(unsigned char tcp_connection)
{
TCP_STRUCTURE	*p_struct;

p_struct=&tcp_struct[tcp_connection];                                    	
#ifdef TCP_DEBUG
if (tcp_debug_flag)
	printf("TCP-W(%u,%u) Retransmit: %p\r\n", tcp_connection, tcp_rw_frame_count, tcp_retransmit_name[p_struct->tcp_last_frame_sent]);
#endif
switch(p_struct->tcp_last_frame_sent)
	{
	#ifdef ARP_ENABLE
    case TCP_ARP_REQUEST   : arp_prepare_request(p_struct->tcp_ip_remote, ARP_REQUEST_IP); break;
	#endif
    case TCP_SYN_FRAME     : 
					tcp_generate_isn(p_struct, TCP_GENERATE_ISN_RETRANSMIT);
					tcp_prepare_frame(tcp_connection, TCP_CODE_SYN); 
					break;
    case TCP_SYN_ACK_FRAME : tcp_prepare_frame(tcp_connection, TCP_CODE_SYN | TCP_CODE_ACK); break;
    case TCP_FIN_FRAME     : tcp_prepare_frame(tcp_connection, TCP_CODE_FIN | TCP_CODE_ACK); break;
	}
}

//*********************************************************************************
// Description	: if all retransmissions failed, close connection and indicate an error
// Input   		: p_struct - pointer to tcp-structure-entry
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_handle_timeout(TCP_STRUCTURE *p_struct)
{
if ((p_struct->tcp_flags & (TCP_FLAG_ACTIVE | TCP_FLAG_IP_ADDR_RESOLVED)) == TCP_FLAG_ACTIVE)
	p_struct->tcp_socket_error|=SOCK_ERR_ARP_TIMEOUT;	// indicate an error to user
else
	p_struct->tcp_socket_error|=SOCK_ERR_TCP_TIMEOUT;
}


//*********************************************************************************
// Description	: function executed every 50ms by the MCU. used for the
//              : inital sequence number generator (ISN) and the TCP-timer
// Input   		: none
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_clock_handler(void)
{
#if(TCP_MAX_CONNECTIONS>1)
unsigned char Lva;
#endif
unsigned char Lvb;

tcp_isn_high_number++; 				// upper 16 bits of initial sequence number
#if(TCP_MAX_CONNECTIONS==1)
tcp_struct[0].tcp_timer++;			// timer for Ctrl-retransmissions and FIN-Timeout
for(Lvb=0;Lvb<TCP_TX_BUFFER_COUNT; Lvb++)
	tcp_struct[0].tcp_tx[Lvb].timer++;	// timer for Data-retransmissions
#ifdef TCP_ALIVE_ACTIVE_ENABLE
tcp_struct[0].tcp_alive_50ms_bit=1;	// 50ms count active
#endif
#else 
for(Lva=0;Lva<TCP_MAX_CONNECTIONS; Lva++)
	{
	tcp_struct[Lva].tcp_timer++;			// timer for Ctrl-retransmissions and FIN-Timeout
	for(Lvb=0;Lvb<TCP_TX_BUFFER_COUNT; Lvb++)
		tcp_struct[Lva].tcp_tx[Lvb].timer++;			// timer for Data-retransmissions
	#ifdef TCP_ALIVE_ACTIVE_ENABLE
	tcp_struct[Lva].tcp_alive_50ms_bit=1;	// 50ms count active
	#endif
	}
#endif
}

//*********************************************************************************
// Description	: close all flags of TCP-Connection
// Input   		: tcp_connection - index to tcp-structure
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_close_flags(unsigned char tcp_connection)
{
unsigned char Lva;
TCP_STRUCTURE *p_struct;

p_struct=&tcp_struct[tcp_connection];                                    	
p_struct->tcp_state_machine = CLOSED;
p_struct->tcp_flags &= TCP_FLAG_RESET_MASK;	  		// reset all flags, stop retransmission...
p_struct->tcp_socket_status &= SOCK_DATA_AVAILABLE;	// clear all flags but data available
p_struct->tcp_socket_status |= SOCK_DISCONNECTED;	// disconnect
for (Lva=0; Lva<TCP_TX_BUFFER_COUNT; Lva++)
	p_struct->tcp_tx[Lva].flags = TCP_TX_FLAG_FREE;
#ifdef TCP_DEBUG
if (tcp_debug_flag)
	printf("TCP-X(%u,%u) SOCK_DISCONNECT\r\n", tcp_connection, tcp_rw_frame_count); 
#endif
#ifdef TCP_ALIVE_ACTIVE_ENABLE
p_struct->tcp_alive_flag &= ~TCP_ALIVE_FLAG_OPEN;
#ifdef TCP_DEBUG
if (tcp_debug_flag && p_struct->tcp_alive_flag&TCP_ALIVE_FLAG_ENABLE)
	printf("TCP-A(%u,%u) Alive close\r\n", tcp_connection, tcp_rw_frame_count); 
#endif
#endif // #ifdef TCP_ALIVE_ACTIVE_ENABLE
}


//*********************************************************************************
// Description	: open all flags of TCP-Connection to connect
// Input   		: tcp_connection - index to tcp-structure
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_connect_flags(unsigned char tcp_connection)
{
unsigned char Lva;
TCP_STRUCTURE *p_struct;

p_struct=&tcp_struct[tcp_connection];                                    	
p_struct->tcp_state_machine = ESTABLISHED;
p_struct->tcp_socket_status &= ~(SOCK_READY_CONNECT | SOCK_DISCONNECTED);
p_struct->tcp_socket_status |= SOCK_CONNECTED;		// user may send data now :-)
for(Lva=0;Lva<TCP_TX_BUFFER_COUNT; Lva++)
	p_struct->tcp_tx[Lva].flags = TCP_TX_FLAG_FREE;
#ifdef TCP_DEBUG
if (tcp_debug_flag)
	printf("TCP-X(%u,%u) SOCK_CONNECTED\r\n", tcp_connection, tcp_rw_frame_count); 
#endif
#ifdef TCP_ALIVE_ACTIVE_ENABLE
if(p_struct->tcp_alive_flag & TCP_ALIVE_FLAG_ENABLE)
	{
	p_struct->tcp_alive_flag|=TCP_ALIVE_FLAG_OPEN;
	#ifdef TCP_DEBUG
	if (tcp_debug_flag)
		printf("TCP-A(%u,%u) Alive open\r\n", tcp_connection, tcp_rw_frame_count); 
	#endif
	}
#endif // #ifdef TCP_ALIVE_ACTIVE_ENABLE
}

//*********************************************************************************
// Description	: checks if all TX-Buffer are free
// Input   		: p_struct - pointer to tcp-structure-entry
// Output  		: 0: 1 or more buffer are not free
//                1: all buffer are free
// Indication	: easyToWeb internal function
//*********************************************************************************
unsigned char tcp_tx_buffer_free(TCP_STRUCTURE *p_struct)
{
unsigned char Lva;

for(Lva=0;Lva<TCP_TX_BUFFER_COUNT; Lva++)
	{
	if(!(p_struct->tcp_tx[Lva].flags & TCP_TX_FLAG_FREE))
		return 0;
	}
return 1;
}                           


//*********************************************************************************
// Description	: generates a new Initial Sequence Number - ISN
// Input   		: p_struct - pointer to tcp-structure-entry
//                mode - controls the generation of ISN, see TCP_GENERATE_ISN_MODE
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void tcp_generate_isn(TCP_STRUCTURE *p_struct, TCP_GENERATE_ISN_MODE mode)
{
if(mode==TCP_GENERATE_ISN_RETRANSMIT)
	tcp_isn_high_number+=0x4000;
p_struct->tcp_sequence_next = tcp_isn_high_number;	// set HIGH-Part of local ISN
p_struct->tcp_sequence_next<<=16; 
p_struct->tcp_sequence_unack = p_struct->tcp_sequence_next + 1;	// one byte out -> increase by one
#ifdef TCP_DEBUG
p_struct->tcp_iss_number=p_struct->tcp_sequence_next;
#endif
}                           


#endif	// #ifdef TCP_ENABLE
