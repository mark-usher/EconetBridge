// ************************************************************************************************
///
/// \file 			ipsec_esp.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Copyright (C) 2001-2004
///					This document is part of embedded IPsec
///					Niklaus Schild and Christian Scheurer, HTI Biel/Bienne
///					This file contains code from the OpenSSL Project<BR>
///					Niklaus Schild <n.schild@gmx.ch>
///					portions Copyright (c) 1998-2003 OpenSSL (www.openssl.org)
///					easyToWeb-AVR and CodeVisionAVR C-Compiler:
///					Udo Jakobza - FTZ Leipzig; 04107 Leipzig; W�chterstr. 13
///					jakobza@e-technik.htwk-leipzig.de
///
/// \par License    
///					Redistribution and use in source and binary forms, with or without 
///					modification, are permitted provided that the following conditions are met:
///
///					1. Redistributions of source code must retain the above copyright notice,
///					   this list of conditions and the following disclaimer.
///					2. Redistributions in binary form must reproduce the above copyright notice,
///					    this list of conditions and the following disclaimer in the documentation
///					   and/or other materials provided with the distribution.
///					3. The name of the author may not be used to endorse or promote products
///					   derived from this software without specific prior written permission.
///
///					THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
///					WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
///					MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
///					EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
///					EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
///					OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
///					INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
///					CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
///					IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
///					OF SUCH DAMAGE.
///
// ************************************************************************************************

#ifndef _IPSEC_ESP_INCLUDED_
#define _IPSEC_ESP_INCLUDED_

#include "project.h"		// Project configuration

#include "ipsec_sa.h"

// --------------------------------------------------------------------------------
// Encapsulating Secutity Payload (ESP) Transport-Mode, see IPSEC buffer "ipsec_rx_buffer"
// -------------------------------------------------------------------------------- 
#define IPSEC_ESP_SPI_OFS			20		// ESP Security Parameter Index - SPI (32bit)
#define IPSEC_ESP_SEQUENCE_OFS		24		// ESP Sequence Number (32bit)
#define IPSEC_ESP_IV_OFS			28		// ESP Initialization Vector (xxbit - xxByte)
#define IPSEC_ESP_DATA_OFS			28		// ESP Data (xxbit - xxByte)

#define IPSEC_ESP_HEADER_SIZE		8		// ESP Header Size SPI+Sequence
#define IPSEC_ESP_DES_IV_SIZE		8		// size of DES IV Data
#define IPSEC_ESP_TRAILER_SIZE		2		// size of ESP-Trailer (Pad Length + Next Header)
#define IPSEC_ESP_AUTH_DATA_SIZE	12		// Defines the authentication data length in bytes (12 bytes for 96bit keys)

//  --------------------------------------------------------------------------------
//	ESP Header structure (RFC2406)
//  -------------------------------------------------------------------------------- 
typedef struct
	{
	unsigned long	spi;		// Security Parameters Index
	unsigned long	sequence;	// Sequence number
	unsigned char	iv[IPSEC_ESP_DES_IV_SIZE];	// IV or start of data
	}ESP_HEADER_STRUCTURE;


//  --------------------------------------------------------------------------------
//	Intput IP-ESP structure
//  -------------------------------------------------------------------------------- 
typedef struct
	{
	IP_HEADER_STRUCTURE		ip;
	ESP_HEADER_STRUCTURE	esp;
	unsigned char data;			// only a position to calculate the payload of AH Packet
	} TRANS_TUNNEL_IN_IP_ESP;

//  --------------------------------------------------------------------------------
//	Transport Output IP-ESP structure
//  -------------------------------------------------------------------------------- 
typedef struct
	{
	unsigned char  	offset[IPSEC_OFFSET-sizeof(ESP_HEADER_STRUCTURE)];
	IP_HEADER_STRUCTURE		ip;
	ESP_HEADER_STRUCTURE	esp;
	unsigned char data;			// only a position to calculate the payload of ESP Packet
	} TRANSPORT_OUT_IP_ESP;

//  --------------------------------------------------------------------------------
//	Tunnel Output IP-ESP-IP structure
//  -------------------------------------------------------------------------------- 
typedef struct
	{
	unsigned char  	offset[IPSEC_OFFSET-sizeof(IP_HEADER_STRUCTURE)-sizeof(ESP_HEADER_STRUCTURE)];
	IP_HEADER_STRUCTURE		ip_out;
	ESP_HEADER_STRUCTURE	esp;
	IP_HEADER_STRUCTURE		ip_in;
	unsigned char data;			// only a position to calculate the payload of ESP Packet
	} TUNNEL_OUT_IP_ESP_IP;

#pragma used+
unsigned char ipsec_esp_input_frame(SA_MEMORY sad_entry_mem *sa, unsigned char *rx_data, unsigned int *rx_length);
unsigned char ipsec_esp_output_frame(SA_MEMORY sad_entry_mem *sa, unsigned char *ip_data, 
									unsigned int *ip_size, unsigned char *ip_offset);
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library ipsec_esp.c
#endif

#endif	// #ifndef _IPSEC_ESP_INCLUDED_