// ************************************************************************************************
///
/// \file 			icmp.c
/// \brief			ICMP protocol
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// \par History
/// 				1.) 08.08.2003 Version 2.00
/// 				2.) 13.08.2003 Version 2.01
/// 					a.)	- new macro "ICMP_ENABLE", see project.h inside of project-path
/// 				3.) 11.02.2004 Version 2.03
/// 					a.)	- supports now Type: "ICMP_DEST_UNREACHABLE"
///						--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef ICMP_ENABLE
#ifdef IP_ENABLE

#include <stdio.h>
#include <string.h>
#include "util.h"
#include "device.h"
#include "ethernet.h"
#include "buffer.h"
#include "icmp.h"
#ifdef WEB_DEBUG_MEASURE			// enable time-measure debug functions, see measure.c
#include "measure.h"
#endif
#ifdef WEB_DEBUG
#include "web_debug.h"
#endif

#pragma regalloc-
#ifdef WEB_DEBUG_ICMP
unsigned int icmp_count=0;
#endif
#pragma regalloc+

//*********************************************************************************
// Description	: prepares the tx_frame2-buffer to send an ICMP-echo-reply
// Input   		: ip_remote  - pointer to IP-Address
//				: mac_remote - pointer to MAC-Address
//				: icmp_ident - identifier of icmp-request
//				: icmp_seq	 - sequenz-number of icmp-request
// Output  		: none
// Indication	: none
//*********************************************************************************
void icmp_prepare_echo_reply(unsigned char *ip_remote, unsigned char *mac_remote, unsigned int icmp_ident, unsigned int icmp_seq)
{
unsigned int icmp_data_count;
unsigned char ip_offset;

icmp_data_count = ip_header.length - IP_HEADER_SIZE - ICMP_HEADER_SIZE;
if(icmp_data_count > ICMP_DATA_SIZE)   // don't overload TX-buffer
	icmp_data_count = ICMP_DATA_SIZE;
// ICMP
*(unsigned int *)&tx_frame2[ICMP_TYPE_CODE_OFS] = SWAPB(ICMP_ECHO_REPLY << 8);
*(unsigned int *)&tx_frame2[ICMP_CHKSUM_OFS] = 0;				  			// initialize checksum field (16bit)
HOST_NETWORK_ENDIAN_16BIT(&tx_frame2[ICMP_IDENT_OFS], &icmp_ident);			// Identifier number (16bit)
HOST_NETWORK_ENDIAN_16BIT(&tx_frame2[ICMP_SEQ_OFS], &icmp_seq);  			// sequence number (16bit)
DEVICE_READ_IP_FRAME_DATA(&tx_frame2[ICMP_ECHO_DATA_OFS], icmp_data_count);	// read data from DEVICE and write data to buffer
*(unsigned int *)&tx_frame2[ICMP_CHKSUM_OFS] = ip_checksum(&tx_frame2[IP_DATA_OFS], icmp_data_count + ICMP_HEADER_SIZE, 0);
// IP   
tx_frame2_size=IP_HEADER_SIZE + ICMP_HEADER_SIZE + icmp_data_count;
if(ip_header_write(tx_frame2, &tx_frame2_size, &ip_offset, IP_ICMP_PROT, ip_address, ip_remote)==0)
	{
	#if defined(WEB_DEBUG_ICMP)&&defined(IPSEC_ENABLE)
	if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
		{
		printf("IMCP(%u) Echo-Reply: IP-Error\r\n", icmp_count); 
		debug_display_mem_hex(tx_frame2, tx_frame2_size+IPSEC_OFFSET+ETH_HEADER_SIZE, 0);
		}
	#endif
	return;
	}
// Ethernet   
#ifdef ETHERNET_ENABLE
memcpy(&tx_frame2[(unsigned char)(ETH_DA_OFS+ip_offset)], mac_remote, 6);
memcpy(&tx_frame2[(unsigned char)(ETH_SA_OFS+ip_offset)], mac_address, 6);
*(unsigned int *)&tx_frame2[(unsigned char)(ETH_TYPE_OFS+ip_offset)] = SWAPB(IP_FRAME);
#else
mac_remote=ip_remote;
memset(&tx_frame2[(unsigned char)(ETH_DA_OFS+ip_offset)], 0x0, ETH_HEADER_SIZE);
#endif	//#ifdef ETHERNET_ENABLE
// Buffer
tx_frame2_size+=ETH_HEADER_SIZE;
buffer_write_command(tx_frame2+ip_offset, tx_frame2_size);
#ifdef WEB_DEBUG_ICMP
if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
	printf("IMCP(%u) Echo-Reply: %ubyte (data %ubyte)\r\n", icmp_count, tx_frame2_size, icmp_data_count); 
#endif
}


//*********************************************************************************
// Description	: prepares the tx_frame2-buffer to send an ICMP-echo-request
// Input   		: ip_remote  - pointer to IP-Address
//				: mac_remote - pointer to MAC-Address
//				: pattern	 - pattern to init data of icmp-frame
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void icmp_prepare_echo_request(unsigned char *ip_remote, unsigned char *mac_remote, unsigned char pattern)
{
static unsigned int icmp_ident;
static unsigned int icmp_seq;
unsigned char ip_offset;

memset(tx_frame2, pattern, sizeof(tx_frame2));
// ICMP
*(unsigned int *)&tx_frame2[ICMP_TYPE_CODE_OFS] = SWAPB(ICMP_ECHO_REQUEST << 8);
*(unsigned int *)&tx_frame2[ICMP_CHKSUM_OFS] = 0;			   			// initialize checksum field (16bit)
HOST_NETWORK_ENDIAN_16BIT(&tx_frame2[ICMP_IDENT_OFS], &icmp_ident);		// Identifier number (16bit)
icmp_ident++;
HOST_NETWORK_ENDIAN_16BIT(&tx_frame2[ICMP_SEQ_OFS], &icmp_seq);	 		// sequence number (16bit)
icmp_seq++;
*(unsigned int *)&tx_frame2[ICMP_CHKSUM_OFS] = ip_checksum(&tx_frame2[IP_DATA_OFS], ICMP_DATA_SIZE + ICMP_HEADER_SIZE, 0);
// IP   
tx_frame2_size=IP_HEADER_SIZE + ICMP_HEADER_SIZE + ICMP_DATA_SIZE;
if(ip_header_write(tx_frame2, &tx_frame2_size, &ip_offset, IP_ICMP_PROT, ip_address, ip_remote)==0)
	{
	#if defined(WEB_DEBUG_ICMP)&&defined(IPSEC_ENABLE)
	if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
		{
		printf("IMCP(%u) Echo-Request: IP-Error\r\n", icmp_count); 
		debug_display_mem_hex(tx_frame2, tx_frame2_size+IPSEC_OFFSET+ETH_HEADER_SIZE, 0);
		}
	#endif
	return;
	}
// Ethernet   
#ifdef ETHERNET_ENABLE
memcpy(&tx_frame2[(unsigned char)(ETH_DA_OFS+ip_offset)], mac_remote, 6);
memcpy(&tx_frame2[(unsigned char)(ETH_SA_OFS+ip_offset)], mac_address, 6);
*(unsigned int *)&tx_frame2[(unsigned char)(ETH_TYPE_OFS+ip_offset)] = SWAPB(IP_FRAME);
#else
mac_remote=ip_remote;
memset(&tx_frame2[(unsigned char)(ETH_DA_OFS+ip_offset)], 0x0, ETH_HEADER_SIZE);
#endif	//#ifdef ETHERNET_ENABLE
// Buffer
tx_frame2_size+=ETH_HEADER_SIZE;
buffer_write_command(tx_frame2+ip_offset, tx_frame2_size);
#ifdef WEB_DEBUG_ICMP
if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
	printf("IMCP(%u) Echo-Request: %ubyte (data %ubyte)\r\n", icmp_count, tx_frame2_size, ICMP_DATA_SIZE); 
#endif
}


//*********************************************************************************
// Description	: prepares the tx_frame2-buffer to send an ICMP-Timestamp-Request
// Input   		: ip_remote  - pointer to IP-Address
//				: mac_remote - pointer to MAC-Address
//				: time	 	 - last time 
// Output  		: none
// Indication	: none
//*********************************************************************************
void icmp_prepare_timestamp_request(unsigned char *ip_remote, unsigned char *mac_remote, unsigned long time)
{
static unsigned int icmp_identifikator=0;		// Identifier number (16bit)
static unsigned int icmp_sequenz=0xaa11; 		// sequence number (16bit)
unsigned char ip_offset;

#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_ICMP_ECHO_S)
#endif
// ICMP
*(unsigned int *)&tx_frame2[ICMP_TYPE_CODE_OFS] = SWAPB(ICMP_TIMESTAMP_REQUEST << 8);
*(unsigned int *)&tx_frame2[ICMP_CHKSUM_OFS] = 0;					// initialize checksum field (16bit)
HOST_NETWORK_ENDIAN_16BIT(&tx_frame2[ICMP_IDENT_OFS], &icmp_identifikator);// Identifier number (16bit)
HOST_NETWORK_ENDIAN_16BIT(&tx_frame2[ICMP_SEQ_OFS], &icmp_sequenz);  		// sequence number (16bit)
HOST_NETWORK_ENDIAN_32BIT(&tx_frame2[ICMP_TIMESTAMP_ORIGINATE_OFS], &time);// last time (32bit)
memset(&tx_frame2[ICMP_TIMESTAMP_RECEIVE_OFS], 0x0, 8);				// set ZERO Receive- and Transmit-Timestamp
*(unsigned int *)&tx_frame2[ICMP_CHKSUM_OFS] = ip_checksum(&tx_frame2[IP_DATA_OFS], ICMP_TIMESTAMP_SIZE, 0);
// IP   
tx_frame2_size=IP_HEADER_SIZE + ICMP_TIMESTAMP_SIZE;
if(ip_header_write(tx_frame2, &tx_frame2_size, &ip_offset, IP_ICMP_PROT, ip_address, ip_remote)==0)
	{
	#if defined(WEB_DEBUG_ICMP)&&defined(IPSEC_ENABLE)
	if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
		{
		printf("IMCP(%u) timestamp-Request: IP-Error\r\n", icmp_count); 
		debug_display_mem_hex(tx_frame2, tx_frame2_size+IPSEC_OFFSET+ETH_HEADER_SIZE, 0);
		}
	#endif	// #if defined(WEB_DEBUG_ICMP)&&defined(IPSEC_ENABLE)
	return;
	}
// Ethernet   
#ifdef ETHERNET_ENABLE
memcpy(&tx_frame2[(unsigned char)(ETH_DA_OFS+ip_offset)], mac_remote, 6);
memcpy(&tx_frame2[(unsigned char)(ETH_SA_OFS+ip_offset)], mac_address, 6);
*(unsigned int *)&tx_frame2[(unsigned char)(ETH_TYPE_OFS+ip_offset)] = SWAPB(IP_FRAME);
#else
mac_remote=ip_remote;
memset(&tx_frame2[(unsigned char)(ETH_DA_OFS+ip_offset)], 0x0, ETH_HEADER_SIZE);
#endif	//#ifdef ETHERNET_ENABLE
// Buffer   
tx_frame2_size+=ETH_HEADER_SIZE;
buffer_write_command(tx_frame2+ip_offset, tx_frame2_size);
#ifdef WEB_DEBUG_ICMP
if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
	printf("IMCP(%u) Timestamp-Request: %ubyte\r\n", icmp_count, tx_frame2_size); 
#endif
icmp_identifikator++;		// Identifier number (16bit)
}


//*********************************************************************************
// Description	: we've just rec'd an ICMP-frame (Internet Control Message Protocol)
//                check what to do and branch to the appropriate sub-function
// Input   		: none
// Output  		: none
// Indication	: see ip_process_frame()
//*********************************************************************************
void icmp_process_frame(void)
{
ICMP_HEADER_STRUCTURE	icmp_header;
unsigned long timestamp;

icmp_header.type=DEVICE_READ_IP_FRAME_16BIT_LE();	// get Message Type and Code
icmp_header.checksum=DEVICE_READ_IP_FRAME_16BIT();	// read ICMP checksum
icmp_header.ident=DEVICE_READ_IP_FRAME_16BIT();		// get Message Identificator
icmp_header.seq=DEVICE_READ_IP_FRAME_16BIT(); 		// get Message Sequence
#ifdef WEB_DEBUG_ICMP
icmp_count++;
#endif
switch(icmp_header.type)	// check type
	{
	case ICMP_ECHO_REQUEST:		
			#ifdef WEB_DEBUG_ICMP
			if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
				printf("IMCP(%u) Echo-Request ident: 0x%x; seq: 0x%x\r\n", icmp_count, icmp_header.ident, icmp_header.seq);
			#endif
			#ifdef ETHERNET_ENABLE
			icmp_prepare_echo_reply(ip_of_last_frame, mac_of_last_frame, icmp_header.ident, icmp_header.seq);		// echo as much as we can...
			#else
			icmp_prepare_echo_reply(ip_of_last_frame, 0, icmp_header.ident, icmp_header.seq);		// echo as much as we can...
			#endif
			break;
	case ICMP_DEST_UNREACHABLE:				// Destination Unreachable
			#ifdef WEB_DEBUG_ICMP
			if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
				printf("IMCP(%u) Destination Unreachable: %u\r\n", icmp_count, icmp_header.code);
			#endif
			break;
	case ICMP_ECHO_REPLY:		
			#ifdef WEB_DEBUG_ICMP
			if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
				printf("IMCP(%u) Echo-Reply ident: 0x%x; seq: 0x%x\r\n", icmp_count, icmp_header.ident, icmp_header.seq);
			#endif
			break;
	case ICMP_TIMESTAMP_REQUEST:
			#ifdef WEB_DEBUG_ICMP
			if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
				printf("IMCP(%u) Timestamp-Request ident: 0x%x; seq: 0x%x\r\n", icmp_count, icmp_header.ident, icmp_header.seq);
			#endif
			break;
	case ICMP_TIMESTAMP_REPLY:	
			#ifdef WEB_DEBUG_ICMP
			if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
				{
				printf("IMCP(%u) Timestamp-Reply ident: %x; seq: %x\r\n", icmp_count, icmp_header.ident, icmp_header.seq);
				timestamp=DEVICE_READ_IP_FRAME_16BIT_LE();						// read low part of timestamp
				timestamp|=(unsigned long)DEVICE_READ_IP_FRAME_16BIT_LE()<<16;	// read high part of timestamp
				printf("IMCP(%u) Originate: %lu,%u\r\n", icmp_count, timestamp/1000, timestamp%1000);
				timestamp=DEVICE_READ_IP_FRAME_16BIT_LE();						// read low part of timestamp
				timestamp|=(unsigned long)DEVICE_READ_IP_FRAME_16BIT_LE()<<16;	// read high part of timestamp
				printf("IMCP(%u) Receive  : %lu,%u\r\n", icmp_count, timestamp/1000, timestamp%1000);
				timestamp=DEVICE_READ_IP_FRAME_16BIT_LE();						// read low part of timestamp
				timestamp|=(unsigned long)DEVICE_READ_IP_FRAME_16BIT_LE()<<16;	// read high part of timestamp
				printf("IMCP(%u) Transmit : %lu,%u\r\n", icmp_count, timestamp/1000, timestamp%1000);
				}
			else
				{
				DEVICE_READ_IP_FRAME_DUMMY(8);	  				 	// ignore Originate and Receive Timestamp
				timestamp=DEVICE_READ_IP_FRAME_16BIT_LE();						// read low part of timestamp
				timestamp|=(unsigned long)DEVICE_READ_IP_FRAME_16BIT_LE()<<16;	// read high part of timestamp
				}
			#else
			DEVICE_READ_IP_FRAME_DUMMY(8);	  				  	// ignore Originate and Receive Timestamp
			timestamp=DEVICE_READ_IP_FRAME_16BIT_LE();						// read low part of timestamp
			timestamp|=(unsigned long)DEVICE_READ_IP_FRAME_16BIT_LE()<<16;	// read high part of timestamp
			#endif
			timestamp/=CLOCKS_PER_SEC;   	// calculate seconds
			board_set_second_counter(timestamp);
			break;
	default:
			#ifdef WEB_DEBUG_ICMP
			if(web_debug_flag & WEB_DEBUG_ICMP_BIT)
				printf("IMCP(%u) type: %u\r\n", icmp_count, icmp_header.type);
			#endif
	}
}
#endif	// #ifdef IP_ENABLE
#endif	// #ifdef ICMP_ENABLE