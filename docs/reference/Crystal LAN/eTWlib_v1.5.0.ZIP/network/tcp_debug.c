// ************************************************************************************************
///
/// \file 			tcp_debug.c
/// \brief			Debug functions for tcp.c
///
/// \todo			Add relative seq and ack numbers to debug output (like ethereal)
/// \date	 		$LastChangedDate: 2007-03-28 10:43:12 +0200 (Mi, 28 Mrz 2007) $
/// \version 		$Rev: 660 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#if (defined(TCP_DEBUG_TESTBENCH) || defined(TCP_DEBUG)) && !defined(TCP_ENABLE)
#error "TCP_DEBUG_TESTBENCH or TCP_DEBUG needs TCP_ENABLE! Define it in project.h"
#endif

#if defined(TCP_DEBUG_TESTBENCH) && !defined(TCP_DEBUG)
#error "TCP_DEBUG_TESTBENCH needs TCP_DEBUG! Define it in project.h"
#endif

#ifdef TCP_DEBUG

#include <stdio.h>
#include <string.h>
#include "debug.h"
#include "tcp.h"
#include "tcp_debug.h"

#pragma regalloc-
#ifdef TCP_DEBUG_TESTBENCH
unsigned char tcp_debug_client_handle=TCP_WRONG_CONNECTIONS;
unsigned char tcp_debug_server_handle=TCP_WRONG_CONNECTIONS;
#endif
eeprom unsigned char tcp_debug_flag = 0x00;	// default: debug output off
#pragma regalloc+

// prototype
void tcp_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);

//********************************************************************************
// Description	: displays the tcp_socket_error
// Input   		: p_struct - pointer auf tcp-structure
// Output  		: none
// Indication	: none
//*********************************************************************************
void tcp_debug_init(void)
{
T_DEBUG_HANDLER_STRUCT 	p_dbg_struct;
                       
p_dbg_struct.fp_handler = &tcp_debug_handler;
p_dbg_struct.id_string = "tcp";
debug_register_handler(&p_dbg_struct);
}


//********************************************************************************
// Description	: displays the tcp_socket_error
// Input   		: p_struct - pointer auf tcp-structure
// Output  		: none
// Indication	: none
//*********************************************************************************
void tcp_debug_display_socket_error(TCP_STRUCTURE *p_struct)
{
if (p_struct->tcp_socket_error!=p_struct->last_tcp_socket_error)
	{
	if (p_struct->tcp_socket_error & SOCK_ERR_ARP_TIMEOUT)	// timeout waiting for an ARP-REPLY
		printf("arp_timeout ");
	if (p_struct->tcp_socket_error & SOCK_ERR_TCP_TIMEOUT)	// timeout waiting for an ACK
		printf("tcp_timeout ");
	if (p_struct->tcp_socket_error & SOCK_ERR_CONN_RESET)	// connection was reset by the other TCP
		printf("conn_reset ");
	if (p_struct->tcp_socket_error & SOCK_ERR_REMOTE)		// remote TCP caused fatal error
		printf("remote ");
	if (p_struct->tcp_socket_error & SOCK_ERR_TCP_SEQ)		// wrong TCP-sequenz number
		printf("tcp_seq ");
	if (p_struct->tcp_socket_error & SOCK_ERR_TCP_ACK)		// wrong TCP-ack number
		printf("tcp_ack ");
	if (p_struct->tcp_socket_error & SOCK_ERR_TCP)			// TCP error
		printf("tcp ");
	putsf("\r");
	p_struct->last_tcp_socket_error=p_struct->tcp_socket_error;
	}
}


//********************************************************************************
// Description	: displays the tcp_flags
// Input   		: p_struct - pointer auf tcp-structure
// Output  		: none
// Indication	: none
//*********************************************************************************
void tcp_debug_display_flags(TCP_STRUCTURE *p_struct)
{
if (p_struct->tcp_flags & TCP_FLAG_OPEN)
	printf(" OPEN");
else
	printf(" CLOSE");
if (p_struct->tcp_flags & TCP_FLAG_PASSIVE)
	printf(", PASSIVE"); 
if (p_struct->tcp_flags & TCP_FLAG_ACTIVE)
	printf(", ACTIVE"); 
if (p_struct->tcp_flags & TCP_FLAG_IP_ADDR_RESOLVED)
	printf(", IP_ADDR_RESOLVED"); 
if (p_struct->tcp_flags & TCP_FLAG_CLOSE_REQUESTED)
	printf(", CLOSE_REQUESTED"); 
if (p_struct->tcp_flags & TCP_FLAG_ABORT)
	printf(", TCP_FLAG_ABORT"); 
if (p_struct->tcp_flags & TCP_FLAG_TIMER_RUNNING)
	printf(", TIMER_RUNNING"); 
if (p_struct->tcp_flags & TCP_FLAG_TIMER_CTRL_RETRANSMIT)
	printf(", TIMER_CTRL_RETRANSMIT"); 
putsf("\r"); 
}


//********************************************************************************
// Description	: displays all TCP-info's
// Input   		: port_number
// Output  		: none
// Indication	: none
//*********************************************************************************
void tcp_debug_info(unsigned int port_number)
{
unsigned char Lva, Lvb, display_count=0;
TCP_STRUCTURE	*p_struct;                                    	

p_struct=&tcp_struct[0];                                    	
for (Lva=0;Lva<TCP_MAX_CONNECTIONS; Lva++)
	{
	if ((port_number==0)||(port_number==p_struct->tcp_port_local))
		{
		display_count++;
		printf("tcp_connection: %u\r\n", Lva); 
		if (p_struct->tcp_socket_status & SOCK_ACTIVE_OPEN)
			printf(" socket_status: ACTIVE_OPEN(Client)"); 
		else		
			printf(" socket_status: PASSIVE_OPEN(Server)"); 
		if (p_struct->tcp_socket_status & SOCK_READY_CONNECT)
			printf(", READY_CONNECT"); 
		if (p_struct->tcp_socket_status & SOCK_CONNECTED)
			printf(", CONNECTED"); 
		if (p_struct->tcp_socket_status & SOCK_DISCONNECTING)
			printf(", DISCONNECTING"); 
		if (p_struct->tcp_socket_status & SOCK_DISCONNECTED)
			printf(", DISCONNECTED"); 
		if (p_struct->tcp_socket_status & SOCK_DATA_AVAILABLE)
			printf(", DATA_AVAILABLE"); 
		putsf("\r"); 
		if (p_struct->tcp_socket_error)
			{
			printf(" socket_error: ");
			p_struct->last_tcp_socket_error=0;		// simulate NO last error
			tcp_debug_display_socket_error(p_struct);
			}
		printf(" port-local, -remote : %u, %u\r\n", p_struct->tcp_port_local, p_struct->tcp_port_remote);
		debug_print_ip(" ip_remote", p_struct->tcp_ip_remote);
		debug_print_mac(" mac_remote", p_struct->tcp_mac_remote);
		printf(" flags      :"); 
		tcp_debug_display_flags(p_struct);
		printf(" state_machine     : %p\r\n", tcp_state_name[p_struct->tcp_state_machine]);
		printf(" last_frame_sent   : %p\r\n", tcp_retransmit_name[p_struct->tcp_last_frame_sent]);
		printf(" sequence next:%lu, unack:%lu, ack:%lu, win:%u\r\n", p_struct->tcp_sequence_next, p_struct->tcp_sequence_unack, 
																p_struct->tcp_sequence_ack, p_struct->tcp_window_local); 
		printf(" timer: %u / retry_counter: %u\r\n", p_struct->tcp_timer, p_struct->tcp_retry_counter);
		printf(" tx_buffer_status - Buffer: %uByte (H:%u D:%u)\r\n", TCP_TX_BUFFER_COUNT*TCP_TX_SEGMENT_SIZE, TCP_ALL_HEADER_SIZE, TCP_TX_SEGMENT_SIZE); 
		for (Lvb=0;Lvb<TCP_TX_BUFFER_COUNT; Lvb++)
			{
			printf("  %u.) ", Lvb); 
			if (p_struct->tcp_tx[Lvb].flags & TCP_TX_FLAG_FREE)
				printf("FREE, "); 
			if (p_struct->tcp_tx[Lvb].flags & TCP_TX_FLAG_HALF_FULL)
				printf("HALF_FULL, "); 
			if (p_struct->tcp_tx[Lvb].flags & TCP_TX_FLAG_FULL)
				printf("FULL, "); 
			if (p_struct->tcp_tx[Lvb].flags & TCP_TX_FLAG_SENT)
				printf("SENT, "); 
			if (p_struct->tcp_tx[Lvb].flags & TCP_TX_FLAG_RETRANSMIT)
				printf("RETRANSMIT, "); 
			printf(" data_count: %uByte age: %u\r\n", p_struct->tcp_tx[Lvb].data_count, p_struct->tcp_tx[Lvb].age);
			}
		printf(" rx_frame - Buffer:%u gap:%u\r\n", TCP_RX_BUFFER_SIZE, p_struct->tcp_rx.gap);
		#ifdef TCP_ALIVE_ACTIVE_ENABLE
		printf(" alive ");
		if (p_struct->tcp_alive_flag & TCP_ALIVE_FLAG_ENABLE)
			printf("ENABLE");
		else
			printf("DISABLE");
		if (p_struct->tcp_alive_flag & TCP_ALIVE_FLAG_OPEN)
			printf(", OPEN");
		else
			printf(", CLOSE");
		printf(": %u0ms; timeout:%u0ms\r\n", p_struct->tcp_alive_time*5, (unsigned int)(TCP_ALIVE_TIMEOUT_FACTOR*p_struct->tcp_alive_time)*5);
		#endif
		printf(" last_state_machine: %p\r\n", tcp_state_name[p_struct->last_tcp_state_machine]);
		printf(" receive-sequenz:%lu, relative:%lu\r\n", p_struct->tcp_irs_number, p_struct->tcp_sequence_ack-p_struct->tcp_irs_number);
		printf(" rx-ok:%lu, -wrong:%lu, -lost:%lu\r\n", p_struct->tcp_rx_ok_data, p_struct->tcp_rx_wrong_data, p_struct->tcp_rx_lost_data); 
		printf(" send-sequenz:%lu, relative:%lu\r\n", p_struct->tcp_iss_number, p_struct->tcp_sequence_next-p_struct->tcp_iss_number);
		printf(" tx-ok:%lu, -repeat:%lu\r\n", p_struct->tcp_tx_ok_data, p_struct->tcp_tx_repeat_data); 
    	}
	p_struct++;
	}
if (display_count == 0)
	{
	printf("no TCP-Port: %u\r\n", port_number);
	}
}


#ifdef TCP_DEBUG_TESTBENCH
unsigned char tcp_debug_buffer[TCP_TX_SEGMENT_SIZE];

//*********************************************************************************
// Description	: handles the test TCP-Connections
// Input     	: none
// Output	   	: none
// Indication	: none
//*********************************************************************************
void tcp_debug_client_server(void)
{
TCP_STRUCTURE	*p_struct;
unsigned int tcp_data_count;

p_struct = tcp_get_struct(tcp_debug_client_handle);
if (p_struct == 0)
	tcp_debug_client_handle = TCP_WRONG_CONNECTIONS;
else
	{
	if (p_struct->tcp_socket_status & SOCK_CONNECTED)// check if somebody has connected to our TCP
		{
		if (p_struct->tcp_socket_status & SOCK_DATA_AVAILABLE)	// check if remote TCP sent data
			{
			tcp_rx_buffer_clear(tcp_debug_client_handle);		// and throw it away
			}
		}
	else
		{
		if ((!(p_struct->tcp_socket_status & (SOCK_READY_CONNECT|SOCK_ACTIVE_OPEN)))  &&
			(p_struct->tcp_socket_status & SOCK_DISCONNECTED))
		   	{
			putsf("\"tcp_debug_client_handle\" close\r"); 
			tcp_debug_client_handle = TCP_WRONG_CONNECTIONS;
			}
		}
	}
p_struct = tcp_get_struct(tcp_debug_server_handle);
if (p_struct == 0)
	tcp_debug_server_handle = TCP_WRONG_CONNECTIONS;
else
	{
	if (p_struct->tcp_socket_status & SOCK_CONNECTED)			// check if somebody has connected to our TCP
		{
		if (p_struct->tcp_socket_status & SOCK_DATA_AVAILABLE)	// check if remote TCP sent data
			{
			if (p_struct->tcp_port_local == TCP_PORT_ECHO)
				{
				tcp_data_count = tcp_tx_buffer_write(tcp_debug_server_handle, 0x0, 
												     0, TCP_TX_BUFFER_GET_SIZE);
				if (tcp_data_count > sizeof(tcp_debug_buffer))
					tcp_data_count = sizeof(tcp_debug_buffer);
				tcp_rx_buffer_read(tcp_debug_server_handle, tcp_debug_buffer, 
							       &tcp_data_count, TCP_RX_BUFFER_READ_DATA);
				if (tcp_data_count)
					tcp_data_count = tcp_tx_buffer_write(tcp_debug_server_handle, 
														 tcp_debug_buffer, 
														 tcp_data_count, 
														 TCP_TX_BUFFER_WRITE_RAM_DATA);
				}
			else
				tcp_rx_buffer_clear(tcp_debug_server_handle);		// and throw it away
			}
		}
	else
		{
		if ((!(p_struct->tcp_socket_status & SOCK_READY_CONNECT)&& 
			  (p_struct->tcp_socket_status & SOCK_DISCONNECTED))   ||
		    p_struct->tcp_socket_error)
			{
			putsf("\"tcp_debug_server_handle\" close\r"); 
			tcp_init_connection(tcp_debug_server_handle);
			tcp_debug_server_handle = TCP_WRONG_CONNECTIONS;
			}
		}
	}
}
#endif	// #define TCP_DEBUG_TESTBENCH


//********************************************************************************
// Description	: help infos to the terminal commands
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void tcp_debug_help(void)
{
putsf("\"tcp-info <number>\" - displays infos to TCP-Connection (example: \"tcp-info 0\")\r"); 
putsf("\"tcp-client <ip> <port>\" - open TCP-Client (example: \"tcp-client 192.168.50.3 9\")\r"); 
putsf("\"tcp-server <port>\" - open TCP-Server (example: \"tcp-server 9\")\r"); 
putsf("\"tcp-close\" - close Client and/or Server connections\r"); 
#ifdef TCP_ALIVE_ACTIVE_ENABLE
putsf("\"tcp-alive <tcp-connection>\" - disable or enable TCP-Alive with 2000ms (example: \"tcp-alive 0\")\r"); 
#endif
putsf("\"tcp-isn <isn>\" - sets a new ISN (example: \"tcp-isn 0\")\r"); 
}


// ************************************************************************************************
/// \brief	    command handler for debug commands
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void tcp_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
signed int 		data;
#ifdef TCP_DEBUG_TESTBENCH	
unsigned char	ip[4];			// see debug_string2ip()
unsigned int 	tcp_port=0;
#endif
#if defined(TCP_ALIVE_ACTIVE_ENABLE) || defined(TCP_DEBUG_TESTBENCH)
TCP_STRUCTURE*	p_struct;
#endif

if (mode == DEBUG_HANDLER_MODE_INFO)
	{
	printf("TCP_DEBUG");
	if (tcp_debug_flag)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
	}
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
	tcp_debug_help();
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
    {
	if (strncmpf(command, "tcp", 3)==0)
	    {
    	tcp_debug_flag ^= 0xFF;
    	if (tcp_debug_flag)
			putsf("TCP_DEBUG ON\r");
		else
			putsf("TCP_DEBUG OFF\r");
	    }
	}
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-info", 5)==0)
		{
		data=debug_get_int_parameter(command);
		if(data==-1)
			data=0;
		tcp_debug_info(data);
		}
	else if (strncmpf(command, "-alive", 5)==0)
		{
		#ifdef TCP_ALIVE_ACTIVE_ENABLE
		data=debug_get_int_parameter(command);
		if (data == -1)
			data = 0;
		if (tcp_get_struct(data))
			{
			tcp_alive_set_time(data, 40);
			if(tcp_struct[data].tcp_alive_flag)
				{
				tcp_alive_disable(data);
				putsf("TCP-Alive disable\r"); 
				}
			else
				{
				tcp_alive_enable(data);
				putsf("TCP-Alive enable (2000ms)\r"); 
				}
			}
		else
			putsf("TCP-Alive wrong TCP-Connection\r"); 
		#else
		putsf("NO TCP-Alive enable\r"); 
		#endif
		}
	else if (strncmpf(command, "-isn", 4)==0)
		{
		data=debug_get_int_parameter(command);
		if (data == -1)
			data = 0xffff;
		tcp_isn_high_number=(unsigned int)data;		// upper word of our Initial Sequence Number
		printf("tcp_isn_high_number: 0x%x\r\n", tcp_isn_high_number);
		}
	#ifdef TCP_DEBUG_TESTBENCH	
	else if (strncmpf(command, "-client", 4)==0)
		{
		if (debug_string2ip(command, ip, &tcp_port)!=0)
			{
			if (tcp_port==0)
				tcp_port=TCP_PORT_DISCARD;	// TCP Port to discard of data
			data = tcp_debug_flag;	// save web_debug_flag
			tcp_debug_flag = 0xff;
			tcp_debug_client_handle = tcp_active_open(ip, tcp_port, tcp_port);
			tcp_debug_flag = data;	// resore web_debug_flag
			}
		else
			putsf("TCP-Client wrong parameter\r"); 
		}
	else if (strncmpf(command, "-server", 3)==0)
		{
		tcp_port=debug_get_int_parameter(command);
		if (tcp_port==0xffff)    // means -1
			tcp_port=TCP_PORT_DISCARD;	// TCP Port to discard of data
		data = tcp_debug_flag;	// save web_debug_flag
		tcp_debug_flag = 0xff;
		if (tcp_debug_server_handle!=TCP_WRONG_CONNECTIONS)
			{
			tcp_abort(tcp_debug_server_handle);
			p_struct=tcp_get_struct(tcp_debug_server_handle);
			p_struct->tcp_flags&=~TCP_FLAG_PASSIVE;
			}
		tcp_debug_server_handle=tcp_passive_open(tcp_port);
		tcp_debug_flag=data;	// resore web_debug_flag
		}
	else if (strncmpf(command, "-close", 3)==0)
		{
		data = tcp_debug_flag;	// save web_debug_flag
		tcp_debug_flag = 0xff;
		if (tcp_debug_client_handle!=TCP_WRONG_CONNECTIONS)
			{
			putsf("TCP-Client close\r"); 
			tcp_close(tcp_debug_client_handle);
			//tcp_debug_client_handle=TCP_WRONG_CONNECTIONS;
			}
		else if (tcp_debug_server_handle!=TCP_WRONG_CONNECTIONS)
			{
			putsf("TCP-Server close\r"); 
			tcp_close(tcp_debug_server_handle);
			//tcp_debug_server_handle=TCP_WRONG_CONNECTIONS;
			}
		else
			putsf("TCP-Client/Server nothing to close\r"); 
		tcp_debug_flag = data;	// resore web_debug_flag
		}
	#endif	// #ifdef TCP_DEBUG_TESTBENCH
	}
}

#endif	// #ifdef TCP_DEBUG