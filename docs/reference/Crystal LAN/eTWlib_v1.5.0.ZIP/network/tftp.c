// ************************************************************************************************
///
/// \file 			tftp.c
/// \brief			Implements TFT protocol
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Daniel Matthes<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef TFTP_ENABLE

#include <stdio.h>
#include <stdlib.h>

#include "ethernet.h"
#include "device.h"
#include "buffer.h"
#include "ip.h"
#include "udp.h"
#include "tftp.h"
#ifdef WEB_DEBUG
#include "web_debug.h"
#endif

#pragma regalloc-
unsigned char 	udp_connection_tftp = UDP_WRONG_CONNECTIONS;
unsigned char	tftp_ok = 0;
#pragma regalloc+


//*********************************************************************************
// Description	: init the TFTP-IP-Connection
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void tftp_init(void)
{
unsigned char temp;

temp = UDP_PORT_TFTP;
udp_connection_tftp = udp_open(UDP_PORT_TFTP, 0, 0, 0, UDP_FLAG_PASSIVE);
if(udp_connection_tftp == UDP_WRONG_CONNECTIONS)
	{
	#ifdef WEB_DEBUG_TFTP
	if(web_debug_flag & WEB_DEBUG_TFTP_BIT)
		printf("TFTP UDP(%u) Passive Open Error!!!!\r\n", temp);
	#endif 
	}
tftp_ok = 1;
}


//*********************************************************************************
// Description	: main routine to handle the TFTP-IP-Connection
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void tftp_main(void)
{
UDP_STRUCTURE	*p_struct;
unsigned int block_number;                                    	

p_struct=udp_get_struct(udp_connection_tftp);
if((p_struct!=0) && (p_struct->udp_flags & UDP_DATA_AVAILABLE))	// check if remote UDP sent data
	{                                                
	#ifdef WEB_DEBUG_TFTP
	if(web_debug_flag & WEB_DEBUG_TFTP_BIT)
		{
		putsf("RX-data:\r");
		debug_display_frame(p_struct->udp_rx_frame, p_struct->udp_rx_data_count, 0);
		}
	#endif
	if((p_struct->udp_rx_frame[1] == (unsigned char)TFTP_RRQ) || 
	   (p_struct->udp_rx_frame[1] == (unsigned char)TFTP_WRQ))
		block_number = 0;										
	if((p_struct->udp_rx_frame[1] == (unsigned char)TFTP_DATA))
	    block_number = (((unsigned int)p_struct->udp_rx_frame[2] << 8) ^ 
	    				(unsigned int)p_struct->udp_rx_frame[3]); 
	
	udp_rx_buffer_release(udp_connection_tftp);					// clear the UDP-RX-Buffer
  	tftp_ack(udp_connection_tftp, block_number);                // send Acknowledgment
  	}
}
//*********************************************************************************
// Description	: function to ACK TFTP-Request and TFTP-Data
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
unsigned char tftp_ack(unsigned char udp_connection, unsigned int block_number)
{
unsigned int	udp_data[2];

udp_data[0] = SWAPB(TFTP_ACK);
udp_data[1] = SWAPB(block_number);
                              
if(udp_tx_buffer_prepare(udp_connection, (unsigned char*)udp_data, 4))
	{
	#ifdef WEB_DEBUG_TFTP
	if(web_debug_flag & WEB_DEBUG_TFTP_BIT)	
		{
		putsf("TX-data:\r");
		debug_display_frame((unsigned char*)udp_data, 4, 0);
    	}
    #endif
	return 1;
	}
return 0;
}


#endif