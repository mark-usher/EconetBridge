// ************************************************************************************************
///
/// \file 			tcp.h
///
/// \date	 		$LastChangedDate: 2007-03-12 13:48:26 +0100 (Mo, 12 Mrz 2007) $
/// \version 		$Rev: 619 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup Network_Stack
/// \addtogroup Network_Stack
/// @{
/// \defgroup TCP
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define TCP_ENABLE
#define TCP_DEBUG
#define TCP_DEBUG_TESTBENCH
#define TCP_TX_BUFFER_SIZE		250		// max. TCP-TX-Buffer data size
#define TCP_TX_SEGMENT_SIZE		250		// max. outgoing TCP data size
#define TCP_RX_BUFFER_SIZE		500		// max. TCP-RX-Buffer data size
#define TCP_RX_SEGMENT_SIZE		250		// max. incoming TCP data size
#define TCP_MAX_CONNECTIONS		1		// max. TCP connections
//@}
#endif


#ifndef _TCP_INCLUDED_
#define _TCP_INCLUDED_

#include "project.h"		// Project configuration

#include "ethernet.h"
#include "ip.h"
#ifdef IPSEC_ENABLE
#include "ipsec.h"
#endif


///	\def TCP_ENABLE
///		This macro enables the whole TCP module. It must be defined in project.h
///
/// \def TCP_DEBUG
///		Enables all debug output and debug handler in tcp.c and tcp_debug.c. Must be
///		defined in project.h. 
///
/// \def TCP_DEBUG_TESTBENCH
///		Enables an testbench for the tcp module in tcp_debug.c. It works as an test 
///		server/client application using the tcp functions. The macro must be defined
///		in project.h
///
/// \def TCP_TX_BUFFER_SIZE
///		
///
/// \def TCP_TX_SEGMENT_SIZE
///		
///
/// \def TCP_RX_BUFFER_SIZE
///		
///
/// \def TCP_RX_SEGMENT_SIZE
///		
///
/// \def TCP_MAX_CONNECTIONS
///		
///


// --------------------------------------------------------------------------------
// see variable "tcp_socket_status"
// -------------------------------------------------------------------------------- 
#define SOCK_PASSIVE_OPEN				0x00		// state machine server
#define SOCK_ACTIVE_OPEN				0x01		// state machine client
#define SOCK_READY_CONNECT				0x02		// state machine ready to connect
#define SOCK_CONNECTED					0x04		// user may send & receive data
#define SOCK_DISCONNECTING				0x08		// connection is disconnecting
#define SOCK_DISCONNECTED				0x10		// connection is disconnected
#define SOCK_DATA_AVAILABLE				0x20		// new receive-data available

// --------------------------------------------------------------------------------
// see variable "tcp_socket_error"
// -------------------------------------------------------------------------------- 
#define SOCK_ERR_OK						0x00		// no error
#define SOCK_ERR_ARP_TIMEOUT			0x01		// timeout waiting for an ARP-REPLY
#define SOCK_ERR_TCP_TIMEOUT			0x02		// timeout waiting for an ACK or FIN
#define SOCK_ERR_CONN_RESET				0x04		// connection was reset by the other TCP
#define SOCK_ERR_REMOTE					0x08		// remote TCP caused fatal error
#define SOCK_ERR_TCP_SEQ				0x10		// wrong TCP-sequenz number
#define SOCK_ERR_TCP_ACK				0x20		// wrong TCP-ack number
#define SOCK_ERR_TCP					0x40		// TCP error

// --------------------------------------------------------------------------------
// easyToWeb-stack definitions
// -------------------------------------------------------------------------------- 
#ifndef TCP_RETRY_TIMEOUT
#define TCP_RETRY_TIMEOUT		10		// wait max. 10 x 50ms for an ACK (about 0,5 sec)
#endif // #ifndef TCP_RETRY_TIMEOUT
#if(TCP_RETRY_TIMEOUT<1)
#error ERROR: "TCP_RETRY_TIMEOUT" too small: TCP_RETRY_TIMEOUT!!!
#endif

#ifndef TCP_FIN_TIMEOUT
#define TCP_FIN_TIMEOUT			15		// wait max. 15 x 50ms for an ACK of a FIN (about 0.75 sec)
#endif // #ifndef TCP_FIN_TIMEOUT
#if(TCP_FIN_TIMEOUT<1)
#error ERROR: "TCP_FIN_TIMEOUT" too small: TCP_FIN_TIMEOUT!!!
#endif

#if(TCP_FIN_TIMEOUT<TCP_RETRY_TIMEOUT)
#error ERROR: "TCP_FIN_TIMEOUT" must bigger as "TCP_RETRY_TIMEOUT"!!!
#endif

#ifndef TCP_MAX_RETRYS
#define TCP_MAX_RETRYS			4		// number of resendings before reset conn.
#endif                                  // total nr. of transmissions = TCP_MAX_RETRYS

#ifndef TCP_ADD_PSH_FLAG
#define TCP_ADD_PSH_FLAG				// to each payload packet otherwise problems with
#endif									// delays in some windows-tcp/ip-stacks occur

// --------------------------------------------------------------------------------
// TCP layer definitions
// -------------------------------------------------------------------------------- 
#define TCP_SRCPORT_OFS			IP_DATA_OFS + 0     // Source Port (16 bit)
#define TCP_DESTPORT_OFS		IP_DATA_OFS + 2     // Destination Port (16 bit)
#define TCP_SEQNR_OFS			IP_DATA_OFS + 4     // Sequence Number (32 bit)
#define TCP_ACKNR_OFS			IP_DATA_OFS + 8     // Acknowledge Number (32 bit)
#define TCP_DATA_CODE_OFS		IP_DATA_OFS + 12    // Data Offset and Control Bits (16 bit)
#define TCP_WINDOW_OFS			IP_DATA_OFS + 14    // Window Size (16 bit)
#define TCP_CHKSUM_OFS			IP_DATA_OFS + 16    // Checksum Field (16 bit)
#define TCP_URGENT_OFS			IP_DATA_OFS + 18    // Urgent Pointer (16 bit)
#define TCP_DATA_OFS			IP_DATA_OFS + 20    // Frame Data (if no options)
#define TCP_HEADER_SIZE			20                  // size w/o options
#define TCP_ALL_HEADER_SIZE		(ETH_HEADER_SIZE+IP_HEADER_SIZE+IPSEC_ADD_SIZE+TCP_HEADER_SIZE)

#define TCP_OPT_MSS				0x0204              // Type 2, Option Length 4 (Max. Segment Size)
#define TCP_OPT_MSS_SIZE		4

// --------------------------------------------------------------------------------
// define some TCP standard-ports, useful for testing...
// -------------------------------------------------------------------------------- 
#define TCP_PORT_ECHO			7				// echo
#define TCP_PORT_DISCARD		9				// discard
#define TCP_PORT_DAYTIME		13				// daytime
#define TCP_PORT_QOTD			17				// quote of the day
#define TCP_PORT_CHARGEN		19				// character generator
#ifndef TCP_PORT_FTP_DATA
#define TCP_PORT_FTP_DATA		20				// FTP Data Port
#endif	// #ifndef TCP_PORT_FTP_DATA
#ifndef TCP_PORT_FTP_COMMAND
#define TCP_PORT_FTP_COMMAND	21				// FTP Command Port
#endif	// #ifndef TCP_PORT_FTP_COMMAND
#define TCP_PORT_SSH			22				// SSH-Port
#define TCP_PORT_TELNET			23				// Telnet-Port
#define TCP_PORT_HTTP			80				// word wide web HTTP

// --------------------------------------------------------------------------------
// see variable "tcp_flags"
// -------------------------------------------------------------------------------- 
#define TCP_FLAG_OPEN 					0x01		// no connection
#define TCP_FLAG_PASSIVE					0x02		// server connection
#define TCP_FLAG_ACTIVE		 			0x04		// client connection
#define TCP_FLAG_IP_ADDR_RESOLVED		0x08		// IP sucessfully resolved to MAC
#define TCP_FLAG_CLOSE_REQUESTED		0x10
#define TCP_FLAG_ABORT					0x20
#define TCP_FLAG_TIMER_RUNNING			0x40
#define TCP_FLAG_TIMER_CTRL_RETRANSMIT	0x80

#define TCP_FLAG_RESET_MASK		 		(TCP_FLAG_PASSIVE | TCP_FLAG_ACTIVE)

// --------------------------------------------------------------------------------
// TCP TX Buffer size
// -------------------------------------------------------------------------------- 
#ifndef TCP_TX_BUFFER_SIZE
#define TCP_TX_BUFFER_SIZE			128     	// max. TCP-TX-Buffer data size
#endif

#ifndef TCP_TX_SEGMENT_SIZE
#define TCP_TX_SEGMENT_SIZE			128     	// max. outgoing TCP data size
#endif

#if(TCP_TX_BUFFER_SIZE<TCP_TX_SEGMENT_SIZE)
#error ERROR: "TCP_TX_BUFFER_SIZE" to small: needs TCP_TX_SEGMENT_SIZE!!!
#endif

#if((TCP_TX_BUFFER_SIZE%TCP_TX_SEGMENT_SIZE)!=0)
#define TCP_TX_BUFFER_COUNT			((TCP_TX_BUFFER_SIZE/TCP_TX_SEGMENT_SIZE)+1)
#else
#define TCP_TX_BUFFER_COUNT			(TCP_TX_BUFFER_SIZE/TCP_TX_SEGMENT_SIZE)
#endif

#define TCP_TX_BUFFER_AGE_OVER		32	  	   	// undefined TX-Buffer

#if(TCP_TX_BUFFER_COUNT>(TCP_TX_BUFFER_AGE_OVER-1))
#error ERROR: "TCP_TX_BUFFER_COUNT" to big: TCP_TX_BUFFER_COUNT!!!
#endif

#if(TCP_TX_BUFFER_COUNT<1)
#error ERROR: "TCP_TX_BUFFER_COUNT" to small: TCP_TX_BUFFER_COUNT!!!
#endif

#define TCP_TX_BUFFER_UNDEF			0xFF  	   	// undefined TX-Buffer

// --------------------------------------------------------------------------------
// TCP TX Delay send
// -------------------------------------------------------------------------------- 
//#define TCP_TX_DELAY_ENABLE			// enable delay transmit

#ifndef TCP_TX_DELAY_COUNT
#define TCP_TX_DELAY_COUNT			3			// count (repeat function "tcp_main()") to delay the transmit 
#endif

#if(TCP_TX_DELAY_COUNT>255)
#error ERROR: "TCP_TX_DELAY_COUNT" to big: use max. 255 !!!
#endif

// --------------------------------------------------------------------------------
// TCP RX Buffer size
// -------------------------------------------------------------------------------- 
#ifndef TCP_RX_BUFFER_SIZE
#define TCP_RX_BUFFER_SIZE			256     	// max. incoming TCP data size
#endif
#ifndef TCP_RX_SEGMENT_SIZE
#define TCP_RX_SEGMENT_SIZE			128     	// max. incoming TCP-Segment size
#endif

#if(TCP_RX_BUFFER_SIZE<(TCP_RX_SEGMENT_SIZE*2))
#error ERROR: "TCP_RX_BUFFER_SIZE" to small: needs "TCP_RX_SEGMENT_SIZE"*2 !!!
#endif

#ifndef TCP_MAX_WINDOW_SIZE
#define TCP_MAX_WINDOW_SIZE 		TCP_RX_SEGMENT_SIZE	// max. size of TCP-Window
#endif

#if(TCP_MAX_WINDOW_SIZE>TCP_RX_BUFFER_SIZE)
#error ERROR: "TCP_MAX_WINDOW_SIZE" to big: use max. TCP_RX_BUFFER_SIZE !!!
#endif

// --------------------------------------------------------------------------------
// TCP Connections count
// -------------------------------------------------------------------------------- 
#ifndef TCP_MAX_CONNECTIONS
#define TCP_MAX_CONNECTIONS			1	  	   	// max. TCP connections
#endif

#if(TCP_MAX_CONNECTIONS>254)
#error ERROR: "TCP_MAX_CONNECTIONS" too big: TCP_MAX_CONNECTIONS!!!
#endif

#define TCP_WRONG_CONNECTIONS		0xFF  	   	// no TCP connections available

//  --------------------------------------------------------------------------------
//	TCP-Alive Parameter
//  -------------------------------------------------------------------------------- 
#define TCP_ALIVE_FLAG_ENABLE		0x01		// TCP-Alive is ready to open
#define TCP_ALIVE_FLAG_OPEN			0x02		// TCP-Alive is open

#define TCP_ALIVE_MIN_TIME			5			// min 5*50ms=250ms timeout
#ifndef TCP_ALIVE_ACK_RETRYS
#define TCP_ALIVE_ACK_RETRYS		4			// counts of Alive-ACK-Frames before close
#else
#if(TCP_ALIVE_ACK_RETRYS<1)
#error ERROR: "TCP_ALIVE_ACK_RETRYS" too small: TCP_ALIVE_ACK_RETRYS!!!
#endif
#endif	// #ifndef TCP_ALIVE_ACK_RETRYS
#define TCP_ALIVE_TIMEOUT_FACTOR	(TCP_ALIVE_ACK_RETRYS+1)			// factor defines the Alive-timeout time
#define TCP_ALIVE_MAX_TIME			(0xFFFF/TCP_ALIVE_TIMEOUT_FACTOR)	// max Alive time
#ifndef TCP_ALIVE_DEFAULT_TIME
#define TCP_ALIVE_DEFAULT_TIME		40			// min 40*50ms=2000ms timeout
#endif

// --------------------------------------------------------------------------------
// see variable "tcp_tx_buffer_status"
// -------------------------------------------------------------------------------- 
#define TCP_TX_FLAG_FREE			0x01		// user may fill buffer
#define TCP_TX_FLAG_HALF_FULL		0x02		// some place inside of TCP-Buffer
#define TCP_TX_FLAG_FULL			0x04		// transmit buffer full and ready to transmit
#define TCP_TX_FLAG_SENT			0x08		// data sent
#define TCP_TX_FLAG_RETRANSMIT		0x10		// retransmit active

// --------------------------------------------------------------------------------
// TCP-Header
// -------------------------------------------------------------------------------- 
typedef struct 
	{
	unsigned int src;				// source port number
	unsigned int dest;				// destination port number
	unsigned long seq;				// sequence number
	unsigned long ack;				// acknowledge number
	unsigned int offset_flags;		// offset /flags
	unsigned int window;			// window 
	unsigned int checksum;			// checksum
	unsigned int urgent;			// urgent pointer
	} TCP_HEADER_STRUCTURE;

// --------------------------------------------------------------------------------
// TCP-State-Machine-Definitions
// -------------------------------------------------------------------------------- 
typedef enum {                                   // states of the TCP-state machine
  CLOSED,                                        // according to RFC793
  LISTEN,
  SYN_SENT,
  SYN_RCVD,
  ESTABLISHED,
  FIN_WAIT_1,
  FIN_WAIT_2,
  CLOSE_WAIT,
  CLOSING,
  LAST_ACK,
  TIME_WAIT,
  TCP_UNREACHED										// new state to debug
} TCP_STATE_MACHINE;

typedef enum {                                   // type of last frame sent. used
  TCP_NONE,                               
  TCP_ARP_REQUEST,                               // for retransmissions
  TCP_SYN_FRAME,
  TCP_SYN_ACK_FRAME,
  TCP_FIN_FRAME
} TCP_LAST_FRAME_SENT;


//  --------------------------------------------------------------------------------
//	TCP-TX-Buffer structure
//  -------------------------------------------------------------------------------- 
typedef struct 
	{
	unsigned char  	flags;          // status of TX-Buffer
	unsigned char  	age;			// age of frame
	unsigned long  	unack;			// last unaknowledged sequence number - incremented AFTER sending data
	unsigned long  	next;			// next sequence number to send
	unsigned char  	timer;			// inc'd each 50ms
	unsigned char  	retry_counter;	// number of retransmissions
	unsigned int   	data_count;		// count of TCP-data bytes to send
	unsigned char  *data_position;	// pointer to data
	unsigned char  	data_frame[TCP_ALL_HEADER_SIZE+TCP_TX_SEGMENT_SIZE+4]; 	// pointer to Header+TCP-Data
	} TCP_TX_BUFFER_STRUCTURE;


//  --------------------------------------------------------------------------------
//	TCP-RX-Buffer structure
//  -------------------------------------------------------------------------------- 
typedef struct 
	{
	unsigned int	gap;			// gap between last datas
	unsigned int	rtop;			// read top pointer
	unsigned int	wtop;			// write top pointer
	unsigned char   data_frame[TCP_RX_BUFFER_SIZE+1]; // pointer to TCP-Data
	} TCP_RX_BUFFER_STRUCTURE;

//  --------------------------------------------------------------------------------
//	TCP-Buffer structure
//  -------------------------------------------------------------------------------- 
typedef struct{
	unsigned char 			tcp_socket_status;
	unsigned char 			tcp_socket_error;
	unsigned int 			tcp_port_local;				// TCP ports
	unsigned int 			tcp_port_remote;
	unsigned char			tcp_ip_remote[IP_ADR_SIZE];	// ip remote address
	unsigned char			tcp_mac_remote[6];			// MAC of this TCP-session
	unsigned char 			tcp_flags;
	TCP_STATE_MACHINE 		tcp_state_machine;			// perhaps the most important var at all ;-)
	// -------------------------------------------------------------------------------- 
	TCP_LAST_FRAME_SENT 	tcp_last_frame_sent;		// Ctrl-retransmission type
	unsigned long			tcp_sequence_next; 			// next sequence number to send
	unsigned long 			tcp_sequence_ack;			// next seq to receive and ack to send - incremented AFTER receiving data
	unsigned long 			tcp_sequence_unack;			// last unaknowledged sequence number - incremented AFTER sending data
	unsigned int 			tcp_window_remote;			// actual remote window size
	unsigned int 			tcp_window_local;			// actual local window size
	unsigned int            tcp_max_window_size;        // max. segment size for rx data
	unsigned char 			tcp_timer;					// inc'd each 50ms
	unsigned char 			tcp_retry_counter;			// number of retransmissions
	unsigned char 			tcp_tx_ctrl_frame[TCP_ALL_HEADER_SIZE+TCP_OPT_MSS_SIZE+4];	// pointer to Header+TCP-Option
	// TX and RX -------------------------------------------------------------------------------- 
	TCP_TX_BUFFER_STRUCTURE tcp_tx[TCP_TX_BUFFER_COUNT];
	TCP_RX_BUFFER_STRUCTURE tcp_rx;
	// Alive -------------------------------------------------------------------------------- 
	#ifdef TCP_ALIVE_ACTIVE_ENABLE
	unsigned char 			tcp_alive_flag;				// see "TCP_ALIVE_FLAG_xxx"
	unsigned int	 		tcp_alive_time;				// *50ms --> 3276750ms - 3276,75sec - 54min
	unsigned char	 		tcp_alive_50ms_bit;			// buffers the last 50ms count
	unsigned int	 		tcp_alive_delay;			// counts the delay every 10ms until send Alive-ACK
	unsigned int	 		tcp_alive_timeout_delay;	// counts the delay every 10ms until close
	#endif
	// Debug -------------------------------------------------------------------------------- 
	#ifdef TCP_DEBUG
	TCP_STATE_MACHINE 		last_tcp_state_machine;
	unsigned char 			last_tcp_socket_error;
	unsigned long			tcp_iss_number;				// initial send sequence number
	unsigned long 			tcp_irs_number;				// initial receive sequence number
	unsigned long			tcp_rx_ok_data;				// count of all receive data, see function tcp_rx_buffer_read_frame()
	unsigned long			tcp_rx_wrong_data;			// count the wrong data, see function tcp_rx_buffer_read_frame()
	unsigned long			tcp_rx_lost_data;			// count the lost data, see function tcp_rx_buffer_read_frame()
	unsigned long			tcp_tx_ok_data;				// count of all transmit data, see function tcp_process_frame()
	unsigned long			tcp_tx_repeat_data;			// count of repeated transmit data, see function tcp_process_frame()
	#endif
} TCP_STRUCTURE;                                    	


//  --------------------------------------------------------------------------------
//	see tcp_prepare_data_frame()
//  -------------------------------------------------------------------------------- 
typedef enum {
	TCP_DATA_FRAME_1ST_SEND,
	TCP_DATA_FRAME_RETRANSMIT
}TCP_DATA_FRAME_MODE;

//  --------------------------------------------------------------------------------
//	see tcp_rx_buffer_read()
//  -------------------------------------------------------------------------------- 
typedef enum {
	TCP_RX_BUFFER_GET_SIZE,
	TCP_RX_BUFFER_READ_DATA,
	TCP_RX_BUFFER_SET_DATA
}TCP_RX_BUFFER_READ_MODE;

//  --------------------------------------------------------------------------------
//	see tcp_tx_buffer_write() and tcp_tx_buffer_write_f()
//  -------------------------------------------------------------------------------- 
typedef enum {
	TCP_TX_BUFFER_GET_SIZE,
	TCP_TX_BUFFER_WRITE_RAM_DATA,     
	TCP_TX_BUFFER_WRITE_FLASH_DATA,     
	TCP_TX_BUFFER_SET_DATA
}TCP_TX_BUFFER_WRITE_MODE;


//  --------------------------------------------------------------------------------
//	see tcp_generate_isn()
//  -------------------------------------------------------------------------------- 
typedef enum {
	TCP_GENERATE_ISN_1ST,
	TCP_GENERATE_ISN_RETRANSMIT     
}TCP_GENERATE_ISN_MODE;

// --------------------------------------------------------------------------------
// external variables and functions
// -------------------------------------------------------------------------------- 
#pragma used+
#if defined(TCP_DEBUG) || defined(TCP_DEBUG_TESTBENCH)
extern char flash *tcp_state_name[11];
extern char flash *tcp_retransmit_name[5];
#endif

#ifdef TCP_DEBUG_TESTBENCH
extern TCP_STRUCTURE tcp_struct[TCP_MAX_CONNECTIONS];                                    	
extern unsigned int tcp_isn_high_number;		// upper word of our Initial Sequence Number
#endif

// --------------------------------------------------------------------------------
// easyToWeb-internal functions
// -------------------------------------------------------------------------------- 
void 	tcp_main(void);					// Handler for TCP-Status
void 	tcp_process_frame(void);		// Handler for incoming frames
void 	tcp_arp_resolved(unsigned char *new_mac);
void	tcp_clock_handler(void);		// function, called every 50 ms

// --------------------------------------------------------------------------------
// easyToWeb-API functions
// -------------------------------------------------------------------------------- 
void		 	tcp_init(void);										// setup timer, buffer, flags...
void			tcp_init_connection(unsigned char tcp_connection);
TCP_STRUCTURE	*tcp_get_struct(unsigned char tcp_connection);
void 			tcp_passive_reopen(unsigned char tcp_connection);	// listen for a connection
unsigned char	tcp_passive_open(unsigned int tcp_local_port);		// listen for a connection
unsigned char 	tcp_active_open(unsigned char *dest_ip_address, unsigned int dest_port, unsigned int source_port);
void 			tcp_close(unsigned char tcp_connection);			// close connection
void 			tcp_abort(unsigned char tcp_connection);
void 			tcp_rx_buffer_clear(unsigned char tcp_connection);	// indicate to discard rec'd packet
unsigned char  *tcp_rx_buffer_read(unsigned char tcp_connection, unsigned char *data_dest, unsigned int *tcp_data_count, 
                                     TCP_RX_BUFFER_READ_MODE read_mode);
unsigned char 	tcp_get_error(unsigned char tcp_connection);
#ifdef TCP_ALIVE_ACTIVE_ENABLE
void			tcp_alive_set_time(unsigned char tcp_connection, unsigned int alive_time);
void 			tcp_alive_enable(unsigned char tcp_connection);
void			tcp_alive_disable(unsigned char tcp_connection);
#endif
unsigned int 	tcp_tx_buffer_write(unsigned char tcp_connection, unsigned char *ram_data, unsigned int datalen, 
                                       TCP_TX_BUFFER_WRITE_MODE write_mode);
unsigned int 	tcp_tx_buffer_write_f(unsigned char tcp_connection, flash unsigned char *flash_data, unsigned int datalen,
                                       TCP_TX_BUFFER_WRITE_MODE write_mode);
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library tcp.c
#endif

/// @}
/// @}

#endif	// #ifndef _TCP_INCLUDED_
