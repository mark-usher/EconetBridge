// ************************************************************************************************
///
/// \file 			ati.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Mirco Fuchs, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _ATI_INCLUDED_
#define _ATI_INCLUDED_

/// \def ATI_ENABLE
/// 	This macro activates the whole AT-Interface module. It must be defined 
///		in project.h.


//-----------------------------------------------------------------------------
// AT-Device Interface
//-----------------------------------------------------------------------------
#define AT_DEVICE_INTERFACE_SEND_DATA(data)	uart1_putchar(data)
#define AT_DEVICE_INTERFACE_IRQ_ENABLE()	uart1_irq_receive_enable()
#define AT_DEVICE_INTERFACE_IRQ_DISABLE()	uart1_irq_receive_disable()

//-----------------------------------------------------------------------------
// receive function for higher layers (ATTENTION IRQ-function)
//-----------------------------------------------------------------------------
#define RECEIVE_FUNCTION(received_data) 	ppp_receive_data(received_data)

//-----------------------------------------------------------------------------
//user definable constants
//-----------------------------------------------------------------------------
#define ATI_TX_BUFFER_SIZE				64
#define ATI_RX_BUFFER_SIZE				127
#define ATI_STRING_LENGTH 				41

#define ATI_TIMEOUT_NEXT_CHAR			5
#define ATI_TIMEOUT_ANSWER				2000 // Timeout after abt. 60 seconds
											 // ATI_TIMEOUT_ANSWER should be longer than all intern timeouts
//-----------------------------------------------------------------------------
//constants
//-----------------------------------------------------------------------------
#define ATI_CR							0x0d
#define	ATI_LF							0x0a

//-----------------------------------------------------------------------------
// ati_get_device_mode() result codes
//-----------------------------------------------------------------------------
#define	ATI_MODE_COMMAND				0
#define	ATI_MODE_ONLINE_ENTERING		1
#define ATI_MODE_ONLINE					2
#define ATI_MODE_ONLINE_COMMAND_ENTER	3
#define ATI_MODE_ONLINE_COMMAND	 		4
#define ATI_MODE_COMMAND_ENTERING		5

//-----------------------------------------------------------------------------
// ati_get_device_mode() parameter codes
//-----------------------------------------------------------------------------
#define ATI_ANSWER_HIDE					0
#define ATI_ANSWER_SHOW					1

//-----------------------------------------------------------------------------
// "ati_write_data()" and "ati_write_data_flash()" result codes
//-----------------------------------------------------------------------------
#define ATI_WRITE_ONLY_AT_COMMANDS		0
#define ATI_WRITE_MEMORY_OVERFLOW		1
#define ATI_WRITE_COMMAND_WROTE			2
#define ATI_WRITE_ACCESS_DENIED			3
#define ATI_WRITE_DATA_SEND				4

//-----------------------------------------------------------------------------
// "ati_connect()" and "ati_disconnect()" result codes
//-----------------------------------------------------------------------------
#define ATI_CONNECT_DISCONNECT_OK		0
#define ATI_CONNECT_DISCONNECT_ERROR	1

//-----------------------------------------------------------------------------
// see "ata_flag" and "ati_answer_incomming_call()" result codes
//-----------------------------------------------------------------------------
#define ATI_ANSWER_DISABLED				0
#define ATI_ANSWER_ENABLED				1

//-----------------------------------------------------------------------------
// ati_state (states of the at-interface)
//-----------------------------------------------------------------------------
typedef enum		// at-interface state diagramm
	{
	ATI_STATE_BUFFER_EMPTY,		// no new data in the tx-buffer			
	ATI_STATE_BUFFER_FILLED,	// new data in the tx-buffer
	ATI_STATE_CHECK_BUFFER,		// check tx-biffer for new data
	ATI_STATE_RSP_AWAITED,		// waiting for modem response
	ATI_STATE_RECEIVE_DATA,		// receive (check) data stored in rx-buffer
	ATI_STATE_UNREACHED			// unreached state
	} ATI_STATE;

//-----------------------------------------------------------------------------
// "ati_device_state" and "ati_device_nextstate" (states of the AT-Device)
//-----------------------------------------------------------------------------
typedef enum
	{   
	ATI_DEVICE_MODE_COMMAND,
	ATI_DEVICE_MODE_CARRIER,
	ATI_DEVICE_MODE_ONLINE,
	ATI_DEVICE_MODE_COMMAND_ONLINE,
	ATI_DEVICE_UNREACHED			// unreached state
    } ATI_DEVICE_MODE;

//-----------------------------------------------------------------------------
// at-device response availability
//-----------------------------------------------------------------------------
typedef enum		//at-interface response state
	{
	ATI_DEVICE_RESPONSE_NO,
	ATI_DEVICE_RESPONSE_YES
	} ATI_DEVICE_RESPONSE;
                             
//-----------------------------------------------------------------------------
// indicates, if a new at-answer is available for the user
//-----------------------------------------------------------------------------
typedef enum
	{
	ATI_USER_INFO_BUFFER_FILLED,
	ATI_USER_INFO_BUFFER_EMPTY,
	ATI_USER_INFO_TIMEOUT
	} ATI_USER_INFO;

#pragma used+
//-----------------------------------------------------------------------------
// necessary functions
//-----------------------------------------------------------------------------
void ati_state_machine(void);
void ati_init(void);
void ati_receive_data(unsigned char received_data);

//-----------------------------------------------------------------------------
// API functions
//-----------------------------------------------------------------------------
unsigned char ati_write_data(unsigned char* ati_data);
unsigned char ati_write_data_flash(flash unsigned char *ati_data);
unsigned char* ati_get_new_answer(void);
unsigned char ati_get_device_mode(unsigned char show_answer);
unsigned char ati_connect(unsigned char *destination);
unsigned char ati_disconnect(void);
void ati_answer_incomming_call(unsigned char behavior);
#pragma used-


#ifdef NETWORK_LIBRARY_ENABLE
#pragma library ati.c
#endif

#endif 	// #ifndef _ATI_INCLUDED_
