// ************************************************************************************************
///
/// \file 			ftp_server.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _FTP_SERVER_INCLUDED_
#define _FTP_SERVER_INCLUDED_

#include "project.h"		// Project configuration


// --------------------------------------------------------------------------------
// FTP replys
// -------------------------------------------------------------------------------- 
#ifndef FTP_CRLF
#define	FTP_CRLF			"\r\n"
#endif	// #ifndef FTP_CRLF

// --------------------------------------------------------------------------------
// Positive Preliminary reply - 1yz
// -------------------------------------------------------------------------------- 
#define	FTP_REPLY_125		"125 Data connection already open"FTP_CRLF
#define	FTP_REPLY_150		"150 File status ok"FTP_CRLF
// --------------------------------------------------------------------------------
// Positive Completion reoly - 2yz
// -------------------------------------------------------------------------------- 
#define	FTP_REPLY_200		"200 Command okay"FTP_CRLF
#define	FTP_REPLY_202		"202 Command not implemented, superfluous at this site"FTP_CRLF
#define	FTP_REPLY_214		"214 easyToWeb-"DEBUG_PROJECT_NAME" "DEBUG_PROJECT_VERSION" "FTP_CRLF
#define	FTP_REPLY_215		"215 easyToWeb-Software FTZ Leipzig"FTP_CRLF
#define	FTP_REPLY_220		"220 Service ready for new user"FTP_CRLF
#define	FTP_REPLY_221		"221 Service closing control connection"FTP_CRLF
#define	FTP_REPLY_226		"226 Closing data connection"FTP_CRLF
#define	FTP_REPLY_227		"227 Entering Passive Mode %u,%u,%u,%u,%u,%u"FTP_CRLF
#define	FTP_REPLY_230		"230 User looged in, proceed"FTP_CRLF
#define	FTP_REPLY_250		"250 Requested file action okay"FTP_CRLF
#define	FTP_REPLY_257		"257 \x22%s\x22 created"FTP_CRLF     	// \x22 coded the " sign
// --------------------------------------------------------------------------------
// Positive Intermediate reply - 3yz
// -------------------------------------------------------------------------------- 
#define	FTP_REPLY_331		"331 User name ok, need password"FTP_CRLF
#define	FTP_REPLY_332		"332 Need account for login"FTP_CRLF
// --------------------------------------------------------------------------------
// Transient Negative Completion reply - 4yz
// -------------------------------------------------------------------------------- 
#define	FTP_REPLY_421		"421 Service not available, closing control connections"FTP_CRLF
#define	FTP_REPLY_425		"425 Can not open data connection"FTP_CRLF
#define	FTP_REPLY_426		"426 Connection closed, transfer aborted"FTP_CRLF
#define	FTP_REPLY_450		"450 Requested file action not taken"FTP_CRLF
#define	FTP_REPLY_451		"451 Requested action aborted"FTP_CRLF
// --------------------------------------------------------------------------------
// Permanent Negative Completion reply - 5yz
// -------------------------------------------------------------------------------- 
#define	FTP_REPLY_500		"500 Syntax error, command unrecognized"FTP_CRLF
#define	FTP_REPLY_501		"501 Syntax error in parameters or argumants"FTP_CRLF
#define	FTP_REPLY_502		"502 Command not implemented"FTP_CRLF
#define	FTP_REPLY_503		"503 Bad sequence of commands"FTP_CRLF
#define	FTP_REPLY_504		"504 Command not implemented for that parameter"FTP_CRLF
#define	FTP_REPLY_530		"530 Not logged in"FTP_CRLF
#define	FTP_REPLY_532		"532 Need account for storing files"FTP_CRLF
#define	FTP_REPLY_550		"550 Requested action not taken, File unavailable"FTP_CRLF
#define	FTP_REPLY_552		"552 Requested file action aborted, Exceeded storage allocation"FTP_CRLF

// --------------------------------------------------------------------------------
// FTP RFC-959 Experimental Commands, see function "ftp_server_get_command()"
// -------------------------------------------------------------------------------- 
#define	FTP_COMMAND_XMKD	"XMKD"		// Make Directory
#define	FTP_COMMAND_XRMD	"XRMD"		// Remove Directory
#define	FTP_COMMAND_XPWD	"XPWD"		// print working directory
#define	FTP_COMMAND_XCUP	"XCUP"		// change to parent directory
#define	FTP_COMMAND_XCWD	"XCWD"		// change working directory

// --------------------------------------------------------------------------------
// FTP standard command set
// -------------------------------------------------------------------------------- 
#define	FTP_COMMAND_USER	"USER"		// identifying the user
#define	FTP_COMMAND_PASS	"PASS"		// user password
#define	FTP_COMMAND_ACCT	"ACCT"		// Account
#define	FTP_COMMAND_CWD		"CWD"		// change working directory
#define	FTP_COMMAND_CDUP	"CDUP"		// change to parent directory
#define	FTP_COMMAND_SMNT	"SMNT"		// structure mount
#define	FTP_COMMAND_QUIT	"QUIT"		// terminate user
#define	FTP_COMMAND_REIN	"REIN"		// Reinitialize
#define	FTP_COMMAND_PORT	"PORT"		// data port
#define	FTP_COMMAND_PASV	"PASV"		// request the Server-data-port to listen
#define	FTP_COMMAND_TYPE	"TYPE"		// representation type (A)SCII, (E)BCDIC, (I)mage, (L)
#define	FTP_COMMAND_STRU	"STRU"		// structure (F)ile, (R)ecord, (P)age
#define	FTP_COMMAND_MODE	"MODE"		// transfer mode (S)tream, (B)lock, (C)ompressed
#define	FTP_COMMAND_RETR	"RETR"		// retrieve - data from server to client
#define	FTP_COMMAND_STOR	"STOR"		// store - data from client to server
#define	FTP_COMMAND_STOU	"STOU"		// store - unique (create name and send back with 250)
#define	FTP_COMMAND_APPE	"APPE"		// Append with creates
#define	FTP_COMMAND_ALLO	"ALLO"		// Allocate
#define	FTP_COMMAND_REST	"REST"		// Restart
#define	FTP_COMMAND_RNFR	"RNFR"		// Rename from
#define	FTP_COMMAND_RNTO	"RNTO"		// Rename to
#define	FTP_COMMAND_ABOR	"ABOR"		// Abort (abort all service commands and data transfers)
#define	FTP_COMMAND_DELE	"DELE"		// Delete (delete file on server)
#define	FTP_COMMAND_RMD		"RMD"		// Remove Directory
#define	FTP_COMMAND_MKD		"MKD"		// Make Directory
#define	FTP_COMMAND_PWD		"PWD"		// print working directory
#define	FTP_COMMAND_LIST	"LIST"		// sent a list of files from server to client
#define	FTP_COMMAND_NLST	"NLST"		// sent a list of files from server to client (without any other info's)
#define	FTP_COMMAND_SITE	"SITE"		// Site Parameters (add data)
#define	FTP_COMMAND_SYST	"SYST"		// find out the operating system
#define	FTP_COMMAND_STAT	"STAT"		// Status
#define	FTP_COMMAND_HELP	"HELP"		// send helpful information
#define	FTP_COMMAND_NOOP	"NOOP"		// no operation

#define	FTP_MAX_COMMAND_SIZE	5		// ABORT-Command
#define FTP_MAX_PARAMETER_SIZE	20

// --------------------------------------------------------------------------------
// FTP minimal command set
// -------------------------------------------------------------------------------- 

// --------------------------------------------------------------------------------
// FTP general macros
// -------------------------------------------------------------------------------- 
//#define	FTP_ACCOUNT_ENABLE

#ifndef	FTP_USER_ID
#define	FTP_USER_ID			"etw"
#endif	// #ifndef	FTP_USER_ID

#ifndef	FTP_PASSWORD
#define	FTP_PASSWORD		"etw"
#endif	// #ifndef	FTP_PASSWORD

#ifndef	FTP_ACCOUNT
#define	FTP_ACCOUNT			"test"
#endif	// #ifndef	FTP_ACCOUNT


// --------------------------------------------------------------------------------
// FTP flag macros, see variable "ftp_server_flag"
// DEFAULT:
//	ftp_server_flag=FTP_FLAG_TYPE_A | FTP_FLAG_TYPE_N | FTP_FLAG_MODE_S | FTP_FLAG_STRU_F;
// -------------------------------------------------------------------------------- 
#define	FTP_FLAG_TYPE_MASK		0x00fe		// mask to control the TYPE
#define	FTP_FLAG_PASSIVE			0x0001		// activate with PASV-Command
#define	FTP_FLAG_TYPE_A			0x0002		// ASCII, see TYPE-Command - default
#define	FTP_FLAG_TYPE_E			0x0004		// EBCDIC, see TYPE-Command
#define	FTP_FLAG_TYPE_I			0x0008		// Image, see TYPE-Command
#define	FTP_FLAG_TYPE_L			0x0010		// Local Byte size, see TYPE-Command
#define	FTP_FLAG_TYPE_N			0x0020		// Non Print, see TYPE-Command - default
#define	FTP_FLAG_TYPE_T			0x0040		// Telnet format effectors, see TYPE-Command
#define	FTP_FLAG_TYPE_C			0x0080		// Carriage Cobtrol (ASA), see TYPE-Command
#define	FTP_FLAG_MODE_S			0x0100		// Stream - default
#define	FTP_FLAG_MODE_B			0x0200		// Block
#define	FTP_FLAG_MODE_C			0x0400		// Compressed
#define	FTP_FLAG_STRU_F			0x0800		// File (nor record structure) - default
#define	FTP_FLAG_STRU_R			0x1000		// Record
#define	FTP_FLAG_STRU_P			0x2000		// Page

// --------------------------------------------------------------------------------
// typedefs
// -------------------------------------------------------------------------------- 
typedef enum {
	FTP_STATE_CLOSED,
	FTP_STATE_USER_ID,
	FTP_STATE_PASSWORD,
	FTP_STATE_COMMAND,
	FTP_STATE_ACCOUNT,
	FTP_STATE_LIST,
	FTP_STATE_RETR,
	FTP_STATE_STOR 
} FTP_STATE_MACHINE;

//  --------------------------------------------------------------------------------
//	see ftp_server_get_command()
//  -------------------------------------------------------------------------------- 
typedef enum {
	FTP_SERVER_GET_NOTHING,
	FTP_SERVER_GET_NORMAL,     
	FTP_SERVER_GET_BREAK     
}FTP_SERVER_GET_MODE;

// --------------------------------------------------------------------------------
// external variables and functions
// -------------------------------------------------------------------------------- 
#pragma used+
extern unsigned char	ftp_server_tcp_command;

void ftp_server_init(void);
void ftp_server_main(void);
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library ftp_server.c
#endif

#endif	// #ifndef _FTP_SERVER_INCLUDED_