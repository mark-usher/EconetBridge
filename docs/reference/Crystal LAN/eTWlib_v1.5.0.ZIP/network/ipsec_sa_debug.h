// ************************************************************************************************
///
/// \file 			ipsec_sa_debug.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		This document is part of embedded IPsec
///					Niklaus Schild and Christian Scheurer, HTI Biel/Bienne
///					This file contains code from the OpenSSL Project<BR>
///					Niklaus Schild <n.schild@gmx.ch> <BR>
///					portions Copyright (c) 1998-2003 OpenSSL (www.openssl.org)
///					easyToWeb-AVR and CodeVisionAVR C-Compiler:
///					Udo Jakobza - FTZ Leipzig; 04107 Leipzig; W�chterstr. 13
///					jakobza@e-technik.htwk-leipzig.de
///
/// \par License    
///					Redistribution and use in source and binary forms, with or without 
///					modification, are permitted provided that the following conditions are met:
///
///					1. Redistributions of source code must retain the above copyright notice,
///					   this list of conditions and the following disclaimer.
///					2. Redistributions in binary form must reproduce the above copyright notice,
///					    this list of conditions and the following disclaimer in the documentation
///					   and/or other materials provided with the distribution.
///					3. The name of the author may not be used to endorse or promote products
///					   derived from this software without specific prior written permission.
///
///					THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
///					WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
///					MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
///					EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
///					EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
///					OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
///					INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
///					CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
///					IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
///					OF SUCH DAMAGE.
///
// ************************************************************************************************

#ifndef _IPSEC_SA_DEBUG_INCLUDED_
#define _IPSEC_SA_DEBUG_INCLUDED_

#include "project.h"		// Project configuration
#include "ipsec_sa.h"


#ifdef WEB_DEBUG_IPSEC			// enable IPSec debug functions, see ipsec.c
#define WEB_DEBUG_IPSEC_SA_MSG(__message__) { \
				if (ipsec_debug_flag) { \
					printf __message__ ;  } }
#define WEB_DEBUG_IPSEC_SA_MSG_SPD(__message__, __spd_entry__) { \
				if (ipsec_debug_flag) { \
					printf __message__ ; \
					ipsec_sa_debug_spd_print_s(__spd_entry__);  } }
#define WEB_DEBUG_IPSEC_SA_MSG_SAD(__message__, __sad_entry__) { \
				if (ipsec_debug_flag) { \
					printf __message__ ; \
					ipsec_sa_debug_sad_print_s(__sad_entry__);  } }
#define WEB_DEBUG_IPSEC_SA_TEST(__message__) { \
					printf __message__ ;  }
#define WEB_DEBUG_IPSEC_MSG(__message__) { \
				if (ipsec_debug_flag) { \
					printf __message__ ; } }
#else
#define WEB_DEBUG_IPSEC_SA_MSG(__message__)
#define WEB_DEBUG_IPSEC_SA_MSG_SPD(__message__, __spd_entry__)
#define WEB_DEBUG_IPSEC_SA_MSG_SAD(__message__, __sad_entry__)
#define WEB_DEBUG_IPSEC_SA_TEST(__message__)
#define WEB_DEBUG_IPSEC_MSG(__message__)
#endif


#pragma used+
extern eeprom unsigned char ipsec_debug_flag;

void ipsec_sa_debug_init(void);
void ipsec_sa_debug_spd_print_s(SA_MEMORY spd_entry_mem *entry);
void ipsec_sa_debug_spd_print(flash unsigned char *info, SA_MEMORY spd_table_mem *table, unsigned char mode);
void ipsec_sa_debug_sad_print_s(SA_MEMORY sad_entry_mem *entry);
void ipsec_sa_debug_sad_print(flash unsigned char *info, SA_MEMORY sad_table_mem *table, unsigned char mode);
unsigned char ipsec_sa_debug_new_spd(unsigned char new_spd);
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library ipsec_sa_debug.c
#endif

#endif	// #ifndef _IPSEC_SA_DEBUG_INCLUDED_

