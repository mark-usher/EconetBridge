// ************************************************************************************************
///
/// \file 			http_server.h
///
/// \date	 		$LastChangedDate: 2007-03-13 15:07:51 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 630 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************
#ifndef _HTTP_SERVER_INCLUDED_
#define _HTTP_SERVER_INCLUDED_

// --------------------------------------------------------------------------------
// HTTP replys
// -------------------------------------------------------------------------------- 
#define	HTTP_CRLF				"\r\n"

// --------------------------------------------------------------------------------
// HTTP-Request - Informational - 1xx
// -------------------------------------------------------------------------------- 
#define	HTTP_STATUS_100			"100 Continue"

// --------------------------------------------------------------------------------
// HTTP-Request - Sucessful - 2xx
// -------------------------------------------------------------------------------- 
#define	HTTP_STATUS_200			"200 OK"
#define	HTTP_STATUS_201			"201 Created"
#define	HTTP_STATUS_202			"202 Accepted"

// --------------------------------------------------------------------------------
// HTTP-Request - Client Error - 4xx
// -------------------------------------------------------------------------------- 
#define	HTTP_STATUS_404			"404 Not Found"


// --------------------------------------------------------------------------------
// HTTP-general macros
// -------------------------------------------------------------------------------- 
//#define HTTP_MAX_CONNECTIONS		0
//#define WEBPAGE_DEFAULT_ENABLE
#ifndef HTTP_DEFAULT_FILE
#define HTTP_DEFAULT_FILE		"start.html"
#endif	// #ifndef HTTP_DEFAULT_FILE

//  --------------------------------------------------------------------------------
//	see http_server_file()
//  -------------------------------------------------------------------------------- 
typedef enum {
	HTTP_SERVER_FILE_START,
	HTTP_SERVER_FILE_DATA,
	HTTP_SERVER_FILE_CLOSE
}HTTP_SERVER_FILE_STATUS;

//  --------------------------------------------------------------------------------
//	see http_server_default()
//  -------------------------------------------------------------------------------- 
typedef enum {
	HTTP_SERVER_DEFAULT_START,
	HTTP_SERVER_DEFAULT_DATA
}HTTP_SERVER_DEFAULT_STATUS;

//  --------------------------------------------------------------------------------
//	see http_server()
//  -------------------------------------------------------------------------------- 
typedef enum {
	HTTP_SERVER_START,
	HTTP_SERVER_FILE_DATA,
	HTTP_SERVER_FILE_CLOSE,
	HTTP_SERVER_DATA,
	HTTP_SERVER_CLOSE_CONNECTION,
	HTTP_SERVER_CLOSE,
	HTTP_SERVER_HTTP_GET,
	HTTP_SERVER_HTTP_PUT
}HTTP_SERVER_STATUS;

//  --------------------------------------------------------------------------------
//	external variables and functions
//  -------------------------------------------------------------------------------- 
#pragma used+
extern	unsigned char http_server_tcp;
extern	void 	http_server(void);
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library http_server.c
#endif


#endif	// #ifndef _HTTP_SERVER_INCLUDED_

