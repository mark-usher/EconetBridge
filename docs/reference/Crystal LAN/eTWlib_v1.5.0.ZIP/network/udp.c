// ************************************************************************************************
///
/// \file 			udp.c
/// \brief			UDP receive and transmit functions
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef UDP_ENABLE

#include <stdio.h>
#include "board.h"
#include "device.h"
#include "buffer.h"
#include "ethernet.h"
#include "udp.h"
#ifdef WEB_DEBUG
#include "web_debug.h"
#endif

#pragma regalloc-
UDP_STRUCTURE	udp_struct[UDP_MAX_CONNECTIONS];                                    	
#ifdef WEB_DEBUG_UDP
unsigned int	udp_frame_count=0;
#endif
#pragma regalloc+

void udp_prepare_data_frame(unsigned char udp_connection);

//*********************************************************************************
// Description	: initializes the UDP-Stack
// Input   		: none
// Output  		: none
// Indication	: easyToWeb-API function
//*********************************************************************************
void udp_init(void)
{
unsigned char Lva;

memset(udp_struct, 0x0, sizeof(udp_struct));
for(Lva=0;Lva<UDP_MAX_CONNECTIONS; Lva++)
	{
	memset(udp_struct[Lva].udp_ip_remote, 0xff, IP_ADR_SIZE);
	}
}


//*********************************************************************************
// Description	: checks the connection-Number and calculate the address to UDP-Structure
// Input   		: udp_connection - index of connection
// Output  		: pointer to udp-structure
// Indication	: easyToWeb-API function
//*********************************************************************************
UDP_STRUCTURE *udp_get_struct(unsigned char udp_connection)
{
if((udp_connection!=UDP_WRONG_CONNECTIONS)&&(udp_connection<UDP_MAX_CONNECTIONS))
	return &udp_struct[udp_connection];
return 0x0;
}

//*********************************************************************************
// Description	: passive open of UDP-port
// Input   		: udp_local_port - local udp-port
//         		: dest_mac_address - pointer to destination mac-address
//         		: dest_ip_address -  pointer to destination ip-address
//         		: dest_port - destination port-number
//         		: udp_flag - udp-flags
// Output  		: actual "udp_connection", see UDP_MAX_CONNECTIONS
// Indication	: easyToWeb-API function
//*********************************************************************************
unsigned char udp_open(unsigned int udp_local_port, unsigned char *dest_mac_address, unsigned char *dest_ip_address, 
							unsigned int dest_port, unsigned char udp_flag)
{
unsigned char	Lva;
UDP_STRUCTURE	*p_struct;                                    	

p_struct=&udp_struct[0];                                    	
for(Lva=0;Lva<UDP_MAX_CONNECTIONS; Lva++)
	{
	if(!(p_struct->udp_flags & UDP_FLAG_OPEN))
		{
		p_struct->udp_flags=udp_flag | UDP_FLAG_OPEN | UDP_TX_BUF_FREE;
		p_struct->udp_port_local = udp_local_port;			// set port we want to listen to
		memset(p_struct->udp_mac_remote, 0xff, 6);				// st mac to default
		memset(p_struct->udp_ip_remote, 0xff, IP_ADR_SIZE);     // set ip to default
		if(udp_flag & UDP_FLAG_ACTIVE)
			{
			p_struct->udp_port_remote = dest_port;				// destination port of data
			#ifdef WEB_DEBUG_UDP
			if(web_debug_flag & WEB_DEBUG_UDP_BIT)
				printf("UDP(%u,x) Active Open: %u\r\n", Lva, udp_local_port);
			#endif
			udp_bind(Lva, dest_mac_address, dest_ip_address);
			}
		else if(udp_flag & UDP_FLAG_PASSIVE)
			{
			#ifdef WEB_DEBUG_UDP
			if(web_debug_flag & WEB_DEBUG_UDP_BIT)
				printf("UDP(%u,x) Passive Open: %u\r\n", Lva, udp_local_port);
			#endif
			}
		return Lva;
		}
	p_struct++;                                    	
	}
return UDP_WRONG_CONNECTIONS;
}


//*********************************************************************************
// Description	: closes an open connection
// Input   		: udp_connection - index of connection
// Output  		: none
// Indication	: easyToWeb-API function
//*********************************************************************************
void udp_close(unsigned char udp_connection)
{
if(udp_get_struct(udp_connection))
	udp_struct[udp_connection].udp_flags &= UDP_DATA_AVAILABLE;
}

//*********************************************************************************
// Description	: releases the receive-buffer and allows easyToWeb to store new data
// Input   		: udp_connection - index of connection
// Output  		: none
// Indication	: easyToWeb-API function
//*********************************************************************************
void udp_rx_buffer_release(unsigned char udp_connection)
{
if(udp_get_struct(udp_connection))
	udp_struct[udp_connection].udp_flags &= ~UDP_DATA_AVAILABLE;
}

//*********************************************************************************
// Description	: check the data-length and and store in 'TCP_TX_BUF'
// Input   		: udp_connection - index of connection
//         		: data  		- pointer to data
// 		   		: datalen 		- length of data
// Output  		: 0 				 - no connection or no buffer
// 		  		: 1..TCP_MAX_TX_DATA - size of data to buffer
// Indication	: data-count MUST NOT exceed "TCP_MAX_TX_DATA"
//				: easyToWeb-API function
//*********************************************************************************
unsigned int udp_tx_buffer_prepare(unsigned char udp_connection, unsigned char *data, unsigned int datalen)
{
UDP_STRUCTURE	*p_struct;                                    	

if(udp_get_struct(udp_connection))
	{
	p_struct=&udp_struct[udp_connection];                                    	
	if(p_struct->udp_flags & UDP_FLAG_OPEN)
   		{
		if((p_struct->udp_flags & UDP_TX_BUF_FREE)||
		   (p_struct->udp_flags & UDP_TX_BUF_HALF_FULL))
			{
			if(p_struct->udp_flags & UDP_TX_BUF_FREE)
				{
				p_struct->udp_tx_data_position=&p_struct->udp_tx_frame[UDP_DATA_OFS]; 	// pointer to tcp-data
				p_struct->udp_tx_data_count=0;		// the tx-buffer is relly empthy
				}
			if(datalen==0)
				{
				datalen=UDP_TX_DATA_SIZE-p_struct->udp_tx_data_count;
				return datalen;
				}
			if(datalen>(UDP_TX_DATA_SIZE-p_struct->udp_tx_data_count))
				datalen=UDP_TX_DATA_SIZE-p_struct->udp_tx_data_count;
			if(data!=0x0)
				{
				memcpy(p_struct->udp_tx_data_position, data, datalen);
				p_struct->udp_tx_data_position+=datalen;
				}
			p_struct->udp_tx_data_count+= datalen;		 	// bytes to xfer
			if(p_struct->udp_tx_data_count & 0x01)
				p_struct->udp_tx_frame[UDP_DATA_OFS + p_struct->udp_tx_data_count]=0;		// delete odd Data-Byte
			p_struct->udp_flags &= ~UDP_TX_BUF_FREE;		// 
			p_struct->udp_flags |= UDP_TX_BUF_FULL;	 		// occupy tx-buffer
			if(p_struct->udp_tx_data_count<UDP_TX_DATA_SIZE)
				p_struct->udp_flags |= UDP_TX_BUF_HALF_FULL;	// 
			return datalen;
			}
		}
	}
return 0;
}


//*********************************************************************************
// Description	: must be called from user program periodically (the often - the better)
//              :  handles network, UDP/IP-stack and user events
// Input   		: none
// Output  		: none
// Indication	: UDP 'main()'-function
//*********************************************************************************
void udp_main(void)
{
static unsigned char	udp_connection=0;	// start with first tcp-connection
unsigned char			udp_connection_count=0;
UDP_STRUCTURE			*p_struct;                                    	

udp_connection_count=0;
while(udp_connection_count<UDP_MAX_CONNECTIONS)
	{
	udp_connection++;
	if(udp_connection>=UDP_MAX_CONNECTIONS)
		udp_connection=0;
	p_struct=&udp_struct[udp_connection];                                    	
	if(p_struct->udp_flags & UDP_FLAG_OPEN)
		break;
	udp_connection_count++;
	}
if(udp_connection_count>=UDP_MAX_CONNECTIONS)	
	return;		// no open UDP-Connections
if(p_struct->udp_flags & UDP_FLAG_OPEN)
	{
	if((p_struct->udp_flags & UDP_TX_BUF_FULL)&&		// if Transmit-Data and
	   (!(p_struct->udp_flags & UDP_DATA_AVAILABLE)))	// not(Receive-Data)
		udp_prepare_data_frame(udp_connection);
	}
}


//*********************************************************************************
// Description	: bind a connection to IP-Address and MAC-Address
// Input   		: udp_connection - index of connection
//         		: dest_mac_address - pointer to destination mac-address
//         		: dest_ip_address -  pointer to destination ip-address
// Output  		: 0 - 
//         		: 1 - 
// Indication	: easyToWeb internal function
//*********************************************************************************
unsigned char udp_bind(unsigned char udp_connection, unsigned char *dest_mac_address, unsigned char *dest_ip_address)
{
UDP_STRUCTURE	*p_struct;                                    	

if(udp_get_struct(udp_connection))
	{
	p_struct=&udp_struct[udp_connection];                                    	
	if(!(p_struct->udp_flags & UDP_FLAG_BIND))
		{
		if(dest_ip_address)
			memcpy(p_struct->udp_ip_remote, dest_ip_address, IP_ADR_SIZE);	// save ip address
		#ifndef DEVICE_PPP
		if(dest_mac_address)
			memcpy(p_struct->udp_mac_remote, dest_mac_address, 6);			// save mac address
		#endif
		#ifdef WEB_DEBUG_UDP
		if(web_debug_flag & WEB_DEBUG_UDP_BIT)
			{
			printf("UDP(%u,%u) Bind: %u<=>%u:", udp_connection, udp_frame_count, p_struct->udp_port_local, p_struct->udp_port_remote);
			debug_print_ip(0x0, p_struct->udp_ip_remote);
			}
		#endif
		p_struct->udp_flags|=UDP_FLAG_BIND;
		return 1;
		}
	}
return 0;
}

//*********************************************************************************
// Description	: unbind a connection
// Input   		: udp_connection - index of connection
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void udp_unbind(unsigned char udp_connection)
{
if(udp_get_struct(udp_connection))
	udp_struct[udp_connection].udp_flags &= ~UDP_FLAG_BIND;
}


//*********************************************************************************
// Description	: we've just rec'd an UDP-frame (User datagram Protocol)
// Input   		: none
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void udp_process_frame(void)
{
unsigned int	udp_source_port;		// udp source port
unsigned int	udp_dest_port;			// udp destination port
unsigned int	udp_data_count;	 		// real number of data
unsigned char	udp_connection;	 		// pointer to TCP-databuffer
UDP_STRUCTURE	*p_struct;                                    	
    
#ifdef WEB_DEBUG_UDP
udp_frame_count++;
#endif
// UDP header
udp_source_port = DEVICE_READ_IP_FRAME_16BIT();		// get ports
udp_dest_port = DEVICE_READ_IP_FRAME_16BIT();
p_struct=&udp_struct[0];                                    	
for(udp_connection=0; udp_connection<UDP_MAX_CONNECTIONS; udp_connection++)
	{
	if(p_struct->udp_flags & UDP_FLAG_OPEN)
		{
		if(p_struct->udp_flags & UDP_FLAG_ACTIVE)
			{
			if((udp_dest_port==p_struct->udp_port_local)&&
			   (udp_source_port==p_struct->udp_port_remote)&&
			   (!memcmp(ip_of_last_frame, p_struct->udp_ip_remote, IP_ADR_SIZE)))
				break;	// is it for us?
			}
		else if(p_struct->udp_flags & UDP_FLAG_PASSIVE)
			{
			if(udp_dest_port==p_struct->udp_port_local)
				{
				if(p_struct->udp_flags & UDP_FLAG_BIND)
					{
					p_struct->udp_port_remote=udp_source_port;				// save port number
				   //(udp_source_port==p_struct->udp_port_remote)&&
					if(!memcmp(ip_of_last_frame, p_struct->udp_ip_remote, IP_ADR_SIZE))
						break;			// is it for us?
					}
				else
					{
					if(p_struct->udp_port_remote!=udp_source_port) 			// check source port number
						{
						// found a new connection and save all remote informations
						memcpy(p_struct->udp_ip_remote, ip_of_last_frame, IP_ADR_SIZE);	// save ip address
						p_struct->udp_port_remote=udp_source_port;						// save port number
						#ifndef DEVICE_PPP
						memcpy(p_struct->udp_mac_remote, mac_of_last_frame, 6);		// save mac address
						#endif
						#ifdef WEB_DEBUG_UDP
						if(web_debug_flag & WEB_DEBUG_UDP_BIT)
							{
							printf("UDP(%u,%u) Open: %u=>%u ", udp_connection, udp_frame_count, udp_source_port, udp_dest_port);
							debug_print_ip("", ip_of_last_frame);
							}
						#endif	// #ifdef WEB_DEBUG_UDP
						}
					break;
					}
				}
			}
		}
	p_struct++;                                    	
	}
if(udp_connection>=UDP_MAX_CONNECTIONS)
	{
	#ifdef WEB_DEBUG_UDP
	if(web_debug_flag & WEB_DEBUG_UDP_BIT)
		{
		p_struct=&udp_struct[0];                                    	
		printf("UDP(x,%u) Dest-Port: %u!=(", udp_frame_count, udp_dest_port); 
		for(udp_connection=0; udp_connection<UDP_MAX_CONNECTIONS; udp_connection++)
			{
			printf("%u ", p_struct->udp_port_local);
			p_struct++;
			}
		putsf(")\r");
		printf("UDP(x,%u) IP: %u.%u.%u.%u != (", udp_frame_count, ip_of_last_frame[0], ip_of_last_frame[1], 
														ip_of_last_frame[2], ip_of_last_frame[3]); 
		p_struct=&udp_struct[0];                                    	
		for(udp_connection=0; udp_connection<UDP_MAX_CONNECTIONS; udp_connection++)
			{
			printf("%u.%u.%u.%u ", p_struct->udp_ip_remote[0], p_struct->udp_ip_remote[1], p_struct->udp_ip_remote[2], 
										p_struct->udp_ip_remote[3]); 
			p_struct++;
			}
		putsf(")\r");
		p_struct=&udp_struct[0];                                    	
		printf("UDP(x,%u) Source-Port: %u!=(", udp_frame_count, udp_source_port); 
		for(udp_connection=0; udp_connection<UDP_MAX_CONNECTIONS; udp_connection++)
			{
			printf("%u ", p_struct->udp_port_remote);
			p_struct++;
			}
		putsf(")\r");
		}
	#endif
	return;
	}
udp_data_count = DEVICE_READ_IP_FRAME_16BIT();  		// Length
udp_data_count-=UDP_HEADER_SIZE;						// calculate udp-data length
if(udp_data_count > UDP_RX_DATA_SIZE)
		{
		#ifdef WEB_DEBUG_UDP
		if(web_debug_flag & WEB_DEBUG_UDP_BIT)
			printf("UDP(%u,%u) Frame too long: %u\r\n", udp_connection, udp_frame_count, udp_data_count); 
		#endif
		udp_data_count=UDP_RX_DATA_SIZE;
		//return;									// packet too large for us :...-(
		}
DEVICE_READ_IP_FRAME_16BIT();			   		// ignore checksum
if(!(p_struct->udp_flags & UDP_DATA_AVAILABLE))
	{
	DEVICE_READ_IP_FRAME_DATA(p_struct->udp_rx_frame, udp_data_count);		// get data
	p_struct->udp_rx_data_count=udp_data_count;
	p_struct->udp_flags|=UDP_DATA_AVAILABLE;
	}
else
	DEVICE_READ_IP_FRAME_DUMMY(udp_data_count);		// read dummy data
#ifdef WEB_DEBUG_UDP
if(web_debug_flag & WEB_DEBUG_UDP_BIT)
	printf("UDP(%u,%u) Read: %u=>%u (%u Byte)\r\n", udp_connection, udp_frame_count, udp_source_port, udp_dest_port, udp_data_count);
#endif
}


//*********************************************************************************
// Description	: prepares the tx_frame1-buffer to send a payload-packet
// Input   		: udp_connection - index of connection
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void udp_prepare_data_frame(unsigned char udp_connection)
{
UDP_STRUCTURE	*p_struct;                                    	
unsigned char	ip_offset;

p_struct=&udp_struct[udp_connection];                                    	
// UDP header
HOST_NETWORK_ENDIAN_16BIT(&p_struct->udp_tx_frame[UDP_SRCPORT_OFS], &p_struct->udp_port_local);		// Source Port
HOST_NETWORK_ENDIAN_16BIT(&p_struct->udp_tx_frame[UDP_DESTPORT_OFS], &p_struct->udp_port_remote);	// Destination Port
p_struct->udp_tx_all_count = UDP_HEADER_SIZE + p_struct->udp_tx_data_count;
HOST_NETWORK_ENDIAN_16BIT(&p_struct->udp_tx_frame[UDP_LEN_OFS], &p_struct->udp_tx_all_count);		// Length
*(unsigned int *)&p_struct->udp_tx_frame[UDP_CHKSUM_OFS] = 0;			 			  				// Checksum
// IP   
p_struct->udp_tx_all_count+= IP_HEADER_SIZE;
if(ip_header_write(p_struct->udp_tx_frame, &p_struct->udp_tx_all_count, &ip_offset, IP_UDP_PROT, ip_address, p_struct->udp_ip_remote)==0)
	{
	#if defined(WEB_DEBUG_UDP)&&defined(IPSEC_ENABLE)
	if(web_debug_flag & WEB_DEBUG_UDP_BIT)
		{
		printf("UDP(%u,%u) IP-Error\r\n", udp_connection, udp_frame_count);
		web_debug_display_frame(p_struct->udp_tx_frame, p_struct->udp_tx_all_count+IPSEC_OFFSET+ETH_HEADER_SIZE, 0);
		}
	#endif
	return;
	}
// Ethernet
#ifdef ETHERNET_ENABLE
memcpy(&p_struct->udp_tx_frame[(unsigned char)(ETH_DA_OFS+ip_offset)], p_struct->udp_mac_remote, 6);
memcpy(&p_struct->udp_tx_frame[(unsigned char)(ETH_SA_OFS+ip_offset)], mac_address, 6);
*(unsigned int *)&p_struct->udp_tx_frame[(unsigned char)(ETH_TYPE_OFS+ip_offset)] = SWAPB(IP_FRAME);
#else
memset(&p_struct->udp_tx_frame[(unsigned char)(ETH_DA_OFS+ip_offset)], 0x0, ETH_HEADER_SIZE);
#endif	//#ifdef ETHERNET_ENABLE
p_struct->udp_tx_all_count+= ETH_HEADER_SIZE;
// General
if(buffer_write_command(p_struct->udp_tx_frame+ip_offset, p_struct->udp_tx_all_count))
	{
	p_struct->udp_flags &= ~(UDP_TX_BUF_FULL | UDP_TX_BUF_HALF_FULL);	// occupy tx-buffer
	p_struct->udp_flags |= UDP_TX_BUF_FREE;								// to user
	#ifdef WEB_DEBUG_UDP
	if(web_debug_flag & WEB_DEBUG_UDP_BIT)
		{
		printf("UDP(%u,%u) Write: %u=>%u (%u Byte)\r\n", udp_connection, udp_frame_count, p_struct->udp_port_local, 
							p_struct->udp_port_remote, p_struct->udp_tx_data_count);
//		web_debug_display_frame(p_struct->udp_tx_frame, p_struct->udp_tx_all_count, 0);
		}
	#endif
	}
else
	{
	#ifdef WEB_DEBUG_UDP
	if(web_debug_flag & WEB_DEBUG_UDP_BIT)
		{
		printf("UDP(%u,%u) ERROR Write Data:%u byte\r\n", udp_connection, udp_frame_count, p_struct->udp_tx_data_count);
		}
	#endif
	}
}


#ifdef WEB_DEBUG_UDP
//********************************************************************************
// Description	: displays the udp_flags
// Input   		: p_struct - pointer to udp-structure
// Output  		: none
// Indication	: none
//*********************************************************************************
void udp_display_flags(UDP_STRUCTURE *p_struct)
{
if(p_struct->udp_flags & UDP_FLAG_OPEN)
	printf(" OPEN");
else
	printf(" CLOSE");
if(p_struct->udp_flags & UDP_FLAG_PASSIVE)
	printf(", PASSIVE"); 
if(p_struct->udp_flags & UDP_FLAG_ACTIVE)
	printf(", ACTIVE"); 
if(p_struct->udp_flags & UDP_FLAG_BIND)
	printf(", BIND"); 
if(p_struct->udp_flags & UDP_DATA_AVAILABLE)
	printf(", DATA_AVAILABLE"); 
if(p_struct->udp_flags & UDP_TX_BUF_FREE)
	printf(", TX_BUF_FREE"); 
if(p_struct->udp_flags & UDP_TX_BUF_HALF_FULL)
	printf(", TX_BUF_HALF_FULL"); 
if(p_struct->udp_flags & UDP_TX_BUF_FULL)
	printf(", TX_BUF_FULL"); 
putsf("\r"); 
}


//********************************************************************************
// Description	: displays all UDP-infos
// Input   		: port number
// Output  		: none
// Indication	: none
//*********************************************************************************
void udp_info(unsigned int port_number)
{
unsigned char Lva, display_count=0;
UDP_STRUCTURE	*p_struct;                                    	

p_struct=&udp_struct[0];                                    	
for(Lva=0;Lva<UDP_MAX_CONNECTIONS; Lva++)
	{
	if((port_number==0)||(port_number==p_struct->udp_port_local))
		{
		display_count++;
		printf("udp_connection: %u\r\n", Lva); 
		printf(" flags      :"); 
		udp_display_flags(p_struct);
		printf(" port_local : %u\r\n", p_struct->udp_port_local);
		printf(" port_remote: %u\r\n", p_struct->udp_port_remote);
		printf(" ip_remote  : %u.%u.%u.%u\r\n", p_struct->udp_ip_remote[0], p_struct->udp_ip_remote[1], 
												p_struct->udp_ip_remote[2], p_struct->udp_ip_remote[3]);
		printf(" tx_all_count: %u / tx_data_count: %u\r\n", p_struct->udp_tx_all_count, p_struct->udp_tx_data_count);
		printf(" tx_frame - H:%u D:%u\r\n", UDP_ALL_HEADER_SIZE, UDP_TX_DATA_SIZE);
    	}
	p_struct++;
	}
if(display_count==0)
	printf("no UDP-Port: %u\r\n", port_number);
}
#endif	// #ifdef WEB_DEBUG_UDP
#endif	// #ifdef UDP_ENABLE