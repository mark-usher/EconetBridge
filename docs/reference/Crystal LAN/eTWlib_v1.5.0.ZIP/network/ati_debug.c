// ************************************************************************************************
///
/// \file 			ati_debug.c
/// \brief			Debug functions for ati.c
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Mirco Fuchs, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef ATI_DEBUG

#include <stdio.h>
#include <string.h>
#include <mega128.h>
#include "ati.h"
#include "ati_debug.h"
#include "board.h"
#include "device.h"
#include "debug.h"


ATI_STATE			ati_state_last=ATI_STATE_UNREACHED;
ATI_STATE			ati_state_old_last=ATI_STATE_UNREACHED;
ATI_DEVICE_MODE		ati_device_mode_last=ATI_DEVICE_UNREACHED;    
ATI_DEVICE_MODE		ati_device_nextmode_last=ATI_DEVICE_UNREACHED;
char flash *ati_state_debug[6]={
				"BUFFER_EMPTY", "BUFFER_FILLED", "CHECK_BUFFER", "RSP_AWAITED", "RECEIVE_DATA", "UNREACHED"};
char flash *ati_device_mode_debug[4]={
				"COMMAND", "CARRIER", "ONLINE", "COMMAND_ONLINE"};
eeprom unsigned char ati_debug_flag = 0x00;	// default: debug output off


// local prototype
void ati_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);

// ************************************************************************************************
/// \brief		   	Registers Debug Handler
///
// ************************************************************************************************
void ati_debug_init(void)
{
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &ati_debug_handler;
p_struct.id_string = "ati";
debug_register_handler(&p_struct);
}

//********************************************************************************
// Description	: prints the change of state
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ati_debug_print_state_change(void)
{
if(ati_state!=ati_state_last)
	{
	printf("ATI State: %p\r\n", ati_state_debug[ati_state]);
	ati_state_last=ati_state;
	}
if(ati_state_old!=ati_state_old_last)
	{
	printf("ATI State-Old: %p\r\n", ati_state_debug[ati_state_old]);
	ati_state_old_last=ati_state_old;
	}
}

//********************************************************************************
// Description	: prints the change of device mode
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ati_debug_print_mode_change(void)
{
if(ati_device_mode!=ati_device_mode_last)
	{
	printf("ATI Mode: %p\r\n", ati_device_mode_debug[ati_device_mode]);
	ati_device_mode_last=ati_device_mode;
	}
if(ati_device_nextmode!=ati_device_nextmode_last)
	{
	printf("ATI Mode-Next: %p\r\n", ati_device_mode_debug[ati_device_nextmode]);
	ati_device_nextmode_last=ati_device_nextmode;
	}
}


// ************************************************************************************************
/// \brief	    command handler for debug commands
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void ati_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
signed int new_timeout;

if (mode == DEBUG_HANDLER_MODE_INFO)
	{
	printf("ATI_DEBUG");
	if (ati_debug_flag)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
	}
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
    // add output for 'help' command here
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
    {
	if (strncmpf(command, "ati", 3)==0)
	    {
    	ati_debug_flag ^= 0xFF;
    	if (ati_debug_flag)
			putsf("ATI_DEBUG ON\r");
		else
			putsf("ATI_DEBUG OFF\r");
	    }
	}
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-init", 3)==0)
		ati_init();
	else if (strncmpf(command, "-modus", 3)==0)
		ati_get_device_mode(ATI_ANSWER_SHOW);
	else if (strncmpf(command, "-answer", 3)==0)
		ati_get_new_answer();
	else if (strncmpf(command, "-connect", 3)==0)
		{
		command=debug_search_parameter(command);
		if(command!=0)
			ati_connect(command);
		}
	else if (strncmpf(command, "-disconnect", 3)==0)
		ati_disconnect();
	else if (strncmpf(command, "-on", 3)==0)
		ati_answer_incomming_call(ATI_ANSWER_ENABLED);
	else if (strncmpf(command, "-off", 3)==0)
		ati_answer_incomming_call(ATI_ANSWER_DISABLED);
	else if (strncmpf(command, "-timeout", 3)==0)
		{
		new_timeout=debug_get_int_parameter(command);
		ati_timeout_answer_eeprom = new_timeout;
		}
	else if (strncmpf(command, "-cmd", 3)==0)
		ati_write_data(command);
	}
}

#endif	// #ifdef ATI_DEBUG
