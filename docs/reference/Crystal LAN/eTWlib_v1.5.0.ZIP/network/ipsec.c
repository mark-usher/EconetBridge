// ************************************************************************************************
///
/// \file 			ipsec.c
/// \brief			Simple IPSec implementation
///
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
///					This document is part of embedded IPsec
///					Niklaus Schild and Christian Scheurer, HTI Biel/Bienne
///					This file contains code from the OpenSSL Project<BR>
///					Niklaus Schild <n.schild@gmx.ch> <BR>
///					portions Copyright (c) 1998-2003 OpenSSL (www.openssl.org)
///
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef IPSEC_ENABLE

#include <stdio.h>
#include <string.h>
#include "util.h"
#include "device.h"
#include "buffer.h"
#include "ipsec.h"
#include "ip.h"
#include "md5.h"
#include "hmac_md5.h"
#include "sha1.h"
#include "hmac_sha1.h"
#include "des.h"
#include "ipsec_sa_debug.h"
#include "debug.h"
#include "ipsec_sa.h"
#include "ipsec_ah.h"
#include "ipsec_esp.h"

#pragma regalloc-
unsigned char	ipsec_rx_buffer[IPSEC_RX_BUFFER];
unsigned int	ipsec_rx_length;

unsigned char	*ipsec_rx_packet;			// pointer to RX-Data-Packet
unsigned int	ipsec_rx_packet_size=0;		// contains size of RX-Data-Packet

unsigned char 	authkey_temp[IPSEC_MAX_AUTHKEY_LEN];	// authentication key

#ifdef WEB_DEBUG_IPSEC
unsigned int 	ipsec_in_count=0;
unsigned int 	ipsec_out_count=0;
#endif
#pragma regalloc+

//*********************************************************************************
// Description	: reads a full IP-Frame
// Input   		: none
// Output  		: none
// Indication	: internal easyToWeb function
//*********************************************************************************
unsigned char ipsec_hmac(SA_MEMORY sad_entry_mem *sa, unsigned char *data, 
					unsigned int data_size, unsigned char *ipsec_digest) 
{
#ifdef IPSEC_SA_MEMORY_SRAM
memcpy(authkey_temp, sa->authkey, IPSEC_MAX_AUTHKEY_LEN);
#else
util_memcpye(authkey_temp, sa->authkey, IPSEC_MAX_AUTHKEY_LEN);
#endif
switch(sa->auth_alg)
	{
	case IPSEC_HMAC_MD5:
		#ifdef	HMAC_MD5_ENABLE
		hmac_md5(data, data_size, authkey_temp, MD5_HASH_SIZE, ipsec_digest);
		#endif
		break;
	case IPSEC_HMAC_SHA1:
		#ifdef	HMAC_SHA1_ENABLE
		hmac_sha1(data, data_size, authkey_temp, SHA1_HASH_SIZE, ipsec_digest);
		#endif
		break;
	default:
		return 0;
	}
return 1;
}


#ifdef IPSEC_REPLAY_ENABLE					// Enable the Replay Functions
//*********************************************************************************
// Description	: Verify the sequence number of the AH packet is inside the window
//                (defined as IPSEC_SEQ_MAX_WINDOW)
//                Note: this function does NOT update the lastSeq variable and may
//                safely be called prior to IVC check.
// Input   		: @param  seq       sequence number of the current packet
//                @param  last_seq  sequence number of the last known packet
//                @param  bitfield  field used to verify resent data within the window
// Output  		: @return 1 if check passed (packet allowed)
//                @return 0 if check failed (packet disallowed)
// Indication	: internal easyToWeb function
//*********************************************************************************
unsigned char ipsec_check_replay_window(unsigned long seq, unsigned long last_seq, unsigned int bitfield) 
{
unsigned int diff;

if(seq == 0) return 0;	// first == 0 or wrapped
if(seq > last_seq)		// new larger sequence number
	{
	diff = seq - last_seq;
	// only accept new number if delta is not > IPSEC_SEQ_MAX_WINDOW
	if(diff >= IPSEC_SEQ_MAX_WINDOW)
		return 0;
	}
else					// new smaller or equal sequence number
	{
	diff = last_seq - seq;
	// only accept new number if delta is not > IPSEC_SEQ_MAX_WINDOW
	if(diff >= IPSEC_SEQ_MAX_WINDOW)
		return 0;
	if(bitfield & ((unsigned int)1 << diff))	// already seen??
		return 0; 
	}
return 1;
}


//*********************************************************************************
// Description	: Verify and update the sequence number.
//                this function is UPDATING the lastSeq variable and must be called
//                only AFTER checking the IVC.
// Input   		: @param  seq       sequence number of the current packet
//                @param  last_seq  pointer to sequence number of the last known packet
//                @param  bitfield  pointer to field used to verify resent data within the window
// Output  		: @return 1 if check passed (packet allowed)
//                @return 0 if check failed (packet disallowed)
// Indication	: internal easyToWeb function
//                This  code  is  based  on  RFC2401,  Appendix  C  --  
//                Sequence  Space  Window  Code  Example 
//*********************************************************************************
void ipsec_update_window(unsigned long seq, unsigned long *last_seq, unsigned int *bitfield) 
{
unsigned int diff;

if(seq > *last_seq)			// new larger sequence number
	{               		
	diff = seq - *last_seq;
	if(diff < IPSEC_SEQ_MAX_WINDOW)	// In window
		{
		*bitfield <<= diff;
		*bitfield |= 0x01;			// set bit for this packet
		}
	else *bitfield = 0x01;			// This packet has a "way larger"
	*last_seq = seq;
    }
else
	{
	diff = *last_seq - seq;
	*bitfield |= ((unsigned int)1 << diff);	// mark as seen
	}
}
#endif	// #ifdef IPSEC_REPLAY_ENABLE


//*********************************************************************************
// Description	: reads a full IP-Frame
// Input   		: none
// Output  		: none
// Indication	: internal easyToWeb function
//*********************************************************************************
unsigned char ipsec_read_ip_frame(void)
{
DEVICE_READ_FRAME_DATA(ipsec_rx_buffer, 2);			// read IP-Version and Length
ipsec_rx_length = DEVICE_READ_FRAME_16BIT();		// get IP frame's length
ipsec_rx_buffer[2]=(unsigned char)(ipsec_rx_length>>8);	// rewrite High-Byte of IP-Length to buffer
ipsec_rx_buffer[3]=ipsec_rx_length;			  		// rewrite Low-Byte of IP-Length to buffer
if(ipsec_rx_length>IPSEC_RX_BUFFER)
	{
	#ifdef WEB_DEBUG_IPSEC
	if (ipsec_debug_flag)
		printf("IPSEC(xx) ERROR too long frame: %u\r\n", ipsec_rx_length); 
	#endif
	return 0;
	}
DEVICE_READ_FRAME_DATA(&ipsec_rx_buffer[4], ipsec_rx_length-4);	// read the rest of complete IP-Frame
// init the pointer of IPSEC-Data
ipsec_rx_packet=ipsec_rx_buffer;			// pointer to RX-Data-Packet
ipsec_rx_packet_size=ipsec_rx_length;		// contains size of RX-Data-Packet
#ifdef WEB_DEBUG_IPSEC
if (ipsec_debug_flag)
	{
//	printf("IPSEC(%u) data: %uByte\r\n", ipsec_in_count, ipsec_rx_length); 
//	web_debug_display_frame(ipsec_rx_buffer, ipsec_rx_length, 0);
	}
#endif
return 1;
}


//*********************************************************************************
// Description	: reads the incomming SPI- and SEQ-Number
// Input   		: ipsec_ip_protocol: type of IPSec-Protocol
// Output  		: *ipsec_spi: pointer to 32bit variable
//                *ipsec_seq: pointer to 32bit variable
// Indication	: internal easyToWeb function
//*********************************************************************************
void ipsec_get_spi_seq(unsigned char ipsec_ip_protocol, unsigned long *ipsec_spi, unsigned long *ipsec_seq)
{
if(ipsec_ip_protocol==IP_IPSEC_AH_PROT)
	{
	WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) AH %ubyte\r\n", ipsec_in_count, ipsec_rx_packet_size));
	NETWORK_HOST_ENDIAN_32BIT(ipsec_spi, &ipsec_rx_buffer[IPSEC_AH_SPI_OFS]);		// read AH Security Parameter Index - SPI (32bit)
	NETWORK_HOST_ENDIAN_32BIT(ipsec_seq, &ipsec_rx_buffer[IPSEC_AH_SEQUENCE_OFS]);	// read AH Sequence Number (32bit)
	}
if(ipsec_ip_protocol==IP_IPSEC_ESP_PROT)
	{
	WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) ESP %ubyte\r\n", ipsec_in_count, ipsec_rx_packet_size));
	NETWORK_HOST_ENDIAN_32BIT(ipsec_spi, &ipsec_rx_buffer[IPSEC_ESP_SPI_OFS]);		// ESP Security Parameter Index - SPI (32bit)
	NETWORK_HOST_ENDIAN_32BIT(ipsec_seq, &ipsec_rx_buffer[IPSEC_ESP_SEQUENCE_OFS]);// ESP Sequence Number (32bit)
	}
WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) spi:0x%lx / seq: 0x%lx\r\n", ipsec_in_count, *ipsec_spi, *ipsec_seq));
}


//*********************************************************************************
// Description	: handles an incoming IPSec-frames
// Input   		: none
// Output  		: none
// Indication	: internal easyToWeb function
//*********************************************************************************
unsigned char ipsec_input_frame(void)
{
unsigned long ipsec_spi, ipsec_seq;
unsigned char ipsec_ok=0, ip_offset=0;
SA_MEMORY sad_entry_mem	*sa;
SA_MEMORY spd_entry_mem	*sp;
IP_HEADER_STRUCTURE		*ip_in_header;

if(!ipsec_read_ip_frame())
	return 0;
#ifdef WEB_DEBUG_IPSEC
ipsec_in_count++;
#endif

ip_in_header=(IP_HEADER_STRUCTURE*)ipsec_rx_packet;
if((ip_in_header->protocol==IP_IPSEC_ESP_PROT)||(ip_in_header->protocol==IP_IPSEC_AH_PROT))
	{
	ipsec_get_spi_seq(ip_in_header->protocol, &ipsec_spi, &ipsec_seq);
	sa = ipsec_sa_sad_lookup_in(ip_in_header->destination, ip_in_header->protocol, ipsec_spi);
	if(sa == NULL)
		{
		WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) no SA found\r\n", ipsec_in_count));
		return 0;
		}
	// preliminary anti-replay check (without updating the global sequence number window)
	// This check prevents useless ICV calculation if the Sequence Number is obviously wrong
	#ifdef IPSEC_REPLAY_ENABLE					// Enable the Replay Functions
	ipsec_ok=ipsec_check_replay_window(ipsec_seq, *sa->seq, *sa->bitfield);
	#else
	ipsec_ok=1;
	#endif
	if(ipsec_ok==0)
		{
		WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) wrong sequence (last_seq=%lx, seq=%lx, window=%u)\r\n", \
									ipsec_in_count, *sa->seq, ipsec_seq, IPSEC_SEQ_MAX_WINDOW));
		return 0;
		}
	if(ip_in_header->protocol==IP_IPSEC_AH_PROT)
		ipsec_ok=ipsec_ah_input_frame(sa, ipsec_rx_buffer, &ipsec_rx_packet_size, &ip_offset);
	else if(ip_in_header->protocol==IP_IPSEC_ESP_PROT)
		ipsec_ok=ipsec_esp_input_frame(sa, ipsec_rx_buffer, &ipsec_rx_packet_size);
	else
		{
		WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) ERROR unsupported protocol: %u\r\n", ipsec_in_count, ip_in_header->protocol));
		}
	if(ipsec_ok)
		{
		// post-ICV calculation anti-replay check (this call will update the global sequence number window)
		#ifdef IPSEC_REPLAY_ENABLE					// Enable the Replay Functions
		ipsec_update_window(ipsec_seq, sa->seq, sa->bitfield);
		#endif
		ipsec_rx_packet+=ip_offset;			// set the new start-pointer
		ip_in_header=(IP_HEADER_STRUCTURE*)ipsec_rx_packet;
		sp=ipsec_sa_spd_lookup_in(ip_in_header, ipsec_rx_packet+IP_HEADER_SIZE);
		if(sp == NULL)
			{
			WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) no SPD found\r\n", ipsec_in_count));
			return 0;
			}
		if(sp->policy == POLICY_APPLY)
			{
			if(sp->sa != sa)
				{
				WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) wrong SPD found 0x%x/0x%x\r\n", ipsec_in_count, sp->sa, sa));
				return 0;
				}
			return 1;
			}
		}
	}
else
	{
	sp=ipsec_sa_spd_lookup_in(ip_in_header, ipsec_rx_packet+IP_HEADER_SIZE);
	if(sp == NULL)
		{
		WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) no matching SPD found\r\n", ipsec_in_count));
		return 0;
		}
	else
		{
		switch(sp->policy)
		 	{
			case POLICY_APPLY:
					WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) POLICY_APPLY: non-IPsec packet\r\n", ipsec_in_count));
					break;
			case POLICY_DISCARD:
					WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) POLICY_DISCARD: dropping packet\r\n", ipsec_in_count));
					break;
			case POLICY_BYPASS:
					WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) POLICY_BYPASS: forwarding packet to IP-Layer\r\n", ipsec_in_count));
					return 1;
			default:
				WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) wrong POLICY: 0x%x\r\n", ipsec_in_count, sp->policy));
			} 
		}
	}
return 0;
}


//*********************************************************************************
// Description	: handles an outcoming frame
// Input   		: *ip_data: pointer to full IP-Frame
//                *ip_size: pointer to size of IP-Frame
// Output  		: none
// Indication	: internal easyToWeb function
//*********************************************************************************
unsigned char ipsec_output_frame(unsigned char *ip_data, unsigned int *ip_size, unsigned char *ip_offset)
{
unsigned char ipsec_ok=0;
SA_MEMORY spd_entry_mem	*sp;

#ifdef WEB_DEBUG_IPSEC
ipsec_out_count++;
#endif
sp = ipsec_sa_spd_lookup_out((IP_HEADER_STRUCTURE*)(ip_data+IPSEC_OFFSET), ip_data+IPSEC_OFFSET+IP_HEADER_SIZE);
if(sp == NULL)
	{
	WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) no matching SPD found\r\n", ipsec_out_count));
	return 0;
	}
switch(sp->policy)
	{
	case POLICY_APPLY:																		
		if(sp->sa == NULL)
			{
			WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) no SA available (with IKE)\r\n", ipsec_out_count));
			return 0;
			}
		WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) POLICY_APPLY: processing IPsec packet\r\n", ipsec_out_count));
		if(sp->sa->protocol==IP_IPSEC_AH_PROT)
			ipsec_ok=ipsec_ah_output_frame(sp->sa, ip_data, ip_size, ip_offset);
		else if(sp->sa->protocol==IP_IPSEC_ESP_PROT)
			ipsec_ok=ipsec_esp_output_frame(sp->sa, ip_data, ip_size, ip_offset);
		else
			WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) ERROR unsupported protocol: %u\r\n", ipsec_out_count, sp->sa->protocol));
		return ipsec_ok;
	case POLICY_DISCARD:
		WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) POLICY_DISCARD: dropping packet\r\n", ipsec_out_count));
		break;
	case POLICY_BYPASS:
		WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) POLICY_BYPASS: forwarding packet to IP-Layer\r\n", ipsec_out_count));
		return 1;
	default:
		WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) wrong POLICY: 0x%x\r\n", ipsec_out_count, sp->policy));
	}
return 0;
}


//*********************************************************************************
// Description	: reads 16bit data from IPSec-data-buffer
// Input	   	: data: pointer to 16bit data
// Output   	: 1: data available
// 				  0: no data available
// 				  *data: read data
// Indication	: none
//*********************************************************************************
unsigned char ipsec_data_read16(unsigned int *data)
{
*data=0;
if(ipsec_rx_packet_size>1)
	{
	*data=*ipsec_rx_packet;
	*data<<=8;
	ipsec_rx_packet++;
	*data|=*ipsec_rx_packet;
	ipsec_rx_packet++;
	ipsec_rx_packet_size-=2;
	return 1;
	}
ipsec_rx_packet_size=0;			// delete the rest of data (1Byte)
return 0;
}


//*********************************************************************************
// Description	: reads 8bit data from IPSec-data-buffer
// Input	   	: data: pointer to 16bit data
// Output   	: 1: data available
// 				  0: no data available
// 				  *data: read data
// Indication	: none
//*********************************************************************************
unsigned char ipsec_data_read8(unsigned char *data)
{
*data=0;
if(ipsec_rx_packet_size)
	{
	*data=*ipsec_rx_packet;
	ipsec_rx_packet++;
	ipsec_rx_packet_size--;
	return 1;
	}
return 0;
}


//*********************************************************************************
// Description	: reads 16bit data from IPSec-receive-buffer
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
unsigned int ipsec_read_frame_16bit(void)
{
unsigned int data;

ipsec_data_read16(&data);
return data;
}


//*********************************************************************************
// Description	: reads 16bit data from IPSec-receive-buffer
// Input	   	: none
// Output   	: none
// Indication	: with Little-Endian
//*********************************************************************************
unsigned int ipsec_read_frame_16bit_le(void)
{
unsigned char data_low;
unsigned int data_high;

ipsec_data_read8(&data_low);
ipsec_data_read8(&(unsigned char*)data_high);
data_high<<=8;
data_high|=data_low;
return data_high;
}

//*********************************************************************************
// Description	: reads "size" count data from IPSec-receive-buffer
// Input	   	: 1.) size : 8bit count of data
// Output   	: none
// Indication	: none
//*********************************************************************************
void ipsec_read_frame_dummy(unsigned int size)
{
unsigned char data;

while(size)
	{
	ipsec_data_read8(&data);
	size--;
	#asm("wdr");			// Reset Watchdog
	}
}			

//*********************************************************************************
// Description	: reads a frame of data from IPSec-Buffer
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
void ipsec_read_frame(void *dest, unsigned int size)
{
unsigned char	*p_data;

p_data=dest;
while(size)
	{
	ipsec_data_read8(p_data);
    p_data++;
	size--;
	#asm("wdr");			// Reset Watchdog
	}
}			


#endif	// #ifdef IPSEC_ENABLE

