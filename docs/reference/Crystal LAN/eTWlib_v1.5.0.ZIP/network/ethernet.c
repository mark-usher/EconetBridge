// ************************************************************************************************
///
/// \file 			ethernet.c
/// \brief			easyToWeb ethernet functions
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef ETHERNET_ENABLE

#include <stdio.h>
#include <string.h>
#include <delay.h>
#include "device.h"
#include "ethernet.h"
#include "buffer.h"
#include "ip.h"
#if defined(ARP_ENABLE) || defined(RARP_ENABLE)
#include "arp_rarp.h"
#endif
#ifdef WEB_DEBUG_MEASURE			// enable time-measure debug functions, see measure.c
#include "measure.h"
#endif
#ifdef WEB_DEBUG
#include "debug.h"
#include "web_debug.h"
#endif


#pragma regalloc-
// properties of the just received frame
unsigned char mac_of_last_frame[6];				// 48 bit MAC
#pragma regalloc+


//*********************************************************************************
// Description	: must be called from user program periodically (the often - the better)
//              : handles ethernet protocol traffic
// Input   		: none
// Output  		: none
// Indication	: easyToWeb main()-function
//*********************************************************************************
void ethernet_process(void) 
{
unsigned int	rx_event;		   	// copy of CS8900's RxEvent-Register

#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_NET_S)
#endif	// #ifdef WEB_DEBUG_MEASURE
rx_event = DEVICE_READ_READY();
/*
#ifdef WEB_DEBUG_ETHERNET
if(web_debug_flag & WEB_DEBUG_ETHERNET_BIT)
	{
	delay_ms(100);
	printf("rx_event:0x%04x ", rx_event); 
	}
#endif	// #ifdef WEB_DEBUG_ETHERNET
*/
if(rx_event & DEVICE_READ_READY_RECEIVE)
	{
	if(rx_event & DEVICE_READ_READY_FRAME)
		ethernet_process_frame(0);
	else if(rx_event & DEVICE_READ_READY_BROADCAST)
		ethernet_process_frame(1);
	}
#ifdef ARP_ENABLE
arp_request_timer(ARP_REQUEST_TIMER_CONTINUE);	// normal mode
#endif	// #ifdef ARP_ENABLE
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_NET_E)
#endif	// #ifdef WEB_DEBUG_MEASURE
}


//*********************************************************************************
// Description	: handles an incoming frame that passed CS8900's address filter
//              : (individual addressed = IA)
// Input   		: broadcast_flag - 
// Output  		: none
// Indication	: easyToWeb internal function
//*********************************************************************************
void ethernet_process_frame(unsigned char broadcast_flag)
{
unsigned int ip_frame_type;
unsigned int frame_length;		// CS8900 reported frame length
#ifdef WEB_DEBUG_ETHERNET
unsigned char mac_dest[6];		// store DA (for debug)
#endif

#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_ETHERNET_S)
#endif
 // next two words MUST be read with High-Byte 1st (CS8900 AN181 Page 2)
DEVICE_READ_FRAME_STATUS();					// ignore RxStatus Word
frame_length = DEVICE_READ_FRAME_STATUS();	// get real length of frame 
  
#ifdef WEB_DEBUG_ETHERNET
DEVICE_READ_FRAME_DATA(mac_dest, 6);			// store DA (for debug)
#else
DEVICE_READ_FRAME_DUMMY(6);						// ignore DA
#endif
DEVICE_READ_FRAME_DATA(mac_of_last_frame, 6);	// store SA (for our answer)
ip_frame_type=DEVICE_READ_FRAME_16BIT(); 		// get frame type
#ifdef WEB_DEBUG_ETHERNET
if(web_debug_flag & WEB_DEBUG_ETHERNET_BIT)
	{
	printf("ETHERNET FRAME-Typ: 0x%04x, %uByte", ip_frame_type, frame_length); 
	if(broadcast_flag) 
		putsf(" Broadcast\r"); 
	else
		putsf("\r"); 
	debug_print_mac("ETHERNET MAC", mac_dest);
	}
#endif
switch(ip_frame_type)		
	{
	#if defined(ARP_ENABLE) || defined(RARP_ENABLE)
	case ARP_FRAME:								// check for ARP
	case RARP_FRAME:							// check for RARP
			arp_rarp_process_frame(broadcast_flag); 
			break;
	#endif
	#ifdef IP_ENABLE
	case IP_FRAME:				  				// check for IP-type
			ip_process_frame(broadcast_flag);
			break;
	#endif
	default:
		#ifdef WEB_DEBUG_ETHERNET
		if(web_debug_flag & WEB_DEBUG_ETHERNET_BIT)
			printf("ETHERNET unsupported FRAME-Typ: 0x%04x\r\n", ip_frame_type); 
		#endif
	}
#ifdef WEB_DEBUG_MEASURE
MEASURE_SETTIME(MEA_ETHERNET_E)
#endif
}

#endif	// #ifdef ETHERNET_ENABLE