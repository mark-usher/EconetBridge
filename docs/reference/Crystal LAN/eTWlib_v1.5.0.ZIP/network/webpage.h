// ************************************************************************************************
///
/// \file 			webpage.h
///
/// \date	 		$LastChangedDate: 2007-08-03 09:47:32 +0200 (Fr, 03 Aug 2007) $
/// \version 		$Rev: 672 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

/// \defgroup Network_Stack
/// \addtogroup Network_Stack
/// @{
/// \defgroup Webpage
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define WEBPAGE_DEFAULT_ENABLE
//@}
#endif

///	\def WEBPAGE_DEFAULT_ENABLE
///		Enables Default webpage. If the user doesn't request a specific webside e.g. 
///		'index.html', or this side can't be found, a default webpage can be provided. 
///		The application code in /apps/ has to specify a function http_server_default() 
///		which copies the HTML data to the TCP/IP stack. 2 examples are provided: 
///		webpage_dynamic.c and webpage_static.c

#ifndef _WEBPAGE_INCLUDED_
#define _WEBPAGE_INCLUDED_

unsigned char http_server_default(HTTP_SERVER_DEFAULT_STATUS status);

#endif	// #ifndef _WEBPAGE_INCLUDED_

/// @}
/// @}
