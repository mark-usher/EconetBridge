// ************************************************************************************************
///
/// \file 			ipsec_esp.c
/// \brief			IPSec Encapsulating Security Payload
///
///					Function:	RFC2406 - ESP Header
///					This module contains the Encapsulating Security Payload code
///
///					Implementation:
///					All functions work in-place (i.g. mainipulate directly the original
///					packet without copying any data). For the encapsulation routine,
///					the caller must ensure that space for the new IP and ESP header are
///					available in front of the packet:
///
///					                          | pointer to packet header
///					_________________________\/________________________________________________
///					|          �       �      �                             � padd       � ev. |
///					| Ethernet � newIP � ESP  �   original (inner) packet   � next-proto � ICV |
///					|__________�_______�______�_____________________________�____________�_____|
///					�                         �                             �                  � 
///					�<-room for new headers-->�                             �<-   room tail  ->� 
///
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		Copyright (C) 2001-2004
///					This document is part of embedded IPsec
///					Niklaus Schild and Christian Scheurer, HTI Biel/Bienne
///					This file contains code from the OpenSSL Project<BR>
///					Niklaus Schild <n.schild@gmx.ch>
///					portions Copyright (c) 1998-2003 OpenSSL (www.openssl.org)
///					easyToWeb-AVR and CodeVisionAVR C-Compiler:
///					Udo Jakobza - FTZ Leipzig; 04107 Leipzig; W�chterstr. 13
///					jakobza@e-technik.htwk-leipzig.de
///
/// \par License    
///					Redistribution and use in source and binary forms, with or without 
///					modification, are permitted provided that the following conditions are met:
///
///					1. Redistributions of source code must retain the above copyright notice,
///					   this list of conditions and the following disclaimer.
///					2. Redistributions in binary form must reproduce the above copyright notice,
///					    this list of conditions and the following disclaimer in the documentation
///					   and/or other materials provided with the distribution.
///					3. The name of the author may not be used to endorse or promote products
///					   derived from this software without specific prior written permission.
///
///					THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
///					WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
///					MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
///					EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
///					EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
///					OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
///					INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
///					CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
///					IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
///					OF SUCH DAMAGE.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef	IPSEC_ENABLE

#include <string.h>
#include "buffer.h"
#include "ip.h"
#include "ipsec.h"
#include "ipsec_esp.h"
#include "md5.h"
#include "hmac_md5.h"
#include "sha1.h"
#include "hmac_sha1.h"
#include "des.h"
#include "debug.h"
#include "ipsec_sa_debug.h"
#include "ipsec_sa.h"

#pragma regalloc-
unsigned char			des_iv_data[IPSEC_ESP_DES_IV_SIZE];
DES_KEY_SCHEDULE	 	esp_ks1, esp_ks2, esp_ks3;
unsigned char  			esp_digest[IPSEC_MAX_AUTHKEY_LEN];
eeprom unsigned char	esp_3des_iv[IPSEC_ESP_DES_IV_SIZE] = {0xD4, 0xDB, 0xAB, 0x9A, 0x9A, 0xDB, 0xD1, 0x94};
#pragma regalloc+

//*********************************************************************************
// Description	: Returns the number of padding needed for a certain ESP packet size 
// Input   		: @param  len    the length of the packet
// Output  		: @return the length of padding needed
// Indication	: internal easyToWeb function
//*********************************************************************************
unsigned char ipsec_esp_get_padding(unsigned int len)
{
unsigned char padding;

for(padding = 0; padding < 8; padding++)
	if(((len+padding) % 8) == 0)
		break;
return padding;
}


//*********************************************************************************
// Description	: Returns the number of padding needed for a certain ESP packet size 
// Input   		: @param  len    the length of the packet
// Output  		: @return the length of padding needed
// Indication	: internal easyToWeb function
//*********************************************************************************
unsigned char ipsec_esp_key(SA_MEMORY sad_entry_mem *sa)
{
#ifdef IPSEC_SA_MEMORY_SRAM
memcpy(esp_digest, sa->enckey, DES_KEY_SIZE);		// copy 8 byte to buffer
#else
util_memcpye(esp_digest, sa->enckey, DES_KEY_SIZE);		// copy 8 byte to buffer
#endif
#ifdef	DES_ENABLE
if(des_set_key_checked(esp_digest,&esp_ks1))
	return 0;
#endif
#ifdef IPSEC_SA_MEMORY_SRAM
memcpy(esp_digest, &sa->enckey[1*DES_KEY_SIZE], DES_KEY_SIZE);		// copy 8 byte to buffer
#else
util_memcpye(esp_digest, &sa->enckey[1*DES_KEY_SIZE], DES_KEY_SIZE);		// copy 8 byte to buffer
#endif
#ifdef	DES_ENABLE
if(des_set_key_checked(esp_digest,&esp_ks2))
	return 0;
#endif
#ifdef IPSEC_SA_MEMORY_SRAM
memcpy(esp_digest, &sa->enckey[2*DES_KEY_SIZE], DES_KEY_SIZE);		// copy 8 byte to buffer
#else
util_memcpye(esp_digest, &sa->enckey[2*DES_KEY_SIZE], DES_KEY_SIZE);		// copy 8 byte to buffer
#endif
#ifdef	DES_ENABLE
if(des_set_key_checked(esp_digest,&esp_ks3))
	return 0;
#endif
return 1;
}

//*********************************************************************************
// Description	: handles the incomming frames
// Input   		: sa: pointer to SA
//                rx_data: pointer to received data
//                rx_length: pointer to received length data
// Output  		: @return: 0 some error inside of data
//                @return: 1 OK
// Indication	: internal easyToWeb function
//*********************************************************************************
unsigned char ipsec_esp_input_frame(SA_MEMORY sad_entry_mem *sa, unsigned char *rx_data, unsigned int *rx_length)
{
#if defined(IPSEC_ESP_TRANSPORT_ENABLE)||defined(IPSEC_ESP_TUNNEL_ENABLE)
unsigned char next_header, temp_length;
unsigned int esp_length;
TRANS_TUNNEL_IN_IP_ESP	*rx_header;

rx_header=(TRANS_TUNNEL_IN_IP_ESP*)rx_data;
esp_length=*rx_length-IP_HEADER_SIZE-IPSEC_ESP_AUTH_DATA_SIZE; 
if(ipsec_hmac(sa, (unsigned char*)&rx_header->esp, esp_length, esp_digest)==0)
	{
	WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) unknown AH-HASH algorithm\r\n", ipsec_in_count));
	return 0;
	}
if(memcmp(&rx_header->esp+esp_length, esp_digest, IPSEC_ESP_AUTH_DATA_SIZE))	// Check ESP Authenticatioon Data (96bit - 12Byte)
	{
	#ifdef WEB_DEBUG_IPSEC
	if (ipsec_debug_flag)
		{
		printf("IPSEC-IN(%u) ERROR Authentication: %uByte\r\n", ipsec_in_count, sizeof(esp_digest)); 
		//web_debug_display_frame(esp_digest, sizeof(esp_digest), 0);
		}
	#endif
	return 0;
	}
WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) Authentication OK\r\n", ipsec_in_count));
if(sa->enc_alg != IPSEC_3DES)
	{
	WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) unknown CHIPER algorithm for this ESP\r\n", ipsec_in_count));
	return 0;
	}
// check and calculate the 3DES-Key
if(ipsec_esp_key(sa)==0)
	{
	WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) ERROR des_set_key_checked\r\n", ipsec_in_count));
	return 0;
	}
// Read ESP IV Datas (64bit - 8Byte)
memcpy(des_iv_data, (unsigned char*)rx_header->esp.iv, sizeof(des_iv_data));	
esp_length-=(IPSEC_ESP_HEADER_SIZE+IPSEC_ESP_DES_IV_SIZE); 
#ifdef	DES_ENABLE
if(sa->mode==IPSEC_TRANSPORT)
	des_3des_cbc_encrypt((unsigned char*)&rx_header->data, (unsigned char*)&rx_header->esp, 
						esp_length, &esp_ks1, &esp_ks2, &esp_ks3, des_iv_data, DES_DECRYPT);
if(sa->mode==IPSEC_TUNNEL)
	des_3des_cbc_encrypt((unsigned char*)&rx_header->data, (unsigned char*)&rx_header->ip, 
						esp_length, &esp_ks1, &esp_ks2, &esp_ks3, des_iv_data, DES_DECRYPT);
#endif
#ifdef WEB_DEBUG_IPSEC
if (ipsec_debug_flag)
	{
	printf("IPSEC-IN(%u) 3DES data: %uByte\r\n", ipsec_in_count, esp_length); 
//	if(sa->mode==IPSEC_TRANSPORT)
//		web_debug_display_frame((unsigned char*)&rx_header->esp, esp_length, 0);
//	if(sa->mode==IPSEC_TUNNEL)
//		web_debug_display_frame((unsigned char*)&rx_header->ip, esp_length, 0);
	}
#endif
#endif	// #if defined(IPSEC_AH_TRANSPORT_ENABLE)||defined(IPSEC_AH_TUNNEL_ENABLE)
#ifdef IPSEC_ESP_TRANSPORT_ENABLE			// Enable the IPSec-ESP-Transport Protocol
if(sa->mode==IPSEC_TRANSPORT)
	{
	*rx_length-=(IPSEC_ESP_HEADER_SIZE+IPSEC_ESP_DES_IV_SIZE+IPSEC_ESP_TRAILER_SIZE+IPSEC_ESP_AUTH_DATA_SIZE);	// set a new Length of IP-Frame
	next_header=*(unsigned char*)(&rx_header->esp + esp_length - 1);	// read next header entry
	temp_length=*(unsigned char*)(&rx_header->esp + esp_length - 2);	// read padding length
	*rx_length-=temp_length;					// set a new Length of IP-Frame
	// set the new length
	HOST_NETWORK_ENDIAN_16BIT((unsigned char*)&rx_header->ip.length, rx_length);
	rx_header->ip.checksum=0;		// set Checksum to zero, should later compute
	rx_header->ip.protocol=next_header;
	#ifdef WEB_DEBUG_IPSEC
	if (ipsec_debug_flag)
		{
		printf("IPSEC-IN(%u) data: %uByte\r\n", ipsec_in_count, *rx_length); 
		//web_debug_display_frame(rx_data, *rx_length, 0);
  		}
	#endif
	return 1;
	}   	
#else
WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) NO ESP-TRANSPORT\r\n", ipsec_in_count));
#endif	// #ifdef IPSEC_ESP_TRANSPORT_ENABLE
#ifdef IPSEC_ESP_TUNNEL_ENABLE			// Enable the IPSec-ESP-Tunnel Protocol
if(sa->mode==IPSEC_TUNNEL)
	{
	// set a new Length of IP-Frame
	*rx_length-=(IP_HEADER_SIZE + IPSEC_ESP_HEADER_SIZE + IPSEC_ESP_DES_IV_SIZE + IPSEC_ESP_TRAILER_SIZE + 
																						IPSEC_ESP_AUTH_DATA_SIZE);	
	temp_length=*(unsigned char*)(&rx_header->ip + *rx_length + 0);	// read padding length
	next_header=*(unsigned char*)(&rx_header->ip + *rx_length + 1);	// read next header entry
	*rx_length-=temp_length;					// set a new Length of IP-Frame without padding
	#ifdef WEB_DEBUG_IPSEC
	if (ipsec_debug_flag)
		{
		printf("IPSEC-IN(%u) data: %uByte; next_header:0x%x\r\n", ipsec_in_count, *rx_length, next_header); 
		//web_debug_display_frame(rx_data, *rx_length, 0);
  		}
	#endif
	return 1;
	}
#else
WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) NO ESP-TUNNEL\r\n", ipsec_in_count));
#endif	// #ifdef IPSEC_ESP_TUNNEL_ENABLE
return 0;
}

//*********************************************************************************
// Description	: handles the outgoing ESP-frames
// Input   		: sad_entry_mem: pointer to SA
//              : *ip_data: pointer to full IP-Frame
//                *ip_size: pointer to size of IP-Frame
//                *ip_offset: pointer to offset inside of TX-Buffer
// Output  		: @return: 0 some error inside of data
//                @return: 1 OK
// Indication	: internal easyToWeb function
//*********************************************************************************
unsigned char ipsec_esp_output_frame(SA_MEMORY sad_entry_mem *sa, unsigned char *ip_data, 
									unsigned int *ip_size, unsigned char *ip_offset)
{
#ifdef IPSEC_ESP_TUNNEL_ENABLE			// Enable the IPSec-ESP-Tunnel Protocol
TUNNEL_OUT_IP_ESP_IP	*tx_header_tunnel;
#endif
unsigned char			padding_length, Lva;
unsigned int			esp_length;

#ifdef IPSEC_ESP_TRANSPORT_ENABLE			// Enable the IPSec-ESP-Transport Protocol
TRANSPORT_OUT_IP_ESP	*tx_header_trans;
if(sa->mode==IPSEC_TRANSPORT)
	{
//	web_debug_display_frame(ip_data, *ip_size+IPSEC_OFFSET, 0);
	tx_header_trans=(TRANSPORT_OUT_IP_ESP*)ip_data;
	// move the IP-Header
	memmove(&tx_header_trans->ip, ip_data+IPSEC_OFFSET, IP_HEADER_SIZE);
	// calculate the padding
	padding_length=ipsec_esp_get_padding(*ip_size - IP_HEADER_SIZE + IPSEC_ESP_TRAILER_SIZE);	// IP-Data only and ESP-Trailer (2Byte)
	ip_data+=(IPSEC_OFFSET + *ip_size);	// set to last IP-Data
	// set the Padding-Data, see RFC 2406; page 6
	for(Lva=0;Lva<padding_length;Lva++)
		*ip_data++=(Lva+1);		
//	ip_data+=(IPSEC_OFFSET + *ip_size + padding_length);	// set to last read next header entry
	*ip_data=padding_length;				// write padding length
	ip_data++;
	*ip_data=tx_header_trans->ip.protocol;	// write next header entry
	// check and calculate the 3DES-Key
	if(ipsec_esp_key(sa)==0)
		{
		WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) ERROR des_set_key_checked\r\n", ipsec_out_count));
		return 0;
		}
	// Write ESP IV Datas (64bit - 8Byte) to Buffer
	util_memcpye(des_iv_data, esp_3des_iv, sizeof(des_iv_data));	
	// Write ESP IV Datas (64bit - 8Byte) to IP-Frame
	memcpy(tx_header_trans->esp.iv, des_iv_data, sizeof(des_iv_data));	
	esp_length=*ip_size + padding_length + IPSEC_ESP_TRAILER_SIZE - IP_HEADER_SIZE;
	#ifdef	DES_ENABLE
	des_3des_cbc_encrypt((unsigned char*)&tx_header_trans->data, (unsigned char*)&tx_header_trans->data, 
							esp_length, &esp_ks1, &esp_ks2, &esp_ks3, des_iv_data, DES_ENCRYPT);
	#endif
	// calculate the ESP-Size
	*ip_size+=(IPSEC_ESP_HEADER_SIZE + IPSEC_ESP_DES_IV_SIZE + IPSEC_ESP_TRAILER_SIZE - IP_HEADER_SIZE);
	*ip_size+=padding_length;
	// Init the ESP-Header
	HOST_NETWORK_ENDIAN_32BIT((unsigned char*)&tx_header_trans->esp.spi, &sa->spi);		// write ESP Security Parameter Index - SPI (32bit)
	(*sa->seq)++;
	HOST_NETWORK_ENDIAN_32BIT((unsigned char*)&tx_header_trans->esp.sequence, sa->seq);	// write ESP Sequence Number (32bit)
	if(ipsec_hmac(sa, (unsigned char*)&tx_header_trans->esp, *ip_size, esp_digest))
		{
		*ip_size+=(IP_HEADER_SIZE + IPSEC_ESP_AUTH_DATA_SIZE);
		ip_data++;
		memcpy(ip_data, esp_digest, IPSEC_ESP_AUTH_DATA_SIZE);
		//web_debug_display_frame(esp_digest, sizeof(esp_digest), 0);
		}
	else
		{
		WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) NO ESP-HASH algorithm\r\n", ipsec_out_count));
		*ip_size+=IP_HEADER_SIZE;	// without Authentication Data
		}
	// Init the IP-Header
	tx_header_trans->ip.protocol=IP_IPSEC_ESP_PROT;				// set Next Header Entry
	HOST_NETWORK_ENDIAN_16BIT((unsigned char*)&tx_header_trans->ip.length, ip_size);	// set the new length
	tx_header_trans->ip.checksum = 0; 			// 16bit Checksum
	tx_header_trans->ip.checksum = ip_checksum(&tx_header_trans->ip, IP_HEADER_SIZE, 0);
	*ip_offset-=(IPSEC_ESP_HEADER_SIZE + IPSEC_ESP_DES_IV_SIZE);
	WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) ESP %ubyte; ip_offset:0x%x\r\n", ipsec_out_count, *ip_size, *ip_offset));
	//web_debug_display_frame((unsigned char*)&tx_header_trans->ip, *ip_size, 0);
	return 1;
	}
#else
WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) NO ESP-TRANSPORT\r\n", ipsec_out_count));
#endif	// #ifdef IPSEC_ESP_TRANSPORT_ENABLE
#ifdef IPSEC_ESP_TUNNEL_ENABLE			// Enable the IPSec-ESP-Tunnel Protocol
if(sa->mode==IPSEC_TUNNEL)
	{
	tx_header_tunnel=(TUNNEL_OUT_IP_ESP_IP*)ip_data;
	// move the IP-Header
	memmove(&tx_header_tunnel->ip_out, &tx_header_tunnel->ip_in, IP_HEADER_SIZE);
	// calculate the padding
	padding_length=ipsec_esp_get_padding(*ip_size + IPSEC_ESP_TRAILER_SIZE);	// IP-Data only and ESP-Trailer (2Byte)
	ip_data+=(IPSEC_OFFSET + *ip_size);	// set to last IP-Data
	// set the Padding-Data, see RFC 2406; page 6
	for(Lva=0;Lva<padding_length;Lva++)
		*ip_data++=(Lva+1);		
	*ip_data=padding_length;	// write padding length
	ip_data++;
	*ip_data=IP_IP_PROT;		// write next header entry
	// check and calculate the 3DES-Key
	if(ipsec_esp_key(sa)==0)
		{
		WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) ERROR des_set_key_checked\r\n", ipsec_out_count));
		return 0;
		}
	// Write ESP IV Datas (64bit - 8Byte) to Buffer
	util_memcpye(des_iv_data, esp_3des_iv, sizeof(des_iv_data));	
	// Write ESP IV Datas (64bit - 8Byte) to IP-Frame
	memcpy(tx_header_tunnel->esp.iv, des_iv_data, sizeof(des_iv_data));	
	esp_length=*ip_size + padding_length + IPSEC_ESP_TRAILER_SIZE;
	#ifdef	DES_ENABLE
	des_3des_cbc_encrypt((unsigned char*)&tx_header_tunnel->ip_in, (unsigned char*)&tx_header_tunnel->ip_in, 
							esp_length, &esp_ks1, &esp_ks2, &esp_ks3, des_iv_data, DES_ENCRYPT);
	#endif
	// calculate the ESP-Size
	*ip_size+=(IPSEC_ESP_HEADER_SIZE + IPSEC_ESP_DES_IV_SIZE + IPSEC_ESP_TRAILER_SIZE);
	*ip_size+=padding_length;
	// Init the ESP-Header
	HOST_NETWORK_ENDIAN_32BIT((unsigned char*)&tx_header_tunnel->esp.spi, &sa->spi);		// write ESP Security Parameter Index - SPI (32bit)
	(*sa->seq)++;
	HOST_NETWORK_ENDIAN_32BIT((unsigned char*)&tx_header_tunnel->esp.sequence, sa->seq);	// write ESP Sequence Number (32bit)
	if(ipsec_hmac(sa, (unsigned char*)&tx_header_tunnel->esp, *ip_size, esp_digest))
		{
		*ip_size+=(IP_HEADER_SIZE + IPSEC_ESP_AUTH_DATA_SIZE);
		ip_data++;
		memcpy(ip_data, esp_digest, IPSEC_ESP_AUTH_DATA_SIZE);
		//web_debug_display_frame(esp_digest, sizeof(esp_digest), 0);
		}
	else
		{
		WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) NO ESP-HASH algorithm\r\n", ipsec_out_count));
		*ip_size+=IP_HEADER_SIZE;	// without Authentication Data
		}
	// Init the IP-Header
	tx_header_tunnel->ip_out.protocol=IP_IPSEC_ESP_PROT;				// set Next Header Entry
	HOST_NETWORK_ENDIAN_16BIT((unsigned char*)&tx_header_tunnel->ip_out.length, ip_size);	// set the new length
	tx_header_tunnel->ip_out.checksum = 0; 			// 16bit Checksum
	tx_header_tunnel->ip_out.checksum = ip_checksum(&tx_header_tunnel->ip_out, IP_HEADER_SIZE, 0);
	*ip_offset-=(IP_HEADER_SIZE + IPSEC_ESP_HEADER_SIZE + IPSEC_ESP_DES_IV_SIZE);
	WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) ESP %ubyte; ip_offset:0x%x\r\n", ipsec_out_count, *ip_size, *ip_offset));
	//web_debug_display_frame((unsigned char*)&tx_header_tunnel->ip_out, *ip_size, 0);
	return 1;
	}
#else
WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) NO ESP-TUNNEL\r\n", ipsec_out_count));
#endif	// #ifdef IPSEC_ESP_TUNNEL_ENABLE
return 0;
}

#endif	// #ifdef	IPSEC_ENABLE
