// ************************************************************************************************
///
/// \file 			buffer.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _BUFFER_INCLUDED_
#define _BUFFER_INCLUDED_

#include "project.h"		// USER defines

#include "ethernet.h"
#include "ip.h"
#ifdef IPSEC_ENABLE
#include "ipsec.h"
#endif
#include "icmp.h"
#include "arp_rarp.h"

#ifndef	BUFFER_COUNT
#define	BUFFER_COUNT	     	4  	// 
#endif

// --------------------------------------------------------------------------------
// inline macros
// -------------------------------------------------------------------------------- 
// 14byte for Ethernet-Frame + 28byte ARP-Frame
#define TX_BUFFER2_ARP_SIZE		(ETH_HEADER_SIZE + ARP_FRAME_SIZE)		
// 14byte Ethernet-Frame + 20byte IP-Header + 0..64byte IPSec-Header-Trailer + 8byte ICMP-Header + 56byte ICMP-Data
#define TX_BUFFER2_ICMP_SIZE	(ETH_HEADER_SIZE+IP_HEADER_SIZE+IPSEC_ADD_SIZE+ICMP_HEADER_SIZE+ICMP_DATA_SIZE)	

// --------------------------------------------------------------------------------
// inline macros
// -------------------------------------------------------------------------------- 
#define TX_BUFFER2_SIZE		TX_BUFFER2_ICMP_SIZE       	// 2nd buffer, used ICMP size
#if(TX_BUFFER2_ARP_SIZE>TX_BUFFER2_SIZE)
#undef TX_BUFFER2_SIZE
#define TX_BUFFER2_SIZE		TX_BUFFER2_ARP_SIZE       	// 2nd buffer, used ARP size
#endif	//#if(TX_BUFFER2_ARP_SIZE>TX_BUFFER2_SIZE)

//  --------------------------------------------------------------------------------
//	Network <-> Host Byte Order
//	AVR use the Little-Endian (Low-Byte on First Address)
//	Network needs the Big-Endian (High-Byte on First Address)
//  -------------------------------------------------------------------------------- 
#define	HOST_NETWORK_ENDIAN_32BIT(out, in)		util_swap32(out, in)		// Host    -> Network Byte Order
#define	NETWORK_HOST_ENDIAN_32BIT(out, in)		util_swap32(out, in)	    // Network -> Host Byte Order
#define	HOST_NETWORK_ENDIAN_16BIT(out, in)		util_swap16(out, in)		// Host    -> Network Byte Order
#define	NETWORK_HOST_ENDIAN_16BIT(out, in)		util_swap16(out, in)	    // Network -> Host Byte Order

#pragma used+
//  --------------------------------------------------------------------------------
//	Buffer structure
//  -------------------------------------------------------------------------------- 
typedef struct{
	unsigned char		*data[BUFFER_COUNT];	// pointer to data
	unsigned int		datasize[BUFFER_COUNT];	// size of data
	unsigned char		gap;					// gap
	unsigned char		rtop;					// read top pointer
	unsigned char		wtop;					// write top pointer
} BUFFER_FRAME;                                    	

extern unsigned char	tx_frame2[TX_BUFFER2_SIZE];
extern unsigned int		tx_frame2_size;			 			// bytes to send in tx_frame2

unsigned char	buffer_process(void);
unsigned char	buffer_data_available(void);
void			buffer_clear(void);
unsigned char	buffer_free(void);
unsigned char	buffer_write_command(unsigned char *data, unsigned int datasize);
unsigned char	buffer_process_wait(void);

#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library buffer.c
#endif

#endif		// end of buffer.h
