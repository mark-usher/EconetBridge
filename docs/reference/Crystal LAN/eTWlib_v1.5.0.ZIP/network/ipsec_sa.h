// ************************************************************************************************
///
/// \file 			ipsec_sa.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		This document is part of embedded IPsec
///					Niklaus Schild and Christian Scheurer, HTI Biel/Bienne
///					This file contains code from the OpenSSL Project<BR>
///					Niklaus Schild <n.schild@gmx.ch> <BR>
///					portions Copyright (c) 1998-2003 OpenSSL (www.openssl.org)
///					easyToWeb-AVR and CodeVisionAVR C-Compiler:
///					Udo Jakobza - FTZ Leipzig; 04107 Leipzig; W�chterstr. 13
///					jakobza@e-technik.htwk-leipzig.de
///
/// \par License    
///					Redistribution and use in source and binary forms, with or without 
///					modification, are permitted provided that the following conditions are met:
///
///					1. Redistributions of source code must retain the above copyright notice,
///					   this list of conditions and the following disclaimer.
///					2. Redistributions in binary form must reproduce the above copyright notice,
///					    this list of conditions and the following disclaimer in the documentation
///					   and/or other materials provided with the distribution.
///					3. The name of the author may not be used to endorse or promote products
///					   derived from this software without specific prior written permission.
///
///					THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
///					WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
///					MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
///					EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
///					EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
///					OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
///					INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
///					CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
///					IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
///					OF SUCH DAMAGE.
///
// ************************************************************************************************

#ifndef _IPSEC_SA_INCLUDED_
#define _IPSEC_SA_INCLUDED_

#include "project.h"		// Project configuration

#include "ip.h"
#include "des.h"
#include "sha1.h"


// --------------------------------------------------------------------------------
// Security Association general
// -------------------------------------------------------------------------------- 
#ifndef IPSEC_MAX_SAD_ENTRIES
#define IPSEC_MAX_SAD_ENTRIES	(4)		// Defines the size of SAD entries in the SAD table.
#endif

#ifndef IPSEC_MAX_SPD_ENTRIES
#define IPSEC_MAX_SPD_ENTRIES	(8)		// Defines the size of SPD entries in the SPD table.
#endif

#define IPSEC_3DES_KEY_LEN		(DES_KEY_SIZE*3)		// Defines the length of a 3DES key in bytes
#define IPSEC_MAX_ENCKEY_LEN	(IPSEC_3DES_KEY_LEN)	// Defines the maximum encryption key length of our IPsec system
#define IPSEC_MAX_AUTHKEY_LEN   (SHA1_HASH_SIZE) 	  	// Maximum length of authentication keys

// --------------------------------------------------------------------------------
// Security Association SPD default
// -------------------------------------------------------------------------------- 
#ifndef IPSEC_SPD_DEF_SRC
#define IPSEC_SPD_DEF_SRC		{0, 0, 0, 0}	// SPD Default IP Source
#endif
#ifndef IPSEC_SPD_DEF_SRC_MASK
#define IPSEC_SPD_DEF_SRC_MASK	{0, 0, 0, 0}	// SPD Default IP Source Mask
#endif
#ifndef IPSEC_SPD_DEF_DEST
#define IPSEC_SPD_DEF_DEST		{0, 0, 0, 0}	// SPD Default IP Destination
#endif
#ifndef IPSEC_SPD_DEF_DEST_MASK
#define IPSEC_SPD_DEF_DEST_MASK	{0, 0, 0, 0}	// SPD Default IP Destination Mask
#endif
#ifndef IPSEC_SPD_DEF_SRC_PORT
#define IPSEC_SPD_DEF_SRC_PORT	(0)				// SPD Default IP Source Port
#endif
#ifndef IPSEC_SPD_DEF_DEST_PORT
#define IPSEC_SPD_DEF_DEST_PORT	(0)				// SPD Default IP Destination Port
#endif
#ifndef IPSEC_SPD_DEF_PROTOCOL
#define IPSEC_SPD_DEF_PROTOCOL	(0)				// SPD Default Protocol
												// 0x01 - Internet Control Message Protocol
												// 0x06 - Transmission Control Protocol
												// 0x11 - User Datagram Protocol
												// 0x32 - Encapsulating Security Payload Protocol
												// 0x33 - Authentication Header Protocol
#endif
#ifndef IPSEC_SPD_DEF_POLICY
#define IPSEC_SPD_DEF_POLICY	(2)				// SPD Default Policy - POLICY_APPLY==1; POLICY_BYPASS==2; POLICY_DISCARD==3 
#endif


// --------------------------------------------------------------------------------
// Security Association internal
// -------------------------------------------------------------------------------- 
#define IPSEC_SA_FREE			(0x0)	// Tells you that an SPD entry is free
#define IPSEC_SA_USED			(0xff)	// Tells you that an SPD entry is used

#define POLICY_APPLY			(1)		// Defines that the policy for this SPD entry means: apply IPsec.
#define POLICY_BYPASS			(2)		// Defines that the policy for this SPD entry means: bypass IPsec
#define POLICY_DISCARD			(3)		// Defines that the policy for this SPD entry means: the packet must be discarded

#define IPSEC_TUNNEL			(1)		// Defines TUNNEL mode as the mode the packet must be processed
#define IPSEC_TRANSPORT			(2)		// Defines TRANSPORT mode as the mode the packet must be processed

#define IPSEC_DES				(1)		// Defines DES as the encryption algorithm for an ESP packet
#define IPSEC_3DES				(2)		// Defines 3DES as the encryption algorithm for an ESP packet
#define IPSEC_IDEA				(3)		// Defines IDEA as the encryption algorithm for an ESP packet

#define IPSEC_HMAC_MD5			(1)		// Defines HMAC-MD5 as the authentication algorithm for an AH or an ESP packet
#define IPSEC_HMAC_SHA1			(2)		// Defines HMAC-SHA1 as the authentication algorithm for an AH or an ESP packet

#ifdef IPSEC_SA_MEMORY_SRAM
#define		SA_MEMORY
#endif

#ifndef	SA_MEMORY
#define	SA_MEMORY	eeprom
#endif

// --------------------------------------------------------------------------------
// Holds all the values used by one SA entry
// -------------------------------------------------------------------------------- 
typedef SA_MEMORY struct sad_entry_struct_mem
	{
	unsigned char	dest[IP_ADR_SIZE];		// IP destination address
	unsigned char 	dest_netaddr[IP_ADR_SIZE];	// IP destination network mask
	unsigned long	spi;					// Security Parameter Index
	unsigned char	protocol;				// IPsec protocol
	unsigned char	mode;					// tunnel or transport mode
	// this fields are used to maintain the current connection
	unsigned char	replay_win;				// reply windows size
	unsigned long	lifetime;				// lifetime of the SA (must be dropped if lifetime runs out)
	unsigned int	path_mtu;				// mean transmission unit
	// this fields are used for the cryptography
	unsigned char	enc_alg ;						// encryption algorithm
	unsigned char	enckey[IPSEC_MAX_ENCKEY_LEN];	// encryption key
	unsigned char	auth_alg;						// authentication algorithm
	unsigned char	authkey[IPSEC_MAX_AUTHKEY_LEN];	// authentication key
	unsigned long	*seq;  							// pointer to Sequence-Number
	unsigned int	*bitfield; 						// pointer to Bitmap-Number
	unsigned char	use_flag;						// this flag defines if the SAD entry is still used or not
	unsigned char	checksum; 				  		// checksum to prevent data manipulations
	// *@todo IV// for cbc-mode should be added to this structure
	}sad_entry_mem;

typedef struct sad_entry_struct
	{
	unsigned char	dest[IP_ADR_SIZE];		// IP destination address
	unsigned char 	dest_netaddr[IP_ADR_SIZE];	// IP destination network mask
	unsigned long	spi;					// Security Parameter Index
	unsigned char	protocol;				// IPsec protocol
	unsigned char	mode;					// tunnel or transport mode
	// this fields are used to maintain the current connection
	unsigned char	replay_win;				// reply windows size
	unsigned long	lifetime;				// lifetime of the SA (must be dropped if lifetime runs out)
	unsigned int	path_mtu;				// mean transmission unit
	// this fields are used for the cryptography
	unsigned char	enc_alg ;						// encryption algorithm
	unsigned char	enckey[IPSEC_MAX_ENCKEY_LEN];	// encryption key
	unsigned char	auth_alg;						// authentication algorithm
	unsigned char	authkey[IPSEC_MAX_AUTHKEY_LEN];	// authentication key
	unsigned long	*seq;  							// pointer to Sequence-Number
	unsigned int	*bitfield; 						// pointer to Bitmap-Number
	unsigned char	use_flag;						// this flag defines if the SAD entry is still used or not
	unsigned char	checksum; 				  		// checksum to prevent data manipulations
	// *@todo IV// for cbc-mode should be added to this structure
	}sad_entry;


// --------------------------------------------------------------------------------
// Holds all the values used by an SPD entry
// -------------------------------------------------------------------------------- 
typedef SA_MEMORY struct spd_entry_struct_mem
	{
	unsigned char	src[IP_ADR_SIZE];			// IP source address
	unsigned char	src_netaddr[IP_ADR_SIZE];	// net mask for source address
	unsigned char	dest[IP_ADR_SIZE];			// IP destination address
	unsigned char	dest_netaddr[IP_ADR_SIZE];	// net mask for the destination address
	unsigned int	src_port;					// source port number
	unsigned int	dest_port;					// destination port number
	unsigned char	protocol;					// the transport layer protocol
	unsigned char	policy ;					// defines how this packet must be processed
	SA_MEMORY sad_entry_mem	*sa;  				// pointer to the associated SA
	unsigned char	use_flag; 					// tells whether the entry is free or not
	unsigned char	checksum; 					// checksum to prevent data manipulations
	}spd_entry_mem;

typedef struct spd_entry_struct
	{
	unsigned char	src[IP_ADR_SIZE];			// IP source address
	unsigned char	src_netaddr[IP_ADR_SIZE];	// net mask for source address
	unsigned char	dest[IP_ADR_SIZE];			// IP destination address
	unsigned char	dest_netaddr[IP_ADR_SIZE];	// net mask for the destination address
	unsigned int	src_port;					// source port number
	unsigned int	dest_port;					// destination port number
	unsigned char	protocol;					// the transport layer protocol
	unsigned char	policy ;					// defines how this packet must be processed
	sad_entry		*sa;  						// pointer to the associated SA
	unsigned char	use_flag; 					// tells whether the entry is free or not
	unsigned char	checksum; 					// checksum to prevent data manipulations
	}spd_entry;

typedef flash struct spd_entry_struct_flash
	{
	unsigned char	src[IP_ADR_SIZE];			// IP source address
	unsigned char	src_netaddr[IP_ADR_SIZE];	// net mask for source address
	unsigned char	dest[IP_ADR_SIZE];			// IP destination address
	unsigned char	dest_netaddr[IP_ADR_SIZE];	// net mask for the destination address
	unsigned int	src_port;					// source port number
	unsigned int	dest_port;					// destination port number
	unsigned int	prot_pol;					// 8bit the transport layer protocol
												// 8bit defines how this packet must be processed
	sad_entry		*sa;  						// pointer to the associated SA
	unsigned int	use_flag_check; 			// 8bit tells whether the entry is free or not
							 					// 8bit checksum to prevent data manipulations
	}spd_entry_fl;

// --------------------------------------------------------------------------------
// This structure holds pointers which together define the Security Policy Database
// -------------------------------------------------------------------------------- 
typedef SA_MEMORY struct spd_table_struct_mem
{
	spd_entry_mem	entry[IPSEC_MAX_SPD_ENTRIES];	// inbound SPD
}spd_table_mem;

typedef struct spd_table_struct
{
	spd_entry	entry[IPSEC_MAX_SPD_ENTRIES];		// inbound SPD
}spd_table;

typedef SA_MEMORY struct sad_table_struct_mem
{
	sad_entry_mem	entry[IPSEC_MAX_SAD_ENTRIES];	// inbound SAD
}sad_table_mem;

typedef struct sad_table_struct
{
	sad_entry	entry[IPSEC_MAX_SAD_ENTRIES];		// inbound SAD
}sad_table;

typedef struct sad_seq_table_struct
{
	unsigned long	seq[IPSEC_MAX_SAD_ENTRIES];			// Sequence-Number
	unsigned int	bitmap[IPSEC_MAX_SAD_ENTRIES];		// Bitmap to detect replays
}sad_seq_table;


typedef SA_MEMORY struct database_set_netif_struct
{
	SA_MEMORY spd_table_mem		*inbound_spd;		// inbound SPD
	SA_MEMORY spd_table_mem		*outbound_spd;		// outbound SPD
	SA_MEMORY sad_table_mem		*inbound_sad;		// inbound SAD
	SA_MEMORY sad_table_mem		*outbound_sad;		// outbound SAD
}db_set_netif;


#pragma used+

extern flash spd_entry_fl spd_default_flash;

//---------------------------------------------------------------------------------
// Database functions
//---------------------------------------------------------------------------------
SA_MEMORY db_set_netif	*ipsec_sa_load_database(spd_table *inbound_spd_data, spd_table *outbound_spd_data, 
									sad_table *inbound_sad_data, sad_table *outbound_sad_data);
void					ipsec_sa_release_database(void);
//---------------------------------------------------------------------------------
// SPD functions
//---------------------------------------------------------------------------------
SA_MEMORY spd_entry_mem *ipsec_sa_spd_get_free(SA_MEMORY spd_table_mem *table);
SA_MEMORY spd_entry_mem	*ipsec_sa_spd_add(spd_entry *new_entry, SA_MEMORY spd_table_mem *table);
void					ipsec_sa_spd_add_sa(SA_MEMORY spd_entry_mem *entry, SA_MEMORY sad_entry_mem *sa);
unsigned char			ipsec_sa_spd_del(SA_MEMORY spd_entry_mem *entry, SA_MEMORY spd_table_mem *table);
SA_MEMORY spd_entry_mem *ipsec_sa_spd_lookup_in(IP_HEADER_STRUCTURE *header, void *inner_header);
SA_MEMORY spd_entry_mem *ipsec_sa_spd_lookup_out(IP_HEADER_STRUCTURE *header, void *inner_header);
void 					ipsec_sa_spd_flush(SA_MEMORY spd_table_mem *table, flash spd_entry_fl *def_entry);
//---------------------------------------------------------------------------------
// SAD functions
//---------------------------------------------------------------------------------
SA_MEMORY sad_entry_mem	*ipsec_sa_sad_get_free(SA_MEMORY sad_table_mem *table);
SA_MEMORY sad_entry_mem	*ipsec_sa_sad_add(sad_entry *entry, SA_MEMORY sad_table_mem *table);
unsigned char			ipsec_sa_sad_del(SA_MEMORY sad_entry_mem *entry, SA_MEMORY sad_table_mem *table);
SA_MEMORY sad_entry_mem	*ipsec_sa_sad_lookup(unsigned char *dest, unsigned char proto, unsigned long spi, SA_MEMORY sad_table_mem *table);
SA_MEMORY sad_entry_mem	*ipsec_sa_sad_lookup_in(unsigned char *dest, unsigned char proto, unsigned long spi);
void					ipsec_sa_sad_flush(SA_MEMORY sad_table_mem *table);

#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library ipsec_sa.c
#endif

#endif	// #ifndef _SA_INCLUDED_
