// ************************************************************************************************
///
/// \file 			ati.c
/// \brief			AT interface
///
/// \todo			More testing is needed. The state of the module is still EXPERIMENTAL
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		Mirco Fuchs, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <io.h>
#include <stdio.h>
#include <string.h>
#include <delay.h>
#include <ctype.h>
#include "ati.h"
#ifdef ATI_DEBUG
#include "ati_debug.h"
#include "debug.h"
#endif

#pragma regalloc-
unsigned char ati_tx_buffer[ATI_TX_BUFFER_SIZE];
unsigned char ati_rx_buffer[ATI_RX_BUFFER_SIZE];
unsigned char ati_user_buffer[ATI_RX_BUFFER_SIZE];

unsigned char *p_ati_tx_buffer_s;	// Pointer to last written command in TX-Buffer
unsigned char *p_ati_tx_buffer_w;	// Pointer to next free cell in TX-Buffer
unsigned char *p_ati_rx_buffer;

unsigned char *p_ati_response_start;
unsigned char *p_ati_response_stop;

unsigned char ati_disconnect_flag=0;

#ifdef ATI_ANSWER_ENABLE_DEFAULT		
unsigned char ati_answer_flag=ATI_ANSWER_ENABLED;		//enabled auto-answering incomming call
#else
unsigned char ati_answer_flag=ATI_ANSWER_DISABLED;		//disable auto-answering incomming call
#endif

unsigned char ati_old_time;
unsigned char ati_timeout_next_char;         
unsigned int  ati_timeout_answer;       
eeprom unsigned int ati_timeout_answer_eeprom = ATI_TIMEOUT_ANSWER;

ATI_STATE		   		ati_state;
ATI_STATE				ati_state_old;

ATI_DEVICE_MODE			ati_device_mode;    
ATI_DEVICE_MODE			ati_device_nextmode;

ATI_DEVICE_RESPONSE		ati_device_response;
ATI_USER_INFO			ati_user_info;
#pragma regalloc+                       

void ati_send_command(void);
unsigned char ati_check_tx_buffer(void);
unsigned char ati_rsp_awaited(void);
void ati_check_rx_buffer(void);

//******************************************************************************
// Description: checks the actual phase of the ati-state-machine
// Input	  : 
// Output     : 
// Indication : 
//******************************************************************************
void ati_state_machine(void)
{
unsigned char ret;		//to store the return-value of the functions

switch(ati_state)
	{
	case ATI_STATE_BUFFER_EMPTY: 
			break;
	case ATI_STATE_BUFFER_FILLED:
			ati_send_command(); 
			if(ati_state != ATI_STATE_RECEIVE_DATA)
				ati_state = ATI_STATE_RSP_AWAITED;
			else
				ati_state_old = ATI_STATE_RSP_AWAITED;
			break;
	case ATI_STATE_CHECK_BUFFER: 
	        ret = ati_check_tx_buffer();
	        if(ati_state != ATI_STATE_RECEIVE_DATA)
				{
		        if(ret == ATI_STATE_BUFFER_FILLED)
		        	ati_state = ATI_STATE_BUFFER_FILLED;
		        else 
		        	ati_state = ATI_STATE_BUFFER_EMPTY;
				}
			else
				{
				if(ret == ATI_STATE_BUFFER_FILLED)
					ati_state_old = ATI_STATE_BUFFER_FILLED;
		        else 
		        	ati_state_old = ATI_STATE_BUFFER_EMPTY;				
				}		
			break;
	case ATI_STATE_RSP_AWAITED: 
			ret = ati_rsp_awaited();
			if(ati_state != ATI_STATE_RECEIVE_DATA)
				{
				if(ret == ATI_STATE_CHECK_BUFFER)
					ati_state = ATI_STATE_CHECK_BUFFER;
				else
					ati_state = ATI_STATE_RSP_AWAITED;
	            }                      
		   	else
				{
				if(ret == ATI_STATE_CHECK_BUFFER)
					ati_state_old = ATI_STATE_CHECK_BUFFER;
				else
					ati_state_old = ATI_STATE_RSP_AWAITED;
	            }                      
			break;
	case ATI_STATE_RECEIVE_DATA: 
			ati_check_rx_buffer();
			if(ati_timeout_next_char == 0)
				ati_state = ati_state_old;
			break;
	}// end switch
#ifdef ATI_DEBUG
if (ati_debug_flag)
	{
	ati_debug_print_state_change();
	ati_debug_print_mode_change();
	}
#endif
}              
                                                                                
//******************************************************************************
// Description: initialisation of the ATI state machine and the ATI
// Input	  : 
// Output     : 
// Indication : 
//******************************************************************************
void ati_init(void)
{
#ifdef ATI_DEBUG
ati_debug_init();

if (ati_debug_flag)
	putsf("ATI Starting initialisation ...\r");
#endif
p_ati_tx_buffer_w = ati_tx_buffer;				// initialisation of pointers to
p_ati_tx_buffer_s = ati_tx_buffer;				// tx and rx buffer
p_ati_rx_buffer = ati_rx_buffer;
ati_state = ATI_STATE_BUFFER_EMPTY;				// spec. phase and misc flags
ati_device_response = ATI_DEVICE_RESPONSE_NO;	// of the state machine
ati_device_mode = ATI_DEVICE_MODE_COMMAND;		// spec. mode of the AT-Interface
ati_device_nextmode = ATI_DEVICE_MODE_COMMAND;

#ifdef AT_DEVICE_MODEM
//DDRF|=0x08;
//PORTF&=~0x08;
//delay_us(200);
//PORTF|=0x08;		// reset modem
//delay_ms(250);
DDRB.4 = 1;         // DTR-Signal
PORTB.4 = 1;        // DTR = 1
ati_write_data_flash("ATZ");    //load stored settings
ati_write_data_flash("AT&D0");  //modem ignores DTR
ati_write_data_flash("AT&K0");  //flow control disabled
ati_write_data_flash("ATM0");   //speaker always off
//ati_write_data_flash("ATM2");   //speaker always on
ati_write_data_flash("ATX3");   //inner dialtone
#endif

#ifdef AT_DEVICE_BLUETOOTH
AT_DEVICE_INTERFACE_IRQ_DISABLE();
DDRF|=0x08;
PORTF&=~0x08;
delay_ms(100);
PORTF|=0x08;
delay_ms(5000);		
AT_DEVICE_INTERFACE_IRQ_ENABLE();
ati_write_data_flash("ATZ");    		//load stored settings
ati_write_data_flash("ATS0 = 0");    //no automatic call acceptance
#endif
#ifdef ATI_DEBUG
if(ati_debug_flag)
	putsf("ATI initialised\r");
#endif
}


//******************************************************************************
// Description: if response occured, eval response string; organise Timeout
// Input	  : 
// Output     : 
// Indication : 
//******************************************************************************
unsigned char ati_rsp_awaited(void)
{
unsigned char *p_ati_answer;
unsigned char response_found = 0;
unsigned char lf_passed = 0;
unsigned char response_end = 0;
unsigned char response_length;
#ifdef ATI_DEBUG
unsigned char *p_temp;
#endif

p_ati_answer = p_ati_response_stop;
switch(ati_device_response)
    {
    case ATI_DEVICE_RESPONSE_YES:
			*p_ati_answer = '\0';
			while(response_found == 0)
				{
				switch(*p_ati_answer--)
					{
					case ATI_LF:
							lf_passed = 1;
							break;
					case ATI_CR:
							if((response_end == 0) && (lf_passed == 1))
								{
								response_end = 1;
								lf_passed = 0;
								}
							if((response_end == 1) && (lf_passed == 1))
								{
								p_ati_answer += 3;
								lf_passed = 0;
								response_end = 0;
								response_found = 1;
								}	
							break;	
					default:
							lf_passed = 0;
					} //end switch
				} //end while
			response_length = (unsigned char)((p_ati_response_stop + 1) - p_ati_response_start);
			strncpy(ati_user_buffer, p_ati_response_start, response_length);
			ati_user_info = ATI_USER_INFO_BUFFER_FILLED;
			#ifdef ATI_DEBUG
			if(ati_debug_flag)
				{
				p_temp=p_ati_response_start;
				printf("ATI AT-Device answer: \"");
				while(*p_temp!=0)
					{
					if(isprint(*p_temp))
						printf("%c", *p_temp);
					p_temp++;
					}
				putsf("\"\r");
				}
			#endif
			switch(ati_device_mode)
				{
				case ATI_DEVICE_MODE_COMMAND:
						break;
				case ATI_DEVICE_MODE_CARRIER:
	    				if(ati_device_nextmode == ATI_DEVICE_MODE_ONLINE)
	    					{
		    				if(strncmpf(p_ati_answer,"CONNECT",7) == 0)
								{
								ati_device_mode = ATI_DEVICE_MODE_ONLINE;
								ati_device_nextmode = ATI_DEVICE_MODE_ONLINE;
								#ifdef ATI_DEBUG
								if(ati_debug_flag)
									putsf("ATI Connected. Online mode\r");
								#endif							
								}
							else //e.g. if "NO CARRIER"
								{
								//nach ATA, ATD oder ATO
								ati_device_mode = ATI_DEVICE_MODE_COMMAND;
								ati_device_nextmode = ATI_DEVICE_MODE_COMMAND;
		    					#ifdef ATI_DEBUG
								if(ati_debug_flag)
									putsf("ATI Conection failed. Command mode\r");
								#endif
	    						ati_write_data_flash("ATH");
								}						
							}// end if(ati_device_nextmode == ATI_DEVICE_MODE_ONLINE)
						else if(ati_device_nextmode == ATI_DEVICE_MODE_COMMAND_ONLINE)
							{
							if(strncmpf(p_ati_answer,"OK",2) == 0)
								{
								//nach +++ und AT<ATI_CR>
								#ifdef ATI_DEBUG
								if(ati_debug_flag)
									putsf("ATI Online command mode\r");
								#endif
								ati_device_mode = ATI_DEVICE_MODE_COMMAND_ONLINE;
								ati_device_nextmode = ATI_DEVICE_MODE_COMMAND_ONLINE;
								if(ati_disconnect_flag)
									{
									ati_disconnect_flag = 0;
									ati_write_data_flash("ATH");
									}
								}
							else
								{
								#ifdef ATI_DEBUG
								if(ati_debug_flag)
									putsf("ATI Connection failed. Command mode\r");
								#endif
	    						ati_write_data_flash("ATH");
								ati_device_mode = ATI_DEVICE_MODE_COMMAND;
								ati_device_nextmode = ATI_DEVICE_MODE_COMMAND;
								}
							}
						else if(ati_device_nextmode == ATI_DEVICE_MODE_COMMAND)
							{
							//nach eingabe von ath            
					  		if((strncmpf(p_ati_answer,"OK",2) == 0) ||
					  		    (strncmpf(p_ati_answer,"NO CARRIER",10) == 0))
					  			{
								#ifdef ATI_DEBUG
								if(ati_debug_flag)
									putsf("ATI Command mode\r");				  			
								#endif
				  				ati_device_mode = ATI_DEVICE_MODE_COMMAND;
					  			ati_device_nextmode = ATI_DEVICE_MODE_COMMAND;
					  			}
							}
						break; // case ATI_DEVICE_MODE_CARRIER				
				} //end switch(ati_device_mode)
            ati_device_response = ATI_DEVICE_RESPONSE_NO;
            return ATI_STATE_CHECK_BUFFER;
            break;
    case ATI_DEVICE_RESPONSE_NO:
             if(ati_old_time != (unsigned char) counter_10ms_16bit)
				{
				ati_old_time = (unsigned char) counter_10ms_16bit;
				ati_timeout_answer--;
				}
			if(ati_timeout_answer == 0)
				{
				#ifdef ATI_DEBUG
    			if(ati_debug_flag)
					putsf("ATI TIMEOUT\r");
				#endif
	            ati_user_info = ATI_USER_INFO_TIMEOUT;
				//a stabil functionality of the AT-device is not longer guaranted
				//use ati_get_answer to detect ATI_USER_INFO_TIMEOUT, then reset the device
				//using ati_init();
				ati_device_mode = ATI_DEVICE_MODE_COMMAND;
				ati_device_nextmode = ATI_DEVICE_MODE_COMMAND;
	            return ATI_STATE_CHECK_BUFFER;
	            }
			return ATI_STATE_RSP_AWAITED;
            break;
    } //end switch
} //unsigned char ati_rsp_awaited(void)

//******************************************************************************
// Description: send one command
// Input	  : 
// Output     :
// Indication : 
//******************************************************************************
void ati_send_command(void)
{
unsigned char ati_strlength;

ati_strlength = *p_ati_tx_buffer_s++;

#ifdef ATI_DEBUG
if(ati_debug_flag)
	putsf("ATI Waiting for AT-Device answer\r");
#endif

while(ati_strlength-- > 0) 
    {
    if(p_ati_tx_buffer_s > &ati_tx_buffer[ATI_TX_BUFFER_SIZE - 1])
        {
        p_ati_tx_buffer_s = ati_tx_buffer;
        } //end if
    AT_DEVICE_INTERFACE_SEND_DATA(*p_ati_tx_buffer_s++);
    } //end while
AT_DEVICE_INTERFACE_SEND_DATA(ATI_CR);
if(p_ati_tx_buffer_s > &ati_tx_buffer[ATI_TX_BUFFER_SIZE - 1])
    {
    p_ati_tx_buffer_s = ati_tx_buffer;
    } //end if
ati_timeout_answer = ati_timeout_answer_eeprom;
//ati_timeout_answer = ATI_TIMEOUT_ANSWER;
ati_user_info = ATI_USER_INFO_BUFFER_EMPTY;
} //end void ati_send_command(void)



//******************************************************************************
// Description: check tx-buffer for valid string to send
// Input	  : 
// Output     : 
// Indication : 
//******************************************************************************
unsigned char ati_check_tx_buffer(void)
{
if(p_ati_tx_buffer_w != p_ati_tx_buffer_s)
	return ATI_STATE_BUFFER_FILLED;
else
	return ATI_STATE_BUFFER_EMPTY;
}

//******************************************************************************
// Description: check rx-buffer for valid response string
// Input	  : 
// Output     : 
// Indication : 
//******************************************************************************
void ati_check_rx_buffer(void)
{
unsigned char *p_ati_rx_buffer_local = ati_rx_buffer;
char response_begin = 0;
char cr_passed = 0;

if(ati_old_time != (unsigned char) counter_10ms_16bit)
	{
	ati_old_time = (unsigned char) counter_10ms_16bit;
	ati_timeout_next_char--;
	}
if(ati_timeout_next_char == 0)
	{
	while(p_ati_rx_buffer_local < p_ati_rx_buffer)
		{
		switch(*p_ati_rx_buffer_local++)
			{
			case ATI_CR: 
					cr_passed = 1;
					break;
			case ATI_LF: 
					if(cr_passed && (response_begin == 0)) 
						{
						cr_passed = 0;
						response_begin = 1;
						p_ati_response_start = (p_ati_rx_buffer_local - 2);
						p_ati_rx_buffer_local = (p_ati_rx_buffer - 2);
						}
					else if(cr_passed && (response_begin == 1))
						{
						cr_passed = 0;
						response_begin = 0;
						p_ati_response_stop = p_ati_rx_buffer;
						if(ati_state_old == ATI_STATE_RSP_AWAITED)
		                    ati_device_response = ATI_DEVICE_RESPONSE_YES;
						else
							{
							if(strncmpf((p_ati_response_start + 2),"RING",4) == 0)
								{
								#ifdef ATI_DEBUG
								if(ati_debug_flag)
							   		putsf("ATI Incomming Call\r");
								#endif
								if(ati_answer_flag == ATI_ANSWER_ENABLED)								
									ati_write_data_flash("ATA");
								} //end if
							} //end else
						} //end else if
					break;
			default:
		    	    cr_passed = 0;
			} //end switch
		} //end while
	p_ati_rx_buffer = ati_rx_buffer;
	} //end if(ati_timeout_next_char == 0)
} //end void ati_check_rx_buffer(void)


//******************************************************************************
// Description: move received char to rx buffer
// Input	  : received_data --> char from UART
// Output     : 
// Indication : 
//******************************************************************************
void ati_receive_data(unsigned char received_data)
{
#ifdef ATI_RECEIVE_DEBUG
if(ati_debug_flag)
	putchar(received_data);
#endif
if(ati_device_mode != ATI_DEVICE_MODE_ONLINE)
	{
	if(ati_state != ATI_STATE_RECEIVE_DATA) ati_state_old = ati_state;
	ati_state = ATI_STATE_RECEIVE_DATA;
	ati_timeout_next_char = ATI_TIMEOUT_NEXT_CHAR;
	*p_ati_rx_buffer++ = received_data;
	}
else if(ati_device_mode == ATI_DEVICE_MODE_ONLINE)
	{
	RECEIVE_FUNCTION(received_data);	// go to PPP-Layer
	}
} //end void ati_receive_data(unsigned char reveived_data)             




////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//API FUNCTIONS                                                               //
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

//******************************************************************************
// Description: write string located in flash to tx-buffer
// Input	  : 
// Output     : ATI_WRITE_ONLY_AT_COMMANDS	- only at-commands allowed in this mode
//				ATI_WRITE_MEMORY_OVERFLOW	- memory overflow
//             	ATI_WRITE_COMMAND_WROTE		- command succesfully wrote to tx-buffer
//              ATI_WRITE_ACCESS_DENIED		- no command allowed in this mode
//			    ATI_WRITE_DATA_SEND			- data successfully send
// Indication : 
//******************************************************************************
unsigned char ati_write_data_flash(flash unsigned char *ati_data)	
{
unsigned char ati_string[ATI_STRING_LENGTH];

if(strlenf(ati_data) < ATI_STRING_LENGTH)
	strcpyf(ati_string, ati_data);
return ati_write_data(ati_string);
} //unsigned char ati_write_data_flash(flash unsigned char *ati_data)

//******************************************************************************
// Description: write string to tx-buffer
// Input	  : 
// Output     : ATI_WRITE_ONLY_AT_COMMANDS	- only at-commands allowed in this mode
//				ATI_WRITE_MEMORY_OVERFLOW	- memory overflow
//              ATI_WRITE_COMMAND_WROTE		- command succesfully wrote to tx-buffer
//              ATI_WRITE_ACCESS_DENIED		- no command allowed in this mode
//			    ATI_WRITE_DATA_SEND			- data successfully send
// Indication : 
//******************************************************************************
unsigned char ati_write_data(unsigned char *ati_data)	
{
unsigned char ati_strlength;
unsigned char first_char = 1;
unsigned char offset_a;
unsigned char offset_b;
unsigned char *p_temp;

// switch chars in command from lower to upper case
p_temp=ati_data;
while(*p_temp!=0)
	{
	*p_temp=toupper(*p_temp);
	p_temp++;
	}
switch(ati_device_mode)
	{
	case ATI_DEVICE_MODE_COMMAND:
	        if(strncmpf(ati_data,"AT",2) != 0)
	            {
	            #ifdef ATI_DEBUG
                if(ati_debug_flag)
	                putsf("ATI Only AT-commands allowed in this mode\r");
	            #endif
	            return ATI_WRITE_ONLY_AT_COMMANDS;
	            }
	        switch(*(ati_data + 2))
	            {
	            case 'A': // ATA
						#ifdef ATI_DEBUG
						if(ati_debug_flag)
							putsf("ATI Answering incomming call..\r");	
						#endif
                        ati_device_mode = ATI_DEVICE_MODE_CARRIER;
                        ati_device_nextmode = ATI_DEVICE_MODE_ONLINE;
	                    break;
	            case 'D': // ATD
						#ifdef ATI_DEBUG
						if(ati_debug_flag)
							putsf("ATI Dialing ..\r");						
						#endif						
                        ati_device_mode = ATI_DEVICE_MODE_CARRIER;
						ati_device_nextmode = ATI_DEVICE_MODE_ONLINE;
	                    break;
	     		case 'H': // ATH
	     				#ifdef ATI_DEBUG
						if(ati_debug_flag)
							putsf("ATI Hanging up\r");	     				
	     				#endif
						ati_device_mode = ATI_DEVICE_MODE_CARRIER;
						ati_device_nextmode = ATI_DEVICE_MODE_COMMAND;
	            default:
	                    ati_device_mode = ATI_DEVICE_MODE_COMMAND; 
	                    ati_device_nextmode = ATI_DEVICE_MODE_COMMAND;
	            }
	        break;
	case ATI_DEVICE_MODE_CARRIER:
	        #ifdef ATI_DEBUG
			if(ati_debug_flag)
	            putsf("ATI No command allowed in this mode!\r");
	        #endif
	        return ATI_WRITE_ACCESS_DENIED;
	        break;
	case ATI_DEVICE_MODE_ONLINE:
	        if(strncmpf(ati_data,"+++",3) == 0) 
	        	{
				#ifdef ATI_DEBUG
				if(ati_debug_flag)
					putsf("ATI Entering online command mode 2.5sec wait ...\r");   
				#endif
				delay_ms(1000);
				AT_DEVICE_INTERFACE_SEND_DATA('+');
				AT_DEVICE_INTERFACE_SEND_DATA('+');
				AT_DEVICE_INTERFACE_SEND_DATA('+');
				delay_ms(1500);
				strcpyf(ati_data, "AT");
	        	ati_device_mode = ATI_DEVICE_MODE_CARRIER;
	        	ati_device_nextmode = ATI_DEVICE_MODE_COMMAND_ONLINE;
	        	}
	        else 
	            {
				if((strncmpf(ati_data,"AT",2) == 0))
	            	{
		            #ifdef ATI_DEBUG
					if(ati_debug_flag)
		                putsf("ATI Command entered + Online\r");
		            #endif
		            }
				while(*ati_data != '\0')
					AT_DEVICE_INTERFACE_SEND_DATA(*ati_data++);
	            return ATI_WRITE_DATA_SEND;
	            }
	        break;
    case ATI_DEVICE_MODE_COMMAND_ONLINE:
	        if(strncmpf(ati_data,"AT",2) != 0)
	            {
	            #ifdef ATI_DEBUG
				if(ati_debug_flag)
	                putsf("ATI Only AT-commands allowed in this mode.\r");
	            #endif
	            return ATI_WRITE_ONLY_AT_COMMANDS;
	            }
			switch(*(ati_data + 2))
	            {
	            case 'H': //ATH
						#ifdef ATI_DEBUG
						if(ati_debug_flag)
							putsf("ATI Hanging Up\r");						
						#endif
                        ati_device_mode = ATI_DEVICE_MODE_CARRIER;
                        ati_device_nextmode = ATI_DEVICE_MODE_COMMAND;
	                    break;
	     		case 'O': //ATO                   
	     				#ifdef ATI_DEBUG
						if(ati_debug_flag)
							putsf("ATI Returning to online mode\r");						
						#endif
                        ati_device_mode = ATI_DEVICE_MODE_CARRIER;
                        ati_device_nextmode = ATI_DEVICE_MODE_ONLINE;
	                    break;
	            default:
	                    ati_device_mode = ATI_DEVICE_MODE_COMMAND_ONLINE; 
	                    ati_device_nextmode = ATI_DEVICE_MODE_COMMAND_ONLINE;
	            }
            break;
	} //end switch(ati_device_mode)
#ifdef ATI_DEBUG
if(ati_debug_flag)
	ati_debug_print_mode_change();
#endif
ati_strlength = (unsigned char) strlen(ati_data);
offset_a = 0;
offset_b = 0;
while(ati_strlength > 0)
	{
	if((p_ati_tx_buffer_w + offset_a + 1) != p_ati_tx_buffer_s)
		{
		if(first_char)
			{
			*(p_ati_tx_buffer_w + offset_a++) = ati_strlength;
			first_char = 0;
			} //end if(first_char)
		else
			{
			*(p_ati_tx_buffer_w + offset_a++) = *(ati_data + offset_b++);
			ati_strlength--;
			} //end else
		if((p_ati_tx_buffer_w + offset_a) == &ati_tx_buffer[ATI_TX_BUFFER_SIZE])
			{
			if((ati_tx_buffer + ati_strlength) < p_ati_tx_buffer_s)
				{
				p_ati_tx_buffer_w = ati_tx_buffer;
				offset_a = 0;
				} //end if
			else
				{
				#ifdef ATI_DEBUG
				if(ati_debug_flag)                
                	putsf("ATI Memory overflow, try again\r");
                #endif
                return ATI_WRITE_MEMORY_OVERFLOW;
				} //end else
			} //end if
		} //end if
	else
		{
		#ifdef ATI_DEBUG
		if(ati_debug_flag)                
        putsf("ATI Memory overflow, try again\r");
        #endif
        return ATI_WRITE_MEMORY_OVERFLOW;	
		} //end else
	} //end while(ati_strlength > 0)
p_ati_tx_buffer_w += offset_a;
if(ati_state == ATI_STATE_BUFFER_EMPTY)
	ati_state = ATI_STATE_CHECK_BUFFER;
//for auto-answering-call support
else if((ati_state == ATI_STATE_RECEIVE_DATA) && (ati_state_old == ATI_STATE_BUFFER_EMPTY))
	{
	ati_state_old = ATI_STATE_CHECK_BUFFER;
	}
return ATI_WRITE_COMMAND_WROTE;
} //end unsigned char ati_write_data(unsigned char ati_data)


//******************************************************************************
// Description: returns current mode of the AT-Interface
// Input	  : ATI_ANSWER_HIDE - hide function answer
//				ATI_ANSWER_SHOW - show function answer (usefull in debug-mode)
// Output     :	ATI_MODE_COMMAND 	 			- AT command mode
//				ATI_MODE_ONLINE_ENTERING 		- Entering online mode	
//				ATI_MODE_ONLINE 				- online mode
//				ATI_MODE_ONLINE_COMMAND_ENTER	- Entering online command mode
//				ATI_MODE_ONLINE_COMMAND			- online AT command mode
//				ATI_MODE_COMMAND_ENTERING		- Returning to AT command mode
// Indication : 
//******************************************************************************
unsigned char ati_get_device_mode(unsigned char show_answer)
{
#ifdef ATI_DEBUG
if((ati_debug_flag) && show_answer)
	printf("ATI ati_device_mode: %p\r\n", ati_device_mode_debug[ati_device_mode]);
#else
show_answer=0;
#endif
switch(ati_device_mode)
	{
	case ATI_DEVICE_MODE_COMMAND:
			return ATI_MODE_COMMAND;
	case ATI_DEVICE_MODE_ONLINE:
			return ATI_MODE_ONLINE;
	case ATI_DEVICE_MODE_COMMAND_ONLINE:
			return ATI_MODE_ONLINE_COMMAND;
	case ATI_DEVICE_MODE_CARRIER:
	        #ifdef ATI_DEBUG
			if((ati_debug_flag) && show_answer)
				printf("ATI ati_device_nextmode: %p\r\n", ati_device_mode_debug[ati_device_nextmode]);
			#endif
			switch(ati_device_nextmode)
				{
				case ATI_DEVICE_MODE_COMMAND:
						return ATI_MODE_COMMAND_ENTERING;
				case ATI_DEVICE_MODE_ONLINE:
						return ATI_MODE_ONLINE_ENTERING;
				case ATI_DEVICE_MODE_COMMAND_ONLINE:
						return ATI_MODE_ONLINE_COMMAND_ENTER;
				} //end switch(ati_device_nextmode)
			break;
	} //end switch(ati_device_mode)
}

//******************************************************************************
// Description: Returns a pointer to at-answer string, if new is available
// Input	  :
// Output     : RETURN 	 - pointer to string (zero if no data)
// Indication : 
//******************************************************************************
unsigned char* ati_get_new_answer(void)
{
switch(ati_user_info)
	{
	case ATI_USER_INFO_BUFFER_FILLED:
//			ati_user_info = ATI_USER_INFO_BUFFER_EMPTY;
			#ifdef ATI_DEBUG
			if(ati_debug_flag)		
				{
				putsf("ATI Answer:\r");
				puts(ati_user_buffer);
				printf("\r");
				}
			#endif
			return ati_user_buffer;
			break;
	case ATI_USER_INFO_BUFFER_EMPTY:
			#ifdef ATI_DEBUG
			if(ati_debug_flag)		
				putsf("ATI No new answer available!\r");
			#endif
			break;
	case ATI_USER_INFO_TIMEOUT:
			#ifdef ATI_DEBUG
			if(ati_debug_flag)		
				putsf("ATI Timeout occured\r");
			#endif
			break;
	}
return 0x0;
}

//******************************************************************************
// Description: Initiates connection to destination
// Input	  : 
// Output     : ATI_CONNECT_DISCONNECT_OK	 - command written to tx-buffer
//				ATI_CONNECT_DISCONNECT_ERROR - error		
// Indication : 
//******************************************************************************
unsigned char ati_connect(unsigned char *destination)
{
unsigned char ati_string[ATI_STRING_LENGTH];

strcpyf(ati_string,"ATD");
strcat(ati_string, destination);
if(ati_write_data(ati_string) == ATI_WRITE_COMMAND_WROTE)
	return ATI_CONNECT_DISCONNECT_OK;
else
	return ATI_CONNECT_DISCONNECT_ERROR;
}

//*********************************************************************************
// Description	: Initiates disconnection from destination
// Input	   	: none
// Output   	: ATI_CONNECT_DISCONNECT_OK	   - o.k.
//				  ATI_CONNECT_DISCONNECT_ERROR - error
// Indication	: none
//*********************************************************************************
unsigned char ati_disconnect(void)
{
if(!ati_disconnect_flag)
	{ 	
	switch(ati_get_device_mode(ATI_ANSWER_HIDE))
		{
		case ATI_MODE_ONLINE:
				if(ati_write_data_flash("+++") == ATI_WRITE_COMMAND_WROTE)
					{
					ati_disconnect_flag = 1;
			  		#ifdef ATI_DEBUG
				    if(ati_debug_flag)
						putsf("ATI Disconnecting ...\r");
					#endif
					return ATI_CONNECT_DISCONNECT_OK;
					}
				else 
			  		#ifdef ATI_DEBUG
				    if(ati_debug_flag)
						putsf("ATI Error\r");
					#endif
					return ATI_CONNECT_DISCONNECT_ERROR;
				break;
		default:
				return ATI_CONNECT_DISCONNECT_ERROR;
		} //end switch(ati_get_device_mode(ATI_ANSWER_HIDE))
	} //end if(!ati_disconnect_flag)
else
	return ATI_CONNECT_DISCONNECT_ERROR;
} // unsigned char ati_disconnect(void);

//*********************************************************************************
// Description	: used to enable or disable auto answering incomming call
// Input	   	: ATI_ANSWER_ENABLED  - enabled auto answer
//				: ATI_ANSWER_DISABLED - disables auto answer
// Output   	: 
// Indication	: none
//*********************************************************************************
void ati_answer_incomming_call(unsigned char behavior)
{
switch(behavior)
	{
	case ATI_ANSWER_ENABLED:
			ati_answer_flag = ATI_ANSWER_ENABLED;
			#ifdef ATI_DEBUG
			if(ati_debug_flag)
				putsf("ATI Auto answering incomming call ENABLED\r");
			#endif
			break;                             
	case ATI_ANSWER_DISABLED:
			ati_answer_flag = ATI_ANSWER_DISABLED;
			#ifdef ATI_DEBUG
			if(ati_debug_flag)
				putsf("ATI Auto answering incomming call DISABLED\r");
			#endif
			break;
	}
}