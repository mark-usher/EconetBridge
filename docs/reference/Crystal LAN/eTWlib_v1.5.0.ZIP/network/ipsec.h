// ************************************************************************************************
///
/// \file 			ipsec.h
/// \brief			Simple IPSec implementation
///
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
///					This document is part of embedded IPsec
///					Niklaus Schild and Christian Scheurer, HTI Biel/Bienne
///					This file contains code from the OpenSSL Project<BR>
///					Niklaus Schild <n.schild@gmx.ch> <BR>
///					portions Copyright (c) 1998-2003 OpenSSL (www.openssl.org)
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _IPSEC_INCLUDED_
#define _IPSEC_INCLUDED_

#include "project.h"		// Project configuration

#include "ip.h"
#include "ipsec_sa.h"

// --------------------------------------------------------------------------------
// IPSec definitions
// -------------------------------------------------------------------------------- 
#define IPSEC_SEQ_MAX_WINDOW		16	// Defines the maximum window for Sequence Number checks (used as anti-replay protection)

// --------------------------------------------------------------------------------
// generell internal definitions
// -------------------------------------------------------------------------------- 
#define IPSEC_HEADER_SIZE 			44	// add. Header-Size to handle IPSec-Connection
										// Tunnel-Mode with ESP needs 36Byte
										// Tunnel-Mode with AH needs 44Byte
										// Transport-Mode with ESP needs 16Byte
										// Transport-Mode with AH needs 24Byte
#define IPSEC_TRAILER_SIZE 			20	// add. Header-Size to handle IPSec-Connection
										// Tunnel-Mode with ESP needs 20Byte
										// Tunnel-Mode with AH needs 0Byte
										// Transport-Mode with ESP needs 20Byte
										// Transport-Mode with AH needs 0Byte
#define IPSEC_HEADER_TRAILER_SIZE 	(IPSEC_HEADER_SIZE+IPSEC_TRAILER_SIZE)	// add. Buffer-Size to handle IPSec-Connection
										// Tunnel-Mode with ESP needs 56Byte
										// Tunnel-Mode with AH needs 44Byte
										// Transport-Mode with ESP needs 36Byte
										// Transport-Mode with AH needs 24Byte
#ifndef IPSEC_RX_BUFFER
#define IPSEC_RX_BUFFER				1500
#endif

#ifdef	IPSEC_ENABLE
#define	IPSEC_OFFSET	IPSEC_HEADER_SIZE
#define IPSEC_ADD_SIZE	IPSEC_HEADER_TRAILER_SIZE
#endif                                        

#pragma used+

#ifdef WEB_DEBUG_IPSEC
extern unsigned int ipsec_in_count;
extern unsigned int ipsec_out_count;
#endif

// --------------------------------------------------------------------------------
// API functions to handle IPSec-Read and -Write
// -------------------------------------------------------------------------------- 
unsigned char ipsec_hmac(SA_MEMORY sad_entry_mem *sa, unsigned char *data, 
					unsigned int data_size, unsigned char *ipsec_digest);
unsigned char ipsec_input_frame(void); 												// see file ip.c
unsigned char ipsec_output_frame(unsigned char *ip_data, unsigned int *ip_size, unsigned char *ip_offset);	//see file buffer.c

// --------------------------------------------------------------------------------
// Macro functions to handle the RX-Buffer of IPSec
// -------------------------------------------------------------------------------- 
unsigned int ipsec_read_frame_16bit(void);
unsigned int ipsec_read_frame_16bit_le(void);
void ipsec_read_frame_dummy(unsigned int size);
void ipsec_read_frame(void *dest, unsigned int size);

#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library ipsec.c
#endif

#endif		// #ifndef _IPSEC_INCLUDED_
