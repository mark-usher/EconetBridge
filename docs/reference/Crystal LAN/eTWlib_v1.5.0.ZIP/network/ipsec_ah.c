// ************************************************************************************************
///
/// \file 			ipsec_ah.c
/// \brief			IPSec Authentication Header
///
///
///					RFC2402 - IP Authentication Header (AH)
///					The AH functions are used to authenticate IPsec traffic.
///
///					Implementation:
///					All functions work in-place (i.g. manipulate directly the original
///					packet without copying any data). For the encapsulation routine,
///					the caller must ensure that space for the new IP and AH header are
///					available in front of the packet:
///
///					                              | pointer to packet header
///					 ____________________________\/_____________________________
///					|          �       �         �                              |
///					| Ethernet � newIP � AH, ICV �   original (inner) packet    |
///					|__________�_______�_________�______________________________|
///					�                            �
///					�<-- room for new headers -->�
///
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		Copyright (C) 2001-2004
///					This document is part of embedded IPsec
///					Niklaus Schild and Christian Scheurer, HTI Biel/Bienne
///					This file contains code from the OpenSSL Project<BR>
///					Christian Scheurer <http://www.christianscheurer.ch>
///					portions Copyright (c) 1998-2003 OpenSSL (www.openssl.org)
///					easyToWeb-AVR and CodeVisionAVR C-Compiler:
///					Udo Jakobza - FTZ Leipzig; 04107 Leipzig; W�chterstr. 13
///					jakobza@e-technik.htwk-leipzig.de
/// \todo 			compiler error, if IPSEC_SA_MEMORY_SRAM is not defined
///
/// \par License    
///					Redistribution and use in source and binary forms, with or without 
///					modification, are permitted provided that the following conditions are met:
///
///					1. Redistributions of source code must retain the above copyright notice,
///					   this list of conditions and the following disclaimer.
///					2. Redistributions in binary form must reproduce the above copyright notice,
///					    this list of conditions and the following disclaimer in the documentation
///					   and/or other materials provided with the distribution.
///					3. The name of the author may not be used to endorse or promote products
///					   derived from this software without specific prior written permission.
///
///					THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
///					WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
///					MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
///					EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
///					EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
///					OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
///					INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
///					CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
///					IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
///					OF SUCH DAMAGE.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef	IPSEC_ENABLE

#include <string.h>
#include "buffer.h"
#include "ip.h"
#include "ipsec.h"
#include "ipsec_ah.h"
#include "md5.h"
#include "ipsec_sa_debug.h"
#include "debug.h"
#include "ipsec_sa.h"

#pragma regalloc-

IP_HEADER_STRUCTURE	ipsec_ip_header_temp;
unsigned char		ah_authentication_buffer[IPSEC_AH_AUTH_DATA_SIZE];
unsigned char		ah_digest[IPSEC_MAX_AUTHKEY_LEN];
#pragma regalloc+


//*********************************************************************************
// Description	: handles the incomming frames
// Input   		: sa: pointer to SA
//                rx_data: pointer to received data
//                rx_length: pointer to received length data
// Output  		: @return: 0 some error inside of data
//                @return: 1 OK
// Indication	: internal easyToWeb function
//*********************************************************************************
unsigned char ipsec_ah_input_frame(SA_MEMORY sad_entry_mem *sa, unsigned char *rx_data, unsigned int *rx_length, unsigned char *ip_offset)
{
#if defined(IPSEC_AH_TRANSPORT_ENABLE)||defined(IPSEC_AH_TUNNEL_ENABLE)
unsigned char 			next_header, temp_length;
TRANS_TUNNEL_IN_IP_AH	*rx_header;

rx_header=(TRANS_TUNNEL_IN_IP_AH*)rx_data;
next_header=rx_header->ah.next_header;	
temp_length=rx_header->ah.length;	
temp_length=(temp_length+2)*4;		// real length of AH Header;
temp_length-=IPSEC_AH_LENGTH; 		// calculate the Length of Authentication Data
if(temp_length>IPSEC_AH_AUTH_DATA_SIZE)
	{
	WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) Auth. Data Error: %uByte\r\n", ipsec_in_count, temp_length));
	return 0;
	}
memcpy(ah_authentication_buffer, rx_header->ah.ah_data, sizeof(ah_authentication_buffer));	// Read AH Authenticatioon Data (96bit - 12Byte)
memset(rx_header->ah.ah_data, 0x0, IPSEC_AH_AUTH_DATA_SIZE);	// Clear AH Authenticatioon Data (96bit - 12Byte)
// save the last IP-Header
memcpy(&ipsec_ip_header_temp, &rx_header->ip, sizeof(ipsec_ip_header_temp));
// set all nessesary IP-Entries to Zero
rx_header->ip.tos=0;					// Type of Service
rx_header->ip.flags_frag_offset = 0;	// 16bit Flags and Fragment Offset
rx_header->ip.ttl=0;	  				// Time to Live
rx_header->ip.checksum = 0; 			// 16bit Checksum
#ifdef WEB_DEBUG_IPSEC
if (ipsec_debug_flag)
	{
//	printf("IPSEC(%u) hmac-data: %uByte\r\n", ipsec_in_count, *rx_length); 
//	web_debug_display_frame(rx_data, *rx_length, 0);
	}
#endif
if(ipsec_hmac(sa, (unsigned char*)&rx_header->ip, *rx_length, ah_digest)==0)
	{
	WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) unknown AH-HASH algorithm\r\n", ipsec_in_count));
	return 0;
	}
if(memcmp(ah_authentication_buffer, ah_digest, sizeof(ah_authentication_buffer)))
	{
	#ifdef WEB_DEBUG_IPSEC
	if (ipsec_debug_flag)
		{
		printf("IPSEC-IN(%u) digest data: %uByte\r\n", ipsec_in_count, sizeof(ah_digest)); 
		debug_display_mem_hex(ah_digest, sizeof(ah_digest), 0);
		debug_display_mem_hex(ah_authentication_buffer, sizeof(ah_authentication_buffer), 0);
		}
	#endif
	return 0;
	}
WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) Authentication OK\r\n", ipsec_in_count));
#endif	// #if defined(IPSEC_AH_TRANSPORT_ENABLE)||defined(IPSEC_AH_TUNNEL_ENABLE)
#ifdef IPSEC_AH_TRANSPORT_ENABLE			// Enable the IPSec-AH-Transport Protocol
if(sa->mode==IPSEC_TRANSPORT)
	{
	*rx_length-=IPSEC_AH_HEADER_SIZE;						// calculate the new Length of IP-Frame
	HOST_NETWORK_ENDIAN_16BIT((unsigned char*)&ipsec_ip_header_temp.length, rx_length);	// set the new length
	// set Checksum to zero, should later compute
	ipsec_ip_header_temp.checksum = 0;	
	ipsec_ip_header_temp.protocol = next_header;
	// write the IP-Header to the new position;
	memcpy(&rx_header->data-IP_HEADER_SIZE, &ipsec_ip_header_temp, sizeof(ipsec_ip_header_temp));
	*ip_offset=IPSEC_AH_HEADER_SIZE;
	// move the data to rigth position
//	memmove(&rx_header->ah.next_header, &rx_header->data, *rx_length-IP_HEADER_SIZE);
	#ifdef WEB_DEBUG_IPSEC
	if (ipsec_debug_flag)
		{
//		printf("IPSEC(%u) data: %uByte\r\n", ipsec_in_count, *rx_length); 
//		web_debug_display_frame(rx_data, *rx_length, 0);
		}
	#endif
	return 1;
	}
#else
WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) NO AH-TRANSPORT\r\n", ipsec_in_count));
#endif	// #ifdef IPSEC_AH_TRANSPORT_ENABLE
#ifdef IPSEC_AH_TUNNEL_ENABLE			// Enable the IPSec-AH-Tunnel Protocol
if(sa->mode==IPSEC_TUNNEL)
	{
	*rx_length-=(IPSEC_AH_HEADER_SIZE + IP_HEADER_SIZE);	// calculate the new Length of IP-Frame
	*ip_offset=IPSEC_AH_HEADER_SIZE + IP_HEADER_SIZE;       // set offset to start of inner IP-Frame
	return 1;
	}
#else
WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) NO AH-TUNNEL\r\n", ipsec_in_count));
#endif	// #ifdef IPSEC_AH_TUNNEL_ENABLE
return 0;
}
 

//*********************************************************************************
// Description	: handles the outgoing AH-frames
// Input   		: sad_entry_mem: pointer to SA
//              : *ip_data: pointer to full IP-Frame
//                *ip_size: pointer to size of IP-Frame
//                *ip_offset: pointer to offset inside of TX-Buffer
// Output  		: @return: 0 some error inside of data
//                @return: 1 OK
// Indication	: internal easyToWeb function
//*********************************************************************************
unsigned char ipsec_ah_output_frame(SA_MEMORY sad_entry_mem *sa, unsigned char *ip_data, 
									unsigned int *ip_size, unsigned char *ip_offset)
{
#ifdef IPSEC_AH_TUNNEL_ENABLE			// Enable the IPSec-AH-Tunnel Protocol
TUNNEL_OUT_IP_AH_IP		*tx_header_tunnel;
#endif
#ifdef IPSEC_AH_TRANSPORT_ENABLE			// Enable the IPSec-AH-Transport Protocol
TRANSPORT_OUT_IP_AH		*tx_header_trans;
if(sa->mode==IPSEC_TRANSPORT)
	{
	tx_header_trans=(TRANSPORT_OUT_IP_AH*)ip_data;
	// move the IP-Header
	memmove(&tx_header_trans->ip, ip_data+IPSEC_OFFSET, sizeof(IP_HEADER_STRUCTURE));
	// set the new length
	*ip_size+=IPSEC_AH_HEADER_SIZE;
	// calculate the new IP-Offset to write the Ethernet-Header
	*ip_offset=(IPSEC_OFFSET - IPSEC_AH_HEADER_SIZE);
	// Init the AH-Header
    tx_header_trans->ah.next_header=tx_header_trans->ip.protocol;   	// set Next Header Entry
	tx_header_trans->ah.length=(sizeof(AH_HEADER_STRUCTURE)/4)-2;		// set Length of AH-Header
	HOST_NETWORK_ENDIAN_32BIT((unsigned char*)&tx_header_trans->ah.spi, &sa->spi);		// write AH Security Parameter Index - SPI (32bit)
	(*sa->seq)++;
	HOST_NETWORK_ENDIAN_32BIT((unsigned char*)&tx_header_trans->ah.sequence, sa->seq);	// write AH Sequence Number (32bit)
	memset(tx_header_trans->ah.ah_data, 0x0, IPSEC_AH_AUTH_DATA_SIZE);				// Clear AH Authentication Data (96bit - 12Byte)
	// Init the IP-Header
	tx_header_trans->ip.protocol=IP_IPSEC_AH_PROT;				// set Next Header Entry
	HOST_NETWORK_ENDIAN_16BIT((unsigned char*)&tx_header_trans->ip.length, ip_size);	// set the new length
	// save the last IP-Header
	memcpy(&ipsec_ip_header_temp, &tx_header_trans->ip, sizeof(ipsec_ip_header_temp));
	// set all nessesary IP-Entries to Zero
	tx_header_trans->ip.tos=0;					// Type of Service
	tx_header_trans->ip.flags_frag_offset = 0;	// 16bit Flags and Fragment Offset
	tx_header_trans->ip.ttl=0;	  				// Time to Live
	tx_header_trans->ip.checksum = 0; 			// 16bit Checksum
	// calculate AH according the SA
	if(ipsec_hmac(sa, (unsigned char*)&tx_header_trans->ip, *ip_size, ah_digest)==0)
		{
		WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) unknown AH-HASH algorithm\r\n", ipsec_out_count));
		return 0;
		}
	memcpy(tx_header_trans->ah.ah_data, ah_digest, IPSEC_AH_AUTH_DATA_SIZE);	// Write AH Authentication Data (96bit - 12Byte)
	// reset the IP-Header;
	memcpy(&tx_header_trans->ip, &ipsec_ip_header_temp, sizeof(ipsec_ip_header_temp));
	tx_header_trans->ip.checksum = 0; 			// set to Zero before calculate the Checksum
	tx_header_trans->ip.checksum = ip_checksum(&tx_header_trans->ip, IP_HEADER_SIZE, 0);
	WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) AH %ubyte; ip_offset:0x%x\r\n", ipsec_out_count, *ip_size, *ip_offset));
	return 1;
	}
#else
WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) NO AH-TRANSPORT\r\n", ipsec_out_count));
#endif	// #ifdef IPSEC_AH_TRANSPORT_ENABLE
#ifdef IPSEC_AH_TUNNEL_ENABLE			// Enable the IPSec-AH-Tunnel Protocol
if(sa->mode==IPSEC_TUNNEL)
	{
	tx_header_tunnel=(TUNNEL_OUT_IP_AH_IP*)ip_data;
	// move the IP-Header
	memmove(&tx_header_tunnel->ip_out, &tx_header_tunnel->ip_in, sizeof(IP_HEADER_STRUCTURE));
	// set the new length
	*ip_size+=IPSEC_AH_HEADER_SIZE+IP_HEADER_SIZE;
	// calculate the new IP-Offset to write the Ethernet-Header
	*ip_offset=(IPSEC_OFFSET - IPSEC_AH_HEADER_SIZE - IP_HEADER_SIZE);
	// Init the AH-Header
	tx_header_tunnel->ah.next_header=IP_IP_PROT; 						// set Next Header Entry
	tx_header_tunnel->ah.length=(sizeof(AH_HEADER_STRUCTURE)/4)-2;		// set Length of AH-Header
	HOST_NETWORK_ENDIAN_32BIT((unsigned char*)&tx_header_tunnel->ah.spi, &sa->spi);	// write AH Security Parameter Index - SPI (32bit)
	(*sa->seq)++;
	HOST_NETWORK_ENDIAN_32BIT((unsigned char*)&tx_header_tunnel->ah.sequence, sa->seq);	// write AH Sequence Number (32bit)
	memset(tx_header_tunnel->ah.ah_data, 0x0, IPSEC_AH_AUTH_DATA_SIZE);				// Clear AH Authentication Data (96bit - 12Byte)
	// Init the IP-Header
	tx_header_tunnel->ip_out.protocol=IP_IPSEC_AH_PROT;					// set Next Header Entry
	HOST_NETWORK_ENDIAN_16BIT((unsigned char*)&tx_header_tunnel->ip_out.length, ip_size);	// set the new length
	// save the outer IP-Header
	memcpy(&ipsec_ip_header_temp, &tx_header_tunnel->ip_out, sizeof(ipsec_ip_header_temp));
	// set all nessesary IP-Entries to Zero
	tx_header_tunnel->ip_out.tos=0;					// Type of Service
	tx_header_tunnel->ip_out.flags_frag_offset = 0;	// 16bit Flags and Fragment Offset
	tx_header_tunnel->ip_out.ttl=0;	  				// Time to Live
	tx_header_tunnel->ip_out.checksum = 0; 			// 16bit Checksum
	// calculate AH according the SA
	if(ipsec_hmac(sa, (unsigned char*)&tx_header_tunnel->ip_out, *ip_size, ah_digest)==0)
		{
		WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) unknown AH-HASH algorithm\r\n", ipsec_out_count));
		return 0;
		}
	memcpy(tx_header_tunnel->ah.ah_data, ah_digest, IPSEC_AH_AUTH_DATA_SIZE);	// Write AH Authentication Data (96bit - 12Byte)
	// reset the IP-Header;
	memcpy(&tx_header_tunnel->ip_out, &ipsec_ip_header_temp, sizeof(ipsec_ip_header_temp));
	tx_header_tunnel->ip_out.checksum = 0; 			// set to Zero before calculate the Checksum
	tx_header_tunnel->ip_out.checksum = ip_checksum(&tx_header_tunnel->ip_out, IP_HEADER_SIZE, 0);
	WEB_DEBUG_IPSEC_MSG(("IPSEC-OUT(%u) AH %ubyte; ip_offset:0x%x\r\n", ipsec_out_count, *ip_size, *ip_offset));
	return 1;
	}
#else
WEB_DEBUG_IPSEC_MSG(("IPSEC-IN(%u) NO AH-TUNNEL\r\n", ipsec_out_count));
#endif	// #ifdef IPSEC_AH_TUNNEL_ENABLE
return 0;
}

#endif	// #ifdef	IPSEC_ENABLE
