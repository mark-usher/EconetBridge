// ************************************************************************************************
///
/// \file 			bootp.c
/// \brief			BOOT-Protocol functions
///
/// \todo			Switch module to new debug framework
/// \date	 		$LastChangedDate: 2007-03-21 17:53:42 +0100 (Mi, 21 Mrz 2007) $
/// \version 		$Rev: 647 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef BOOTP_ENABLE

#include <stdio.h>
#include <stdlib.h>
#include "arp_rarp.h"
#include "tcp.h"

#include "ethernet.h"
#include "device.h"
#include "buffer.h"
#include "ip.h"
#include "udp.h"
#include "bootp.h"
#ifdef WEB_DEBUG
#include "web_debug.h"
#endif

#pragma regalloc-
unsigned long 	bootp_xid=0;
unsigned char 	bootp_ok=0;							// flag to signal the actual status of BooTP
unsigned char 	bootp_your_ip[IP_ADR_SIZE];			// 32 bit IP
unsigned char 	bootp_server_ip[IP_ADR_SIZE];		// 32 bit IP
unsigned char 	bootp_gateway_ip[IP_ADR_SIZE];		// 32 bit IP
unsigned char 	bootp_subnet_ip[IP_ADR_SIZE];		// 32 bit IP
unsigned char 	bootp_dns_ip[4,IP_ADR_SIZE];		// 32 bit IP
unsigned char	bootp_rx_buffer[BOOTP_VENDOR_SIZE];	// buffer for incoming BootP-data
unsigned char 	udp_connection_bootp=UDP_WRONG_CONNECTIONS;
#pragma regalloc+


// ************************************************************************************************
/// \brief		Init the BOOTP-IP-Connection
///
/// \todo		Rework function. (Currently no multitasking possible)
// ************************************************************************************************
void bootp_init(void)
{
#ifdef WEB_DEBUG
web_debug_flag|=WEB_DEBUG_BOOTP_BIT;		//	set debug flag
#endif
udp_connection_bootp=udp_open(UDP_PORT_BOOTP_CLIENT, 0, 0, UDP_PORT_BOOTP_SERVER, UDP_FLAG_ACTIVE);
if(udp_connection_bootp==UDP_WRONG_CONNECTIONS)
	{
	#ifdef BOOTP_DEBUG
	if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
		putsf("BOOTP UDP Active Open Error!!!!\r"); 
	#endif
	return;
	}
bootp_request(TIMEOUT_START);				// first start of timeout
while(!bootp_ok)
	{
	server_main();
	if(bootp_timeout(TIMEOUT_STOP_CHECK))	// checks if the timeout stops
		break;
	idle();
	#asm("wdr");							// Reset Watchdog
	#ifdef WEB_DEBUG
	web_debug_command();
	#endif
	}
udp_close(udp_connection_bootp);
#ifdef WEB_DEBUG
web_debug_flag&=~WEB_DEBUG_BOOTP_BIT;		// clear debug flag
#endif
}


//********************************************************************************
// Description	: init the new IPs
// Input  	 	: none
// Output  	 	: none
// Indication	: none
//********************************************************************************
void bootp_copy(void)
{
memcpy(ip_address, bootp_your_ip, sizeof(ip_address));				// set new IP
memcpy(ip_subnet_mask, bootp_subnet_ip, sizeof(ip_subnet_mask));	// new subnet-IP
memcpy(ip_gateway, bootp_gateway_ip, sizeof(ip_gateway));			// new gateway-IP
#ifdef WEB_DEBUG_BOOTP
if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
	bootp_display();
#endif
bootp_ok=1;					// flag to signal the actual status of BooTP
}


//********************************************************************************
// Description	: sends a BOOTP-Request
// Input  	 	: mode -  TIMEOUT_START,		// first start of timeout
//				:		  TIMEOUT_RESTART,		// re-start of timeout
//				:		see BOOTP_TIMEOUT_TYP
// Output  	 	: none
// Indication	: none
//********************************************************************************
void bootp_request(BOOTP_TIMEOUT_TYP mode)
{   
UDP_STRUCTURE	*p_struct;                                    	
unsigned int 	timer_value;

p_struct=udp_get_struct(udp_connection_bootp);
if(p_struct==0)
	{
	#ifdef WEB_DEBUG_BOOTP
	if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
		putsf("BOOTP No valid UDP-Connection\r"); 
	#endif
	return;
	}
if(udp_tx_buffer_prepare(udp_connection_bootp, 0x0, 0x0)<BOOTP_HEADER_SIZE)	// check size UDP-size
	{
	#ifdef WEB_DEBUG_BOOTP
	if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
		putsf("BOOTP too small UDP-buffer\r"); 
	#endif
	return;
	}
bootp_ok=0;					// flag to signal the actual status of BooTP
if(mode==TIMEOUT_START)		// first start
	{
	srand(board_timer1_counter());	// set random number
	bootp_xid=rand();			// generates a pseudo-random number between 0 and 32767.
	bootp_xid<<=16;
	bootp_xid |= board_timer1_counter();
	memset(bootp_dns_ip, 0x0, sizeof(bootp_dns_ip));
	}
memset(&p_struct->udp_tx_frame[UDP_DATA_OFS], 0x0, UDP_TX_DATA_SIZE);	// clear all entries
p_struct->udp_tx_frame[BOOTP_OP_OFS] = BOOTP_FRAME_OP_REQUEST;		// Operation (8 bit)
p_struct->udp_tx_frame[BOOTP_HTYPE_OFS] = 1;		// hardware address type (8 bit)
p_struct->udp_tx_frame[BOOTP_HLEN_OFS] = 6;			// hardware address length (8 bit)
HOST_NETWORK_ENDIAN_32BIT(&p_struct->udp_tx_frame[BOOTP_XID_OFS], &bootp_xid);		// transaction ID (32 bit)
timer_value = board_timer1_counter() & 0x0003;
HOST_NETWORK_ENDIAN_16BIT(&p_struct->udp_tx_frame[BOOTP_SECS_OFS], &timer_value);	// seconds elapsed since client started (16 bit)
memcpy(&p_struct->udp_tx_frame[BOOTP_CHADDR_OFS], &mac_address[0], 6);				// client hardware address (128 bit - 16 byte)
timer_value=udp_tx_buffer_prepare(udp_connection_bootp, 0x0, BOOTP_HEADER_SIZE);	// initiate transfer after TxBuffer is filled
#ifdef WEB_DEBUG_BOOTP
if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
	{
	printf("BOOTP Write Request: %ubyte ", timer_value); 
	if(timer_value==BOOTP_HEADER_SIZE)
		putsf("OK\r"); 
	else
		putsf("Error\r"); 
	}
#endif
bootp_timeout(mode);													// starts or restart the BOOTP-Timeout
}


#pragma regalloc-
//********************************************************************************
// Description	: starts und checks the BOOTP-Anwser
// Input  	 	: mode -  TIMEOUT_START,		// first start of timeout
//				:		  TIMEOUT_RESTART,		// re-start of timeout
//				:		see BOOTP_TIMEOUT_TYP
// Output  	 	: none
// Indication	: none
//********************************************************************************
unsigned char bootp_timeout(BOOTP_TIMEOUT_TYP mode)
{   
static unsigned int 	start_timeout=0;
static unsigned int		counter_10ms_delay;
static unsigned char	counter_10ms_old; 

if(mode==TIMEOUT_STOP_CHECK)	// checks the timeout stops
	{
	if(start_timeout==0)
		return 1;
	return 0;
	}
if(mode==TIMEOUT_CHECK)	// checks the timeout
	{
	if(start_timeout==0)
		return 0;
	if(counter_10ms_old!=(unsigned char)counter_10ms_16bit)
		{
		counter_10ms_old=(unsigned char)counter_10ms_16bit;
		if(counter_10ms_delay>0)
			counter_10ms_delay--;
		else
			{		
			#ifdef WEB_DEBUG_BOOTP
			if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
				printf("BOOTP Timeout: %ums\r\n", start_timeout*10);
			#endif
			return 1;
			}
		}
	return 0;
	}
if (mode == TIMEOUT_START)		// first start
	{
	srand(board_timer1_counter());
	start_timeout=rand();	// generates a pseudo-random number between 0 and 32767.
	start_timeout&=0xff;	// generate the start timeout (0..255 counts - 10ms)
	if(start_timeout<100)	// 100 counts*10ms == at least 1 sec.
		start_timeout+=100;
	#ifdef WEB_DEBUG_BOOTP
	if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
		putsf("BOOTP Search Server\r");
	#endif
	}
if(mode==TIMEOUT_RESTART)	// re-start
	{
	start_timeout*=2;		// calculate new timeout
	if(start_timeout>BOOTP_TIMEOUT)	// after xx seconds
		{
		bootp_xid=0;		// set global variable to zero
		start_timeout=0;
		#ifdef WEB_DEBUG_BOOTP
		if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
			putsf("BOOTP Stop\r");
		#endif
		}
	else
		{
		#ifdef WEB_DEBUG_BOOTP
		if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
			putsf("BOOTP Restart\r");
		#endif
		}
	}
if(mode==TIMEOUT_CLEAR)		// clear all values
	{
	bootp_xid=0;			// set global variable to zero
	start_timeout=0;
	}
counter_10ms_old = (unsigned char)counter_10ms_16bit;
counter_10ms_delay = start_timeout;
return 0;
}
#pragma regalloc+


//********************************************************************************
// Description	: external API to handle the Bootp-process
// Input  	 	: none
// Output  	 	: none
// Indication	: none
//********************************************************************************
void bootp_process(void)
{   
if(bootp_timeout(TIMEOUT_CHECK))	// checks the timeout of BOOTP-Anwser
	bootp_request(TIMEOUT_RESTART);	// re-start, if timeout
}


flash unsigned long bootp_magic_cookie=BOOTP_MAGIC_COOKIE;
//********************************************************************************
// Description	: handles the BOOTP-Answer
// Input  	 	: none
// Output  	 	: none
// Indication	: none
//********************************************************************************
void bootp_answer(void)
{   
unsigned int	bootp_len;		// length of bootp-data
unsigned char	length;			// general variable
unsigned int	data;	    	// general variable
unsigned long	answer_xid;		// answer Transaction-ID

if(bootp_xid==0)				// not BOOTP-process
	return;
// UDP header
DEVICE_READ_IP_FRAME_16BIT();			// ingnore Source Port
data = DEVICE_READ_IP_FRAME_16BIT();	// Destination Port
#ifdef WEB_DEBUG_BOOTP
if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
	{
	//printf("BOOTP port: %u\r\n", data);
	}
#endif
if(data==UDP_PORT_BOOTP_CLIENT)
	{
	bootp_len=DEVICE_READ_IP_FRAME_16BIT();	// reads UDP-Length
	bootp_len-=UDP_HEADER_SIZE;				// calculate bootp-length
	DEVICE_READ_IP_FRAME_16BIT();		   	// ignore UDP-checksum
	// BOOTstrap-Protocoll-Data
	data=DEVICE_READ_IP_FRAME_16BIT_LE(); 	// read Operation and Hardwaretyp (High-Byte on Low-Address)
	if((data & 0xff)==BOOTP_FRAME_OP_ANSWER)
		{
		DEVICE_READ_IP_FRAME_16BIT();	  			// ignore Hardware length and "Hops"
		answer_xid=DEVICE_READ_IP_FRAME_16BIT();	// HIGH-Part of answer Transaction-ID
		answer_xid<<=16;
		answer_xid|=DEVICE_READ_IP_FRAME_16BIT();  	// LOW-Part of answer Transaction-ID
		#ifdef WEB_DEBUG_BOOTP
		if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
			printf("BOOTP answer_xid: 0x%lx\r\n", answer_xid);
		#endif
		if(answer_xid==bootp_xid)
			{
			bootp_timeout(TIMEOUT_CLEAR);		  			// set bootp_xid=0
			DEVICE_READ_IP_FRAME_DUMMY(8);		   			// ignore seconds(16bit),unused(16bit) and client-IP(32bit)
			DEVICE_READ_IP_FRAME_DATA(&bootp_your_ip[0], 4);	// reads "your" (client) IP address (32 bit)
			DEVICE_READ_IP_FRAME_DATA(&bootp_server_ip[0], 4);	// reads server IP address (32 bit)
			DEVICE_READ_IP_FRAME_DATA(&bootp_gateway_ip[0], 4);// gateway IP address (32 bit)
			DEVICE_READ_IP_FRAME_DUMMY(16);			  	 	// ignore client hardware address (16 byte)
			DEVICE_READ_IP_FRAME_DATA(&bootp_rx_buffer[0], BOOTP_SERVER_NAME_SIZE);	// optional server host name (64 byte)
			#ifdef WEB_DEBUG_BOOTP
			if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
				{
				printf("BOOTP Server    : %s\r\n", bootp_rx_buffer);
				}
			#endif 
			DEVICE_READ_IP_FRAME_DUMMY(128);		// ignore boot file name (128 byte)
			bootp_len-=(BOOTP_MIN_HEADER_SIZE+BOOTP_SERVER_NAME_SIZE+BOOTP_BOOT_FILE_SIZE);	// 44+64+128 calculate the vendor area of BOOTP-data
			if(bootp_len>BOOTP_VENDOR_SIZE)			// bigger than 64Byte
				{
				#ifdef WEB_DEBUG_BOOTP
				if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
					putsf("BOOTP Vendor to long\r"); 
				#endif
				bootp_copy();		// we can life with this error
				return;
				}
			DEVICE_READ_IP_FRAME_DATA(&bootp_rx_buffer[0], BOOTP_VENDOR_SIZE);	// vendor-specific area (max. 64 byte)
			#ifdef WEB_DEBUG_BOOTP
			if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
				{
				putsf("BOOTP Vendor:\r"); 
				debug_display_frame(bootp_rx_buffer, BOOTP_VENDOR_SIZE, 0);
				}
			#endif
			if(memcmpf(&bootp_rx_buffer[0], &bootp_magic_cookie, 4))		// check magic cookie
				{
				data=4;
		  		while(data<bootp_len)
					{
					if(bootp_rx_buffer[data]==BOOTP_VENDOR_SUBNET)
						{
						#ifdef WEB_DEBUG_BOOTP
						if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
							{
							//printf("%x\r\n", bootp_rx_buffer[data]);
							}
						#endif
						data++;
						length=bootp_rx_buffer[data++];
						memcpy(&bootp_subnet_ip[0], &bootp_rx_buffer[data], 4);		// 32 bit IP
						data+=length;
						}
					else if(bootp_rx_buffer[data]==BOOTP_VENDOR_GATEWAY)
						{
						#ifdef WEB_DEBUG_BOOTP
						if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
							{
							//printf("%x\r\n", bootp_rx_buffer[data]);
							}
						#endif 
						data++;
						length=bootp_rx_buffer[data++];
						memcpy(&bootp_gateway_ip[0], &bootp_rx_buffer[data], 4);	// 32 bit IP
						data+=length;
						}
					else if(bootp_rx_buffer[data]==BOOTP_VENDOR_DNS)
						{
						data++;
						length=bootp_rx_buffer[data++];
/*
						#ifdef WEB_DEBUG_BOOTP
						if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
							{
							for(Lva=0;Lva<length;Lva+=4)
								web_debug_print_ip("BOOTP-DNS", &bootp_rx_buffer[data+Lva]);
							}
						#endif 
*/
						if(length<(sizeof(bootp_dns_ip)))
							memcpy(bootp_dns_ip, &bootp_rx_buffer[data], length);	
						else
							memcpy(bootp_dns_ip, &bootp_rx_buffer[data], sizeof(bootp_dns_ip));
						data+=length;
						}
					else if(bootp_rx_buffer[data]==BOOTP_VENDOR_DOMAIN_NAME)
						{
						data++;
						length=bootp_rx_buffer[data++];
						#ifdef WEB_DEBUG_BOOTP
						if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
							printf("BOOTP Domain    : %s\r\n", &bootp_rx_buffer[data]);
						#endif 
						data+=length;
						}
					else if(bootp_rx_buffer[data]==BOOTP_VENDOR_NETBIOS_NODE)
						{
						#ifdef WEB_DEBUG_BOOTP
						if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
							{
							printf("BOOTP NetBIOS over TCP/IP Node: 0x%02x\r\n", bootp_rx_buffer[data+2]);
							}
						#endif 
  						data+=3;
						}
					else if(bootp_rx_buffer[data]==BOOTP_VENDOR_END)
						{
						break;
						}
					else data++;
					}
				}
			else
				{
				#ifdef WEB_DEBUG_BOOTP
				if(web_debug_flag & WEB_DEBUG_BOOTP_BIT)
					printf("BOOTP wrong magic cookie: %02x%02x%02x%02x\r\n", bootp_rx_buffer[0], bootp_rx_buffer[1], 
												bootp_rx_buffer[2], bootp_rx_buffer[3]); 
				#endif
				return;
				}
			bootp_copy();
			}
		}
	}
}


#ifdef WEB_DEBUG_BOOTP
//********************************************************************************
// Description	: displays all IPs
// Input  	 	: none
// Output  	 	: none
// Indication	: none
//********************************************************************************
void bootp_display(void)
{
unsigned char Lva;

debug_print_ip("BOOTP Your-IP   ", bootp_your_ip);
debug_print_ip("BOOTP Server-IP ", bootp_server_ip);
debug_print_ip("BOOTP Subnet-IP ", bootp_subnet_ip);
debug_print_ip("BOOTP Gateway-IP", bootp_gateway_ip);
for(Lva=0;Lva<4;Lva++)
	debug_print_ip("BOOTP DNS-IP    ", &bootp_dns_ip[Lva,0]);
}
#endif
#endif		// #ifdef BOOTP_ENABLE