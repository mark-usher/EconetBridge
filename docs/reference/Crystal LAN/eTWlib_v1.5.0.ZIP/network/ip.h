// ************************************************************************************************
///
/// \file 			ip.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _IP_INCLUDED_
#define _IP_INCLUDED_

#include "project.h"		// Project configuration

// --------------------------------------------------------------------------------
// Default Remote IP-address, see PPP
// -------------------------------------------------------------------------------- 
#ifndef IP_REMOTE_DEFAULT
#define IP_REMOTE_DEFAULT		(192, 168, 0, 13)
#endif	// #ifndef IP_REMOTE_DEFAULT

// --------------------------------------------------------------------------------
// Default IP-addresses for own subnet
// -------------------------------------------------------------------------------- 
#ifndef IP_DEFAULT
#define IP_DEFAULT				(192, 168, 0, 2)	// our internet protocol (IP) address
#endif	// #ifndef IP_DEFAULT

#ifndef IP_SUBMASK_DEFAULT
#define IP_SUBMASK_DEFAULT		(255, 255, 255, 0)	// subnet mask
#endif	// #ifndef IP_SUBMASK_DEFAULT

#ifndef IP_GATEWAY_DEFAULT
#define IP_GATEWAY_DEFAULT		(192, 168, 0, 100)	// standard gateway (used if remote IP is no part of our subnet)
#endif	// #ifndef IP_GATEWAY_DEFAULT

#ifndef	IPSEC_ENABLE
#define	IPSEC_OFFSET	 		0		// without IPSec the buffer has no offset 
#define IPSEC_ADD_SIZE			0		// without IPSec the buffer has no additional size
#endif                                        

// --------------------------------------------------------------------------------
// IPv4 layer definitions
// -------------------------------------------------------------------------------- 
#define IP_HEADER_START_OFS		ETH_DATA_OFS + IPSEC_OFFSET + 0		// Start of IP-Header inside of Buffer
#define IP_VER_IHL_TOS_OFS		ETH_DATA_OFS + IPSEC_OFFSET + 0		// Version, Header Length, Type of Service
#define IP_TOTAL_LENGTH_OFS		ETH_DATA_OFS + IPSEC_OFFSET + 2		// IP Frame's Total Length
#define IP_IDENT_OFS			ETH_DATA_OFS + IPSEC_OFFSET + 4		// Identifying Value
#define IP_FLAGS_FRAG_OFS		ETH_DATA_OFS + IPSEC_OFFSET + 6		// Flags and Fragment Offset
#define IP_TTL_OFS				ETH_DATA_OFS + IPSEC_OFFSET + 8		// Frame's Time to Live
#define IP_PROTOCOL_OFS			ETH_DATA_OFS + IPSEC_OFFSET + 9		// Frame's Protocol
#define IP_TTL_PROT_OFS			ETH_DATA_OFS + IPSEC_OFFSET + 8		// Frame's Time to Live, Protocol
#define IP_HEAD_CHKSUM_OFS		ETH_DATA_OFS + IPSEC_OFFSET + 10	// IP Frame's Header Checksum
#define IP_SOURCE_OFS			ETH_DATA_OFS + IPSEC_OFFSET + 12	// Source Address (32 Bit)
#define IP_DESTINATION_OFS		ETH_DATA_OFS + IPSEC_OFFSET + 16	// Destination Address (32 Bit)
#define IP_DATA_OFS				ETH_DATA_OFS + IPSEC_OFFSET + 20	// Frame Data (if no options)
#define IP_HEADER_SIZE			20                  // w/o options

#define IP_VER_IHL				0x4500              // Version==4->IPv4, Header Length==5x32 bit
#define IP_TOS_MIN_DELAY		0x0010              // TOS min delay
#define IP_TOS_MAX_TROUGHPUT	0x0008              // TOS max throughput
#define IP_TOS_MAX_RELIABILITY	0x0004              // TOS max reliability
#define IP_TOS_MIN_COST			0x0002              // TOS min monetary cost
#define IP_TOS_NORMAL			0x0000              // TOS normal service

#define IP_FLAG_DONTFRAG		0x4000              // don't fragment IP frame
#define IP_FLAG_MOREFRAG		0x2000              // more fragments available
#define IP_FRAGOFS_MASK			0x1FFF              // indicates where this fragment belongs

#define IP_IP_PROT				4                   // 0x04 - IP Protocol
#define IP_ICMP_PROT			1                   // 0x01 - Internet Control Message Protocol
#define IP_TCP_PROT     	    6                   // 0x06 - Transmission Control Protocol
#define IP_UDP_PROT				17                  // 0x11 - User Datagram Protocol
#define IP_IPSEC_ESP_PROT		50                  // 0x32 - Encapsulating Security Payload Protocol
#define IP_IPSEC_AH_PROT		51					// 0x33 - Authentication Header Protocol

#define IP_FRAME				0x0800				// Ethernet Type, see also ARP_FRAME
#define IP_ADR_SIZE				4					// supports only 4-Byte IP
         
#define IP_DEFAULT_TTL			64					// Time To Live sent with packets

//  --------------------------------------------------------------------------------
//	IP-Header structure (IPv4)
//  -------------------------------------------------------------------------------- 
typedef struct
	{
	unsigned char	ver_ihl;				// ver=4; ihl=5
	unsigned char	tos;					// tos=8bit
	unsigned int	length;
	unsigned int 	ident;					// necessary for fragmentation
	unsigned int 	flags_frag_offset;
	unsigned char	ttl;					// 
	unsigned char 	protocol;				// 
	unsigned int 	checksum;				// 
	unsigned char	source[IP_ADR_SIZE];	// ip source address
	unsigned char	destination[IP_ADR_SIZE];// ip destination address
	} IP_HEADER_STRUCTURE;

//typedef IP_HEADER_STRUCTURE		*p_IP_HEADER_STRUCTURE

#pragma used+
extern IP_HEADER_STRUCTURE	ip_header;                                    	
extern unsigned char ip_of_last_frame[IP_ADR_SIZE];	// 32 bit IP

extern unsigned char ip_address[IP_ADR_SIZE];		// "IP_DEFAULT_0.IP_DEFAULT_1.IP_DEFAULT_2.IP_DEFAULT_3"
extern unsigned char ip_subnet_mask[IP_ADR_SIZE];	// "SUBMASK1.SUBMASK2.SUBMASK3.SUBMASK4"
extern unsigned char ip_gateway[IP_ADR_SIZE];		// "IP_GATEWAY_DEFAULT_0.IP_GATEWAY_DEFAULT_1.IP_GATEWAY_DEFAULT_2.IP_GATEWAY_DEFAULT_3"

void 			ip_process_frame(unsigned char broadcast_flag);
unsigned int	ip_checksum(void *data, unsigned int count, unsigned char *tcp_ip_remote);
unsigned char	ip_header_write(unsigned char *eth_data, unsigned int *ip_length, unsigned char *ip_offset, 
							  unsigned char ip_protocol, unsigned char *ip_source, unsigned char *ip_destination);
unsigned char 	ip_compare(unsigned char* ip1, unsigned char* ip2);
unsigned char 	ip_comparef(unsigned char* ip1, unsigned char flash* ip2);

#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library ip.c
#endif

#endif	// #ifndef _IP_INCLUDED_