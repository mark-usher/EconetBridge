// ************************************************************************************************
///
/// \file 			measure.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifdef	WEB_DEBUG_MEASURE

#ifndef _MEASURE_INCLUDED_
#define _MEASURE_INCLUDED_

#if (_MCU_CLOCK_FREQUENCY_==16000000)
#define	MEASURE_TIME	16			// 16�sec with 1 clock of 16bit-Timer1 (_MCU_CLOCK_FREQUENCY_/256)
#endif

#if (_MCU_CLOCK_FREQUENCY_==8000000)
#define	MEASURE_TIME	32			// 32�sec with 1 clock of 16bit-Timer1 (_MCU_CLOCK_FREQUENCY_/256)
#endif

#if (_MCU_CLOCK_FREQUENCY_==7372800)
#define	MEASURE_TIME	35			// 34.72�sec with 1 clock of 16bit-Timer1 (_MCU_CLOCK_FREQUENCY_/256)
#endif


#define MEA_BUFFER_FRAME1_S		0	 	// see file buffer.c and function "buffer_process"
#define MEA_BUFFER_FRAME1_E		1		// see file buffer.c and function "buffer_process"
#define MEA_BUFFER_FRAME2_S		2		// see file buffer.c and function "buffer_process"
#define MEA_BUFFER_FRAME2_E		3		// see file buffer.c and function "buffer_process"
#define MEA_UDP_CHECKSUM_S		4		// see file udp.c and function "udp_send_frame"
#define MEA_UDP_CHECKSUM_E		5		// see file udp.c and function "udp_send_frame"
#define MEA_ICMP_CHECKSUM_S1	6		// see file icmp.c and function "icmp_prepare_echo_reply"
#define MEA_ICMP_CHECKSUM_E1	7		// see file icmp.c and function "icmp_prepare_echo_reply"
#define MEA_ICMP_CHECKSUM_S2	8		// see file icmp.c and function "icmp_prepare_echo_reply"
#define MEA_ICMP_CHECKSUM_E2	9		// see file icmp.c and function "icmp_prepare_echo_reply"
#define MEA_TCP_CHECKSUM_S1		10		// see file tcp.c and function "tcp_prepare_frame", "tcp_prepare_data_frame"
#define MEA_TCP_CHECKSUM_E1		11		// see file tcp.c and function "tcp_prepare_frame", "tcp_prepare_data_frame"
#define MEA_TCP_CHECKSUM_S2		12		// see file tcp.c and function "tcp_prepare_frame", "tcp_prepare_data_frame"
#define MEA_TCP_CHECKSUM_E2		13		// see file tcp.c and function "tcp_prepare_frame", "tcp_prepare_data_frame"
#define MEA_TCP_DATA_S			14		// see file tcp.c and function "tcp_prepare_data_frame"
#define MEA_TCP_DATA_E			15		// see file tcp.c and function "tcp_prepare_data_frame"
#define MEA_TCP_FRAME_S			16		// see file tcp.c and function "tcp_prepare_frame"
#define MEA_TCP_FRAME_E			17		// see file tcp.c and function "tcp_prepare_frame"
#define MEA_ICMP_ECHO_S			18		// see file icmp.c and function "icmp_prepare_echo_reply"
#define MEA_ICMP_ECHO_E			19		// see file icmp.c and function "icmp_prepare_echo_reply"
#define MEA_ARP_ANSWER_S		20		// see file arp.c and function "arp_prepare_answer"
#define MEA_ARP_ANSWER_E		21		// see file arp.c and function "arp_prepare_answer"
#define MEA_ARP_REQUEST_S		22		// see file arp.c and function "arp_prepare_request"
#define MEA_ARP_REQUEST_E		23		// see file arp.c and function "arp_prepare_request"
#define MEA_TCP_S				24		// see file tcp.c and function "tcp_process_frame"
#define MEA_TCP_E1				25		// see file tcp.c and function "tcp_process_frame"
#define MEA_TCP_E2				26		// see file tcp.c and function "tcp_process_frame"
#define MEA_TCP_E3				27		// see file tcp.c and function "tcp_process_frame"
#define MEA_ETHERNET_S			28		// see file ethernet.c and function "ethernet_process_frame"
#define MEA_ETHERNET_E			29		// see file ethernet.c and function "ethernet_process_frame"
#define MEA_NET_S				30		// see file ethernet.c and function "ethernet_process"
#define MEA_NET_E				31		// see file ethernet.c and function "ethernet_process"
#define MEA_MAIN_S				32		// see file avr_web.c and function "main"
#define MEA_MAIN_E				33		// see file avr_web.c and function "main"

#define MEA_MAX_TIMES			34
#define MEA_MAX_TIME_FRAMES		4

#define MEASURE_SETTIME(x)     measure_pointer->time[x]=TCNT1; measure_pointer->over[x]=measure_timer1;

#pragma used+
/*  --------------------------------------------------------------------------------
 *	Data Buffer structure
 *  -------------------------------------------------------------------------------- */
typedef struct 
	{
	unsigned int	time[MEA_MAX_TIMES];	 	// 16bit timer count
	unsigned char	over[MEA_MAX_TIMES];		// overflow count
	}MEASURE_FRAME;

typedef		MEASURE_FRAME	*p_MEASURE_FRAME;

extern unsigned char	measure_timer1;    // count with every overflow of timer1 XTAL/256
extern unsigned char	measure_flag;		// flag to switch to a new TIME_FRAME
extern MEASURE_FRAME	measure_buffer[MEA_MAX_TIME_FRAMES];
extern p_MEASURE_FRAME	measure_pointer;	

void measure_init(void);
void measure_time(void);
void measure_switch_time_frame(void);
void measure_diplay(void);
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library measure.c
#endif

#endif		// #ifdef	WEB_DEBUG_MEASURE
#endif		// #ifndef _MEASURE_INCLUDED_