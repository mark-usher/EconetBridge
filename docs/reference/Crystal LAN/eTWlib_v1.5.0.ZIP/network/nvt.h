// *********************************************************************************
///
/// \file ip2serial.h
///
/// implements telnet functions by using the easyToWeb-API
///
/// \par Created
///					01.09.2005
/// \date	 		$LastChangedDate: 2007-04-16 09:16:49 +0200 (Mo, 16 Apr 2007) $
/// \version 		$Rev: 664 $
///	\author  		Thomas Kellner
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// *********************************************************************************
#ifndef _IP2SERIAL_INCLUDED_
#define _IP2SERIAL_INCLUDED_

#include "project.h"
#include "debug.h"


// Macros to define in project.h:
/// \def IP2SERIAL_TCP_PORT_TELNET
///     define the 1st default local tcp port for telnet server connection
/// \def IP2SERIAL_TCP_MAX_WINDOW_SIZE
///     define the maximum window size for tcp communication
/// \def IP2SERIAL_TELNET_NVT_ENABLE
///     enable nvt support reffering to rfc2217 <br>
///     nvt support must also be enabled in telnet client (hw virtual serial port)

#ifndef IP2SERIAL_TCP_PORT_TELNET
#define IP2SERIAL_TCP_PORT_TELNET           23
#endif

#define IP2SERIAL_CONN_ENABLE_BIT           0x01
#define IP2SERIAL_CONN_PORT_CHANGE_BIT      0x02

#ifdef IP2SERIAL_DEBUG
#define IP2SERIAL_STATISTIC
#endif

#ifdef IP2SERIAL_TELNET_NVT_ENABLE
#define NVT_OPTION_BUFFER_SIZE              20
// --------------------------------------------------------------------------------
// nvt command macros
// --------------------------------------------------------------------------------
#define NVT_CMD_IAC         0xff    // interprete as command (start of nvt data)
#define NVT_CMD_SE          0xf0    // end of subnegotiation
#define NVT_CMD_NOP         0xf1    // no operation
#define NVT_CMD_DM          0xf2    // dara mark
#define NVT_CMD_BRK         0xf3    // break
#define NVT_CMD_IP          0xf4    // suspend or interrupt
#define NVT_CMD_AO          0xf5    // abort output
#define NVT_CMD_AYT         0xf6    // are you there
#define NVT_CMD_EC          0xf7    // erase character
#define NVT_CMD_EL          0xf8    // erase line
#define NVT_CMD_GA          0xf9    // go ahead
#define NVT_CMD_SB          0xfa    // start of subnegotiation
#define NVT_CMD_WILL        0xfb    // indicates desire to begin performing
#define NVT_CMD_WONT        0xfc    // indicates refusal to perform
#define NVT_CMD_DO          0xfd    // indicates request to the other party to perform
#define NVT_CMD_DONT        0xfe    // indicates request to the other party to stop performing
// --------------------------------------------------------------------------------
// nvt option macros
// --------------------------------------------------------------------------------
#define NVT_OPTN_ECH        0x01    // echo
#define NVT_OPTN_SGA        0x03    // suppress go ahead
#define NVT_OPTN_ST         0x05    // status
#define NVT_OPTN_TM         0x06    // timing mark
#define NVT_OPTN_TT         0x18    // terminal type
#define NVT_OPTN_WS         0x1F    // window size
#define NVT_OPTN_TS         0x20    // terminal speed
#define NVT_OPTN_RFC        0x21    // remote flow control
#define NVT_OPTN_LM         0x22    // line mode
#define NVT_OPTN_EV         0x24    // environment variables
#define NVT_OPTN_CP         0x2c    // control option
// --------------------------------------------------------------------------------
// nvt cas (client to access server) macros
// --------------------------------------------------------------------------------
#define NVT_CAS_SIGNATURE       0x00    // cas_signature
#define NVT_CAS_BAUDRATE        0x01    // cas_set_baudrate
#define NVT_CAS_DATASIZE        0x02    // cas_set_datasize
#define NVT_CAS_PARITY          0x03    // cas_set_parity
#define NVT_CAS_STOPSIZE        0x04    // cas_set_stopsize
#define NVT_CAS_CONTROL         0x05    // cas_set_control
#define NVT_CAS_NTFY_LINESTATE  0x06    // cas_notify_linestate
#define NVT_CAS_NTFY_MODEMSTATE 0x07    // cas_notify_modemstate
#define NVT_CAS_FC_SUSPEND      0x08    // cas_flowcontrol_suspend
#define NVT_CAS_FC_RESUME       0x09    // cas_flowcontrol_resume
#define NVT_CAS_LINESTATE_MASK  0x0a    // cas_set_linestate_mask
#define NVT_CAS_MODEMSTATE_MASK 0x0b    // cas_set_modemstate_mask
#define NVT_CAS_PURGE_DATA      0x0c    // cas_purge_data
// --------------------------------------------------------------------------------
// nvt asc (access server to client) macros
// --------------------------------------------------------------------------------
#define NVT_ASC_SIGNATURE       0x64    // acs_signature
#define NVT_ASC_BAUDRATE        0x65    // acs_set_baudrate
#define NVT_ASC_DATASIZE        0x66    // acs_set_datasize
#define NVT_ASC_PARITY          0x67    // acs_set_parity
#define NVT_ASC_STOPSIZE        0x68    // acs_set_stopsize
#define NVT_ASC_CONTROL         0x69    // acs_set_control
#define NVT_ASC_NTFY_LINESTATE  0x6a    // acs_notify_linestate
#define NVT_ASC_NTFY_MODEMSTATE 0x6b    // acs_notify_modemstate
#define NVT_ASC_FC_SUSPEND      0x6c    // acs_flowcontrol_suspend
#define NVT_ASC_FC_RESUME       0x6d    // acs_flowcontrol_resume
#define NVT_ASC_LINESTATE_MASK  0x6e    // acs_set_linestate_mask
#define NVT_ASC_MODEMSTATE_MASK 0x6f    // acs_set_modemstate_mask
#define NVT_ASC_PURGE_DATA      0x70    // acs_purge_data
#endif  // #ifdef IP2SERIAL_TELNET_NVT_ENABLE

// --------------------------------------------------------------------------------
// states for telnet_server
// --------------------------------------------------------------------------------
typedef enum {
    NVT_CMD_INIT,
    NVT_CMD_NONE,
	NVT_CMD_START,
	NVT_CMD_SUBNEG,
    NVT_CMD_COMPORT_OPTION,
	NVT_CMD_OPTION,
	NVT_CMD_PARAM
} T_TELNET_NVT_STATUS;

// --------------------------------------------------------------------------------
// states for ip2serial connections
// --------------------------------------------------------------------------------
#define IP2SERIAL_CONNECTION_MAX    2
typedef enum {
	IP2SERIAL_CONNECTION_1,
	IP2SERIAL_CONNECTION_2
//	IP2SERIAL_CONNECTION_3
//	IP2SERIAL_CONNECTION_4
} T_IP2SERIAL_CONNECTION;

typedef enum {
    IP2SERIAL_TIMEOUT_CHECK,
    IP2SERIAL_TIMEOUT_RESET
} T_IP2SERIAL_TIMEOUT_ACCESS;

typedef struct{
    unsigned char           connection_status;
    unsigned char           protocol;
    unsigned char           packetsize;
    unsigned int            timeout_ms;
    unsigned int            local_port;
} T_IP2SERIAL_CONFIG_STRUCT;

typedef struct{
	unsigned int            rx_count;   // count of total rx bytes
	unsigned int            tx_count;   // count of total tx bytes
	unsigned int            rx_lost;    // count of total lost rx bytes
	unsigned int            tx_lost;    // count of total lost tx bytes
} T_IP2SERIAL_STAT_STRUCT;

typedef struct{
	unsigned long           baudrate;
	unsigned char           datasize;
	unsigned char           parity;
	unsigned char           stopsize;
} T_IP2SERIAL_NVT_STRUCT;

typedef struct{
    void                    (*fp_buffer_read)(T_IP2SERIAL_CONNECTION, unsigned char *p_data, unsigned int size);
    void                    (*fp_buffer_write)(T_IP2SERIAL_CONNECTION, unsigned char *p_data, unsigned int size);
    unsigned int            (*fp_buffer_get_rx_count)(T_IP2SERIAL_CONNECTION);
    unsigned int            (*fp_buffer_get_tx_gap)(T_IP2SERIAL_CONNECTION);
    T_IP2SERIAL_CONFIG_STRUCT cfg;
	#ifdef IP2SERIAL_STATISTIC
    T_IP2SERIAL_STAT_STRUCT stat;
	#endif
	#ifdef IP2SERIAL_NVT_ENABLE
	T_IP2SERIAL_NVT_STRUCT  nvt;
	#endif
} T_IP2SERIAL_STRUCT;

#pragma used+
#ifdef IP2SERIAL_DEBUG
#define IP2SERIAL_DEBUG_BIT          0x01
extern eeprom unsigned char ip2serial_debug_flag;
#endif

void	            ip2serial_main(void);
unsigned char       ip2serial_init(void);
unsigned char       ip2serial_connection_enabled(unsigned char Lva);
void                ip2serial_set_config_struct(T_IP2SERIAL_CONFIG_STRUCT *p_struct, unsigned char Lva);
T_IP2SERIAL_STRUCT* ip2serial_get_struct(unsigned char Lva);
#ifdef IP2SERIAL_DEBUG
void                ip2serial_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);
#endif
#pragma used-

#endif	// #ifndef _IP2SERIAL_INCLUDED_
