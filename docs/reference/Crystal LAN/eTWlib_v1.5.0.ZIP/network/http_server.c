// ************************************************************************************************
///
/// \file 			http_server.c
/// \brief			HTTP server
///
/// \todo			Implement multichannel HTTP connections
/// \date	 		$LastChangedDate: 2007-07-10 14:20:40 +0200 (Di, 10 Jul 2007) $
/// \version 		$Rev: 670 $
///	\todo			Check, if http_server.c is really generic. Can an generic webpage by easily
///					included? Check http_server_dynamic_values()
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
/// \par History
///					1.) 04.11.2003 Version 2.02
///					2.) 02.12.2003 Version 2.03
///						a.)	- HTTP-Server supports now a default start file, see 
///							"HTTP_DEFAULT_FILE"
///					3.) 17.01.2005 Version 2.06
///						a.)	- HTTP-Server with Default, File and CGI support
///						--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef HTTP_ENABLE

#include <stdio.h>
#include <string.h>
#include <delay.h>
#include "device.h"
#include "buffer.h"
#ifdef WEB_DEBUG
#include "web_debug.h"
#endif
#include "board.h"
#ifdef ETHERNET_ENABLE
#include "ethernet.h"
#endif
#ifdef TCP_ENABLE
#include "tcp.h"
#endif
#ifdef HTTP_ENABLE
#include "http_server.h"
#include "webpage.h"
#endif	// #ifdef HTTP_ENABLE
#ifdef WEB_DEBUG_MEASURE			// enable time-measure debug functions, see measure.c
#include "measure.h"
#endif
#ifdef FTP_ENABLE
#include "ftp_server.h"
#endif	// #ifdef FTP_ENABLE
#include "util.h"
#include "debug.h"
#ifdef DATAFLASH_FILE_ENABLE
#include "dataflash_file.h"
#include "dataflash_file_debug.h"
#endif


#define HTTP_COMMAND_SIZE		20
#define HTTP_PARAMETER_SIZE		40

#pragma regalloc-
unsigned char 	http_server_tcp=TCP_WRONG_CONNECTIONS;
unsigned char 	http_command[HTTP_COMMAND_SIZE+1];
unsigned char 	http_parameter[HTTP_PARAMETER_SIZE+1];
#ifdef DATAFLASH_FILE_ENABLE
unsigned char 	http_file_handle=FILE_HANDLE_DISABLE;
unsigned char 	http_server_file_data_buffer[TCP_TX_SEGMENT_SIZE];
#endif
#pragma regalloc+


//*********************************************************************************
// Description	: generate a HTTP-Response and write it to TCP-Data-Buffer
// Input	   	: response_code - pointer to HTTP-Response-Code
//      	   	: file_size		- size of file, see dataflash_file.h
//          	: file_type		- type of file, see dataflash_file.h and "FILE_TYP"
// Output      	: 1 - file read OK; file start OK; tcp write OK
//              : 0 - file read Error; file open Error; tcp write Error
// Indication	: none
//*********************************************************************************
unsigned char http_response(flash unsigned char *response_code, unsigned long data_size, flash unsigned char *message)
{
unsigned char http_buffer[50];
#ifdef DATAFLASH_FILE_ENABLE
FILE_TYP file_type;
DATE_STRUCT file_time;
#endif

if(tcp_tx_buffer_write(http_server_tcp, 0x0, 0, TCP_TX_BUFFER_GET_SIZE)==0)	// get whole size of buffer
	return 0;	// TCP is busy
tcp_tx_buffer_write_f(http_server_tcp, "HTTP/1.1 ", strlenf("HTTP/1.1 "), TCP_TX_BUFFER_WRITE_FLASH_DATA);	// 
tcp_tx_buffer_write_f(http_server_tcp, response_code, strlenf(response_code), TCP_TX_BUFFER_WRITE_FLASH_DATA);	// 
tcp_tx_buffer_write_f(http_server_tcp, "\r\nServer: "DEBUG_PROJECT_NAME" "DEBUG_PROJECT_VERSION"\r\n", 
                      strlenf("\r\nServer: "DEBUG_PROJECT_NAME" "DEBUG_PROJECT_VERSION"\r\n"), TCP_TX_BUFFER_WRITE_FLASH_DATA);
#ifdef DATAFLASH_FILE_ENABLE
if(http_file_handle!=FILE_HANDLE_DISABLE)
	{
	dataflash_file_size(http_file_handle, &data_size);
	dataflash_file_gettype(http_file_handle, &file_type);
	dataflash_file_gettime(http_file_handle, &file_time);
	sprintf(http_buffer, "Last-Modified: Thu, 15 Mar 2004 %02u:%02u:%02u GMT\r\n", file_time.hour, 
											file_time.minute, file_time.second);	// 
	tcp_tx_buffer_write(http_server_tcp, http_buffer, strlen(http_buffer), TCP_TX_BUFFER_WRITE_RAM_DATA);	// 
	switch(file_type)
		{
		case FILE_TYPE_HTML : tcp_tx_buffer_write_f(http_server_tcp, "Content-Type: text/html\r\n", strlenf("Content-Type: text/html\r\n"), TCP_TX_BUFFER_WRITE_FLASH_DATA); break;
		case FILE_TYPE_JPEG : tcp_tx_buffer_write_f(http_server_tcp, "Content-Type: image/jpeg\r\n", strlenf("Content-Type: image/jpeg\r\n"), TCP_TX_BUFFER_WRITE_FLASH_DATA); break;
		case FILE_TYPE_CLASS: tcp_tx_buffer_write_f(http_server_tcp, "Content-Type: application/octet-stream\r\n", strlenf("Content-Type: application/octet-stream\r\n"), TCP_TX_BUFFER_WRITE_FLASH_DATA); break;
		default: tcp_tx_buffer_write_f(http_server_tcp, "Content-Type: text/html\r\n", strlenf("Content-Type: text/html\r\n"), TCP_TX_BUFFER_WRITE_FLASH_DATA); 
		}
	}
#else
tcp_tx_buffer_write_f(http_server_tcp, "Content-Type: text/html\r\n", strlenf("Content-Type: text/html\r\n"), TCP_TX_BUFFER_WRITE_FLASH_DATA);
#endif	// #ifdef	DATAFLASH_FILE_ENABLE
//tcp_tx_buffer_write_f(http_server_tcp, "Connection: close\r\n", strlenf("Connection: close\r\n"), TCP_TX_BUFFER_WRITE_FLASH_DATA);
if(message!=0x0)
	data_size+=strlenf(message);	// 
sprintf(http_buffer, "Content-Length: %lu\r\n\r\n", data_size);				// with endsign
tcp_tx_buffer_write(http_server_tcp, http_buffer, strlen(http_buffer), TCP_TX_BUFFER_WRITE_RAM_DATA);	// write data to TX-Buffer 
#ifdef WEB_DEBUG_HTTP
if(web_debug_flag & WEB_DEBUG_HTTP_BIT)
	printf("HTTP Response: \"%p\" %u Byte\r\n", response_code, data_size);
#endif	// #ifdef WEB_DEBUG_HTTP
if((message!=0x0)&&(*message!=0))
	tcp_tx_buffer_write_f(http_server_tcp, message, strlenf(message), TCP_TX_BUFFER_WRITE_FLASH_DATA);	// 
return 1;
}


//*********************************************************************************
// Description	: write data from file to tcp
// Input	   	: status - 	see HTTP_SERVER_FILE_STATUS
// Output      	: 0 - either no file open or file is empty
//                1 - OK (data write, tcp- busy or file close)
// Indication	: none
//*********************************************************************************
unsigned char http_server_file(HTTP_SERVER_FILE_STATUS status)
{
#ifdef DATAFLASH_FILE_ENABLE
unsigned int count;
TCP_STRUCTURE	*p_struct;                                    	

if(status==HTTP_SERVER_FILE_START)
	{
	if(http_file_handle!=FILE_HANDLE_DISABLE)
		{
		dataflash_file_close(&http_file_handle);
		#ifdef WEB_DEBUG_HTTP
		if(web_debug_flag & WEB_DEBUG_HTTP_BIT)
			putsf("HTTP Close File\r");
		#endif
		}
	if(!dataflash_file_open(http_parameter, &http_file_handle))
		return 0;
	http_response(HTTP_STATUS_200, 0, 0x0);
	}
if(status==HTTP_SERVER_FILE_CLOSE)
	{
	if(http_file_handle!=FILE_HANDLE_DISABLE)
		dataflash_file_close(&http_file_handle);
	return 1;
	}
p_struct=tcp_get_struct(http_server_tcp);
if((p_struct!=0)&&(p_struct->tcp_socket_status & SOCK_CONNECTED))
	{
	count=tcp_tx_buffer_write(http_server_tcp, 0x0, 0, TCP_TX_BUFFER_GET_SIZE);	// get size of buffer
	if(count<sizeof(http_server_file_data_buffer))	// too few data inside of TC-Buffer
		return 1;
	if(http_file_handle!=FILE_HANDLE_DISABLE)
		{
		if(count>sizeof(http_server_file_data_buffer))
			count=sizeof(http_server_file_data_buffer);
		count=dataflash_file_read(http_file_handle, http_server_file_data_buffer, count);	// read data
		tcp_tx_buffer_write(http_server_tcp, http_server_file_data_buffer, count, TCP_TX_BUFFER_WRITE_RAM_DATA);					// set size of data
		if(count!=0)
			{
			#ifdef WEB_DEBUG_HTTP
			if(web_debug_flag & WEB_DEBUG_HTTP_BIT)
				printf("HTTP DATA: %u Byte\r\n", count);
			#endif
			}
		else
			{
			if(http_file_handle!=FILE_HANDLE_DISABLE)
				dataflash_file_close(&http_file_handle);
			return 0;
			}
		}
	else
		{
		http_response(HTTP_STATUS_404, 0, "File Not Found\r\n");
		return 0;
		}
	}
return 1;
#else
status=0;
return 0;
#endif
}


//*********************************************************************************
// Description	: HTTP-Server
// Input	   	: none
// Output      	: none
// Indication	: none
//*********************************************************************************
void http_server(void)
{
static HTTP_SERVER_STATUS http_status=HTTP_SERVER_START;		// status byte 
unsigned char 	*p_data, Lva;
unsigned int 	tcp_data_size, Lvb;
TCP_STRUCTURE	*p_struct;                                    	

p_struct=tcp_get_struct(http_server_tcp);
if((p_struct!=0)&&(p_struct->tcp_socket_status & SOCK_CONNECTED))
	{
	if(http_status==HTTP_SERVER_START)
		{
		if(p_struct->tcp_socket_status & SOCK_DATA_AVAILABLE)	// check if remote TCP sent data
			{
			http_command[0]=0;
			http_parameter[0]=0;
			p_data=tcp_rx_buffer_read(http_server_tcp, 0x0, &tcp_data_size, TCP_RX_BUFFER_GET_SIZE);
			if(p_data && (tcp_data_size>(HTTP_COMMAND_SIZE+HTTP_PARAMETER_SIZE)))
				{
				Lva=0;
				while((*p_data!=' ')&&(Lva<HTTP_COMMAND_SIZE))
					{
					http_command[Lva]=*p_data++;
					Lva++;
					}
				http_command[Lva]=0;	// close string
				if(*p_data==' ')
					p_data++;
				if(*p_data=='/')
					p_data++;
				Lva=0;
				while((*p_data!=' ')&&(Lva<HTTP_PARAMETER_SIZE))
					{
					http_parameter[Lva]=*p_data++;
					Lva++;
					}
				http_parameter[Lva]=0;	// close string
				if(Lva==0)
					strncpyf(http_parameter, HTTP_DEFAULT_FILE, HTTP_PARAMETER_SIZE);
				}
			#ifdef WEB_DEBUG_HTTP
			if(web_debug_flag & WEB_DEBUG_HTTP_BIT)
				{
				printf("HTTP request: \"%s\" - \"%s\" %u Byte\r\n", http_command, http_parameter, tcp_data_size);
				//for(Lvb=0;Lvb<tcp_data_size;Lvb++)
				//	printf("%c", p_struct->tcp_rx.data_frame[Lvb]);
				}
			#endif
			if(strcmpf(http_command, "GET")==0)
				{
				tcp_rx_buffer_clear(http_server_tcp);		// clear and throw it away
				http_status=HTTP_SERVER_HTTP_GET;
				}
			else if(strcmpf(http_command, "POST")==0)
				http_status=HTTP_SERVER_HTTP_PUT;
			else
				tcp_rx_buffer_clear(http_server_tcp);		// clear and throw it away
			}	// if(p_struct->tcp_socket_status & SOCK_DATA_AVAILABLE)	// check if remote TCP sent data
		}	// 	if(http_status==HTTP_SERVER_START)
	else if(http_status==HTTP_SERVER_FILE_DATA)
		{
		if(!http_server_file(HTTP_SERVER_FILE_DATA))
			http_status=HTTP_SERVER_FILE_CLOSE;
		}
	else if(http_status==HTTP_SERVER_FILE_CLOSE)
		{
		http_server_file(HTTP_SERVER_FILE_CLOSE);	// close all files
		http_status=HTTP_SERVER_CLOSE_CONNECTION;
		}
	#ifdef WEBPAGE_DEFAULT_ENABLE
	else if(http_status==HTTP_SERVER_DATA)
		{
		if(!http_server_default(HTTP_SERVER_DEFAULT_DATA))
			http_status=HTTP_SERVER_CLOSE_CONNECTION;
		}
	#endif
	else if(http_status==HTTP_SERVER_CLOSE_CONNECTION)
		{
		tcp_close(http_server_tcp);			// close connection
		http_status=HTTP_SERVER_CLOSE;
		}
	else if(http_status==HTTP_SERVER_CLOSE)
		{
		tcp_rx_buffer_clear(http_server_tcp);		// clear and throw it away
		http_status=HTTP_SERVER_START;
		#ifdef WEB_DEBUG_HTTP
		if(web_debug_flag & WEB_DEBUG_HTTP_BIT)
			putsf("HTTP close\r");
		#endif
		}
	else if(http_status==HTTP_SERVER_HTTP_PUT)
		{
		p_data=tcp_rx_buffer_read(http_server_tcp, 0x0, &tcp_data_size, TCP_RX_BUFFER_GET_SIZE);
		if(p_data && (tcp_data_size>(HTTP_COMMAND_SIZE+HTTP_PARAMETER_SIZE)))
			{
			p_data=strstrf(p_data, "\r\n\r\n");		// search the end of HTTP-Request
			if(p_data!=0x0)					
				{
				p_data+=4;			   			// set pointer to start of data "\r\r\n\n"
//				Lvb=strstrf(p_struct->tcp_rx.data_frame, "\r\n\r\n");   // get position of string
//				Lvb+=4;
				Lvb=(unsigned int)(p_data - p_struct->tcp_rx.data_frame);   // get position of string
				#ifdef WEB_DEBUG_HTTP
				if(web_debug_flag & WEB_DEBUG_HTTP_BIT)
					{
					printf("HTTP POST: %u Byte\r\n", tcp_data_size);
					while(Lvb<tcp_data_size)
						{
						printf("%c", *p_data);
						p_data++;
						Lvb++;
						}
					putsf("\r"); 
					}
				#endif
				}
			tcp_rx_buffer_clear(http_server_tcp);		// clear and throw it away
			http_status=HTTP_SERVER_CLOSE_CONNECTION;
			}
		}
	else if(http_status==HTTP_SERVER_HTTP_GET)
		{
		if(http_server_file(HTTP_SERVER_FILE_START))	// start the data transfer
			http_status=HTTP_SERVER_FILE_DATA;
		else
			{
			#ifdef WEB_DEBUG_HTTP
			if(web_debug_flag & WEB_DEBUG_HTTP_BIT)
				printf("HTTP open File: \"%s\" Error!!\r\n", http_parameter);
			#endif
			#ifdef WEBPAGE_DEFAULT_ENABLE
			if(http_server_default(HTTP_SERVER_DEFAULT_START))	// start the data transfer
				http_status=HTTP_SERVER_DATA;
			else
				http_status=HTTP_SERVER_CLOSE_CONNECTION;
			#else
			http_response(HTTP_STATUS_404, 0, "File Not Found\r\n");	// answer with error-message
			http_status=HTTP_SERVER_FILE_CLOSE;
			#endif	// #ifdef WEBPAGE_DEFAULT_ENABLE
			}
		}
	}	// if(p_struct->tcp_socket_status & SOCK_CONNECTED)   	// check if somebody has connected to our TCP
else
	http_status=HTTP_SERVER_START;
}


#endif	// #ifdef HTTP_ENABLE