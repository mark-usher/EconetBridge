// ************************************************************************************************
///
/// \file 			arp_rarp.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _ARP_RARP_INCLUDED_
#define _ARP_RARP_INCLUDED_

#include "project.h"			// Project configuration
#include "ip.h"

#define ARP_FRAME	 			 0x0806              // frame types (stored in Type/Length field of IP-Frame)
#define RARP_FRAME				 0x8035				// frame types (stored in Type/Length field of IP-Frame)

// ARP definitions
#define ARP_HARDW_OFS			ETH_DATA_OFS + 0    // Hardware address type
#define ARP_PROT_OFS			ETH_DATA_OFS + 2    // Protocol
#define ARP_HLEN_PLEN_OFS		ETH_DATA_OFS + 4    // byte length of each hardw. / prot. address
#define ARP_OPCODE_OFS			ETH_DATA_OFS + 6    // Opcode
#define ARP_SENDER_HA_OFS		ETH_DATA_OFS + 8    // Hardw. address of sender of this packet
#define ARP_SENDER_IP_OFS		ETH_DATA_OFS + 14   // IP address of sender
#define ARP_TARGET_HA_OFS		ETH_DATA_OFS + 18   // Hardw. address of target of this packet
#define ARP_TARGET_IP_OFS		ETH_DATA_OFS + 24   // IP address of target
#define ARP_FRAME_SIZE			28

#define RARP_HARDW_OFS			ETH_DATA_OFS + 0    // Hardware address type
#define RARP_PROT_OFS			ETH_DATA_OFS + 2    // Protocol
#define RARP_HLEN_PLEN_OFS		ETH_DATA_OFS + 4    // byte length of each hardw. / prot. address
#define RARP_OPCODE_OFS			ETH_DATA_OFS + 6    // Opcode
#define RARP_SENDER_HA_OFS		ETH_DATA_OFS + 8    // Hardw. address of sender of this packet
#define RARP_SENDER_IP_OFS		ETH_DATA_OFS + 14   // IP address of sender
#define RARP_TARGET_HA_OFS		ETH_DATA_OFS + 18   // Hardw. address of target of this packet
#define RARP_TARGET_IP_OFS		ETH_DATA_OFS + 24   // IP address of target
#define RARP_FRAME_SIZE			28

#define HARDW_ETH10	  			1					// hardware-type 10Mbps Ethernet
#define IP_HLEN_PLEN			0x0604				// MAC = 6 byte long, IP = 4 byte long
#define ARP_OP_REQUEST			1					// operations for ARP-frames
#define ARP_OP_ANSWER			2
#define RARP_OP_REQUEST			3					// operations for RARP-frames
#define RARP_OP_ANSWER			4

#ifndef ARP_CACHE_SIZE
#define ARP_CACHE_SIZE			8
#endif

#if(ARP_CACHE_SIZE>255)
#error ERROR: "ARP_CACHE_SIZE" to big: ARP_CACHE_SIZE!!!
#endif

#ifndef RARP_DEFAULT_ANSWER_IP
#define RARP_DEFAULT_ANSWER_IP	{192, 168, 50, 250}	// rarp answer internet protocol (IP) address
#endif

//--------------------------------------------------------------------------------
//	see "arp_prepare_request()"
//-------------------------------------------------------------------------------- 
typedef enum {
  ARP_REQUEST_IP,		// ARP-Request to IP
  ARP_REQUEST_SELF,		// ARP-Request to myself
  ARP_REQUEST_GATEWAY	// ARP-Request to gateway
} ARP_REQUEST_MODE;


//  --------------------------------------------------------------------------------
//	ARP-Cache structure
//  -------------------------------------------------------------------------------- 
typedef struct{
	unsigned char	ip_adr[IP_ADR_SIZE];	// ip address
	unsigned char	mac_adr[6];				// MAC address
} ARP_CACHE_STRUCTURE;

//  --------------------------------------------------------------------------------
//	see "arp_request_timer()"
//  -------------------------------------------------------------------------------- 
typedef enum {
  ARP_REQUEST_TIMER_START,                               
  ARP_REQUEST_TIMER_CONTINUE
} ARP_REQUEST_TIMER_MODE;

#pragma used+
//  --------------------------------------------------------------------------------
// easyToWeb-API functions
//  --------------------------------------------------------------------------------
#ifdef ARP_CACHE_ENABLE
unsigned char *arp_cache(unsigned char *ip_adr, unsigned char *mac_adr);
#endif
void	arp_request_timer(ARP_REQUEST_TIMER_MODE mode);
void	rarp_prepare_request(void);
//  --------------------------------------------------------------------------------
// easyToWeb-internal functions
//  --------------------------------------------------------------------------------
void	arp_rarp_process_frame(unsigned char broadcast_flag);
void	arp_prepare_request(unsigned char *arp_ip, ARP_REQUEST_MODE mode);	// fill TX-buffers
void	arp_prepare_answer(void);
void	rarp_prepare_answer(unsigned char* rarp_ip);
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library arp_rarp.c
#endif

#endif	// #ifndef _ARP_RARP_INCLUDED_