// ************************************************************************************************
///
/// \file 			ipsec_sa_debug.c
/// \brief			Debug functions to display the SA's and debug IPSec functions
///
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		This document is part of embedded IPsec
///					Niklaus Schild and Christian Scheurer, HTI Biel/Bienne
///					This file contains code from the OpenSSL Project<BR>
///					Niklaus Schild <n.schild@gmx.ch> <BR>
///					portions Copyright (c) 1998-2003 OpenSSL (www.openssl.org)
///					easyToWeb-AVR and CodeVisionAVR C-Compiler:
///					Udo Jakobza - FTZ Leipzig; 04107 Leipzig; W�chterstr. 13
///					jakobza@e-technik.htwk-leipzig.de
///
/// \par License    
///					Redistribution and use in source and binary forms, with or without 
///					modification, are permitted provided that the following conditions are met:
///
///					1. Redistributions of source code must retain the above copyright notice,
///					   this list of conditions and the following disclaimer.
///					2. Redistributions in binary form must reproduce the above copyright notice,
///					    this list of conditions and the following disclaimer in the documentation
///					   and/or other materials provided with the distribution.
///					3. The name of the author may not be used to endorse or promote products
///					   derived from this software without specific prior written permission.
///
///					THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
///					WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
///					MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
///					EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
///					EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
///					OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
///					INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
///					CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
///					IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
///					OF SUCH DAMAGE.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#if defined(IPSEC_ENABLE)&&defined(WEB_DEBUG_IPSEC)

#include <string.h>
#include "icmp.h"
#include "ipsec_sa.h"
#include "debug.h"


#pragma regalloc-
//eeprom unsigned char ipsec_sa_debug_spd_entry=(IPSEC_MAX_SPD_ENTRIES-1);		// saves the actual active SPD Database
eeprom unsigned char ipsec_sa_debug_spd_entry=8;
eeprom unsigned char ipsec_debug_flag = 0x00;
#pragma regalloc+

// prototypes
void ipsec_sa_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);

//*********************************************************************************
// Description	: Prints a single SPD entry.
// Input	   	: @param entry pointer to the SPD entry
// Output     	: @return void
// Indication	: none
//*********************************************************************************
void ipsec_sa_debug_init(void)
{
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &ipsec_sa_debug_handler;
p_struct.id_string = "ipsec-sa";
debug_register_handler(&p_struct);
}


//*********************************************************************************
// Description	: Prints a single SPD entry.
// Input	   	: @param entry pointer to the SPD entry
// Output     	: @return void
// Indication	: none
//*********************************************************************************
void ipsec_sa_debug_spd_print_s(SA_MEMORY spd_entry_mem *entry)
{
printf("%u.%u.%u.%u/", entry->src[0], entry->src[1], entry->src[2], entry->src[3]);
printf("%u.%u.%u.%u  ", entry->src_netaddr[0], entry->src_netaddr[1], entry->src_netaddr[2], entry->src_netaddr[3]);
printf("%u.%u.%u.%u/", entry->dest[0], entry->dest[1], entry->dest[2], entry->dest[3]);
printf("%u.%u.%u.%u\r\n    %5u %5u 0x%x ", entry->dest_netaddr[0], entry->dest_netaddr[1], entry->dest_netaddr[2], entry->dest_netaddr[3],
							entry->src_port, entry->dest_port, entry->sa);
switch(entry->protocol)
	{
	case IP_ICMP_PROT:
		printf("ICMP ");
		break;
	case IP_TCP_PROT:
		printf("TCP  ");
		break;
	case IP_UDP_PROT:
		printf("UDP  ");
		break;
	case IP_IPSEC_AH_PROT:
		printf("AH   ");
		break;
	case IP_IPSEC_ESP_PROT:
		printf("ESP  ");
		break;
	default :
		printf("%4u", entry->protocol);
	}
switch(entry->policy)
	{
	case POLICY_APPLY:
		printf("APPLY") ; 
		break;
	case POLICY_BYPASS:
		printf("BYPASS") ; 
		break;
	case POLICY_DISCARD:
		printf("DISCARD") ; 
		break;
	default:
		printf("UNKNOWN") ;
	}
putsf("\r");
}

//*********************************************************************************
// Description	: Prints a Security Policy Database.
// Input	   	: @param table pointer to the SPD table
// Output     	: @return void
// Indication	: none
//*********************************************************************************
void ipsec_sa_debug_spd_print(flash unsigned char *info, SA_MEMORY spd_table_mem *table, unsigned char mode)
{
unsigned char index;

printf("SPD - %p:\r\n", info);
for(index = 0; index < IPSEC_MAX_SPD_ENTRIES; index++)
	{
	if((table->entry[index].use_flag == IPSEC_SA_USED)||(mode))
		{
		printf("%u-0x%04x) ", index, &table->entry[index]);
		ipsec_sa_debug_spd_print_s(&table->entry[index]);
		}
	}
}


//*********************************************************************************
// Description	: Prints a single SA entry.
// Input	   	: @param entry pointer to the SA entry which will be printed
// Output     	: @return void
// Indication	: none
//*********************************************************************************
void ipsec_sa_debug_sad_print_s(SA_MEMORY sad_entry_mem *entry)
{
printf("%u.%u.%u.%u/", entry->dest[0], entry->dest[1], entry->dest[2], entry->dest[3]);
printf("%u.%u.%u.%u\r\n    ", entry->dest_netaddr[0], entry->dest_netaddr[1], entry->dest_netaddr[2], entry->dest_netaddr[3]);
switch(entry->protocol)
	{
	case IP_IPSEC_ESP_PROT:
		printf("ESP ");
		break ;
	case IP_IPSEC_AH_PROT:
		printf("AH  ");
	}
switch(entry->mode)
	{
	case IPSEC_TUNNEL:
		printf("TUNNEL ");
		break ;
	case IPSEC_TRANSPORT:
		printf("TRANS  ");
	}
switch(entry->auth_alg)
	{
	case IPSEC_HMAC_MD5:
		printf("MD5  ");
		break ;
	case IPSEC_HMAC_SHA1:
		printf("SHA1 ");
	}
switch(entry->enc_alg)
	{
	case IPSEC_DES:
		printf("DES  ");
		break ;
	case IPSEC_3DES:
		printf("3DES ");
	}
printf("%2u %lu %u 0x%08lx 0x%08lx 0x%04x\r\n", entry->replay_win, entry->lifetime, entry->path_mtu, 
                                 entry->spi, *entry->seq, *entry->bitfield);
}

//*********************************************************************************
// Description	: Prints a SAD table.
// Input	   	: @param table pointer to the SAD table which will be printed
// Output     	: @return void
// Indication	: none
//*********************************************************************************
void ipsec_sa_debug_sad_print(flash unsigned char *info, SA_MEMORY sad_table_mem *table, unsigned char mode)
{
unsigned char index;

printf("SAD - %p:\r\n", info);
for(index = 0; index < IPSEC_MAX_SAD_ENTRIES; index++)
	{
	if((table->entry[index].use_flag == IPSEC_SA_USED)||(mode))
		{
		printf("%u-0x%04x) ", index, &table->entry[index]);
		ipsec_sa_debug_sad_print_s(&table->entry[index]);
		}
	}
}

//********************************************************************************
// Description	: flushes all entries of database
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ipsec_sa_flush_all(void)
{
SA_MEMORY db_set_netif *db_set;

db_set = ipsec_sa_load_database(0x0, 0x0, 0x0, 0x0);	// get pointer to database
ipsec_sa_spd_flush(db_set->inbound_spd, 0x0);
ipsec_sa_spd_flush(db_set->outbound_spd, 0x0);
ipsec_sa_sad_flush(db_set->inbound_sad);
ipsec_sa_sad_flush(db_set->outbound_sad);
}

//********************************************************************************
// Description	: help infos to the terminal commands
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ipsec_sa_debug_help(void)
{
putsf("\"sa-info\"  - prints \"IPSEC_SA_USED\" SAD and SPD entries\r"); 
putsf("\"sa-all\"   - prints all SAD and SPD entries\r"); 
putsf("\"sa-flush\" - flush all SAD and SPD entries\r"); 
putsf("\"sa-set <x>\" - set SAD[0..7] and SPD[0..8] to \"IPSEC_SA_USED\"\r"); 
}

//********************************************************************************
// Description	: sets a new SPD Database
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
unsigned char ipsec_sa_debug_new_spd(unsigned char new_spd)
{
SA_MEMORY db_set_netif *db_set;

if(new_spd==0xff)
	new_spd=ipsec_sa_debug_spd_entry;
if(new_spd>=IPSEC_MAX_SPD_ENTRIES)
	new_spd=0;
if(ipsec_sa_debug_spd_entry!=new_spd)
	ipsec_sa_debug_spd_entry=new_spd;		// saves the actual active SPD Database
ipsec_sa_flush_all();
db_set = ipsec_sa_load_database(0x0, 0x0, 0x0, 0x0);	// get pointer to database
db_set->inbound_spd->entry[new_spd].use_flag=IPSEC_SA_USED;
if(db_set->inbound_spd->entry[new_spd].sa!=NULL)
	db_set->inbound_spd->entry[new_spd].sa->use_flag=IPSEC_SA_USED;
db_set->outbound_spd->entry[new_spd].use_flag=IPSEC_SA_USED;
if(db_set->outbound_spd->entry[new_spd].sa!=NULL)
	db_set->outbound_spd->entry[new_spd].sa->use_flag=IPSEC_SA_USED;
return new_spd;
}


// ************************************************************************************************
/// \brief	    command handler for debug commands
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void ipsec_sa_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
SA_MEMORY db_set_netif *db_set;
int Lva;

if (mode == DEBUG_HANDLER_MODE_INFO)
	{
	#ifdef IPSEC_ENABLE
	putsf("IPSEC_ENABLE\r");
	#endif
	printf("WEB_DEBUG_IPSEC");
	if (ipsec_debug_flag)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
	}
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
	ipsec_sa_debug_help();
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
    {
	if (strncmpf(command, "ipsec", 5)==0)
		{
		ipsec_debug_flag ^= 0xff;
		if (ipsec_debug_flag)
			putsf("WEB_DEBUG_IPSEC ON\r");
		else
			putsf("WEB_DEBUG_IPSEC OFF\r");
		}
	}
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-info", 3)==0)
		{
		db_set = ipsec_sa_load_database(0x0, 0x0, 0x0, 0x0);	// get pointer to database
		ipsec_sa_debug_spd_print("inbound", db_set->inbound_spd, 0);
		/*
		#ifdef IPSEC_SA_MEMORY_SRAM
		web_debug_display_frame((unsigned char*)db_set->inbound_spd, sizeof(spd_table), sizeof(spd_entry));
		#else
		web_debug_display_frame_ee((eeprom unsigned char*)db_set->inbound_spd, sizeof(spd_table), sizeof(spd_entry));
		#endif
		*/
		ipsec_sa_debug_spd_print("outbound", db_set->outbound_spd, 0);
		/*
		#ifdef IPSEC_SA_MEMORY_SRAM
		web_debug_display_frame((unsigned char*)db_set->outbound_spd, sizeof(spd_table), sizeof(spd_entry));
		#else
		web_debug_display_frame_ee((eeprom unsigned char*)db_set->outbound_spd, sizeof(spd_table), sizeof(spd_entry));
		#endif
		*/
		ipsec_sa_debug_sad_print("inbound", db_set->inbound_sad, 0);
		/*
		#ifdef IPSEC_SA_MEMORY_SRAM
		web_debug_display_frame((unsigned char*)db_set->inbound_sad, sizeof(sad_table), sizeof(sad_entry));
		#else
		web_debug_display_frame_ee((eeprom unsigned char*)db_set->inbound_sad, sizeof(sad_table), sizeof(sad_entry));
		#endif
		*/
		ipsec_sa_debug_sad_print("outbound", db_set->outbound_sad, 0);
		/*
		#ifdef IPSEC_SA_MEMORY_SRAM
		web_debug_display_frame((unsigned char*)db_set->outbound_sad, sizeof(sad_table), sizeof(sad_entry));
		#else
		web_debug_display_frame_ee((eeprom unsigned char*)db_set->outbound_sad, sizeof(sad_table), sizeof(sad_entry));
		#endif
		*/
		}
	else if (strncmpf(command, "-all", 4)==0)
		{
		db_set = ipsec_sa_load_database(0x0, 0x0, 0x0, 0x0);	// get pointer to database
		ipsec_sa_debug_spd_print("inbound", db_set->inbound_spd, 1);
		ipsec_sa_debug_spd_print("outbound", db_set->outbound_spd, 1);
		ipsec_sa_debug_sad_print("inbound", db_set->inbound_sad, 1);
		ipsec_sa_debug_sad_print("outbound", db_set->outbound_sad, 1);
		}
	else if (strncmpf(command, "-flush", 3)==0)
		ipsec_sa_flush_all();
	else if (strncmpf(command, "-set", 3)==0)
		{
		Lva=debug_get_int_parameter(command);
		if(Lva!=-1)
			ipsec_sa_debug_new_spd(Lva);
		db_set = ipsec_sa_load_database(0x0, 0x0, 0x0, 0x0);	// get pointer to database
		ipsec_sa_debug_spd_print("inbound", db_set->inbound_spd, 0);
		ipsec_sa_debug_spd_print("outbound", db_set->outbound_spd, 0);
		ipsec_sa_debug_sad_print("inbound", db_set->inbound_sad, 0);
		ipsec_sa_debug_sad_print("outbound", db_set->outbound_sad, 0);
		}
	}
}

#endif	// #if defined(IPSEC_ENABLE)||defined(WEB_DEBUG_IPSEC)
