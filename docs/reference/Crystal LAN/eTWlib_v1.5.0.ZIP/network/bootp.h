// ************************************************************************************************
///
/// \file 			bootp.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _BOOTP_INCLUDED_
#define _BOOTP_INCLUDED_

// --------------------------------------------------------------------------------
// BOOTP general definitions
// -------------------------------------------------------------------------------- 
#ifndef	BOOTP_TIMEOUT
#define	BOOTP_TIMEOUT				1000	// 10 sec. timeout until wait of anwser from BootP-Server (max. 655,35 sec.)
#endif

// --------------------------------------------------------------------------------
// BOOTP frame definitions
// -------------------------------------------------------------------------------- 
#define BOOTP_FRAME_OP_REQUEST		1	// BootP Request (8 bit)
#define BOOTP_FRAME_OP_ANSWER		2	// BootP Answer (8 bit)

// --------------------------------------------------------------------------------
// BOOTP layer definitions
// -------------------------------------------------------------------------------- 
#define BOOTP_OP_OFS			    UDP_DATA_OFS + 0	// Operation (8 bit)
#define BOOTP_HTYPE_OFS			    UDP_DATA_OFS + 1	// hardware address type (8 bit)
#define BOOTP_HLEN_OFS			    UDP_DATA_OFS + 2	// hardware address length (8 bit)
#define BOOTP_HOPS_OFS			    UDP_DATA_OFS + 3	// hop field - client sets to zero (8 bit)
#define BOOTP_XID_OFS			    UDP_DATA_OFS + 4	// transaction ISD (32 bit)
#define BOOTP_SECS_OFS			    UDP_DATA_OFS + 8	// seconds elapsed since client started (16 bit)
#define BOOTP_UNUSED_OFS		    UDP_DATA_OFS + 10	// unused (16 bit)
#define BOOTP_CIADDR_OFS		    UDP_DATA_OFS + 12	// client IP address (32 bit)
#define BOOTP_YIADDR_OFS		    UDP_DATA_OFS + 16	// "your" (client) IP address (32 bit)
#define BOOTP_SIADDR_OFS		    UDP_DATA_OFS + 20	// server IP address (32 bit)
#define BOOTP_GIADDR_OFS		    UDP_DATA_OFS + 24	// gateway IP address (32 bit)
#define BOOTP_CHADDR_OFS		    UDP_DATA_OFS + 28	// client hardware address (16 byte)
#define BOOTP_SNAME_OFS			    UDP_DATA_OFS + 44	// optional server host name (64 byte)
#define BOOTP_FILE_OFS			    UDP_DATA_OFS + 108	// boot file name (128 byte)
#define BOOTP_VEND_OFS			    UDP_DATA_OFS + 236	// vendor-specific area (64 byte)

#define BOOTP_MIN_HEADER_SIZE	    44					// smallest BootP-Header
#define BOOTP_SERVER_NAME_SIZE	    64					// size of "Server Host Name" see (BOOTP_FILE_OFS-BOOTP_SNAME_OFS)
#define BOOTP_BOOT_FILE_SIZE	    128					// size of "Boot File Name" see (BOOTP_VEND_OFS-BOOTP_FILE_OFS)
#define BOOTP_VENDOR_SIZE		    64					// max. size of "Vendor Specific Area" see (BOOTP_MAX_HEADER_SIZE-BOOTP_VEND_OFS)
#define BOOTP_MAX_HEADER_SIZE	    300					// biggest size of BootP-Header sum of BOOTP_MIN_HEADER_SIZE+
													//										BOOTP_SERVER_NAME_SIZE+
													//										BOOTP_BOOT_FILE_SIZE+
													//										BOOTP_VENDOR_SIZE+
													
//#define BOOTP_HEADER_SIZE		    BOOTP_MIN_HEADER_SIZE
#define BOOTP_HEADER_SIZE		    BOOTP_MAX_HEADER_SIZE

// --------------------------------------------------------------------------------
// BOOTP vendor specific area
// -------------------------------------------------------------------------------- 
#define BOOTP_MAGIC_COOKIE			0x63825363L
#define	BOOTP_VENDOR_SUBNET			1
#define	BOOTP_VENDOR_GATEWAY		3
#define	BOOTP_VENDOR_DNS			6
#define	BOOTP_VENDOR_DOMAIN_NAME	15
#define	BOOTP_VENDOR_NETBIOS_NODE	46
#define	BOOTP_VENDOR_END			0xff


#if(UDP_TX_DATA_SIZE<BOOTP_HEADER_SIZE)
#error ERROR: BOOTP-TX-BUFFER too small: "UDP_TX_DATA_SIZE"==UDP_TX_DATA_SIZE (use >=BOOTP_HEADER_SIZE)!!!
#endif

// --------------------------------------------------------------------------------
// typedefs
// -------------------------------------------------------------------------------- 
typedef enum {			// modes of Timeout of BOOTP
  TIMEOUT_STOP_CHECK,	// mode to check if the timeout stops
  TIMEOUT_CHECK,		// mode to check the timeout
  TIMEOUT_START,		// first start of timeout
  TIMEOUT_RESTART,		// re-start of timeout
  TIMEOUT_CLEAR			// clear and stop of timeout
} BOOTP_TIMEOUT_TYP;

#pragma used+
//extern unsigned char 	udp_connection_bootp;
extern unsigned char 	bootp_ok;					// flag to signal the actual status of BooTP
void			bootp_init(void);
void 			bootp_request(BOOTP_TIMEOUT_TYP mode);
unsigned char	bootp_timeout(BOOTP_TIMEOUT_TYP mode);
void		 	bootp_answer(void);
void 			bootp_process(void);

#ifdef WEB_DEBUG_BOOTP
void 			bootp_display(void);
#endif
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library bootp.c
#endif

#endif	// #ifndef _UDP_INCLUDED_