// ************************************************************************************************
///
/// \file 			sys_delay.h
///
/// \date	 		$LastChangedDate: 2007-08-06 19:31:59 +0200 (Mo, 06 Aug 2007) $
/// \version 		$Rev: 673 $
///	\author  		Carsten K�gler, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br>
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup Tools
/// \addtogroup Tools
/// @{
/// \defgroup System_Timer
/// \addtogroup System_Timer
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define SYS_DELAY_ENABLE
#define SYS_DELAY_CHANNEL_SIZE     10
//@}
#endif

///	\def SYS_DELAY_ENABLE
///		This macro enables the System Delay module. SYSTIMER_ENABLE is also needed.
///
/// \def SYS_DELAY_CHANNEL_SIZE
///		Specifies the number of available delay channels. Must be at least 1.
                       
#ifndef _SYS_DELAY_INCLUDED_
#define _SYS_DELAY_INCLUDED_

#define SYS_DELAY_ERROR		0xff		///< errorcode for sys_delay functions

#pragma used+
void 		  sys_delay_init(void);
void 		  sys_delay_isr(void);
unsigned char sys_delay_register(void);
unsigned char sys_delay_start(unsigned int delay_10ms);
unsigned char sys_delay_restart(unsigned char delay_handle, unsigned int delay_ms);
unsigned char sys_delay_unregister(unsigned char delay_handle);
unsigned char sys_delay_ended(unsigned char delay_handle);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library sys_delay.c
#endif

#endif		// #ifndef _SYS_DELAY_INCLUDED_

/// @}
/// @}
