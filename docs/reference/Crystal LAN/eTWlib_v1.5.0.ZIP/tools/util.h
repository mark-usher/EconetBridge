// ************************************************************************************************
///
/// \file 			util.h
/// \brief			header file of util.c
///
/// \date	 		$LastChangedDate: 2007-02-19 16:50:32 +0100 (Mo, 19 Feb 2007) $
/// \version 		$Rev: 552 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#ifndef _UTIL_INCLUDED_
#define _UTIL_INCLUDED_

#pragma used+
void			util_memcpye(void *dest, eeprom void *src, unsigned int n);
unsigned int 	util_memcpy2e(eeprom void *dest, void *src, unsigned int n);
void   			util_memsete(eeprom void *dest, unsigned char c, unsigned int n);
unsigned int 	util_strstrfn(char *str1, char flash *str2);
unsigned char 	util_atoi_hex(unsigned char ascii_char);
unsigned char 	util_itoa_hex(unsigned char binary);
void 			util_swap16(void *out_data, void *in_data);
void 			util_swap32(void *out_data, void *in_data);
signed int 		util_ftoi(float float_input);
unsigned int 	util_round_int_devision(unsigned int x, unsigned int y);
unsigned int 	util_ceil_int_devision(unsigned int x, unsigned int y);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library util.c
#endif

#endif		// #ifndef _UTIL_INCLUDED_