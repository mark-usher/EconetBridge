// ************************************************************************************************
///
/// \file 			sys_callback.c
/// \brief			Enables Callback functions based on system timer
///
/// \todo			More testing. This module is EXPERIMENTAL
/// \date	 		$LastChangedDate: 2007-05-29 13:40:15 +0200 (Di, 29 Mai 2007) $
/// \version 		$Rev: 668 $
///	\author  		Carsten K�gler, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br>
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef _DOXYGEN_PARSER_
#define SYSTIMER_ENABLE
#define SYS_CALLBACK_ENABLE
#endif

#if defined(SYSTIMER_ENABLE) && defined(SYS_CALLBACK_ENABLE)

#include <string.h>
#include "systimer.h"
#include "sys_callback.h"

typedef struct {
	SYS_CALLBACK_ENUM	mode;            	 	///< mode for this callback function
	unsigned int    	countdown_tics;	 		///< countdown in system timer tics
	unsigned int    	interval_tics;			///< interval in system timer tics
	void            	(*fp_callback)(void);	///< function pointer
	} T_SYS_CALLBACK_STRUCT;

#pragma regalloc-
volatile T_SYS_CALLBACK_STRUCT sys_callback_struct[SYS_CALLBACK_CHANNEL_SIZE];
#pragma regalloc+

// ************************************************************************************************
/// \brief		Initialization data array
///
// ************************************************************************************************
void sys_callback_init(void)
{
unsigned char i;

memset(&sys_callback_struct, 0, sizeof(sys_callback_struct));
for (i=0; i<SYS_CALLBACK_CHANNEL_SIZE; i++)
	sys_callback_struct[i].mode = SYS_CALLBACK_UNUSED;
systimer_register_isr_hook(sys_callback_isr);
}


// ************************************************************************************************
/// \brief		Interrupt handling of callback functions
///
// ************************************************************************************************
void sys_callback_isr(void)
{
unsigned char i;

for (i=0; i<SYS_CALLBACK_CHANNEL_SIZE; i++)
	{
	if (sys_callback_struct[i].mode!=SYS_CALLBACK_UNUSED &&
		sys_callback_struct[i].fp_callback!=0)
		{
		if (sys_callback_struct[i].countdown_tics)
			sys_callback_struct[i].countdown_tics--;
		if (sys_callback_struct[i].countdown_tics == 0)
			{
			sys_callback_struct[i].fp_callback();
			if (sys_callback_struct[i].mode == SYS_CALLBACK_CYCLIC)
				sys_callback_struct[i].countdown_tics =
									sys_callback_struct[i].interval_tics;
			if (sys_callback_struct[i].mode == SYS_CALLBACK_ONCE)
            	sys_callback_struct[i].mode = SYS_CALLBACK_UNUSED;
			}

		}
	}
}


// ************************************************************************************************
/// \brief		Register callback function
/// @param[in]	fp   - function pointer, called in ISR
///	@param[in]	mode - specifies behaviour
///				       	SYS_CALLBACK_UNUSED - internal value. Do not use
///				       	SYS_CALLBACK_CYCLIC - callback function is executed again and again
///									   		  with specified interval
///				       	SYS_CALLBACK_ONCE   - callback function is executed once and
///											  automatically unregistered
///	@param[in]	interval - time in ms until callback function is called. Maximum time is
///						   65.540 seconds. Notice the granularity of the system timer. The exact
///						   delay time depends on when the next Timer/Counter interrupt occurs.
///						   Because of this, the time is rounded up to the next Timer/Counter tic.
///						   This ensures, that the delay is >= 'interval_ms'.
/// @retval		0..SYS_CALLBACK_CHANNEL_SIZE-1 - channel handle
/// @retval		SYS_CALLBACK_ERROR			   - error. SYS_CALLBACK_CHANNEL_SIZE too small
// ************************************************************************************************
unsigned char sys_callback_register(void (*fp)(void),
									SYS_CALLBACK_ENUM mode,
									unsigned int interval_ms)
{
unsigned char i;
unsigned char sreg_temp;

sreg_temp = SREG;
#asm("cli");

for (i=0; i<SYS_CALLBACK_CHANNEL_SIZE; i++)
    {
	if (sys_callback_struct[i].mode == SYS_CALLBACK_UNUSED)
		{
		sys_callback_struct[i].mode = mode;
		sys_callback_struct[i].fp_callback = fp;
		sys_callback_struct[i].interval_tics = SYS_MS2TICS(interval_ms);
		sys_callback_struct[i].countdown_tics = SYS_MS2TICS(interval_ms)+1; // round up to next T/C tic
		SREG = sreg_temp;
		return i;
		}
    }

SREG = sreg_temp;
return SYS_CALLBACK_ERROR;
}


// ************************************************************************************************
/// \brief		Unregister callback channel
/// \note		Functions, wich are called only once are unregistered automatically
/// @param[in]	fp   - function pointer
/// @retval		0                  - success. function unregistered
/// @retval		SYS_CALLBACK_ERROR - error function pointer unknown
// ************************************************************************************************
unsigned char sys_callback_unregister(void (*fp)(void))
{
unsigned char i;
unsigned char sreg_temp;

sreg_temp = SREG;
#asm("cli");

for (i=0; i<SYS_CALLBACK_CHANNEL_SIZE; i++)
    {
    if (sys_callback_struct[i].fp_callback == fp)
    	sys_callback_struct[i].mode = SYS_CALLBACK_UNUSED;
	SREG = sreg_temp;
    return 0;
    }

SREG = sreg_temp;
return SYS_CALLBACK_ERROR;
}

#endif	// #if defined(SYSTIMER_ENABLE) && (SYS_CALLBACK_CHANNEL_SIZE>0)
