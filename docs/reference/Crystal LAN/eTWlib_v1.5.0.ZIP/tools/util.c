// ************************************************************************************************
///
/// \file 			util.c
/// \brief			Various utility functions
///
/// \date	 		$LastChangedDate: 2007-01-05 18:12:48 +0100 (Fr, 05 Jan 2007) $
/// \version 		$Rev: 446 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
/// \par History
///					1.) 30.07.2003 Version 2.00a
///					2.) 11.11.2003 Version 2.02
///						a.)	- add variable "second_counter"(32bit) and
///					          "day_counter"(16bit)
///					3.) 30.01.2004 Version 2.03
///						a.)	- functions memcpye() and memcpy2e() now with 16bit count
///					4.) 31.01.2004 Version 2.03
///						a.)	- new function memsete(), see memset
///					5.) 25.02.2004 Version 2.03
///					    a.) - new file structure
///					-- this History will no be continued, see Subversion --
///
// ************************************************************************************************

#include "project.h"			// project configuration

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "util.h"

#pragma regalloc-
#pragma regalloc+


// ************************************************************************************************
/// \brief		   	Copies n bytes from src to dest
///
/// @param[in,out] 	dest - pointer to destination-string in SRAM
/// @param[in]	   	src  - pointer to source-string in EEPROM
/// @param[in]		n    - bytes to copy
// ************************************************************************************************
void util_memcpye(void *dest, eeprom void *src, unsigned int n)
{
while (n)
	{
	*(unsigned char*)dest=*(eeprom unsigned char*)src;
	(unsigned char*)dest++;
	(eeprom unsigned char*)src++;
	n--;
	}
}


// ************************************************************************************************
/// \brief		   	Copies n bytes from src to dest
///					Only bytes that differ are written to EEPROM
///
/// @param[in,out] 	dest - pointer to source-string in EEPROM
/// @param[in]	   	src  - pointer to destination-string in SRAM
/// @param[in]		n    - bytes to copy
/// @return			count of written values (dest was different from src)
// ************************************************************************************************
unsigned int util_memcpy2e(eeprom void *dest, void *src, unsigned int n)
{
unsigned int i=0;

while (n)
	{
	if (*(eeprom unsigned char*)dest!=*(unsigned char*)src)
		{
		*(eeprom unsigned char*)dest=*(unsigned char*)src;
		i++;
		}
	(eeprom unsigned char*)dest++;
	(unsigned char*)src++;
	n--;
	}
return i;
}


// ************************************************************************************************
/// \brief		   	Sets n bytes to given value
///
/// @param[in,out] 	dest - pointer to memory location in EEPROM
/// @param[in]	   	c  	 - value to write to 'dest'
/// @param[in]		n    - bytes to set
// ************************************************************************************************
void util_memsete(eeprom void *dest, unsigned char c, unsigned int n)
{
while (n)
	{
	if ((*(eeprom unsigned char*)dest)!=c)
		*(eeprom unsigned char*)dest=c;
	(eeprom unsigned char*)dest++;
	n--;
	}
}


// ************************************************************************************************
/// \brief		   	Searches the string str1, located in SRAM, for the first occurrence
///					of the string str2, located in FLASH.
///
/// @param[in]	 	str1 - pointer to string 1 in SRAM
/// @param[in]	   	str2 - pointer to string 2 in FLASH
/// @retval			0    - If there is no match
/// @retval			!=0  - the index to the character in str1 where str2 begins.
// ************************************************************************************************
unsigned int util_strstrfn(char *str1, char flash *str2)
{	
unsigned int Lva=0;
unsigned char str_len=0;

str_len=strlenf(str2);
while (*str1!=0x0)
	{
	if (strncmpf(str1, str2, str_len)==0)
		return Lva;
	str1++;
	Lva++;
	}
return Lva;
}


// ************************************************************************************************
/// \brief		   	Converts an hex value presented as ASCII-characters to an binary nibble
///
/// @param[in]	 	ascii_char -  '0' to '9' and 'A' to 'F' and 'a' to 'f'
/// @retval			0x00..0x0F - converted nibble 
/// @retval		   	0xFF	   - conversion error
// ************************************************************************************************
unsigned char util_atoi_hex(unsigned char ascii_char)
{
if (ascii_char>='0' && ascii_char<='9')
	return ascii_char-0x30;
else if (ascii_char>='A' && ascii_char<='F')
	return ascii_char-0x37;
else if (ascii_char>='a' && ascii_char<='f')
	return ascii_char-0x57;
return 0xff;
}


// ************************************************************************************************
/// \brief		   	Convert an binary nibble to the corresponding hex-ASCII-character
///
/// @param[in]	 	binary - binary nibble to convert: 0x00.. 0x0F
///							 must NOT be > 0x0F
/// @return		   	conversion result: '0'..'F'
// ************************************************************************************************
unsigned char util_itoa_hex(unsigned char binary)
{
if (binary < 0x0A)
	return (binary+0x30);
else
	return (binary+0x37);
}


// ************************************************************************************************
/// \brief		Function to swap the byte-order with 16bit
/// 
///	@param[in]	in_data - pointer to 16bit value
///	@param[out]	in_data - pointer to data buffer with at least 16bit size
// ************************************************************************************************
void util_swap16(void *out_data, void *in_data)
{
*((unsigned char*)out_data+1) = *((unsigned char*)in_data++);
*((unsigned char*)out_data) = *(unsigned char*)in_data;
}


// ************************************************************************************************
/// \brief		Function to swap the byte-order with 32bit
/// 
///	@param[in]	in_data - pointer to 32bit value
///	@param[out]	in_data - pointer to data buffer with at least 32bit size
// ************************************************************************************************
void util_swap32(void *out_data, void *in_data)
{
*((unsigned char*)out_data+3) = *((unsigned char*)in_data++);
*((unsigned char*)out_data+2) = *((unsigned char*)in_data++);
*((unsigned char*)out_data+1) = *((unsigned char*)in_data++);
*((unsigned char*)out_data) = *(unsigned char*)in_data;
}


// ************************************************************************************************
/// \brief		Rounds float to next integer-Value
/// 
///	@param[in]	float_input - float input to round
/// @return		rounded signed integer
// ************************************************************************************************
signed int util_ftoi(float float_input)
{
signed int output;

output = floor(float_input);
if ((float_input-output) >= 0.5)
	output++;
	
return output;
}


// ************************************************************************************************
/// \brief		make an "round" after an integer division
///				
/// @param[in]	x - dividend
/// @param[in]	y - divisior
/// @return		quotient
// ************************************************************************************************
unsigned int util_round_int_devision(unsigned int x, unsigned int y)
{
if (x%y >= y/2)
	return x/y+1;
else
	return x/y;
}


// ************************************************************************************************
/// \brief		make an "ceil" after an integer division
///				
/// @param[in]	x - dividend
/// @param[in]	y - divisior
/// @return		quotient
// ************************************************************************************************
unsigned int util_ceil_int_devision(unsigned int x, unsigned int y)
{
if (x%y == 0)
	return x/y;
else
	return x/y+1;
}
