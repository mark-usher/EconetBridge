// ************************************************************************************************
///
/// \file 			fifo.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _FIFO_INCLUDED_
#define _FIFO_INCLUDED_

typedef struct{
	unsigned char* 		 buffer;
	unsigned int 		 write_index;
	unsigned int 		 read_index;
	unsigned int 		 gap;
	unsigned int 		 size;
	unsigned char flash* name;
	unsigned int         debug_wr_counter;
} T_FIFO_STRUCT;

#pragma used+
void          fifo_init(T_FIFO_STRUCT* p_struct, unsigned char* p_buffer, unsigned int size, 
                            unsigned char flash* p_name);
void 		  fifo_reset(T_FIFO_STRUCT* p_struct);
unsigned int  fifo_write(T_FIFO_STRUCT* p_struct, unsigned char* p_data, unsigned int size);
unsigned int  fifo_read(T_FIFO_STRUCT* p_struct, unsigned char* p_data, unsigned int size);
void          fifo_debug_output(T_FIFO_STRUCT* p_struct);
unsigned char fifo_calc_average(T_FIFO_STRUCT* p_buffer);
unsigned char fifo_search_max(T_FIFO_STRUCT* p_buffer);
unsigned char fifo_search_min(T_FIFO_STRUCT* p_buffer);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library fifo.c
#endif

#endif	// #ifndef _FIFO_INCLUDED_