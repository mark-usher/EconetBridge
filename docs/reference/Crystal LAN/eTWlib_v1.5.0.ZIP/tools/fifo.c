// ************************************************************************************************
///
/// \file 			fifo.c
/// \brief			Generic fifo module
///
/// \date	 		$LastChangedDate: 2007-03-06 08:50:49 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 591 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#ifdef FIFO_ENABLE

#include "fifo.h"
#include "debug.h"


// ************************************************************************************************
/// \brief		Init FIFO buffer structure
///
/// @param[in]  p_struct - pointer to buffer structure, see T_FIFO_STRUCT
/// @param[in]  p_buffer - pointer to data array
/// @param[in]  size     - size, the buffer should have
/// @param[in]  p_name   - pointer to FLASH, where the name of the buffer is stored
// ************************************************************************************************
void fifo_init(T_FIFO_STRUCT* p_struct,
               unsigned char* p_buffer,
               unsigned int size,
               unsigned char flash* p_name)
{
p_struct->buffer = p_buffer;
p_struct->size = size;
p_struct->gap = size;
p_struct->write_index = 0;
p_struct->read_index = 0;
p_struct->name = p_name;
p_struct->debug_wr_counter=0;
}


// ************************************************************************************************
/// \brief		Resets ring buffer
///
/// @param[in]  p_struct - pointer to buffer structure, see T_FIFO_STRUCT
// ************************************************************************************************
void fifo_reset(T_FIFO_STRUCT* p_struct)
{
p_struct->gap = p_struct->size;
p_struct->write_index = 0;
p_struct->read_index = 0;
p_struct->debug_wr_counter=0;
}


// ************************************************************************************************
/// \brief		Writes some bytes in a ring buffer
///
/// @param[in]  p_struct - pointer to buffer structure, see T_FIFO_STRUCT
/// @param[in]  p_data   - pointer to data to write in buffer
/// @param[in]  size     - number of bytes to write
/// @return     number of bytes written. Should be equal to 'size'
// ************************************************************************************************
unsigned int fifo_write(T_FIFO_STRUCT* p_struct, unsigned char* p_data, unsigned int size)
{
unsigned int i;

for (i=0; i<size; i++)
    {
    if (p_struct->gap > 0)
        {
        p_struct->buffer[p_struct->write_index] = *p_data;
        p_struct->debug_wr_counter++;
        p_struct->gap--;
        p_data++;
        if (++p_struct->write_index == p_struct->size)
            p_struct->write_index = 0;
        }
    else    // sorry, buffer is full
        return i;
    }
return i;
}


// ************************************************************************************************
/// \brief		Reads some bytes from a ring buffer
///
/// @param[in]  p_struct - pointer to buffer structure, see T_FIFO_STRUCT
/// @param[out] p_data   - pointer to buffer, where to store data
/// @param[in]  size     - number of bytes to read
/// @return     number of bytes read. Should be equal to 'size'
// ************************************************************************************************
unsigned int fifo_read(T_FIFO_STRUCT* p_struct, unsigned char* p_data, unsigned int size)
{
unsigned int i;

for (i=0; i<size; i++)
    {
    if (p_struct->gap < p_struct->size)
        {
        *p_data = p_struct->buffer[p_struct->read_index];
        p_struct->gap++;
        p_data++;
        if (++p_struct->read_index == p_struct->size)
            p_struct->read_index = 0;
        }
    else    // sorry, buffer is empty
        return i;
    }
return i;
}


// ************************************************************************************************
/// \brief		Calculates average value of the content of the specified buffer
///
/// @param[in]  p_struct - pointer to buffer structure, see T_FIFO_STRUCT
/// @return     calculated average value
// ************************************************************************************************
unsigned char fifo_calc_average(T_FIFO_STRUCT* p_struct)
{
unsigned int act_index, i;
unsigned int bytes_in_buffer;
unsigned long sum=0;

bytes_in_buffer = p_struct->size - p_struct->gap;
if (bytes_in_buffer == 0)	// buffer empty
	return 0;
act_index = p_struct->read_index;

for (i=0; i<bytes_in_buffer; i++)
    {
    sum += p_struct->buffer[act_index];
    if (++act_index == p_struct->size)
    	act_index = 0;
    }

return sum/bytes_in_buffer;
}


// ************************************************************************************************
/// \brief		Returns maximum value of the content of the specified buffer
///
/// @param[in]  p_struct - pointer to buffer structure, see T_FIFO_STRUCT
/// @return     found minimum value
// ************************************************************************************************
unsigned char fifo_search_min(T_FIFO_STRUCT* p_struct)
{
unsigned int act_index, i;
unsigned int bytes_in_buffer;
unsigned int min;

bytes_in_buffer = p_struct->size - p_struct->gap;
act_index = p_struct->read_index;
min = p_struct->buffer[act_index];
for (i=0; i<bytes_in_buffer; i++)
    {
    if (min > p_struct->buffer[act_index])
    	min = p_struct->buffer[act_index];
    if (++act_index == p_struct->size)
    	act_index = 0;
    }

return min;
}


// ************************************************************************************************
/// \brief		Returns maximum value of the content of the specified buffer
///
/// @param[in]  p_struct - pointer to buffer structure, see T_FIFO_STRUCT
/// @return     found maximum value
// ************************************************************************************************
unsigned char fifo_search_max(T_FIFO_STRUCT* p_struct)
{
unsigned int act_index, i;
unsigned int bytes_in_buffer;
unsigned int max;

bytes_in_buffer = p_struct->size - p_struct->gap;
act_index = p_struct->read_index;
max = p_struct->buffer[act_index];
for (i=0; i<bytes_in_buffer; i++)
    {
    if (max > p_struct->buffer[act_index])
    	max = p_struct->buffer[act_index];
    if (++act_index == p_struct->size)
    	act_index = 0;
    }

return max;
}


// ************************************************************************************************
/// \brief		Debug function to output FIFO buffer
///
/// @param[in]  p_struct - pointer to buffer structure, see T_FIFO_STRUCT
// ************************************************************************************************
void fifo_debug_output(T_FIFO_STRUCT* p_struct)
{
putsf("Debug Output of FIFO-Buffer:\r");
printf("Name: \"%p\"\r\n", p_struct->name);
printf("Size: %u Bytes\r\n", p_struct->size);
printf("Gap: %u Bytes\r\n", p_struct->gap);
printf("Next write index: %u\r\n", p_struct->write_index);
printf("Next read index: %u\r\n", p_struct->read_index);
printf("Bytes written: %u Bytes\r\n", p_struct->debug_wr_counter);
p_struct->debug_wr_counter = 0;
putsf("Content:\r");
debug_display_mem_hex(p_struct->buffer, p_struct->size, 0);
}
#endif	// #ifdef FIFO_ENABLE