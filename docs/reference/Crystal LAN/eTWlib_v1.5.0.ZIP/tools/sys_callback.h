// ************************************************************************************************
///
/// \file 			sys_callback.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Carsten K�gler, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br>
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup Tools
/// \addtogroup Tools
/// @{
/// \defgroup System_Timer
/// \addtogroup System_Timer
/// @{


#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define SYS_CALLBACK_ENABLE
#define SYS_CALLBACK_CHANNEL_SIZE  10
//@}
#endif

///	\def SYS_CALLBACK_ENABLE
///		This macro enables the System Callback module. SYSTIMER_ENABLE is also needed.
///
/// \def SYS_CALLBACK_CHANNEL_SIZE
///		Specifies the number of callback functions, that can be registered. Must be at least 1.
                       

#ifndef _SYS_CALLBACK_INCLUDED_
#define _SYS_CALLBACK_INCLUDED_

#define SYS_CALLBACK_ERROR	0xff	///< errorcode for sys_callback functions

typedef enum {
	SYS_CALLBACK_UNUSED,			///< callback functions not used (internal value)
	SYS_CALLBACK_CYCLIC,			///< function is called periodically
	SYS_CALLBACK_ONCE				///< function is called only once
	} SYS_CALLBACK_ENUM;

#pragma used+
void 		  sys_callback_init(void);
void 		  sys_callback_isr(void);
unsigned char sys_callback_register(void (*fp)(void), SYS_CALLBACK_ENUM mode, unsigned int interval);
unsigned char sys_callback_unregister(void (*fp)(void));
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library sys_callback.c
#endif

#endif		// #ifndef _SYS_CALLBACK_INCLUDED_

/// @}
/// @}
