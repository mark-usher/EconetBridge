// ************************************************************************************************
///
/// \file 			sys_delay.c
/// \brief			Enables delays based on system timer
///
/// \todo			More testing. This module is EXPERIMENTAL
/// \date	 		$LastChangedDate: 2007-08-06 19:31:59 +0200 (Mo, 06 Aug 2007) $
/// \version 		$Rev: 673 $
///	\author  		Carsten K�gler, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br>
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef _DOXYGEN_PARSER_
#define SYSTIMER_ENABLE
#define SYS_DELAY_ENABLE
#endif

#if defined(SYSTIMER_ENABLE) && defined(SYS_DELAY_ENABLE)

#include <string.h>
#include "systimer.h"
#include "sys_delay.h"

typedef struct {
	unsigned int  countdown_tics;	///< countdown in system timer tics
	unsigned char channel_used;		///< 1, if this delay channel is in use
	} T_SYS_DELAY_STRUCT;

#pragma regalloc-
volatile T_SYS_DELAY_STRUCT sys_delay_struct[SYS_DELAY_CHANNEL_SIZE];
#pragma regalloc+


// ************************************************************************************************
/// \brief		Initialization data array
///
// ************************************************************************************************
void sys_delay_init(void)
{
memset(&sys_delay_struct, 0, sizeof(sys_delay_struct));	// clears field "channel_used"
systimer_register_isr_hook(sys_delay_isr);
}


// ************************************************************************************************
/// \brief		Interrupt handling for delay functions
///
// ************************************************************************************************
void sys_delay_isr(void)
{
unsigned char i;

for (i=0; i<SYS_DELAY_CHANNEL_SIZE; i++)
	{
	if (sys_delay_struct[i].channel_used)
		if (sys_delay_struct[i].countdown_tics > 0)
			sys_delay_struct[i].countdown_tics--;
	}
}


// ************************************************************************************************
/// \brief		Registers delay channel
///
/// @retval		0..SYS_DELAY_CHANNEL_SIZE-1 - success
/// @retval 	SYS_DELAY_ERROR	            - error
// ************************************************************************************************
unsigned char sys_delay_register(void)
{
unsigned char i;
unsigned char sreg_temp;

sreg_temp = SREG;
#asm("cli");

for (i=0; i<SYS_DELAY_CHANNEL_SIZE; i++)
    {
	if (sys_delay_struct[i].channel_used == 0)
		{
		sys_delay_struct[i].channel_used = 1;
		SREG = sreg_temp;
		return i;
		}
    }
SREG = sreg_temp;
return SYS_DELAY_ERROR;
}


// ************************************************************************************************
/// \brief		Register delay channel and start countdown
///	@param[in]	delay_ms - time in ms. Maximum time is 65.540 seconds. Notice the granularity
///						   of the system timer. The exact delay time depends on when the next
///						   Timer/Counter interrupt occurs. Because of this, the time is rounded
///				   		   up to the next Timer/Counter tic. This ensures, that the 
///						   delay is >= 'interval_ms'.
/// @retval		0..SYS_DELAY_CHANNEL_SIZE-1 - success
/// @retval 	SYS_DELAY_ERROR				- error
// ************************************************************************************************
unsigned char sys_delay_start(unsigned int delay_ms)
{
unsigned char i;
unsigned char sreg_temp;

sreg_temp = SREG;
#asm("cli");

for (i=0; i<SYS_DELAY_CHANNEL_SIZE; i++)
    {
	if (sys_delay_struct[i].channel_used == 0)
		{
		sys_delay_struct[i].countdown_tics = SYS_MS2TICS(delay_ms) + 1;
		sys_delay_struct[i].channel_used = 1;
		SREG = sreg_temp;
		return i;
		}
    }
SREG = sreg_temp;

return SYS_DELAY_ERROR;
}


// ************************************************************************************************
/// \brief		Restarts specific delay channel
/// @param[in]	delay_handle - handle, created by sys_delay_start()
///	@param[in]	delay_ms - time in ms. Maximum time is 65.540 seconds. Notice the granularity
///						   of the system timer. The exact delay time depends on when the next
///						   Timer/Counter interrupt occurs. Because of this, the time is rounded
///				   		   up to the next Timer/Counter tic. This ensures, that the 
///						   delay is >= 'interval_ms'.
/// @retval		0 				- success
/// @retval 	SYS_DELAY_ERROR	- error, delay_handle was not registered
// ************************************************************************************************
unsigned char sys_delay_restart(unsigned char delay_handle, unsigned int delay_ms)
{
unsigned char sreg_temp;

sreg_temp = SREG;
#asm("cli");

if (sys_delay_struct[delay_handle].channel_used == 0)
	{
	SREG = sreg_temp;
	return SYS_DELAY_ERROR;
	}
sys_delay_struct[delay_handle].countdown_tics = SYS_MS2TICS(delay_ms) + 1;
SREG = sreg_temp;
return 0;
}


// ************************************************************************************************
/// \brief		Unregisters delay channel
/// @param[in]	delay_handle - handle, created by sys_delay_start()
/// @retval		1 - handle was in use. Is now unregistered
/// @retval 	0 - unknown handle. Already ended?
// ************************************************************************************************
unsigned char sys_delay_unregister(unsigned char delay_handle)
{
if (sys_delay_struct[delay_handle].channel_used)
	{
	sys_delay_struct[delay_handle].channel_used = 0;
	return 1;
	}
else
	{
	sys_delay_struct[delay_handle].channel_used = 0;
	return 0;
	}
}


// ************************************************************************************************
/// \brief		Check countdown
/// \note		If time is expired, the delay channel is unregistered after calling this function.
/// \note		When specifying an unvalid delay_handle, the function result is not defined.
/// @param[in]	delay_handle - handle, created by sys_delay_start()
/// @retval		0 - time running
/// @retval		1 - time expired. Delay channel is now unregistered
// ************************************************************************************************
unsigned char sys_delay_ended(unsigned char delay_handle)
{
unsigned char sreg_temp;

sreg_temp = SREG;
#asm("cli");

if (sys_delay_struct[delay_handle].countdown_tics == 0)
	{
	SREG = sreg_temp;
    return 1;
    }
else
	{
	SREG = sreg_temp;
	return 0;
	}
}

#endif	// #if defined(SYSTIMER_ENABLE) && defined(SYS_DELAY_ENABLE)
