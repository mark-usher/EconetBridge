// ************************************************************************************************
///
/// \file 			dataflash_file.c
/// \brief			File system for AT45 Dataflashs
///
/// \todo			test changes in dataflash_file.c (see revision 139)
/// \date	 		$LastChangedDate: 2007-01-09 18:27:42 +0100 (Di, 09 Jan 2007) $
/// \version 		$Rev: 462 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// \par History
///					1.) 08.10.2003 Version 2.02
///						a.)	- add check, whether file open, see "dataflash_file_open()"
///					2.) 01.10.2004 Version 2.05b
///						a.)	- function "dataflash_file_check()" checks now the storage typ
///						--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef DATAFLASH_FILE_ENABLE

#include <math.h>
#include "dataflash_file.h"
#include "dataflash_file_debug.h"
#include "debug.h"
#ifdef ICMP_ENABLE
#include "icmp.h"
#endif

#pragma regalloc-
unsigned char dataflash_temp_buffer[FLASH_PAGE_SIZE];
unsigned char dataflash_file_buffer[FLASH_PAGE_SIZE];
FILE_HANDLE file_handle[FILE_HANDLE_COUNT];
unsigned char directory_actual=DIR_NAME_ROOT;
#pragma regalloc+

flash INFO_FLASH_STRUCT info_struct={FILE_INFO_LABEL, FILE_INFO_VERSION, STORAGE_TYP, __DATE__, __TIME__, FILE_DIR_COUNT, FILE_NAME_COUNT, FILE_INFO_STRING};

// local prototypes
unsigned char dataflash_file_check(void);
unsigned char dataflash_file_consistence(void);


// **********************************************************************************
// Description   : init the dataflash-file-system
// Input         : spi_mode - see avr_spi.h for details
// Output     	 : 0 - Error (DataFlash no available)
//            	 : 1 - OK
// Indication	 : none
// **********************************************************************************
unsigned char dataflash_file_init(unsigned int spi_mode)
{
#ifdef DEBUG_DATAFLASH_FILE
dataflash_file_debug_init();
#endif

if (dataflash_cfg_spi(spi_mode))		// init dataflash
	{
	if (!dataflash_file_check())
		dataflash_file_format();
	memset(file_handle, 0x0, sizeof(file_handle));
	directory_actual=DIR_NAME_ROOT;
	return 1;
	}
return 0;
}


// **********************************************************************************
// Description   : checks the file-system (reads the Info-Page and checks the file
//                 consistence
// Input         : none
// Output     	 : 0 - Read Error
//            	 : 1 - OK
// Indication	 : internal function, use "dataflash_file_init()"
// **********************************************************************************
unsigned char dataflash_file_check(void)
{
INFO_STRUCT *p_info;

if(!dataflash_read_flash(dataflash_temp_buffer, FILE_INFO_PAGE_ADDR, 0, FLASH_PAGE_SIZE))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		putsf("FILE Check Read Error (page: 0)\r"); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
p_info=(INFO_STRUCT*)dataflash_temp_buffer;
if((p_info->label!=(unsigned long)FILE_INFO_LABEL)||
   (p_info->version!=(unsigned int)FILE_INFO_VERSION)||
   (p_info->storage_typ!=(unsigned int)STORAGE_TYP))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		{
		putsf("FILE Check Error\r"); 
		printf("FILE Label: 0x%lx\r\n", p_info->label); 
		printf("FILE Version: 0x%x\r\n", p_info->version); 
		printf("FILE Storage: 0x%x\r\n", p_info->storage_typ); 
		}
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
if(!dataflash_file_consistence())
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		putsf("FILE Consistence Error\r"); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
return 1;
}

// **********************************************************************************
// Description   : formats the file-system (erase the whole FataFlash and rewrite the 
//                 info-sector 
// Input         : none
// Output     	 : 0 - Erase or Write Error
//            	 : 1 - OK
// Indication	 : none
// **********************************************************************************
unsigned char dataflash_file_format(void)
{
unsigned int Lva;

for(Lva=FILE_INFO_PAGE_ADDR;Lva<FILE_DATA_PAGE_ADDR;Lva++)
	{
	#asm("wdr");	// Reset Watchdog
	if(!(dataflash_erase_page(Lva)))
		{
		#ifdef DEBUG_DATAFLASH_FILE
		if(dataflash_file_debug_flag)
			printf("FILE Format Erase Error (page: %u)\r\n", Lva); 
		#endif	// #ifdef DEBUG_DATAFLASH_FILE
		return 0;
		}
	}
memcpyf(dataflash_temp_buffer, &info_struct, sizeof(info_struct));
dataflash_write_buffer(dataflash_temp_buffer, 0, FLASH_PAGE_SIZE, FLASH_BUFFER1);	// 
if(!(dataflash_write_buffer2flash(FLASH_BUFFER1, FILE_INFO_PAGE_ADDR)))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		putsf("FILE Format Write Error (page: 0)\r"); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	putsf("FILE Format OK\r"); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
return 1;
}


// **********************************************************************************
// Description   : checks the file consistence, reads the full DataFlash and checks
//                 chain of file pages
// Input         : none
// Output     	 : 0 - read error
//            	 : 1 - no file error
// Indication	 : internal function, use in "dataflash_file_check()"
// **********************************************************************************
unsigned char dataflash_file_consistence(void)
{
unsigned int Lva, Lvb;
unsigned char page_change;
unsigned int buffer[2];
FILE_NAME_STRUCT *p_name;

for(Lva=FILE_NAME_PAGE_ADDR;Lva<FILE_NAME_PAGE_END;Lva++)
	{
	if(!dataflash_read_flash(dataflash_temp_buffer, Lva, 0, FLASH_PAGE_SIZE))
		{
		#ifdef DEBUG_DATAFLASH_FILE
		if(dataflash_file_debug_flag)
			printf("FILE Consistence Read Error (page: %u)\r\n", Lva); 
		#endif	// #ifdef DEBUG_DATAFLASH_FILE
		return 0;
		}
	page_change=0;
	p_name=(FILE_NAME_STRUCT*)dataflash_temp_buffer;
	for(Lvb=0;Lvb<FILE_NAME_COUNT_PAGE;Lvb++)
		{
		if((p_name->startpage!=0xffff)&&(p_name->startpage!=0x0000))
			{
			p_name->name[FILE_NAME_LAST_SIGN]=0;	// cut length of string, if wrong
			if(p_name->startpage>=FLASH_PAGE_COUNT)
				{
				p_name->startpage=0x0000;		// delete entry
				page_change=1;
				#ifdef DEBUG_DATAFLASH_FILE
				if(dataflash_file_debug_flag)
					printf("FILE Consistence Filename-Error %s Page: %u\r\n", p_name->name, p_name->startpage);
				#endif	// #ifdef DEBUG_DATAFLASH_FILE
				}
			else
				{
				dataflash_read_flash2buffer(FLASH_BUFFER2, p_name->startpage);
				dataflash_read_buffer((unsigned char*)buffer, 0, 2, FLASH_BUFFER2);
				if(buffer[0]!=p_name->startpage)
					{
					p_name->startpage=0x0000;		// delete entry
					page_change=1;
					#ifdef DEBUG_DATAFLASH_FILE
					if(dataflash_file_debug_flag)
						printf("FILE Consistence Data-Error %s Page: %u\r\n", p_name->name, p_name->startpage);
					#endif	// #ifdef DEBUG_DATAFLASH_FILE
					}
				}
			}
		p_name++;
		}
	if(page_change)
		{
		dataflash_write_buffer(dataflash_temp_buffer, 0, FLASH_PAGE_SIZE, FLASH_BUFFER1);
		dataflash_write_buffer2flash(FLASH_BUFFER1, Lva);
		#ifdef DEBUG_DATAFLASH_FILE
		if(dataflash_file_debug_flag)
			printf("FILE Consistence Write Page: %u\r\n", Lva); 
		#endif	// #ifdef DEBUG_DATAFLASH_FILE
		}
	}
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	putsf("FILE Consistence OK\r"); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
return 1;
}


// **********************************************************************************
// Description	: search a file
// Input        : file_name 		- pointer to file name
//              : file_name_struct - pointer to "FILE_NAME_STRUCT" 
//              : file_entry 		- pointer to 16bit - return file_entry (1 .. (FILE_NAME_COUNT-1))
//              : mode: SEARCH_FIRST - start with first entry; SEARCH_NEXT - start with last entry
// Output     	: 0 - Error - found no file
//            	: 1 - found file
// Indication	: none
// **********************************************************************************
unsigned char dataflash_file_search(unsigned char *file_name, FILE_NAME_STRUCT *file_name_struct, unsigned int *file_entry, SEARCH_MODE mode)
{
static unsigned int page_position;
static unsigned int entry_position;
unsigned int Lva, Lvb;
FILE_NAME_STRUCT *p_name;

if(mode==SEARCH_FIRST)
	{
	page_position=FILE_NAME_PAGE_ADDR;
	entry_position=0;
	}
if(mode==SEARCH_NEXT)
	{
	entry_position++;
	if(entry_position>=FILE_NAME_COUNT_PAGE)
		{
		entry_position=0;
		page_position++;
		}
	if(page_position>=FILE_NAME_PAGE_END)
		{
		page_position=FILE_NAME_PAGE_ADDR;
		return 0;
		}
	}
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	printf("FILE Search Start %u/%u\r\n", page_position, entry_position); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
for(Lva=FILE_NAME_PAGE_ADDR;Lva<FILE_NAME_PAGE_END;Lva++)
	{
	if(!dataflash_read_flash(dataflash_temp_buffer, page_position, 0, FLASH_PAGE_SIZE))
		{
		#ifdef DEBUG_DATAFLASH_FILE
		if(dataflash_file_debug_flag)
			printf("FILE Search Read Error (page: %u)\r\n", page_position); 
		#endif	// #ifdef DEBUG_DATAFLASH_FILE
		return 0;
		}
	p_name=(FILE_NAME_STRUCT*)&dataflash_temp_buffer[sizeof(FILE_NAME_STRUCT)*entry_position];
	for(Lvb=0;Lvb<FILE_NAME_COUNT_PAGE;Lvb++)
		{
		if((p_name->startpage!=0x0000)&&		// entry delete ?
		   (p_name->startpage!=0xffff)&&		// entry refresh ?
		   (p_name->dir_number==directory_actual)&&
		   ((file_name==0)||(strcmp(p_name->name, file_name)==0)))
			{
			if(file_name_struct)
				memcpy(file_name_struct, p_name, sizeof(FILE_NAME_STRUCT));
			if(file_entry)
				*file_entry=((page_position-FILE_NAME_PAGE_ADDR)*FILE_NAME_COUNT_PAGE+entry_position);
			#ifdef DEBUG_DATAFLASH_FILE
			if(dataflash_file_debug_flag)
				printf("FILE Search End %u/%u\r\n", page_position, entry_position); 
			#endif	// #ifdef DEBUG_DATAFLASH_FILE
			return 1;
			}
		entry_position++;
		if(entry_position>=FILE_NAME_COUNT_PAGE)
			break;
		p_name++;
		}
	page_position++;
	if(page_position>=FILE_NAME_PAGE_END)
		return 0;
	entry_position=0;
	}
return 0;
}


// **********************************************************************************
// Description   : open a file handle
// Input         : file_name: pointer to file name
// Output     	 : 0 - found no file - can't open
//               : 1..FILE_HANDLE_COUNT - find file and open a handle
// Indication	 : open only if
//               : a.) handle free
//               : b.) file still open
// **********************************************************************************
unsigned char dataflash_file_open(unsigned char *file_name, unsigned char *handle)
{
unsigned char Lva, free_handle;
unsigned int file_entry_position;
FILE_HANDLE	*p_file;

#ifdef DEBUG_DATAFLASH_FILE
counter_10ms_16bit=0;
#endif
*handle=FILE_HANDLE_DISABLE;
file_name[FILE_NAME_LAST_SIGN]=0x0;	// cut the file name to "FILE_NAME_SIZE" signs + 0-sign
free_handle=FILE_HANDLE_DISABLE;
p_file=&file_handle[0];
for(Lva=0;Lva<FILE_HANDLE_COUNT;Lva++)
	{
	if(p_file->startpage==0x0)
		free_handle=Lva;
	else
		{
		if((p_file->dir_number==directory_actual)&&
		   (strcmp(p_file->name, file_name)==0))
			{
			free_handle=FILE_HANDLE_DISABLE;
			break;
			}
		}
	p_file++;		
	}
if(free_handle<FILE_HANDLE_COUNT)	// found free handle
	{
	p_file=&file_handle[free_handle];	// init new pointer
	if(dataflash_file_search(file_name, p_file, &file_entry_position, SEARCH_FIRST))
		{
		p_file->file_entry=file_entry_position;
		p_file->act_absolut_page=p_file->startpage;
		p_file->act_absolut_byte=FILE_DATA_ENTRY;
		#ifdef DEBUG_DATAFLASH_FILE
		if(dataflash_file_debug_flag)
			printf("FILE Open: %u0ms (page: %u)\r\n", counter_10ms_16bit, p_file->act_absolut_page);
		#endif
		*handle=free_handle;
		return 1;
		}
	}
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	printf("FILE Open Error \"%s\"\r\n", file_name); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
return 0;
}

// **********************************************************************************
// Description   : check the file-handle
// Input         : handle: handle to check
// Output     	 : 0 - error
//               : 1 - OK and decrement handle
// Indication	 : internal function
// **********************************************************************************
unsigned char dataflash_file_check_handle(unsigned char handle)
{
if((handle==FILE_HANDLE_DISABLE)||(handle>=FILE_HANDLE_COUNT))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("FILE wrong handle: %u\r\n", handle); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
if(file_handle[handle].startpage!=0x0)
	return 1;
return 0;
}

// **********************************************************************************
// Description   : close a file handle
// Input         : handle: number to data-structure
// Output     	 : 0 - error
//               : 1 - OK
// Indication	 : none
// **********************************************************************************
unsigned char dataflash_file_close(unsigned char *handle)
{
unsigned int file_name_page, file_name_entry;
FILE_HANDLE	*p_file;

if(!dataflash_file_check_handle(*handle))
	return 0;
p_file=&file_handle[*handle];
file_name_page=p_file->file_entry/FILE_NAME_COUNT_PAGE;	// calculate page position
file_name_page+=FILE_NAME_PAGE_ADDR;					// add FILE-NAME offset
file_name_entry=p_file->file_entry%FILE_NAME_COUNT_PAGE;// calculate within the page
if(!dataflash_read_flash2buffer(FLASH_BUFFER1, file_name_page))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("FILE Close Read Error (page: %u)\r\n", file_name_page); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
dataflash_write_buffer((unsigned char*)p_file, sizeof(FILE_NAME_STRUCT)*file_name_entry, sizeof(FILE_NAME_STRUCT), FLASH_BUFFER1);
if(!dataflash_compare(FLASH_BUFFER1, file_name_page))
	{
	dataflash_write_buffer2flash_e(FLASH_BUFFER1, file_name_page);	// Erease and Write Page
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("FILE Close Write Page: %u\r\n", file_name_page); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	}
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	printf("FILE Close: \"%s\"\r\n", p_file->name); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
p_file->startpage=0x0;		// disable handle
*handle=FILE_HANDLE_DISABLE;
return 1;
}


// **********************************************************************************
// Description   : close all file-handler
// Input         : none
// Output     	 : none
// Indication	 : tries all possible file-handler (0..254)
// **********************************************************************************
void dataflash_file_close_all(void)
{
unsigned char Lva, handle;

for(Lva=0;Lva<FILE_HANDLE_COUNT;Lva++)
	dataflash_file_close(&handle);
}


// **********************************************************************************
// Description   : read data from a open a file handle
// Input         : handle 	- number to data-structure
//               : data		- pointer to buffer
//               : data_size - size of data
// Output     	 : 0 	- error
//               : 1..x - OK and size of read data
// Indication	 : none
// **********************************************************************************
unsigned int dataflash_file_read(unsigned char handle, unsigned char *data, unsigned int data_size)
{
unsigned int page_data_count, startpage, nextpage, act_datacount=0;
FILE_HANDLE	*p_file;

if(!dataflash_file_check_handle(handle))
	return 0;
p_file=&file_handle[handle];
while(data_size)
	{
	//dataflash_file_debug_handle_d(handle);
	if(!dataflash_read_flash(dataflash_temp_buffer, p_file->act_absolut_page, 0, FLASH_PAGE_SIZE))
		{
		#ifdef DEBUG_DATAFLASH_FILE
		if(dataflash_file_debug_flag)
			printf("FILE Read Error (page: %u)\r\n", p_file->act_absolut_page); 
		#endif	// #ifdef DEBUG_DATAFLASH_FILE
		return 0;
		}
	// check wether the first 4 Byte Data of every Flash-Page OK?
	memcpy(&startpage, dataflash_temp_buffer, 2);
	memcpy(&nextpage, dataflash_temp_buffer+2, 2);
	if(startpage!=p_file->startpage)
		{
		#ifdef DEBUG_DATAFLASH_FILE
		if(dataflash_file_debug_flag)
			printf("FILE Read Error Startpage (page: %u)\r\n", p_file->act_absolut_page); 
		#endif	// #ifdef DEBUG_DATAFLASH_FILE
		return 0;
		}
	if(p_file->act_absolut_page==p_file->lastpage)
		{
		nextpage=0xFFFF;
		if(p_file->act_absolut_byte>(p_file->lastpage_byte+FILE_DATA_ENTRY))
			p_file->act_absolut_byte=p_file->lastpage_byte+FILE_DATA_ENTRY;
		page_data_count=p_file->lastpage_byte-(p_file->act_absolut_byte-FILE_DATA_ENTRY);
		}
	else
		page_data_count=FLASH_PAGE_SIZE-p_file->act_absolut_byte;
	if(data_size>page_data_count)
		{
		memcpy(data, dataflash_temp_buffer+p_file->act_absolut_byte, page_data_count);
    	act_datacount+=page_data_count;	// calculate data counter
	    data_size-=page_data_count;
	    data+=page_data_count;			// set data pointer
		if(nextpage!=0xFFFF)
			{
			p_file->act_absolut_page=nextpage;
			p_file->act_absolut_byte=FILE_DATA_ENTRY;	// set to first data bytes
			}
		else
			{
			p_file->act_absolut_byte+=page_data_count;
			break;
			}
		}
	else	//if(data_size<=page_data_count)
		{
		memcpy(data, dataflash_temp_buffer+p_file->act_absolut_byte, data_size);
    	act_datacount+=data_size;			// calculate data counter
		if(data_size==page_data_count)		// last page was full used
			{
			if(nextpage!=0xFFFF)
				{
				p_file->act_absolut_page=nextpage;
				p_file->act_absolut_byte=FILE_DATA_ENTRY;
				}
			else
				p_file->act_absolut_byte+=data_size;
			}
		else	// if(data_size<page_data_count)		
			p_file->act_absolut_byte+=data_size;		// leave old page-address
		data_size=0;   				// set break condition
		}
	}
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	printf("FILE Read Data: %u\r\n", act_datacount); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
return act_datacount;		
}

// **********************************************************************************
// Description	: checks the end of file
// Input       	: handle - number to data-structure
// Output     	: 0 - error
//             	: 1 - OK and end of file
// Indication	: none
// **********************************************************************************
unsigned char dataflash_file_eof(unsigned char handle)
{
FILE_HANDLE	*p_file;
if(!dataflash_file_check_handle(handle))
	return 0;
p_file=&file_handle[handle];
if((p_file->lastpage==p_file->act_absolut_page)&&
   ((p_file->lastpage_byte+FILE_DATA_ENTRY)==p_file->act_absolut_byte))
	{
	return 1;
	}
return 0;		
}


// **********************************************************************************
// Description   : calculate the size of file
// Input         : handle: number to data-structure
// Output     	 : 0 - error
//               : 1 - OK and end of file
// Indication	 : none
// **********************************************************************************
unsigned char dataflash_file_size(unsigned char handle, unsigned long *file_size)
{
FILE_HANDLE	*p_file;
if(!dataflash_file_check_handle(handle))
	return 0;
p_file=&file_handle[handle];
*file_size=(unsigned long)(p_file->countpage-1)*FILE_DATA_PAGE_SIZE+p_file->lastpage_byte;
return 1;		
}


// **********************************************************************************
// Description   : seek the data-pointer to value
// Input         : handle   - number to data-structure
//               : file_pos - number to data-structure
// Output     	 : 0 - error
//               : 1 - OK and end of file (EOF)
// Indication	 : none
// **********************************************************************************
unsigned char dataflash_file_seek(unsigned char handle, unsigned long file_pos)
{
unsigned int  Lva, Lvb;
unsigned int  page_count, page_rest;
unsigned int* allocation_data;
unsigned long file_size;
FILE_HANDLE*  p_file;

if(!dataflash_file_check_handle(handle))
	return 0;
p_file=&file_handle[handle];
// test last position in the file
dataflash_file_size(handle, &file_size);
if((file_size==file_pos)||(file_pos==0xffffffff))
	{
	p_file->act_absolut_page=p_file->lastpage;
	p_file->act_absolut_byte=p_file->lastpage_byte+FILE_DATA_ENTRY;
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		putsf("FILE Seek EOF\r"); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 1;
	}
if(file_size<file_pos)
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("FILE Seek Error: %lu\r\n", file_pos); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
page_count=file_pos/FILE_DATA_PAGE_SIZE;
page_count+=1;
page_rest=file_pos%FILE_DATA_PAGE_SIZE;
for(Lva=0;Lva<FILE_ALLOCATION_PAGE_COUNT;Lva++)
	{
	if(!dataflash_read_flash(dataflash_temp_buffer, FILE_ALLOCATION_PAGE_ADDR+Lva, 0, FLASH_PAGE_SIZE))
		{
		#ifdef DEBUG_DATAFLASH_FILE
		if(dataflash_file_debug_flag)
			printf("FILE Seek Read Error (page: %u)\r\n", FILE_ALLOCATION_PAGE_ADDR+Lva); 
		#endif	// #ifdef DEBUG_DATAFLASH_FILE
		return 0;
		}
	allocation_data = (unsigned int*)dataflash_temp_buffer;
	for(Lvb=0;Lvb<FILE_ALLOCATION_PAGE_ENTRY;Lvb++)
		{
		if((*allocation_data==file_handle[handle].startpage)&&
		   (*(allocation_data+1)==page_count))
			{
			p_file->act_absolut_page=FILE_ALLOCATION_PAGE_ENTRY*Lva+Lvb+FILE_DATA_PAGE_ADDR;
			p_file->act_absolut_byte=page_rest+FILE_DATA_ENTRY;
			#ifdef DEBUG_DATAFLASH_FILE
			if(dataflash_file_debug_flag)
				printf("FILE Seek page: %u byte: %u\r\n", p_file->act_absolut_page, p_file->act_absolut_byte);
			#endif	// #ifdef DEBUG_DATAFLASH_FILE
			return 1;
			}
		allocation_data+=2;		// set to new allocation entry
		}
	}
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	putsf("FILE Seek Error\r"); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
return 0;		
}


// **********************************************************************************
// Description	: refresh a page with filename entries (all 0x0000 entries to 0xffff)
// Input        : page  	- page of filenames
//              : page_data - data of "page"
// Output     	: 0 - Error
//              : 1 - OK
// Indication	: internal file function
// **********************************************************************************
unsigned char dataflash_file_refresh(unsigned int page, unsigned char *page_data)
{
unsigned int Lvb;
FILE_NAME_STRUCT *p_name;

p_name=(FILE_NAME_STRUCT*)page_data;
for(Lvb=0;Lvb<FILE_NAME_COUNT_PAGE;Lvb++)
	{
	if(p_name->startpage==0x0000)
		memset(p_name, 0xff, sizeof(FILE_NAME_STRUCT));
	p_name++;
	}
dataflash_write_buffer(page_data, 0, FLASH_PAGE_SIZE, FLASH_BUFFER1);
dataflash_write_buffer2flash_e(FLASH_BUFFER1, page);
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	printf("FILE Filename Refresh: %u\r\n", page); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
return 1;
}


// **********************************************************************************
// Description  : refresh a page with allocation entries 
// Input        : page 		- page of filenames
//              : page_data - data of "page"
//              : search 	- data to search, see below
// Output     	: 0 - Error
//              : 1 - OK
// Indication	: internal file function
//              :  search==0x0000 all entries to 0xffff, and erase + program "page"
//           	:  search==0x0001..0xffff all entries to 0x0000, and program only "page"
// **********************************************************************************
unsigned char dataflash_file_alloc_refresh(unsigned int page, unsigned char *page_data, unsigned int search)
{
unsigned char page_change=0;
unsigned char Lvb;
unsigned int *allocation_data;

allocation_data = (unsigned int*)page_data;
for(Lvb=0;Lvb<FILE_ALLOCATION_PAGE_ENTRY;Lvb++)
	{
	if(*allocation_data==search)
		{
		page_change=1;
		if(search==0x0000)
			{
			*allocation_data=0xffff;		// clear startpage entry
			*(allocation_data+1)=0xffff;	// clear nextpage entry
			}
		else
			*allocation_data=0x0000;		// clear startpage entry
		}
	allocation_data+=2;		// set to next allocation entry
	}
if(page_change)
	{
	dataflash_write_buffer(page_data, 0, FLASH_PAGE_SIZE, FLASH_BUFFER1);
	if(search==0x0000)
		dataflash_write_buffer2flash_e(FLASH_BUFFER1, page);
	else
		dataflash_write_buffer2flash(FLASH_BUFFER1, page);
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("FILE Allocation Refresh: %u with 0x%x\r\n", page, search); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	}
return 1;
}


// **********************************************************************************
// Description   : search a startpage
// Input         : freepage - pointer to new free page 
// Output     	 : 0 - Error
//               : 1 - OK
// Indication	 : internal file function
//               : freepage==0xffff - search start with first Allocation page
//               : freepage!=0xffff - calculate Allocation page and than start
//               : both versions search the whole Allocation table
// **********************************************************************************
unsigned char dataflash_file_freepage(unsigned int *freepage)
{
unsigned char search_0x0000=0;
unsigned int  alloc_page, alloc_entry, Lva;
unsigned int* allocation_data;
unsigned int  data_page;

while(1)
	{
	if(*freepage==0xffff)
		{
		alloc_page=FILE_ALLOCATION_PAGE_ADDR;	// start with first Allocation Page Address
		alloc_entry=0;
		data_page=FILE_DATA_PAGE_ADDR;			// start with first data_page
		}
	else
		{
		data_page=*freepage;					// start with last data_page
		alloc_page=(data_page-FILE_DATA_PAGE_ADDR)/FILE_ALLOCATION_PAGE_ENTRY;
		if(alloc_page>FILE_ALLOCATION_PAGE_COUNT)
			{
			#ifdef DEBUG_DATAFLASH_FILE
			if(dataflash_file_debug_flag)
				printf("FILE Freepage Error (page: %u)\r\n", data_page); 
			#endif	// #ifdef DEBUG_DATAFLASH_FILE
			*freepage=0xffff;
			return 0;
			}
		alloc_entry=(*freepage-FILE_DATA_PAGE_ADDR)%FILE_ALLOCATION_PAGE_ENTRY;
		alloc_entry++;
		data_page++;			// count the data page position
		if(alloc_entry>=FILE_ALLOCATION_PAGE_ENTRY)
			{
			alloc_entry=0;
			alloc_page++;
			if(alloc_page>=FILE_ALLOCATION_PAGE_COUNT)
				alloc_page=0;
			}
		alloc_page+=FILE_ALLOCATION_PAGE_ADDR;
		}
	for(Lva=0;Lva<FILE_ALLOCATION_PAGE_COUNT;Lva++)
		{
		if(!dataflash_read_flash(dataflash_temp_buffer, alloc_page, 0, FLASH_PAGE_SIZE))
			{
			#ifdef DEBUG_DATAFLASH_FILE
			if(dataflash_file_debug_flag)
				printf("FILE Freepage Error (page: %u)\r\n", alloc_page); 
			#endif	// #ifdef DEBUG_DATAFLASH_FILE
			*freepage=0xffff;
			return 0;
			}
		allocation_data = (unsigned int*)dataflash_temp_buffer;		// init allocation-pointer
		if(alloc_entry)
			allocation_data+=(alloc_entry*2);       // add offset with calculate 16bit Position
		while(alloc_entry<FILE_ALLOCATION_PAGE_ENTRY)
			{
			if(data_page>FILE_DATA_PAGE_END)
				break;
			if(((search_0x0000))&&(*allocation_data==0x0000))	// now search to 0x0000 entry
				dataflash_file_alloc_refresh(alloc_page, dataflash_temp_buffer, 0x0000);	// set one or more to 0xffff
			if(*allocation_data==0xffff)
				{
				*freepage=data_page;
				#ifdef DEBUG_DATAFLASH_FILE
				if(dataflash_file_debug_flag)
					printf("FILE Freepage: %u\r\n", *freepage);
				#endif	// #ifdef DEBUG_DATAFLASH_FILE
				return 1;
				}
			allocation_data+=2;		// set to new allocation entry
			alloc_entry++;
			data_page++;			// count the data page position
			}
		alloc_entry=0;
		alloc_page++;
		if(alloc_page>=FILE_ALLOCATION_PAGE_END)
			alloc_page=FILE_ALLOCATION_PAGE_ADDR;	
		if(data_page>FILE_DATA_PAGE_END)
			{
			data_page=FILE_DATA_PAGE_ADDR;			// start with first data_page
			alloc_page=FILE_ALLOCATION_PAGE_ADDR;	// start with first alocation page
			}
		}
	if(search_0x0000)		// after second search (0x0000)- all entries are full
		break;
	search_0x0000=1;		// after 0xffff now search to 0x0000 entry
	}
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	putsf("FILE Disk Full\r"); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
*freepage=0xffff;
return 0;
}


// **********************************************************************************
// Description   : search a startpage
// Input         : startpage 	- pagenumber of "startpage"
//               : countpage 	- count of datapages 
//               : actual_page 	- pointer to actual page (absolut page number)
// Output     	 : 0 - Error
//               : 1 - OK
// Indication	 : internal file function
// **********************************************************************************
unsigned char dataflash_file_alloc_write(unsigned int startpage, unsigned int countpage, unsigned int actual_page)
{
unsigned int alloc_page;
unsigned int buffer[2];
#ifdef DEBUG_DATAFLASH_FILE
unsigned int actual_page_temp;
#endif	// #ifdef DEBUG_DATAFLASH_FILE

#ifdef DEBUG_DATAFLASH_FILE
actual_page_temp=actual_page;
#endif	// #ifdef DEBUG_DATAFLASH_FILE
actual_page-=FILE_DATA_PAGE_ADDR;			// calculate datapage number 0..x;
alloc_page=actual_page/FILE_ALLOCATION_PAGE_ENTRY;	// calculate Allocation page;
actual_page%=FILE_ALLOCATION_PAGE_ENTRY;	// calculate position inside of Allocation page;
actual_page*=FILE_ALLOCATION_ENTRY;			// calculate the byte-pointer;
alloc_page+=FILE_ALLOCATION_PAGE_ADDR;		// set correct Allocation Address
buffer[0]=startpage;
buffer[1]=countpage;
dataflash_read_flash2buffer(FLASH_BUFFER1, alloc_page);		// load page to buffer
if(dataflash_write2flash((unsigned char*)buffer, alloc_page, actual_page, 4, FLASH_BUFFER1))// write date, erase and program
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("FILE Alloc Write Page:%u (Datapage:%u)\r\n", alloc_page, actual_page_temp);
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 1;
	}
return 0;
}


// **********************************************************************************
// Description   : checks a name of new file or directory
// Input         : name: pointer to file name
// Output     	 : 0 - Error; wrong file name
//               : 1 - OK
// Indication	 : at least ONE sign inside of (32..166)
// **********************************************************************************
unsigned char dataflash_file_check_name(unsigned char *name)
{
//if((name[0]!=0x0)&&(name[0]>32)&&(isprint(name[0]))	// returns 1 if c is a printable character (32..127).
if((name[0]>32)&&(name[0]<166))		// 
	{
	return 1;
	}
return 0;
}

// **********************************************************************************
// Description	: set the actual date to file
// Input     	: p_date - pointer to date and time
// Output     	: none
// Indication	: internal function
// **********************************************************************************
void dataflash_file_date(DATE_STRUCT *p_date)
{
unsigned long sec_buffer;
unsigned int day_buffer;

day_buffer=day_counter;
p_date->year=(unsigned char)(day_buffer/365);
day_buffer-=(unsigned long)p_date->year*365;
p_date->year+=3;
p_date->month=(unsigned char)(day_buffer/30);
day_buffer-=(unsigned int)p_date->month*30;
if(p_date->month==0)
	p_date->month=1;
p_date->day=(unsigned char)(day_buffer);
if(p_date->day==0)
	p_date->day=1;
#asm("cli");	 	// Global disable interrupts
sec_buffer=second_counter;
#asm("sei");	 	// Global enable interrupts
p_date->hour=(unsigned char)(sec_buffer/3600);
sec_buffer-=(unsigned long)p_date->hour*3600;
p_date->minute=(unsigned char)(sec_buffer/60);
sec_buffer-=(unsigned int)p_date->minute*60;
p_date->second=(unsigned char)(sec_buffer);
}


// **********************************************************************************
// Description   : create a new file entry
// Input         : file_name: pointer to file name
// Output     	 : 0 - Error - can't create
//               : 1 - OK - create file
// Indication	 : none
// **********************************************************************************
unsigned char dataflash_file_new(unsigned char *file_name)
{
unsigned char search_0x0000=0;
unsigned int Lva, Lvb;
unsigned int buffer[2];
FILE_NAME_STRUCT *p_name;

#ifdef DEBUG_DATAFLASH_FILE
counter_10ms_16bit=0;
#endif
file_name[FILE_NAME_LAST_SIGN]=0x0;	// cut the file name to "FILE_NAME_SIZE" signs + 0-sign
if(!dataflash_file_check_name(file_name))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("FILE Name Error: \"%11s\"\r\n", file_name); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
if(dataflash_file_search(file_name, 0x0, 0x0, SEARCH_FIRST))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		putsf("FILE New Error - file available\r"); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
while(1)
	{
	for(Lva=FILE_NAME_PAGE_ADDR;Lva<FILE_NAME_PAGE_END;Lva++)
		{
		if(!dataflash_read_flash(dataflash_file_buffer, Lva, 0, FLASH_PAGE_SIZE))
			{
			#ifdef DEBUG_DATAFLASH_FILE
			if(dataflash_file_debug_flag)
				printf("FILE New Read Error (page: %u)\r\n", Lva); 
			#endif	// #ifdef DEBUG_DATAFLASH_FILE
			return 0;
			}
		p_name=(FILE_NAME_STRUCT*)dataflash_file_buffer;
		for(Lvb=0;Lvb<FILE_NAME_COUNT_PAGE;Lvb++)
			{
			if((search_0x0000)&&(p_name->startpage==0x0000))	// now search to 0x0000 entry
				dataflash_file_refresh(Lva, dataflash_file_buffer);	// set one or more to 0xffff
			if(p_name->startpage==0xffff)
				{
				if(dataflash_file_freepage(&(p_name->startpage)))
					{
					p_name->lastpage=p_name->startpage;
					p_name->countpage=1;
					p_name->lastpage_byte=0;
					dataflash_file_date(&p_name->date);	// set date
					p_name->dir_number=directory_actual;
					strncpy(p_name->name, file_name, FILE_NAME_SIZE);
					// write filename entry
					dataflash_write2flash(dataflash_file_buffer, Lva, 0, FLASH_PAGE_SIZE, FLASH_BUFFER1);
					// write datapage entry
					buffer[0]=p_name->startpage;
					buffer[1]=0xffff;
                    // a reload of date isn't nessecary, because the data after the 4 startbytes are unimportant
					// dataflash_read_flash2buffer(FLASH_BUFFER1, p_name->startpage))		// read datapage in buffer
					dataflash_write2flash((unsigned char*)buffer, p_name->startpage, 0, 4, FLASH_BUFFER1);// write startpage number to flash
					// write allocation entry
					dataflash_file_alloc_write(p_name->startpage, 1, p_name->startpage);
					#ifdef DEBUG_DATAFLASH_FILE
					if(dataflash_file_debug_flag)
						printf("FILE New Time: %u0ms\r\n", counter_10ms_16bit);
					#endif
					return 1;
					}
				else
					return 0;	// no flashpage to create a new file
				}
			p_name++;
			}
		}
	if(search_0x0000)		// after second search (0x0000)- all entries are full
		break;
	search_0x0000=1;		// after 0xffff now search to 0x0000 entry
	}
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	printf("FILE Filename Full %s\r\n", file_name); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
return 0;
}


// **********************************************************************************
// Description   : write data to a open file handle
// Input         : handle 	- number to data-structure
//               : data 	- pointer to buffer
//               : data_size - size of data
// Output     	 : 0 	- error
//               : 1..x - OK and size of write data
// Indication	 : Attention: set Page-pointer to EOF
// **********************************************************************************
unsigned int dataflash_file_write(unsigned char handle, unsigned char *data, unsigned int data_size)
{
unsigned int data_byte_count, start_data_size;
volatile unsigned int nextpage;
FILE_HANDLE	*p_file;

#ifdef DEBUG_DATAFLASH_FILE
counter_10ms_16bit=0;
#endif
if(!dataflash_file_check_handle(handle))
	return 0;
p_file=&file_handle[handle];
start_data_size=data_size;
do
	{
	data_byte_count=FLASH_PAGE_SIZE-p_file->act_absolut_byte;
	if(data_byte_count>data_size)
		data_byte_count=data_size;
	if(p_file->act_absolut_byte!=FILE_DATA_ENTRY)
		{
		// first write and therefore readback the data of this page
		dataflash_read_flash2buffer(FLASH_BUFFER2, p_file->act_absolut_page);
		}
	else
		dataflash_read_flash2buffer(FLASH_BUFFER2, FILE_FF_PAGE_ADDR);		// clear SRAM-buffer
	dataflash_write_buffer(data, p_file->act_absolut_byte, data_byte_count, FLASH_BUFFER2);
	data+=data_byte_count;
	p_file->lastpage_byte+=data_byte_count;	
	p_file->act_absolut_byte+=data_byte_count;	// 
	data_size-=data_byte_count;
	dataflash_write_buffer((unsigned char*)&p_file->startpage, 0, 2, FLASH_BUFFER2);	// rewrite startpage
	nextpage=0xffff;
	dataflash_write_buffer((unsigned char*)&nextpage, 2, 2, FLASH_BUFFER2);		// set nextpage to 0xffff
	if(data_size==0)
		{
		dataflash_write_buffer2flash_e(FLASH_BUFFER2, p_file->act_absolut_page);	// write data
		//dataflash_file_debug_page_dis(p_file->act_absolut_page);
		break;	
		}
	nextpage=p_file->act_absolut_page;			// search after last page
	if(!dataflash_file_freepage(&nextpage))		// check to next free page
		{
		dataflash_write_buffer2flash_e(FLASH_BUFFER2, p_file->act_absolut_page);
		#ifdef DEBUG_DATAFLASH_FILE
		if(dataflash_file_debug_flag)
			printf("FILE Write Error (page: %u)\r\n", p_file->act_absolut_page); 
		#endif	// #ifdef DEBUG_DATAFLASH_FILE
		return (start_data_size-data_size);
		}
	dataflash_write_buffer((unsigned char*)&nextpage, 2, 2, FLASH_BUFFER2);		// set the new nextpage 
	dataflash_write_buffer2flash_e(FLASH_BUFFER2, p_file->act_absolut_page);
	//dataflash_file_debug_page_dis(p_file->act_absolut_page);
	p_file->lastpage_byte=0;	
	p_file->act_absolut_byte=FILE_DATA_ENTRY;	// now on start of the page
	p_file->act_absolut_page=nextpage;
	p_file->lastpage=nextpage;
	p_file->countpage++;
	dataflash_file_alloc_write(p_file->startpage, p_file->countpage, p_file->act_absolut_page);
	}
while(data_size!=0);
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	printf("FILE Write Data: %u (%u0ms)\r\n", start_data_size-data_size, counter_10ms_16bit); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
return (start_data_size-data_size);
}


// **********************************************************************************
// Description   : delete all allocation-entries of page <delete_page>
// Input         : delete_page - number of page that delete
// Output     	 : 0 - Error
//               : 1 - OK
// Indication	 : internal file function
// **********************************************************************************
unsigned char dataflash_file_alloc_delete(unsigned int delete_page)
{
unsigned char Lva;
unsigned int actual_alloc_page;

actual_alloc_page=(delete_page-FILE_DATA_PAGE_ADDR)/FILE_ALLOCATION_PAGE_ENTRY;
if(actual_alloc_page>FILE_ALLOCATION_PAGE_COUNT)
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("FILE Delete Alloc (page: %u)\r\n", delete_page); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
actual_alloc_page+=FILE_ALLOCATION_PAGE_ADDR;
for(Lva=0; Lva<FILE_ALLOCATION_PAGE_COUNT;Lva++)
	{
	if(!dataflash_read_flash(dataflash_temp_buffer, actual_alloc_page, 0, FLASH_PAGE_SIZE))
		{
		#ifdef DEBUG_DATAFLASH_FILE
		if(dataflash_file_debug_flag)
			printf("FILE Delete Alloc Error (page: %u)\r\n", actual_alloc_page); 
		#endif	// #ifdef DEBUG_DATAFLASH_FILE
		return 0;
		}
	dataflash_file_alloc_refresh(actual_alloc_page, dataflash_temp_buffer, delete_page);// set one or more to 0x0000
	actual_alloc_page++;
	if(actual_alloc_page>=FILE_ALLOCATION_PAGE_END)
		actual_alloc_page=FILE_ALLOCATION_PAGE_ADDR;
	}
return 1;
}


// **********************************************************************************
// Description   : delete a file with open a file handle
// Input         : handle - number to data-structure
// Output     	 : 0 - error
//               : 1 - OK
// Indication	 : none
// **********************************************************************************
unsigned char dataflash_file_delete(unsigned char handle)
{
//unsigned int Lva;
unsigned int file_name_page, file_name_entry;
unsigned char buffer[2];
FILE_HANDLE	*p_file;

if(!dataflash_file_check_handle(handle))
	return 0;
p_file=&file_handle[handle];
if(!dataflash_file_alloc_delete(p_file->startpage))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		putsf("FILE Delete Error\r"); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
file_name_page=p_file->file_entry/FILE_NAME_COUNT_PAGE;	// calculate page position
file_name_page+=FILE_NAME_PAGE_ADDR;								// add FILE-NAME offset
file_name_entry=p_file->file_entry%FILE_NAME_COUNT_PAGE;	// calculate within the page
if(!dataflash_read_flash2buffer(FLASH_BUFFER1, file_name_page))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("FILE Delete Read Error (page: %u)\r\n", file_name_page); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
buffer[0]=0x00;
buffer[1]=0x00;
dataflash_write_buffer(buffer, sizeof(FILE_NAME_STRUCT)*file_name_entry, 2, FLASH_BUFFER1);
if(!dataflash_write_buffer2flash(FLASH_BUFFER1, file_name_page))	// Write Page
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("FILE Delete Write Page: %u\r\n", file_name_page); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
/*
file_name_page=p_file->startpage;	
for(Lva=0;Lva<FILE_DATA_PAGE_COUNT;Lva++)
	{
	dataflash_read_flash2buffer(FLASH_BUFFER1, file_name_page);
	dataflash_read_buffer((unsigned char*)&file_name_entry, 2, 2, FLASH_BUFFER2);	// read next page entry
	if((file_name_entry<FILE_DATA_PAGE_ADDR)||(file_name_entry>FILE_DATA_PAGE_END))
		return 0;
	dataflash_write_buffer(buffer, 0, 2, FLASH_BUFFER1);			// delete "Startpage" of data page
	dataflash_write_buffer2flash(FLASH_BUFFER1, file_name_page);	// Write Page
	file_name_page=file_name_entry;									// set to next buffer
	}
*/
file_handle[handle].startpage=0x0;	// close handle
return 1;
}

// **********************************************************************************
// Description	: get the type of a file
// Input        : handle: number to data-structure
//              : file_typ: pointer to "FILE_TYP" variable
// Output 		: 0 - error
//             	: 1 - OK
// Indication	: file must be open; checks the header of file
// **********************************************************************************
unsigned char dataflash_file_gettype(unsigned char handle, FILE_TYP *file_typ)
{
FILE_HANDLE	*p_file;

if(!dataflash_file_check_handle(handle))
	return 0;
*file_typ=FILE_TYPE_NONE;
p_file=&file_handle[handle];
if((strstrf(p_file->name, ".html")!=0)||(strstrf(p_file->name, ".htm")!=0))
	*file_typ=FILE_TYPE_HTML;
if(strstrf(p_file->name, ".class")!=0)
	*file_typ=FILE_TYPE_CLASS;
if(strstrf(p_file->name, ".jpg")!=0)
	*file_typ=FILE_TYPE_JPEG;
return 1;
}

// **********************************************************************************
// Description  : get the time of open file
// Input        : handle - number to data-structure
//              : file_time - pointer to "DATE_STRUCT" variable
// Output 		: 0 - error
//             	: 1 - OK
// Indication	: file must be open
// **********************************************************************************
unsigned char dataflash_file_gettime(unsigned char handle, DATE_STRUCT *file_time)
{
if(!dataflash_file_check_handle(handle))
	return 0;
memcpy(file_time, &file_handle[handle].date, sizeof(DATE_STRUCT));
return 1;
}


// **********************************************************************************
// Description  : refresh a page with Dir-Name Entries (all 0x00 entries to 0xff)
// Input        : page - page of Dirnames
//              : page_data - data of "page"
// Output 		: 0 - error
//             	: 1 - OK
// Indication	: internal file function
// **********************************************************************************
unsigned char dataflash_dir_refresh(unsigned int page, unsigned char *page_data)
{
unsigned int Lvb;
DIR_NAME_STRUCT *p_dir;

p_dir=(DIR_NAME_STRUCT*)page_data;
for(Lvb=0;Lvb<FILE_DIR_COUNT_PAGE;Lvb++)
	{
	if(p_dir->option==0x00)
		memset(p_dir, 0xff, sizeof(DIR_NAME_STRUCT));
	p_dir++;
	}
dataflash_write_buffer(page_data, 0, FLASH_PAGE_SIZE, FLASH_BUFFER1);
dataflash_write_buffer2flash_e(FLASH_BUFFER1, page);
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	printf("FILE Dirname Refresh: %u\r\n", page); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
return 1;
}


// **********************************************************************************
// Description 	: search the DIR-Entry
// Input        : *dir_name: pointer to dir name
//              : *dir_number: dir_number to search
// Output     	: 0 				- Error - can't find
//              : 1..FILE_DIR_COUNT - OK - find directory
// Indication	: supports 2 options:
//              :   1.) dir_name!=0: search the dir number and if(dir_struct!=0)
//              :       read the DIR-Entry
//              :   2.) (dir_number!=0)and(dir_struct!=0): search the dir name
//              :   check first the (dir_name!=0) and than (dir_number!=0)
// **********************************************************************************
unsigned char dataflash_dir_search(unsigned char *dir_name, unsigned char *dir_number, DIR_NAME_STRUCT *dir_struct)
{
static unsigned int dir_page;
static unsigned char dir_entry;
DIR_NAME_STRUCT *p_dir;

/*
if(mode==SEARCH_FIRST)
	{
	dir_page=FILE_DIR_PAGE_ADDR;
	dir_entry=0;
	}
if(mode==SEARCH_NEXT)
	{
	dir_entry++;
	if(dir_entry>=FILE_DIR_COUNT_PAGE)
		{
		dir_entry=0;
		dir_page++;
		}
	if(dir_page>=FILE_DIR_PAGE_END)
		{
		dir_page=FILE_DIR_PAGE_ADDR;
		return 0;
		}
	}
*/
if(dir_name)	// search after dir name
	{
	for(dir_page=FILE_DIR_PAGE_ADDR;dir_page<FILE_DIR_PAGE_END;dir_page++)
		{
		if(!dataflash_read_flash(dataflash_temp_buffer, dir_page, 0, FLASH_PAGE_SIZE))
			{
			#ifdef DEBUG_DATAFLASH_FILE
			if(dataflash_file_debug_flag)
				printf("DIR Search Read Error (page: %u)\r\n", dir_page); 
			#endif	// #ifdef DEBUG_DATAFLASH_FILE
			return 0;
			}
		p_dir=(DIR_NAME_STRUCT*)dataflash_temp_buffer;
		for(dir_entry=0;dir_entry<FILE_DIR_COUNT_PAGE;dir_entry++)
			{
			if((p_dir->option!=0x00)&&(p_dir->option!=0xff)&&	// dir entry OK
			   (!strcmp(p_dir->name, dir_name)))
				{
				if(dir_struct)
					memcpy(dir_struct, p_dir, sizeof(DIR_NAME_STRUCT));
				if(dir_number)	// search after dir number
					*dir_number=((dir_page-FILE_DIR_PAGE_ADDR)*FILE_DIR_COUNT_PAGE+dir_entry);
				return 1;
				}
			p_dir++;
			}
		}
	}
else if(dir_number)	// search after dir number
	{
	if(dir_number==DIR_NAME_ROOT)	// if "root" directory
		{
		if(dir_struct)
			memset(dir_struct, 0, sizeof(DIR_NAME_STRUCT));
		return 1;
		}
	dir_entry=*dir_number;
	dir_page=dir_entry/FILE_DIR_COUNT_PAGE;		// calculate page position
	dir_page+=FILE_DIR_PAGE_ADDR;				// add FILE-DIR offset
	dir_entry%=FILE_DIR_COUNT_PAGE;				// calculate within the page
	if(!dataflash_read_flash(dataflash_temp_buffer, dir_page, 0, FLASH_PAGE_SIZE))
		{
		#ifdef DEBUG_DATAFLASH_FILE
		if(dataflash_file_debug_flag)
			printf("DIR Search Read Error (page: %u)\r\n", dir_page); 
		#endif	// #ifdef DEBUG_DATAFLASH_FILE
		return 0;
		}
	p_dir=(DIR_NAME_STRUCT*)&dataflash_temp_buffer[(unsigned int)sizeof(DIR_NAME_STRUCT)*dir_entry];
	if(dir_struct)
		memcpy(dir_struct, p_dir, sizeof(DIR_NAME_STRUCT));
	if((p_dir->option!=0xff)&&(p_dir->option!=0x00))
		return 1;
	}
return 0;
}


// **********************************************************************************
// Description  : create a new DIR entry
// Input        : *dir_name: pointer to file name
// Output       : 0 - Error - can't create
//              : 1 - OK - create dir
// Indication   : none
// **********************************************************************************
unsigned char dataflash_dir_new(unsigned char *dir_name)
{
unsigned char search_0x00=0;
unsigned int dir_page, dir_entry;
DIR_NAME_STRUCT *p_dir;

dir_name[DIR_NAME_LAST_SIGN]=0x0;	// cut the dir name to DIR_NAME_SIZE signs + 0-sign
if(!dataflash_file_check_name(dir_name))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("DIR Name Error: \"%11s\"\r\n", dir_name); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
if(dataflash_dir_search(dir_name, 0x0, 0x0))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		putsf("DIR New Error - available\r"); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
while(1)
	{
	for(dir_page=FILE_DIR_PAGE_ADDR;dir_page<FILE_DIR_PAGE_END;dir_page++)
		{
		if(!dataflash_read_flash(dataflash_temp_buffer, dir_page, 0, FLASH_PAGE_SIZE))
			{
			#ifdef DEBUG_DATAFLASH_FILE
			if(dataflash_file_debug_flag)
				printf("DIR New Read Error (page: %u)\r\n", dir_page); 
			#endif	// #ifdef DEBUG_DATAFLASH_FILE
			return 0;
			}
		p_dir=(DIR_NAME_STRUCT*)dataflash_temp_buffer;
		for(dir_entry=0;dir_entry<FILE_DIR_COUNT_PAGE;dir_entry++)
			{
			if((search_0x00)&&(p_dir->option==0x00))	// now search to 0x00 entry
				dataflash_dir_refresh(dir_page, dataflash_temp_buffer);	// set one or more to 0xff
			if(p_dir->option==0xff)
				{
				p_dir->option=0xfe;
				dataflash_file_date(&p_dir->date);
				strncpy(p_dir->name, dir_name, DIR_NAME_SIZE);
				dataflash_write2flash(dataflash_temp_buffer, dir_page, 0, FLASH_PAGE_SIZE, FLASH_BUFFER1);	// write Dir-Name entry
				return 1;
				}
			p_dir++;
			}
		}
	if(search_0x00)			// after second search (0x00)- all entries are full
		break;
	search_0x00=1;			// after 0xff now search to 0x00 entry
	}
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	printf("DIR Name Full %s\r\n", dir_name); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
return 0;
}

// **********************************************************************************
// Description  : change the actual DIR
// Input        : *dir_name - pointer to dir name
// Output     	: 0 - Error	- can't change
//              : 1	- OK - change directory
// Indication	: supports follow signs:
//              : ".." : go back to root directory
//              : dir_name : go to sub directory
// **********************************************************************************
unsigned char dataflash_dir_change(unsigned char *dir_name)
{
dir_name[DIR_NAME_LAST_SIGN]=0x0;	// cut the dir name to DIR_NAME_SIZE signs + 0-sign
if(!strncmpf(dir_name, "..", 2))
	{
	if(directory_actual==DIR_NAME_ROOT)
		{
		#ifdef DEBUG_DATAFLASH_FILE
		if(dataflash_file_debug_flag)
			putsf("DIR Unknown\r"); 
		#endif	// #ifdef DEBUG_DATAFLASH_FILE
		return 0;
		}
	else
		{
		directory_actual=DIR_NAME_ROOT;
		return 1;
		}
	}
if(dataflash_dir_search(dir_name, &directory_actual, 0))
	return 1;
#ifdef DEBUG_DATAFLASH_FILE
if(dataflash_file_debug_flag)
	printf("DIR Change Error \"%s\"\r\n", dir_name); 
#endif	// #ifdef DEBUG_DATAFLASH_FILE
return 0;
}

// **********************************************************************************
// Description	: delete a DIR
// Input       	: *dir_name: pointer to dir name
// Output     	: 0: Error - can't delete
//             	: 1: OK - delete directory
// Indication	: delete only empthy directories
//              :   set the root directory
// **********************************************************************************
unsigned char dataflash_dir_delete(unsigned char *dir_name)
{
unsigned int dir_page;
unsigned char dir_entry;
unsigned char buffer;
unsigned char old_dir;		// set root directory

dir_name[DIR_NAME_LAST_SIGN]=0x0;	// cut the dir name to DIR_NAME_SIZE signs + 0-sign
if(!dataflash_dir_search(dir_name, &dir_entry, 0x0))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("DIR Delete wrong name: \"%s\"\r\n", dir_name); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
old_dir=directory_actual;	// save actual directory
directory_actual=dir_entry;	// set directory of "dir_name"
if(dataflash_file_search(0x0, 0x0, 0x0, SEARCH_FIRST))
	{
	directory_actual=old_dir;	// set old directory
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		putsf("DIR Delete no empthy\r"); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
directory_actual=old_dir;	// set old directory
dir_page=dir_entry/FILE_DIR_COUNT_PAGE;		// calculate page position
dir_page+=FILE_DIR_PAGE_ADDR;				// add FILE-DIR offset
dir_entry%=FILE_DIR_COUNT_PAGE;				// calculate within the page
if(!dataflash_read_flash2buffer(FLASH_BUFFER1, dir_page))
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("DIR Delete Read Error (page: %u)\r\n", dir_page); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
buffer=0x00;
dataflash_write_buffer(&buffer, (unsigned int)sizeof(DIR_NAME_STRUCT)*dir_entry, 1, FLASH_BUFFER1);
if(!dataflash_write_buffer2flash(FLASH_BUFFER1, dir_page))	// Write Page
	{
	#ifdef DEBUG_DATAFLASH_FILE
	if(dataflash_file_debug_flag)
		printf("DIR Delete Write Page: %u\r\n", dir_page); 
	#endif	// #ifdef DEBUG_DATAFLASH_FILE
	return 0;
	}
if(dir_entry==directory_actual)	
	directory_actual=DIR_NAME_ROOT;	// set root directory
return 1;
}

#endif	// #ifdef DATAFLASH_FILE_ENABLE