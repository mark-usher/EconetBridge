// ************************************************************************************************
///
/// \file 			dataflash_file_debug.c
/// \brief			Debug functions for dataflash_file.c
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef DEBUG_DATAFLASH_FILE

#include "board.h"
#include "dataflash_file.h"
#include "dataflash_file_debug.h"
#include "debug.h"

#pragma regalloc-
unsigned char 		 dataflash_debug_buffer[FLASH_PAGE_SIZE];
eeprom unsigned char dataflash_file_debug_flag = 0x00;	// default: debug output off
#pragma regalloc+

// prototypes
void dataflash_file_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);

// ************************************************************************************************
/// \brief	    Registers Dataflash-File debug handler with debug framework
///
// ************************************************************************************************
void dataflash_file_debug_init(void)
{
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &dataflash_file_debug_handler;
p_struct.id_string = "dff";
debug_register_handler(&p_struct);
}

// **********************************************************************************
// Description  : displays ONE entry of Filename
// Input        : p_name: pointer to FILE_NAME_STRUCT
//				: file_entry - position in the file-list
//              : mode: 1==displays all; 0==display without directory
// Output     	: none
// Indication	: none
// **********************************************************************************
void dataflash_file_display(FILE_NAME_STRUCT *p_name, unsigned int file_entry, unsigned char mode)
{
DIR_NAME_STRUCT dir_struct;

printf("FILE(%3u):\"%12s\",%6luByte,", file_entry, p_name->name, (unsigned long)(p_name->countpage-1)*FILE_DATA_PAGE_SIZE+p_name->lastpage_byte);
printf("%02u.%02u.%4u/%02u:%02u:%02u,", p_name->date.day, p_name->date.month, (unsigned int)p_name->date.year+2000,
								 p_name->date.hour, p_name->date.minute, p_name->date.second);
printf("%4u,%4u", p_name->startpage, p_name->lastpage); 
if(mode)
	{
	if(p_name->dir_number==0xff)
		putsf(",\"       root\"\r"); 
	else
    	{
		if(dataflash_dir_search(0x0, &p_name->dir_number, &dir_struct))
			printf(",\"%11s\"\r\n", dir_struct.name); 
		else	
			printf(",%u\r\n", p_name->dir_number); 
		}
	}
else
	putsf("\r"); 
}


// **********************************************************************************
// Description   : displays ALL entries of Filenames
// Input         : none
// Output     	 : none
// Indication	 : none
// **********************************************************************************
void dataflash_file_debug_file(void)
{
unsigned int file_entry=0;
FILE_NAME_STRUCT file_struct;
/*
unsigned int Lva, Lvb;
FILE_NAME_STRUCT *p_file_struct;

for(Lva=FILE_NAME_PAGE_ADDR;Lva<FILE_NAME_PAGE_END;Lva++)
	{
	dataflash_read_flash(dataflash_debug_buffer, Lva, 0, FLASH_PAGE_SIZE);
	p_file_struct=(FILE_NAME_STRUCT*)dataflash_debug_buffer;
	for(Lvb=0;Lvb<FILE_NAME_COUNT_PAGE;Lvb++)
		{
		if((p_file_struct->startpage!=0xffff)&&(p_file_struct->startpage!=0x0000))
			dataflash_file_display(p_file_struct, file_entry, 1);
		p_file_struct++;
		file_entry++;
		}
	}
*/
if(dataflash_file_search(0x0, &file_struct, &file_entry, SEARCH_FIRST))
	{
	putsf("dataflash_file_search()\r"); 
	do
		{
		dataflash_file_display(&file_struct, file_entry, 1);
		}
	while(dataflash_file_search(0x0, &file_struct, &file_entry, SEARCH_NEXT));
	}
else
	putsf("no file entries\r");
}


// **********************************************************************************
// Description   : displays ALL entries of Filename from actual directory
// Input         : none
// Output     	 : none
// Indication	 : none
// **********************************************************************************
void dataflash_file_debug_file_dir(void)
{
unsigned int file_entry;
FILE_NAME_STRUCT file_struct;
DIR_NAME_STRUCT dir_struct;

printf("Current DIR: ");
if(directory_actual==DIR_NAME_ROOT)
	putsf("\"root\"\r"); 
else
    {
	if(dataflash_dir_search(0x0, &directory_actual, &dir_struct))
		printf("\"%s\"\r\n", dir_struct.name); 
	}
if(dataflash_file_search(0x0, &file_struct, &file_entry, SEARCH_FIRST))
	{
	do
		{
		dataflash_file_display(&file_struct, file_entry, 0);
		}
	while(dataflash_file_search(0x0, &file_struct, &file_entry, SEARCH_NEXT));
	}
}


// **********************************************************************************
// Description  : displays the data of file-handle
// Input      	: handle - handle to open file
// Output     	: none
// Indication	: none
// **********************************************************************************
void dataflash_file_debug_handle_d(unsigned char handle)
{
printf("Handle: %u\r\n", handle); 
printf("startpage   :%4u lastpage     :%4u\r\n", file_handle[handle].startpage, file_handle[handle].lastpage); 
printf("countpage   :%4u lastpage_byte:%4u\r\n", file_handle[handle].countpage, file_handle[handle].lastpage_byte); 
printf("dir_number  :%4u file_entry   :%4u\r\n", file_handle[handle].dir_number, file_handle[handle].file_entry); 
printf("absolut_page:%4u absolut_byte :%4u\r\n", file_handle[handle].act_absolut_page, file_handle[handle].act_absolut_byte); 
}


// **********************************************************************************
// Description  : info of the file-handle
// Input      	: handle - handle to open file
//                         ==0xff - displays all file handler
//                         !=0xff - displays only the handle
// Output     	: none
// Indication	: none
// **********************************************************************************
void dataflash_file_debug_handle(unsigned char handle)
{
unsigned char Lva;

if(handle==0xff)
	{
	for(Lva=0;Lva<FILE_HANDLE_COUNT;Lva++)
		{
		if(file_handle[Lva].startpage!=0x0)
			dataflash_file_debug_handle_d(Lva);
		}
	}
else
	{
	if(handle<FILE_HANDLE_COUNT)
		dataflash_file_debug_handle_d(handle);
	}	
}


// **********************************************************************************
// Description   : displays ALL entries of Directories
// Input         : none
// Output     	 : none
// Indication	 : none
// **********************************************************************************
void dataflash_file_debug_dir(void)
{
unsigned int Lva, Lvb, dir_entry=0;
DIR_NAME_STRUCT *p_dir;
DIR_NAME_STRUCT dir_struct;

printf("Current DIR: "); 
if(directory_actual==DIR_NAME_ROOT)
	putsf("\"root\"\r"); 
else
    {
	if(dataflash_dir_search(0x0, &directory_actual, &dir_struct))
		printf("\"%s\"\r\n", dir_struct.name); 
	}
for(Lva=FILE_DIR_PAGE_ADDR;Lva<FILE_DIR_PAGE_END;Lva++)
	{
	dataflash_read_flash(dataflash_debug_buffer, Lva, 0, FLASH_PAGE_SIZE);
	p_dir=(DIR_NAME_STRUCT*)dataflash_debug_buffer;
	for(Lvb=0;Lvb<FILE_DIR_COUNT_PAGE;Lvb++)
		{
		if((p_dir->option!=0xff)&&(p_dir->option!=0x00))
			{
			printf("DIR(%2u):\"%12s\", ", dir_entry, p_dir->name);
			printf("%02u.%02u.%04u/%02u:%02u:%02u, ", p_dir->date.day, p_dir->date.month, (unsigned int)p_dir->date.year+2000,
										 p_dir->date.hour, p_dir->date.minute, p_dir->date.second);
			printf("0x%x\r\n", p_dir->option); 
			}
		dir_entry++;
		p_dir++;
		}
	}
}


// **********************************************************************************
// Description   : info to the dataflash-file-system
// Input         : none
// Output     	 : none
// Indication	 : none
// **********************************************************************************
void dataflash_file_debug_info(void)
{
INFO_STRUCT *p_info;

putsf("DataFlash-File:\r");
printf("FILE_INFO      : address:%3u pages: %u (%ubyte)\r\n", FILE_INFO_PAGE_ADDR, FILE_INFO_PAGE_COUNT, FILE_INFO_BYTE_SIZE);
printf("FILE_FF        : address:%3u pages: %u (%ubyte)\r\n", FILE_FF_PAGE_ADDR, FILE_FF_PAGE_COUNT, FILE_FF_BYTE_SIZE);
printf("FILE_DIR       : address:%3u-%4u pages: %u (%ubyte; %u Directories; %ubyte)\r\n", FILE_DIR_PAGE_ADDR, FILE_DIR_PAGE_END,
												FILE_DIR_PAGE_COUNT, FILE_DIR_BYTE_SIZE, FILE_DIR_COUNT, sizeof(DIR_NAME_STRUCT));
printf("FILE_ALLOCATION: address:%3u-%4u pages: %u (%ubyte; Entry:%ubyte)\r\n", FILE_ALLOCATION_PAGE_ADDR, FILE_ALLOCATION_PAGE_END,
												FILE_ALLOCATION_PAGE_COUNT, FILE_ALLOCATION_BYTE_SIZE, FILE_ALLOCATION_ENTRY);
printf("FILE_NAME      : address:%3u-%4u pages: %u (%lubyte; %u Files; %ubyte)\r\n", FILE_NAME_PAGE_ADDR, FILE_NAME_PAGE_END, 
												FILE_NAME_PAGE_COUNT, FILE_NAME_BYTE_SIZE, FILE_NAME_COUNT, sizeof(FILE_NAME_STRUCT));
printf("FILE_DATA      : address:%3u-%4u pages: %u (%lubyte; Pagesize:%ubyte)\r\n", FILE_DATA_PAGE_ADDR, FILE_DATA_PAGE_END,
												FILE_DATA_PAGE_COUNT, FILE_DATA_BYTE_SIZE, FILE_DATA_PAGE_SIZE);
if(dataflash_read_flash(dataflash_debug_buffer, FILE_INFO_PAGE_ADDR, 0, FLASH_PAGE_SIZE))
	{
	p_info=(INFO_STRUCT*)dataflash_debug_buffer;
	printf("FILE Label: 0x%lx\r\n", p_info->label); 
	printf("FILE Version: 0x%04x\r\n", p_info->version); 
	printf("FILE Storage: 0x%04x\r\n", p_info->storage_typ); 
	printf("FILE Date/Time: %s/%s\r\n", p_info->date, p_info->time); 
	printf("FILE Dir: %u  File: %u\r\n", p_info->dir_count, p_info->file_count); 
	printf("FILE Info: %s\r\n", p_info->info);
	}
}


//********************************************************************************
// Description	: display the convert integer from string
// Input   		: data_page: 0...FILE_DATA_PAGE_COUNT
// Output  		: none
// Indication	: none
//*********************************************************************************
void dataflash_file_alloc_info(unsigned int data_page)
{
unsigned int actual_alloc_page;

actual_alloc_page=data_page/FILE_ALLOCATION_PAGE_ENTRY;
if(actual_alloc_page>FILE_ALLOCATION_PAGE_COUNT)
	{
	printf("Too much pages: %u (max: %u)\r\n", data_page, FILE_DATA_PAGE_COUNT); 
	return;
	}
if(dataflash_read_flash(dataflash_debug_buffer, FILE_ALLOCATION_PAGE_ADDR+actual_alloc_page, 0, FLASH_PAGE_SIZE))
	{
	actual_alloc_page*=FILE_ALLOCATION_PAGE_ENTRY;
	printf("Allocation Entries: %u-%u\r\n", actual_alloc_page+1, actual_alloc_page+FILE_ALLOCATION_PAGE_ENTRY); 
	debug_display_mem_hex(dataflash_debug_buffer, FLASH_PAGE_SIZE, 0);
	}
}


//********************************************************************************
// Description	: reads the filename from a command string
// Input   		: command - pointer to command
//         		: file_name - pointer to buffer string with new file name
// Output  		: RETURN 0: no valid file name
//                RETURN 1: valid file name in buffer of file_name
// Indication	: none
//*********************************************************************************
unsigned char dataflash_file_debug_string(unsigned char *command, unsigned char *file_name)
{
unsigned char	*data;

data=debug_search_parameter(command);	// search the Empty-space
if(data!=0x0)							// NO null-pointer NO end-sign
	{
	strncpy(file_name, data, FILE_NAME_LAST_SIGN);
	return 1;
	}
return 0;
}


// **********************************************************************************
// Description 	: displays a page of DataFlash
// Input        : page - number of page
// Output       : none
// Indication	: format with infomations of page-number
// **********************************************************************************
void dataflash_file_debug_page_dis(unsigned int page)
{
dataflash_read_flash(dataflash_debug_buffer, page, 0, FLASH_PAGE_SIZE);
printf("Page: %u (size: %ubyte)\r\n", page, FLASH_PAGE_SIZE);
if((page>=FILE_DIR_PAGE_ADDR)&&(page<FILE_DIR_PAGE_END))
	debug_display_mem_hex(dataflash_debug_buffer, FLASH_PAGE_SIZE, sizeof(DIR_NAME_STRUCT));
else if((page>=FILE_NAME_PAGE_ADDR)&&(page<FILE_NAME_PAGE_END))
	debug_display_mem_hex(dataflash_debug_buffer, FLASH_PAGE_SIZE, sizeof(FILE_NAME_STRUCT));
else
	debug_display_mem_hex(dataflash_debug_buffer, FLASH_PAGE_SIZE, 0);
}


unsigned char file_name[FILE_NAME_SIZE]="test.dat";
unsigned char dir_name[FILE_NAME_SIZE]="test";
unsigned char file_data_buffer[0x1000];

// ************************************************************************************************
/// \brief	    command handler for debug commands
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void dataflash_file_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
static unsigned char handle=FILE_HANDLE_DISABLE;
unsigned long 		file_size;
int 		 		data;
unsigned int 		Lva;

if (mode == DEBUG_HANDLER_MODE_INFO)
	{
	printf("DEBUG_DATAFLASH_FILE");
	if(dataflash_file_debug_flag)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
    // add output for 'info' command here
	}
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
    // add output for 'help' command here
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
    {
	if (strncmpf(command, "dff", 3)==0)
	    {
    	dataflash_file_debug_flag ^= 0xFF;
    	if (dataflash_file_debug_flag)
			putsf("WEB_DEBUG_FILE ON\r");
		else
			putsf("WEB_DEBUG_FILE OFF\r");
	    }
	}
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "page", 4)==0)
		{
		data = debug_get_int_parameter(command);
		if(data==-1)
			data=0;
		dataflash_file_debug_page_dis(data);
		}
	else if (strncmpf(command, "handle-info", 8)==0)
		{
		data=debug_get_int_parameter(command);
		if(data==-1)
			data=0xff;
		dataflash_file_debug_handle(data);
		}
	else if (strncmpf(command, "handle-set", 8)==0)
		{
		handle=debug_get_int_parameter(command);
		if(handle==0xff)    // means -1
			handle=0;
		printf("Set Handle: %u\r\n", handle);
		}
	else if (strncmpf(command, "alloc", 5)==0)
		{
		data=debug_get_int_parameter(command);
		if(data==-1)
			data=0;
		dataflash_file_alloc_info(data);
		}
	else if (strncmpf(command, "file-init", 8)==0)
		{
		if(!(dataflash_file_init(DATAFLASH_SPI_MODE)))		// init dataflash
			putsf("Flash-File init error!!!\r"); 
		else
			putsf("Flash-File init OK\r"); 
		}
	else if (strncmpf(command, "file-format", 6)==0)
		{
		dataflash_file_format();
		dataflash_file_init(DATAFLASH_SPI_MODE);		// init dataflash
		}
	else if (strncmpf(command, "file-info", 8)==0)
		dataflash_file_debug_info();
	else if (strncmpf(command, "file-list", 6)==0)
		dataflash_file_debug_file();
	else if (strncmpf(command, "file-open", 6)==0)
		{
		if(handle!=FILE_HANDLE_DISABLE)
			{
			putsf("Close Handle!!!\r"); 
			return;
			}
		dataflash_file_debug_string(command, file_name);
		if(dataflash_file_open(file_name, &handle))
			dataflash_file_debug_handle_d(handle);
		}
	else if (strncmpf(command, "file-close", 6)==0)
		{
		dataflash_file_close(&handle);
		}
	else if (strncmpf(command, "file-read", 6)==0)
		{
		data=debug_get_int_parameter(command);
		if((data==-1)||(data>sizeof(file_data_buffer)))
			data=192;
		dataflash_file_read(handle, file_data_buffer, data);
	//	debug_display_mem_hex(file_data_buffer, data, 0);
		}
	else if (strncmpf(command, "file-eof", 6)==0)
		{
		if(dataflash_file_eof(handle))
			putsf("FILE EOF True\r"); 
		else
			putsf("FILE EOF False\r"); 
		}
	else if (strncmpf(command, "file-size", 7)==0)
		{
		dataflash_file_size(handle, &file_size);
		printf("FILE Size: %lu Byte\r\n", file_size); 
		}
	else if (strncmpf(command, "file-seek", 7)==0)
		{
		data=debug_get_int_parameter(command);
		if(data!=-1)
			dataflash_file_seek(handle, data);
		else
			dataflash_file_seek(handle, 0xffffffff);
		}
	else if (strncmpf(command, "file-new", 6)==0)
		{
		dataflash_file_debug_string(command, file_name);
		dataflash_file_new(file_name);
		}
	else if (strncmpf(command, "file-w1", 7)==0)
		{
		data=debug_get_int_parameter(command);
		if((data==-1)||(data>sizeof(file_data_buffer)))
			data=272;
		for(Lva=0;Lva<data;Lva++)	// init data
			file_data_buffer[Lva]=(unsigned char)Lva;	// init data
		dataflash_file_seek(handle, 0xffffffff);	// set to EOF
		dataflash_file_write(handle, file_data_buffer, data);
		}
	else if (strncmpf(command, "file-w2", 7)==0)
		{
		data=debug_get_int_parameter(command);
		if((data==-1)||(data>sizeof(file_data_buffer)))
			data=272;
		for(Lva=0;Lva<data;Lva++)
			file_data_buffer[Lva]=0xaa;		 		// init data
		dataflash_file_seek(handle, 0xffffffff);	// set to EOF
		dataflash_file_write(handle, file_data_buffer, data);
		}
	else if (strncmpf(command, "file-delete", 7)==0)
		{
		if(dataflash_file_delete(handle))
			{
			putsf("FILE Delete\r"); 
			handle=FILE_HANDLE_DISABLE;
			}
		}
	else if (strncmpf(command, "file-dir", 7)==0)
		dataflash_file_debug_file_dir();
	else if (strncmpf(command, "dir-list", 5)==0)
		dataflash_file_debug_dir();
	else if (strncmpf(command, "dir-new", 5)==0)
		{
		dataflash_file_debug_string(command, dir_name);
		if(dataflash_dir_new(dir_name))
			printf("DIR New \"%s\"\r\n", dir_name); 
		}
	else if (strncmpf(command, "dir-change", 5)==0)
		{
		dataflash_file_debug_string(command, dir_name);
		if(dataflash_dir_change(dir_name))
			printf("DIR Change \"%s\"\r\n", dir_name); 
		}
	else if (strncmpf(command, "dir-delete", 5)==0)
		{
		dataflash_file_debug_string(command, dir_name);
		if(dataflash_dir_delete(dir_name))
			printf("DIR Delete \"%s\"\r\n", dir_name); 
		}
	}
}
#endif	// #ifdef DEBUG_DATAFLASH_FILE