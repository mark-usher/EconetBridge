// ************************************************************************************************
///
/// \file 			cs8900_sleep.c
/// \brief			CS8900 sleep mode functions
///
/// \todo			Join cs8900_sleep.c and cs8900.c together
/// \todo			Test sleep mode - sleep mode failes sporadically
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration


#include <delay.h>
#include <io.h>

#include "cs8900.h"
#include "board.h"
#include "cs8900_sleep.h"

#pragma regalloc-
#pragma regalloc+

#define	IO_ADDRESS	       	0xf000	// define the address to read/write IO of Ethernet
#define ETHER_IO(address)	*(unsigned char*)(IO_ADDRESS+address) 

//*********************************************************************************
// Description	: writes a word in little-endian byte order to a specified port-address
// Input	   	: none
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void __cs8900_write(unsigned char address, unsigned int data)
{
ETHER_IO(address)=LO(data);
ETHER_IO(address+1)=HI(data);
}

//*********************************************************************************
// Description	: activates the Software-Suspend Mode
// Input  	 	: none
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void	cs8900_sleep_software(void)
{
__cs8900_write(IO_PORT_ADD, CS8900_PP_SELF_CTL);		// dummy write to Wakeup
delay_ms(10);
__cs8900_write(IO_PORT_ADD, CS8900_PP_SELF_CTL);		// set the SelfST-Register-Address (Register 16)
__cs8900_write(IO_PORT_DATA, SELF_CTL_SW_SUSPEND);		// set the Software Suspend Mode
}	


//*********************************************************************************
// Description	: activates the Hardware-Suspend Mode
// Input  	 	: none
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void	cs8900_sleep_hardware(void)
{
CS8900_SLEEP_L;			// see cs8900.h
CS8900_SLEEP_OUTPUT;	// see cs8900.h
__cs8900_write(IO_PORT_ADD, CS8900_PP_SELF_CTL);   		// set the SelfST-Register-Address (Register 16)
__cs8900_write(IO_PORT_DATA, SELF_CTL_HW_SLEEP_E);		// set the Hardware Suspend Mode
}	

//*********************************************************************************
// Description	: init the cs8900 of eTW-Modul
// Input	 	: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void	cs8900_sleep_active(void)
{
if((MCUCR & 0x80)==0)  		// Disable external Interface???
	{
	XMCRA=SRL_7;				// Lower sector=0x1100..0xDfff / Upper sector=0xE000..0xffff
	MCUCR|=0x80;				// Enable external Interface
	cs8900_sleep_software();
	//cs8900_sleep_hardware();
	MCUCR&=~0x80;		  		// Disable external Interface
	}
else
	{
	cs8900_sleep_software();
	//cs8900_sleep_hardware();
	}
}


