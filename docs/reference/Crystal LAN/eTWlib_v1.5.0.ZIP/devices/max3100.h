// ************************************************************************************************
///
/// \file 			max3100.h
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _MAX3100_H_INCLUDED_
#define _MAX3100_H_INCLUDED_

#include "project.h"

//-----------------------------------------------------------------------------
//	Pin macros
//---------------------------------------------------------------------------
#ifndef MAX3100_CS_LOW
#define MAX3100_CS_LOW
#endif
#ifndef MAX3100_CS_HIGH
#define MAX3100_CS_HIGH
#endif
#ifndef MAX3100_CS_ACTIV
#define	MAX3100_CS_ACTIV
#endif
#ifndef MAX3100_CS_PIN
#define	MAX3100_CS_PIN		    1
#endif
#ifndef SPI_SOFT_SCK_ACTIV
#define SPI_SOFT_SCK_ACTIV
#endif
#ifndef SPI_SOFT_SCK_HIGH
#define SPI_SOFT_SCK_HIGH
#endif
#ifndef SPI_SOFT_SCK_LOW
#define SPI_SOFT_SCK_LOW
#endif
#ifndef SPI_SOFT_SCK_PIN
#define SPI_SOFT_SCK_PIN		1
#endif
#ifndef SPI_SOFT_MOSI_ACTIV
#define SPI_SOFT_MOSI_ACTIV
#endif
#ifndef SPI_SOFT_MOSI_HIGH
#define SPI_SOFT_MOSI_HIGH
#endif
#ifndef SPI_SOFT_MOSI_LOW
#define SPI_SOFT_MOSI_LOW
#endif
#ifndef SPI_SOFT_MOSI_PIN
#define SPI_SOFT_MOSI_PIN		1
#endif
#ifndef SPI_SOFT_MISO_PASSIV
#define SPI_SOFT_MISO_PASSIV
#endif
#ifndef SPI_SOFT_MISO_HIGH
#define SPI_SOFT_MISO_HIGH
#endif
#ifndef SPI_SOFT_MISO_LOW
#define SPI_SOFT_MISO_LOW
#endif
#ifndef SPI_SOFT_MISO_PIN
#define SPI_SOFT_MISO_PIN		1
#endif


//-----------------------------------------------------------------------------
//	SPI-Functions
//---------------------------------------------------------------------------
#if defined(MAX3100_ENABLE) && !defined(MAX3100_SPI_HARDWARE) && !defined(MAX3100_SPI_SOFTWARE)
#error "no MAX3100 SPI-Mode defined!"
#endif

#if defined(MAX3100_ENABLE) && defined(DEBUG_UPLINK_UART_MAX3100) && defined(MAX3100_DEBUG)
#error "MAX3100 cannot be debugged via itself"
#endif


#ifdef MAX3100_SPI_HARDWARE
#define MAX3100_SPI_WRITE(c)    spi_transfer(c)
// both variants are valid:
#define MAX3100_SPI_INIT()     	spi_init(SPCR_SPE|SPCR_MSTR|SPCR_4)		// SCK=LOW and rising edge
//#define MAX3100_SPI_INIT     	spi_init(SPCR_SPE|SPCR_MSTR|SPCR_4|SPCR_CPOL|SPCR_CPHA)	// SCK=HIGH and rising edge
#endif

#ifdef MAX3100_SPI_SOFTWARE
#define MAX3100_SPI_WRITE(c)    spi_soft_write(c)
#define MAX3100_SPI_INIT()	    spi_soft_init()
#endif

// prototypes
#pragma used+
extern	bit max3100_rx_flag;

void			max3100_init(void);
void 			max3100_write_config(void);
unsigned int	max3100_read_config(void);
unsigned char   max3100_poll(void);
signed int 		max3100_check_rx(void);
char			max3100_getchar(void);
void			max3100_putchar(char c);
void 			max3100_putsf(char flash *str); 
void			max3100_debug(void);
void            max3100_debug_cmd(unsigned char *command);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library max3100.c 
#endif

#endif 	// #ifndef _MAX3100_H_INCLUDED_