// ************************************************************************************************
///
/// \file 			sdcard.c
/// \brief			Interfacing an MMC or SDCard
///
/// \todo			The macros 'POLL_BUSY_FLAG_SPI' and 'SHIFT_REGISTER_SPI' should be renamed
///					or removed.
/// \todo			Check write protect and mmc functions. See comment at the end of sdcard.h
/// \todo			rename macro CMD_CRC_ENABLE
/// \todo			replace command macros in sdcard.h by enum typedef's
///					
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Nico M�ding, Hubert Nestler, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#ifdef _DOXYGEN_PARSER_
#define SDCARD_ENABLE
#define SDCARD_DEBUG
#endif

#ifdef SDCARD_ENABLE

#include <io.h>
#include <math.h>
#include "sdcard.h"
#include "sdcard_debug.h"
#include "crc.h"
#include "debug.h"
#include "avr_spi.h"

#ifndef SPI_ENABLE
#error "SPI Module is needed for SDcard. Define SPI_ENABLE."
#endif


// ************************************************************************************************
/// \variable csd
/// \brief  Card Specific Data (CSD) structure
// ************************************************************************************************
static CSD_STRUCTURE CSD= { 0x80, SDC_ERROR_INIT_FAILED, 0, 0, 0, 0, 10000, 25000, 0, 0, 0, 0 };	// default values

/// @name Local Prototypes
//@{
unsigned char sdc_data_exchange_spi(unsigned char *buff, unsigned int len, unsigned char opt);
unsigned char sdc_status_detect(unsigned char opt);
unsigned long sdc_cctli(unsigned char *byte);
void sdc_clitc(unsigned char *byte, unsigned long value);
unsigned char crc7_calc(unsigned char *buff, unsigned char len);
unsigned int sdc_crc16_calc(unsigned char *buff, unsigned int len, unsigned char *p_crc);
//@}


// ************************************************************************************************
/// \brief      Initializes SD-Card Software module.
/// \remarks    This function should be called once after reset
// ************************************************************************************************
void sdc_init(void)
{
#ifdef SDCARD_DEBUG
sdc_debug_init();
#endif

sdc_init_card();
}


// ************************************************************************************************
/// \brief      handles the card detection as well as the initialization process.
/// \remarks    This function should be placed in the main loop and called periodically.
// ************************************************************************************************
void sdc_main(void)
{
static unsigned char num_cyc;
unsigned char sdc_init_state;

sdc_check_detection();
// if card detected and not initialized
if(((CSD.reg_detect & SDC_STATUS_DETECTED) != 0) && ((CSD.reg_detect & SDC_STATUS_INITIALIZED) == 0))
    {
    if(num_cyc < SDC_ERROR_COUNT_INIT)      // abort process after ... init cycles
        {
        sdc_init_state = sdc_init_card();
        if(sdc_init_state == 1)			    // init process done
	        {
	        LED2_ON;
            }
        else if(sdc_init_state == 0)	    // maybe additional error handlings ???!!!
	        {
            num_cyc++;
	        }
        }
    else if(num_cyc == SDC_ERROR_COUNT_INIT)
        {
        #ifdef SDCARD_DEBUG
	    if(sdc_debug_flag & SDCARD_DEBUG_BIT)
	        {
		    printf("ERROR SDC/MMC: abort init process after %d cycles.\n\r", num_cyc);
		    num_cyc++;
		    }
        #endif		// #ifdef SDCARD_DEBUG
        }
    }
// if card removed
else if((CSD.reg_detect & SDC_STATUS_DETECTED) == 0)
    {
    LED2_OFF;
    num_cyc = 0;
    }
}



// ************************************************************************************************
/// \brief		checks if a card was inserted or removed.
/// \note The function sets the corresponding members of the csd structure.
// ************************************************************************************************
void sdc_check_detection(void)
{
static unsigned char status_changed = 0x80;		// after chip reset

#ifdef SDC_HW_DETECT_ENABLE
if(SDC_POLL_CARD_DETECTION)						// card inserted
	{
	CSD.reg_detect |= SDC_STATUS_DETECTED;
	if(SDC_POLL_WP_DETECTION)    				// lock/unlock detection
    	CSD.reg_detect &= ~SDC_STATUS_LOCKED;
	else
		CSD.reg_detect |= SDC_STATUS_LOCKED;
    }
else											// card removed
	CSD.reg_detect = 0;							// clear detection register
#else
if((CSD.reg_detect & SD_CARD_DETECTED) == 0)
    {
    // check if card inserted
    if((sdc_send_cmd(GO_IDLE_STATE, 0, R1_LEN, 0)^0x01)==0)
        {
        CSD.reg_detect |= SD_CARD_DETECTED;
        CSD.reg_detect &= ~SD_CARD_LOCKED;      // card never locked
        }
    }
else
    {
    if(sdc_get_status_reg() != 0)               // card removed
        CSD.reg_detect = 0;						// clear detection register
    }
#endif	// #ifdef SDC_HW_DETECT_ENABLE
#ifdef SDCARD_DEBUG
if(status_changed != (CSD.reg_detect&(SDC_STATUS_DETECTED)))
	{
	if(sdc_debug_flag & SDCARD_DEBUG_BIT)
		printf("SDC/MMC Detection: ... ");
	if((CSD.reg_detect & SDC_STATUS_DETECTED) == 0)
		{
		if(sdc_debug_flag & SDCARD_DEBUG_BIT)
			printf("card removed.\n\r");
		}
	else
		{
		if(sdc_debug_flag & SDCARD_DEBUG_BIT)
			printf("card inserted");
		if((CSD.reg_detect & SDC_STATUS_LOCKED) == 0)
			{
	  		if(sdc_debug_flag & SDCARD_DEBUG_BIT)
	    		printf(".\n\r");
			}
		else
			if(sdc_debug_flag & SDCARD_DEBUG_BIT)
				printf(", but locked.\n\r");
		}
	}
#endif	// #ifdef SDCARD_DEBUG
status_changed = (CSD.reg_detect&(SDC_STATUS_DETECTED));
}


#define SPSR_WCOL           0x40    // SPI Write Collision flag            

// ************************************************************************************************
/// \brief		exchanges the data over the SPI shift register.
///	\note		The function writes/reads data to/from the SPI bus, which depends
///				on the passed option.
/// @param[in]	*buff 	- 	pointer to array
/// @param[in]	len		-	array length
/// @param[in]	opt
///						-	0: write command or data <br>
///						-	1: read response token or data <br>
///						-	2: read data token or busy token after write
/// @retval		1		-	success
/// @retval		0		-	error
// ************************************************************************************************
unsigned char sdc_data_exchange_spi(unsigned char *buff, unsigned int len, unsigned char opt)
{
unsigned long time_out_cyc = 0;
unsigned char temp, start_byte = 0;
unsigned int count = 1;
unsigned char counter_busy_flag;

if( opt == 1 ) time_out_cyc = CSD.max_read_access_cyc;			// set time out read cycles
else if (opt == 2 ) time_out_cyc = CSD.max_write_access_cyc; 	// set time out write cycles

while(count <= len)
 	{
	switch(opt)
 		{
		case 0:
		SHIFT_REGISTER_SPI = buff[count-1]; 		// write byte
		break;
		default:
		SHIFT_REGISTER_SPI = 0xFF;					// MOSI line high
 	    }
 	counter_busy_flag = 32;
    while(!POLL_BUSY_FLAG_SPI)
        {
        temp = SPSR;
		if( --counter_busy_flag == 0 )
 			{
 			#ifdef SDCARD_DEBUG
 			if ((temp & SPSR_WCOL) != 0)
 			    printf("ERROR: write collision detected!\n\r");
 			#endif		// #ifdef SDCARD_DEBUG
			CSD.error_code = SDC_ERROR_SPI_BUSY_FLAG;
			return 0;
 			}
        }
    switch(opt)
 	    {
    	case 0:
   		temp = SHIFT_REGISTER_SPI;					// read for nothing
    	break;

    	default:
   		buff[count-1] = SHIFT_REGISTER_SPI;			// read byte
   		if((start_byte == 0) && (opt == 1) && (buff[count-1] >= SDC_START_SINGLE_BLOCK))
    		{
   			if(buff[count-1] == SDC_START_SINGLE_BLOCK) start_byte = 1;	// if start byte
   			count--;
   			if( time_out_cyc-- == 0 )
	   			{
 				CSD.error_code = SDC_ERROR_READ_TAAC;
   				return 0;			// time out read
    			}
    		}
   		else if((opt == 2) && (buff[count-1] == 0))	// if busy token
    		{
   			count--;
   			if( time_out_cyc-- == 0 )
    			{
   				CSD.error_code = SDC_ERROR_WRITE_TAAC;
   				return 0;			// time out write
    			}
    		}
    	}
    count++;
	}
return 1;		// success
}



// ************************************************************************************************
/// \brief		sends a stream of logical ones used as wait cycles.
/// @param[in]	num_cyc	-	number of cycles (1 cycle = 8 clocks)
// ************************************************************************************************
void sdc_wait_cyc(unsigned int num_cyc)
{
unsigned char temp;

while( num_cyc-- != 0 )
	{
	SHIFT_REGISTER_SPI = 0xFF;
	while(!POLL_BUSY_FLAG_SPI);
	temp = SHIFT_REGISTER_SPI;
	}
}



// ************************************************************************************************
/// \brief		resets and initializes the sd card.
/// \note		The function updates the members of the csd structure.
/// @retval		0	-	error <br>
///	@retval		1	-	init process done <br>
/// @retval		2	-	card already initialized <br>
///	@retval		3	-	no card inserted
// ************************************************************************************************
unsigned char sdc_init_card(void)
{
unsigned char reg[16];
unsigned int temp, max_cyc;

if( CSD.reg_detect == 0x80 )	// 0x80: reg-value after chip reset
	{
	// SPI Clock 1/4 Main-Clock during initialization
	spi_init(SPCR_SPE | SPCR_MSTR | SPCR_4);
	SDC_CHIP_SELECT_ACTIV;
	#ifdef SDC_HW_DETECT_ENABLE
	SDC_INIT_CARD_DETECTION;	// init card detection
	SDC_INIT_WP_DETECTION;		// init card write protect detection
	#endif
	CSD.reg_detect = 0;
	sdc_check_detection();		// check sd card detection
	LED2_ACTIVE;					// led for card identification
	LED2_OFF;
	#ifdef CRC16_RAM
	crc16_table_make();
	#endif
	}
if((CSD.reg_detect & SDC_STATUS_DETECTED) != 0)			// sd card detected ?
	{
	if((CSD.reg_detect & SDC_STATUS_INITIALIZED) == 0) 	// sd card initialized ?
		{
		// SPI Clock 1/4 Main-Clock during initialization
		spi_init(SPCR_SPE | SPCR_MSTR | SPCR_4);
		SDC_CHIP_SELECT_HIGH;
		sdc_wait_cyc(SDC_NUM_WAIT_CYC_APU);
		// reset and activate the SPI mode
		max_cyc = SDC_ERROR_COUNT_RESET;
		while((sdc_send_cmd( SDC_GO_IDLE_STATE, 0, SDC_R1_LEN, 0 ) ^ 0x01) != 0 )
 			{
			if( --max_cyc == 0 )
 				{
				CSD.error_code = SDC_ERROR_RESET_CARD;
				return 0;
 				}
 			}
 		// sd card ready ?
		max_cyc = SDC_ERROR_COUNT_IDLE;
	   	while( sdc_send_cmd( SDC_SEND_OP_COND, 0, SDC_R1_LEN, 0 ) != 0 )
 			{
			if( --max_cyc == 0 )
 				{
				CSD.error_code = SDC_ERROR_IDLE_STATE_TAAC;
				return 0;
 				}
 			}
 		// test if sd or mmc card
 		sdc_send_cmd( SDC_APP_CMD,0, SDC_R1_LEN, 0 );
 		if(sdc_send_cmd( SDC_APP_OP_COND, 0, SDC_R1_LEN, 0 )!=0)
 			{
 			#ifdef SDCARD_DEBUG
 			if (sdc_debug_flag & SDCARD_DEBUG_BIT)
 			    printf("MMCard identified.\n\r");
 			#endif		// #ifdef SDCARD_DEBUG
 			CSD.mmc=1;
 			}
 		 else
 		 	{
 		 	#ifdef SDCARD_DEBUG
 		 	if (sdc_debug_flag & SDCARD_DEBUG_BIT)
 		 	    printf("SDCard identified.\n\r");
 		 	#endif		// #ifdef SDCARD_DEBUG
 		 	CSD.mmc=0;
 		 	}
 		//-> sollte noch getestet werden (Hubert)!!!!

	 	spi_init(SPCR_SPE | SPCR_MSTR | SPCR_2);
		#ifdef CMD_CRC_ENABLE
		sdc_send_CMD(SDC_CRC_ON_OFF, 1, SDC_R1_LEN, 0 );
		#endif	// #ifdef CMD_CRC_ENABLE
		// init process done
		CSD.reg_detect |= SDC_STATUS_INITIALIZED;
		// card specific data register
		if( sdc_read_CSD_Reg(reg) )
			{
			// calc: sector size = 2^BLOCK_LEN, if (BLOCK_LEN < 12)
			CSD.block_size = (unsigned int) ldexp( 1, (reg[5] & 0x0F));
			// calc: memory capacity = (1 + C_SIZE)*(2^(2 + C_SIZE_MULT))*(2^(BLOCK_LEN))
			// device size = C_SIZE
			temp = reg[6] & 0x0003;
			temp = ((temp << 8) & 0x0300) | reg[7];
			CSD.max_blocks = 1 + ((temp << 2) & 0x0FFF) | ((reg[8] >> 6) & 0x03);
			// multiplier = 2^(C_SIZE_MULT+2), if (C_SIZE_MULT < 8)
 			temp = reg[9] & 0x03;
 			CSD.max_blocks *= (unsigned int) ldexp( 1, 2 + ((temp << 1) & 0x0007) | ((reg[10] >> 7) & 0x01));
 			CSD.memory_capacity = CSD.max_blocks*CSD.block_size + 1;
 			CSD.max_blocks ++;
 			CSD.wp_grp_enable=((reg[12]>>7)& 0x01);
 			// erasable sector size/group size
   			if (CSD.mmc==0)     //if sdcard
   				{
   				temp = ((reg[10] << 1) & 0x7E);
   				CSD.sector_size = (temp | ((reg[11] >> 7) & 0x01)) + 1;
   			 	if(CSD.wp_grp_enable==1)
   			 		{
	   			 	CSD.wp_grp_size=(unsigned int)((unsigned char)((reg[11]) & 0x7F)+1)*CSD.sector_size;
   					}
   			   	}
   		   	if (CSD.mmc==1)		//if mmccard
   				{
   				CSD.sector_size = ((reg[10] >> 2) & 0x1F) + 1;
   			   	temp = ((reg[10]& 0x03) << 3);
   			 	CSD.erase_grp_size=(((temp |  ((reg[11]>>5))& 0x07)+1)*CSD.sector_size);
   			 	if(CSD.wp_grp_enable==1)
   			 		{
	   			 	CSD.wp_grp_size=((unsigned char)(((reg[11]) & 0x1F)+1)*CSD.erase_grp_size);
					}
   			 	}
   			// further expansion: 	Read and calc the max. access time specification (at this stage
   			// 						just the max default values will be considerd).
			#ifdef SDCARD_DEBUG
	 		if (sdc_debug_flag & SDCARD_DEBUG_BIT)
	 			{
				printf("Memory capacity: %lu bytes (%lu blocks a %u bytes)\n\r", CSD.memory_capacity, CSD.max_blocks, CSD.block_size );
				printf("Erasable sector size: %u blocks\n\r",CSD.sector_size );
				if (CSD.mmc==1)
					printf("Erasable group size: %u blocks\n\r",CSD.erase_grp_size );
				if(CSD.wp_grp_enable==1)
					{
					printf("Write protect group size: %u blocks\n\r",CSD.wp_grp_size );
					}
				}
			#endif	// #ifdef SDCARD_DEBUG
	        // set data block length (neccessary for some card's)
		    sdc_send_cmd( SDC_SET_BLOCKLEN, CSD.block_size, SDC_R1_LEN, 0 );
			CSD.error_code = 0;				// init process done
			return 1;
			}
		else
			{
			CSD.error_code = SDC_ERROR_INIT_FAILED;
			return 0;                       // error
			}
		}
	CSD.error_code = 0;
	return 2;	// card already initialized
	}
CSD.error_code = SDC_ERROR_NO_CARD;
return 3;		// no card available
}



// ************************************************************************************************
/// \brief		initializes the IO port pins if necessary and returns the contents of the detection register.
/// \note		Refer to the header file (sdcard.h) for further information.
/// \remarks    The call of this function is mandatory before any action can take place.
/// @return		CSD.reg_detect	-	detection register (8 bit)
// ************************************************************************************************
unsigned char sdc_init_module(void)
{
if(CSD.reg_detect == 0x80 )	// 0x80: reg-value after chip reset
	{
	// SPI Clock 1/4 Main-Clock during initialization
	spi_init(SPCR_SPE | SPCR_MSTR | SPCR_4);
	SDC_CHIP_SELECT_ACTIV;
	#ifdef SDC_HW_DETECT_ENABLE
		SDC_INIT_CARD_DETECTION;	// init card detection
		SDC_INIT_WP_DETECTION;		// init card write protect detection
	#endif
	CSD.reg_detect = 0;
	sdc_check_detection();		// check sd card detection
	LED2_ACTIVE;					// led for card identification
	LED2_OFF;
	#ifdef CRC16_RAM
		crc16_table_make();
	#endif
	}
return CSD.reg_detect;
}



// ************************************************************************************************
/// \brief		returns the start address of the block.
/// @return		32 bit address value
// ************************************************************************************************
unsigned long sdc_get_addr_block(unsigned long block)
{
return CSD.block_size*block;
}



// ************************************************************************************************
/// \brief		returns the physical block size.
/// @return		CSD.block_size	-	block size
// ************************************************************************************************
unsigned int sdc_get_block_size(void)
{
return CSD.block_size;
}



// ************************************************************************************************
/// \brief		returns the erasable sector size.
/// @return		CSD.sector_size	-	number of blocks per sector
// ************************************************************************************************
unsigned int sdc_get_sector_size(void)
{
return CSD.sector_size;
}



// ************************************************************************************************
/// \brief		returns the memory capacity.
///	\note		Indicates also the address range of the card (CSD.memory_capacity-1).
/// @return		CSD.memory_capacity	-	memory capacity
// ************************************************************************************************
unsigned long sdc_get_mem_cap(void)
{
return CSD.memory_capacity;
}



// ************************************************************************************************
/// \brief		returns the number of blocks.
///	\note		Indicates also the last block (CSD.max_blocks-1).
/// @return		CSD.max_blocks	-	number of blocks
// ************************************************************************************************
unsigned long sdc_get_num_blocks(void)
{
return CSD.max_blocks;
}



// ************************************************************************************************
/// \brief		identifies the sdc status information.
///	\note		The function checks the card detection, the init process and the
///				lock position.
/// @param[in]	opt
///					-	0: used for write cycles (check write protection as well) <br>
///					-	any other value: (used for read cycles)
/// @retval		1	-	success <br>
///	@retval		0	-	error (refer to error code handler:sdc_get_error_code())
// ************************************************************************************************
unsigned char sdc_status_detect(unsigned char opt)
{
if((CSD.reg_detect & SDC_STATUS_DETECTED) != 0)
	{
	if((CSD.reg_detect & SDC_STATUS_INITIALIZED) != 0)
		{
		if((opt == 0)&&((CSD.reg_detect & SDC_STATUS_LOCKED) != 0))
			{
			CSD.error_code = SDC_ERROR_CARD_LOCKED;
			}
		else
			{
			CSD.error_code = 0;
			return 1;
			}
		}
	else
		CSD.error_code = SDC_ERROR_INIT_FAILED;
   	}
else
   	CSD.error_code = SDC_ERROR_NO_CARD;
#ifdef SDCARD_DEBUG
if(sdc_debug_flag & SDCARD_DEBUG_BIT)
	printf("sdc_status_detect: %x\n\r", CSD.error_code);
#endif
return 0;
}



// ************************************************************************************************
/// \brief		sends a command to start the operation.
/// \note		All sd card commands are 6 bytes long and separated into several
///				classes with different response token. A detailed description
///				about the command classes as well as the corresponding response
///				format are located in the header file (sdcard.h).
/// @param[in]	cmd		-	sd card command
///	@param[in]	arg		-	command argument
/// @param[in]	res_len	-	length of the response token
///	@param[in]	opt
///						-	0: for additional wait cycles (NUM_WAIT_CYC_AOP) <br>
///						-	1: without
/// @return		response token
// ************************************************************************************************
unsigned int sdc_send_cmd(unsigned char cmd, unsigned long arg, unsigned int res_len, unsigned char opt)
{
unsigned char cmd_res[SDC_CMD_LEN], cyc[SDC_NUM_WAIT_CYC_AOP];
unsigned int res_token = 0;

cmd_res[0] = SDC_START_BIT | cmd;			   			// set start bit and command
sdc_clitc(&cmd_res[1], arg);				  			// set argument
cmd_res[5] = SDC_STOP_BIT;                          	// set stop bit
#ifdef SDC_CMD_CRC_ENABLE
	cmd_res[5] |= crc7_calc( cmd_res, SDC_CMD_LEN);			// set 7 bit CRC value
#else
	cmd_res[5] |= 0x94;										// set crc default value
#endif    //#ifdef CMD_CRC_ENABLE
if (sdc_debug_flag & SDCARD_CMD_DEBUG_BIT)
	debug_display_mem_hex(cmd_res, SDC_CMD_LEN, SDC_CMD_LEN + 1);
SDC_CHIP_SELECT_LOW;
sdc_data_exchange_spi( cmd_res, SDC_CMD_LEN, 0 );		// send sd card command
sdc_data_exchange_spi( cmd_res, res_len, 1 );			// read answer (response token)
if( opt == 0 )
	sdc_data_exchange_spi( cyc,SDC_NUM_WAIT_CYC_AOP, 3 );	// wait cycles
SDC_CHIP_SELECT_HIGH;
#ifdef SDCARD_DEBUG
if (sdc_debug_flag & SDCARD_CMD_DEBUG_BIT)
	{
	printf("CMD%d: RES%d:", cmd, res_len);				// display command number and response token (terminal)
	debug_display_mem_hex(cmd_res, res_len, res_len + 1);
	}
#endif // #ifdef SDCARD_DEBUG
// response format ?
if( res_len == SDC_R2_LEN ) res_token = cmd_res[1];	    // R2: 2 bytes long; all other 1 byte
return (res_token << 8) | cmd_res[0];					// response token
}



// ************************************************************************************************
/// \brief		reads a single data block.
///	\note		The function can read either one single byte or one data block with
///				a max length limited by the block size e.g. 512 byte. The 32 bit
///				data address has a valid range from 0 up to the max memory capacity.
///				The maximum block length is applied to the data address, because
///				every single read operation is related to a physical block section.
/// @param[in]	addr	-	data address
///	@param[in]	*buff	-	pointer to array
/// @param[in]	len		-	array length
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char sdc_read_single_block(unsigned long addr, unsigned char *buff, unsigned int block_len)
{
unsigned char crc[2], cyc[SDC_NUM_WAIT_CYC_AOP];
static unsigned int length;
unsigned int temp;

if(!sdc_status_detect(1))
   	return 0;
// max. block length applied to the data adrress
if( block_len <= (CSD.block_size - (addr % CSD.block_size)) && (addr < CSD.memory_capacity))
    {
	// set data block length
	if( length != block_len )
		sdc_send_cmd( SDC_SET_BLOCKLEN, block_len, SDC_R1_LEN, 0 );	// block length changed
	length = block_len;

    // set single data block operation
    sdc_send_cmd( SDC_READ_SINGLE_BLOCK, addr, SDC_R1_LEN, 0 );
	SDC_CHIP_SELECT_LOW;
	sdc_data_exchange_spi( buff, block_len, 1 );			// read data block
	sdc_data_exchange_spi( crc, 2, 3 );						// read crc
	sdc_data_exchange_spi( cyc, SDC_NUM_WAIT_CYC_AOP, 3 );	// wait cycles
	SDC_CHIP_SELECT_HIGH;
	temp = sdc_crc16_calc(buff, block_len, crc );				// crc check
	if(!temp )
		{
		#ifdef SDCARD_DEBUG
		if (sdc_debug_flag & SDCARD_DEBUG_BIT)
			printf("CRC16: OKAY\n\r");
		#endif		// #ifdef SDCARD_DEBUG
		CSD.error_code = 0;
		return 1;				// success
		}
	else
		{
		// crc16 error
		#ifdef SDCARD_DEBUG
		if (sdc_debug_flag & SDCARD_DEBUG_BIT)
			{
			printf("CRC16: ERROR = [0x%x 0x%x]\n\r", crc[1], crc[0] );
			printf("Status Register: %u\n\r", sdc_send_cmd( SDC_SEND_STATUS, 0, SDC_R2_LEN, 0 ));
			}
		#endif		// #ifdef SDCARD_DEBUG
		CSD.error_code = SDC_ERROR_READ_CRC16;
		}
    }
else
   	CSD.error_code = SDC_ERROR_WRONG_ADDRESS;
return 0;	// error
}



// ************************************************************************************************
/// \brief		reads data from the sd card continuously.
/// @param[in]	addr	-	data address [range: 0...(CSD.memory_capacity-1)]
///	@param[in]	*buff	-	pointer to array
/// @param[in]	len		-	array length [range: 1...65535]
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char sdc_read_data(unsigned long addr, unsigned char *buff, unsigned int len)
{
unsigned long blocks;
unsigned int block_size;
/*
 * Init the following local variables and the 'len' parameter above as 'long'
 * to allow reading more than 65535 bytes.
 */
unsigned int block_len, offset = 0;

block_size = sdc_get_block_size();		// set block size
while( len != 0 )
	{
	// block length refered to the physical block size
	block_len = (block_size - (addr % block_size));
	if((block_len >= len) || ((addr % block_size) != 0))
		{
		if(block_len > len) block_len = len;
		if( !sdc_read_single_block( addr, &buff[offset], block_len ) )
			return 0;	// error occured
		}
	else if((blocks = (len / block_size)) != 0)
		{
		block_len = blocks*block_size;
		if(!sdc_read_multiple_blocks((addr / block_size) , &buff[offset], blocks ))
			return 0;	// error occured
		}
	offset += block_len;				// update parameter
	addr += block_len;
	len -= block_len;
}
return 1;								// success
}



// ************************************************************************************************
/// \brief		writes data to the sd card continuously.
/// @param[in]	addr	-	data address [range: 0...(CSD.memory_capacity-1)]
///	@param[in]	*buff	-	pointer to array
/// @param[in]	len		-	array length [range: 1...65535]
/// @retval		1	-	success <br>
/// @retval		0	-	error
// ************************************************************************************************
unsigned char sdc_write_data(unsigned long addr, unsigned char *buff, unsigned int len)
{
unsigned long blocks;
unsigned int block_size, count;
unsigned char temp[512];
/*
 * Init the following local variables and the 'len' parameter above as 'long'
 * to allow writing more than 65535 bytes.
 */
unsigned int block_len, offset = 0;

block_size = sdc_get_block_size();				// set block size
while( len != 0 )
	{
	// block length refered to the physical block size
	block_len = (block_size - (addr % block_size));
	if((block_len >= len) || ((addr % block_size) != 0))
		{
		if(block_len > len) block_len = len;

		if( block_len == block_size)
			{
			if(!sdc_write_single_block((addr / block_size), buff))		// write
				return 0;
			}
		else if(sdc_read_single_block(sdc_get_addr_block(addr / block_size), temp, block_size ))	// read
			{
			for( count = 0; count < block_len; count ++ )
				temp[count+(addr % block_size)] = buff[offset+count];
			if(!sdc_write_single_block((addr / block_size), temp))		// write
				return 0;
			}
		else return 0;	// error occured
		}
	else if((blocks = (len / block_size)) != 0)
		{
		block_len = blocks*block_size;
		if(!sdc_write_multiple_blocks((addr / block_size) , &buff[offset], blocks ))
			return 0;	// error occured
		}
	offset += block_len;		// update parameter
	addr += block_len;
	len -= block_len;
}
return 1;						// success
}



// ************************************************************************************************
/// \brief		reads multiple data blocks.
/// @param[in]	block		-	first block [range: 0...(CSD.max_blocks-1)]
///	@param[in]	*buff		-	pointer to array
/// @param[in]	num_blocks	-	number of blocks to be read at once [range: 1...65535]
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char sdc_read_multiple_blocks(unsigned long block, unsigned char *buff, unsigned int num_blocks)
{
unsigned long offset = 0;
unsigned int temp = 0;
unsigned char crc[2], cyc[SDC_NUM_WAIT_CYC_AOP];

if(!sdc_status_detect(1))
	return 0;
// max. block range ?
if(((block + num_blocks) < CSD.max_blocks) && (num_blocks > 0))
    {
	// set data block length
	sdc_send_cmd( SDC_SET_BLOCKLEN, CSD.block_size, SDC_R1_LEN, 0 );
	// set multiple data block operation
	sdc_send_cmd( SDC_READ_MULTIPLE_BLOCK, sdc_get_addr_block(block), SDC_R1_LEN, 1 );

	while( num_blocks-- != 0 )
		{
		SDC_CHIP_SELECT_LOW;
		sdc_data_exchange_spi( &buff[offset], CSD.block_size, 1 );	// read data block
		sdc_data_exchange_spi( crc, 2, 3 );							// read crc
		sdc_data_exchange_spi( cyc, SDC_NUM_WAIT_CYC_AOP, 3 );			// wait cycles
		SDC_CHIP_SELECT_HIGH;
		temp = sdc_crc16_calc( &buff[offset], CSD.block_size, crc );		// crc check
	    offset += CSD.block_size;                           	// update array position
		if( !temp )
			{
			#ifdef SDCARD_DEBUG
			if (sdc_debug_flag & SDCARD_DEBUG_BIT)
				printf("CRC16: OKAY\n\r");
			#endif 		// #ifdef SDCARD_DEBUG
			}
		else
			{
			// crc16 error
			#ifdef SDCARD_DEBUG
			if (sdc_debug_flag & SDCARD_DEBUG_BIT)
				printf("CRC16: ERROR = [0x%x 0x%x]\n\r", crc[1], crc[0] );
			#endif		// #ifdef SDCARD_DEBUG
			CSD.error_code = SDC_ERROR_READ_CRC16;
			return 0;
			}
        }
	// stop multiple data block operation
	sdc_send_cmd( SDC_STOP_TRANSMISSION, 0, SDC_R1_LEN, 0 );
	CSD.error_code = 0;
	return 1;
    }
CSD.error_code = SDC_ERROR_WRONG_ADDRESS;
return 0;
}



// ************************************************************************************************
/// \brief		writes a single data block.
/// @param[in]	block		-	block number [range: 0...(CSD.max_blocks-1)]
///	@param[in]	*buff		-	pointer to array
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char sdc_write_single_block(unsigned long block, unsigned char *buff)
{
unsigned char temp = SDC_START_SINGLE_BLOCK;
unsigned char crc[2], busy[2];

if(!sdc_status_detect(0))
	return 0;
if((block < CSD.max_blocks))
	{
	// set data block length
	sdc_send_cmd( SDC_SET_BLOCKLEN, CSD.block_size, SDC_R1_LEN, 0 );
	// set single write block operation
	sdc_send_cmd( SDC_WRITE_BLOCK, sdc_get_addr_block(block), SDC_R1_LEN, 0 );
	crc[0] = crc[1] = 0;
	sdc_crc16_calc( buff, CSD.block_size, crc ); 		// crc calc
	SDC_CHIP_SELECT_LOW;
	sdc_data_exchange_spi( &temp, 1, 0 );				// send start byte
	sdc_data_exchange_spi( buff, CSD.block_size, 0 );	// write data block
	sdc_data_exchange_spi( crc, 2, 0 );					// write crc
	sdc_data_exchange_spi( busy, 2, 2 );				// read data token
	SDC_CHIP_SELECT_HIGH;
	busy[0] &= 0x1F;								// received data token
	if(busy[0] == SDC_DATA_BLOCK_ACCEPTED)
		{
		#ifdef SDCARD_DEBUG
		if (sdc_debug_flag & SDCARD_DEBUG_BIT)
			printf("DATA ACCEPTED\n\r");
		#endif		// #ifdef SDCARD_DEBUG
		CSD.error_code = 0;
		return 1;	// success
		}
	else
		{
		// data rejected
		#ifdef SDCARD_DEBUG
		if (sdc_debug_flag & SDCARD_DEBUG_BIT)
			{
			printf("DATA REJECTED: %x\n\r", busy[0] );
			printf("STATUS REGISTER: %x\n\r", sdc_send_cmd( SDC_SEND_STATUS, 0, SDC_R2_LEN, 0 ) );
			}
		#endif 		// #ifdef SDCARD_DEBUG
		if( busy[0] == SDC_BLOCK_ERROR_WRITE )
			CSD.error_code = SDC_ERROR_WRITE_CARD;
		else if( busy[0] == SDC_BLOCK_ERROR_CRC )
			CSD.error_code = SDC_ERROR_WRITE_CRC16;
		else
			CSD.error_code = SDC_ERROR_DATA_REJECTED;
		}
    }
else
   	CSD.error_code = SDC_ERROR_WRONG_ADDRESS;
return 0;	// error
}



// ************************************************************************************************
/// \brief		writes multiple data blocks.
/// @param[in]	block		-	first write block [range: 0...(CSD.max_blocks-1)]
///	@param[in]	*buff		-	pointer to array
/// @param[in]	num_blocks	-	number of blocks [range: 1...65535]
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char sdc_write_multiple_blocks(unsigned long block, unsigned char *buff, unsigned int num_blocks)
{
unsigned long offset = 0;
unsigned char temp = SDC_START_MULTIPLE_BLOCK;
unsigned char crc[2], busy[2];

if(!sdc_status_detect(0))
	return 0;
if(((block + num_blocks) < CSD.max_blocks) && (num_blocks > 0))
	{
	// faster multiple block write operation ?
	if( num_blocks >= 3 )	// NOTE: it's not a valid cmd for mmc
		{
		// set application specific command
		sdc_send_cmd( SDC_APP_CMD, 0xFFFFFFFF, SDC_R1_LEN, 0 );
		// set the number of blocks to be pre-erased befor writing
		sdc_send_cmd( SDC_SET_WR_BLK_ERASE_COUNT, num_blocks, SDC_R1_LEN, 0 );
		}
	// set multiple write block operation
	sdc_send_cmd( SDC_WRITE_MULTIPLE_BLOCK, sdc_get_addr_block(block), SDC_R1_LEN, 0 );
   	while( num_blocks-- != 0 )
		{
		crc[0] = crc[1] = 0;
		sdc_crc16_calc(&buff[offset], CSD.block_size, crc );		// crc calc
		SDC_CHIP_SELECT_LOW;
		sdc_data_exchange_spi( &temp, 1, 0 );						// send start byte
		sdc_data_exchange_spi( &buff[offset], CSD.block_size, 0 );	// write data block
		sdc_data_exchange_spi( crc, 2, 0 );							// write crc
		sdc_data_exchange_spi( busy, 2, 2 );						// read data token
		if( num_blocks == 0 )
			{
			temp = SDC_STOP_MULT_BLOCK_WRITE;
			sdc_data_exchange_spi( &temp, 1, 0 );				// send stop byte
			sdc_data_exchange_spi( crc, 2, 2 );					// busy (wait for response)
			}
		SDC_CHIP_SELECT_HIGH;
   		offset += CSD.block_size;                       	// update array position
   		busy[0] &= 0x1F;									// received data token
		if( busy[0] != SDC_DATA_BLOCK_ACCEPTED)
			{
			// data rejected
			sdc_send_cmd( SDC_STOP_TRANSMISSION, 0, SDC_R1_LEN, 0 );		// abort transmission
			#ifdef SDCARD_DEBUG
			if (sdc_debug_flag & SDCARD_DEBUG_BIT)
				{
				printf("DATA REJECTED: %x\n\r", busy[0]);
				printf("STATUS REGISTER: %x\n\r", sdc_send_cmd( SDC_SEND_STATUS, 0, SDC_R2_LEN, 0 ) );
				}
			#endif		// #ifdef SDCARD_DEBUG
			if( busy[0] == SDC_BLOCK_ERROR_WRITE )
				CSD.error_code = SDC_ERROR_WRITE_CARD;
			else if( busy[0] == SDC_BLOCK_ERROR_CRC )
				CSD.error_code = SDC_ERROR_WRITE_CRC16;
			else
				CSD.error_code = SDC_ERROR_DATA_REJECTED;
			// use ACMD22 to find the number of well written blocks
			return 0;	// error
			}
		#ifdef SDCARD_DEBUG
		else
			{
			if (sdc_debug_flag & SDCARD_DEBUG_BIT)
				printf("DATA ACCEPTED\n\r", busy[0]);;
			}
		#endif 		// #ifdef SDCARD_DEBUG
		}
	CSD.error_code = 0;
	return 1;		// success
	}
CSD.error_code = SDC_ERROR_WRONG_ADDRESS;
return 0;	// error
}



// ************************************************************************************************
/// \brief		erases a certain number of sectors.
/// @param[in]	block		-	first block of the sector
///								[range: 0...(CSD.max_blocks-(CSD.sector_size*num_sector-1))]
//								MMC->[range: 0...(CSD.max_blocks-(CSD.erase_grp_size*num_sector-1))]
/// @param[in]	num_sectors	-	number of sectors [range: 1...65535]
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char sdc_erase_sector(unsigned long first_block, unsigned int num_sector)
{
unsigned char busy[2], cyc[SDC_NUM_WAIT_CYC_AOP];
unsigned int temp;

if(!sdc_status_detect(0))
	return 0;
if(sdc_get_mmc_flag()) //if mmc eraseable group size
	{
	temp=num_sector*CSD.erase_grp_size;
	}
else
	temp=num_sector*CSD.sector_size;
if((first_block + temp) < CSD.max_blocks)
	{
   	// set the address of the first block to be erased
	if(!sdc_send_cmd( SDC_ERASE_WR_BLK_START_ADDR, sdc_get_addr_block(first_block), SDC_R1_LEN, 0 ))
		{
		// set the address of the last block to be erased
		if(!sdc_send_cmd( SDC_ERASE_WR_BLK_END_ADDR, sdc_get_addr_block((temp) + first_block), SDC_R1_LEN, 0 ))
			{
			sdc_send_cmd( SDC_ERASE_SELECTED_BLOCK, 0, SDC_R1_LEN, 1 );
			SDC_CHIP_SELECT_LOW;
			sdc_data_exchange_spi( busy, 2, 2 );				// poll busy
			sdc_data_exchange_spi( cyc, SDC_NUM_WAIT_CYC_AOP, 3 );		// wait cycles
			SDC_CHIP_SELECT_HIGH;
			CSD.error_code = 0;
			return 1;		// success
			}
		}
		CSD.error_code = SDC_ERROR_ERASE_SECTOR;
}
else
	CSD.error_code = SDC_ERROR_ADDR_SECTOR;
return 0;
}



// ************************************************************************************************
/// @name Write protection & MMC ?!
/// \note I have not tested the following functions by myself (done by Hubert Nestler as project work).
//@{
// ************************************************************************************************
/// \brief		clears the write protection for a number of wp-groups.
/// @param[in]	first_block		-	first block of the sector
///								[range: 0...(CSD.max_blocks-(CSD.wp_grp_size*num_sector-1))]
/// @param[in]	num_groups	-	number of sectors [range: 1...65535]
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char sdc_clear_wp(unsigned long first_block, unsigned int num_groups)
{
unsigned char busy[2], cyc[SDC_NUM_WAIT_CYC_AOP];

if(!sdc_status_detect(0))
	return 0;

if((first_block + num_groups*CSD.wp_grp_size) < CSD.max_blocks)
{
   	// set the address of the first block to be erased
	if(!sdc_send_cmd( SDC_ERASE_WR_BLK_START_ADDR, sdc_get_addr_block(first_block), SDC_R1_LEN, 0 ))
		{
		// set the address of the last block to be erased
		if(!sdc_send_cmd( SDC_ERASE_WR_BLK_END_ADDR, sdc_get_addr_block((num_groups*CSD.wp_grp_size) + first_block), SDC_R1_LEN, 0 ))
			{
			sdc_send_cmd( SDC_CLR_WRITE_PROT, 0, SDC_R1_LEN, 1 );
			SDC_CHIP_SELECT_LOW;
			sdc_data_exchange_spi( busy, 2, 2 );				// poll busy
			sdc_data_exchange_spi( cyc, SDC_NUM_WAIT_CYC_AOP, 3 );		// wait cycles
			SDC_CHIP_SELECT_HIGH;
			CSD.error_code = 0;
			return 1;		// success
			}
		}
		CSD.error_code = SDC_ERROR_ERASE_SECTOR;
}
else
	CSD.error_code = SDC_ERROR_ADDR_SECTOR;
return 0;
}



// ************************************************************************************************
/// \brief		sets the write protection for a number of WP-groups.
/// @param[in]	first_block		-	first block of the sector
///								[range: 0...(CSD.max_blocks-(CSD.wp_grp_size*num_sector-1))]
/// @param[in]	num_groups	-	number of sectors [range: 1...65535]
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char sdc_set_wp(unsigned long first_block, unsigned int num_groups)
{
unsigned char busy[2], cyc[SDC_NUM_WAIT_CYC_AOP];

if(!sdc_status_detect(0))
	return 0;
if((first_block + num_groups*CSD.wp_grp_size) < CSD.max_blocks)
	{
   	// set the address of the first block to be erased
	if(!sdc_send_cmd( SDC_ERASE_WR_BLK_START_ADDR, sdc_get_addr_block(first_block), SDC_R1_LEN, 0 ))
		{
		// set the address of the last block to be erased
		if(!sdc_send_cmd( SDC_ERASE_WR_BLK_END_ADDR, sdc_get_addr_block((num_groups*CSD.wp_grp_size) + first_block), SDC_R1_LEN, 0 ))
			{
			sdc_send_cmd( SDC_SET_WRITE_PROT, 0, SDC_R1_LEN, 1 );
			SDC_CHIP_SELECT_LOW;
			sdc_data_exchange_spi(busy, 2, 2 );				// poll busy
			sdc_data_exchange_spi(cyc, SDC_NUM_WAIT_CYC_AOP, 3 );		// wait cycles
			SDC_CHIP_SELECT_HIGH;
			CSD.error_code = 0;
			return 1;		// success
			}
		}
		CSD.error_code = SDC_ERROR_ERASE_SECTOR;
	}
else
	CSD.error_code = SDC_ERROR_ADDR_SECTOR;
return 0;
}



// ************************************************************************************************
/// \brief		reads the write protection status bits of next 32 wp-groups.
///				1=write protected, 0=not protected
/// @param[in]	addr	-	data address
///	@param[out]	*buff	-	pointer to array [4 byte]
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char sdc_get_wp_status(unsigned long addr, unsigned char *buff)
{
unsigned char crc[2], cyc[SDC_NUM_WAIT_CYC_AOP];
static unsigned int length;
unsigned long temp;

if(!sdc_status_detect(1))
   	return 0;
// max. block length applied to the data adrress
if( addr<CSD.max_blocks-(unsigned int)(32*CSD.wp_grp_size))
    {
	// set single data block operation
    sdc_send_cmd( SDC_SEND_WRITE_PROT, addr, SDC_R1_LEN, 0 );
	SDC_CHIP_SELECT_LOW;
	sdc_data_exchange_spi( buff, 4, 1 );					// read 32 wp-status bits
	sdc_data_exchange_spi( crc, 2, 3 );						// read crc
	sdc_data_exchange_spi( cyc, SDC_NUM_WAIT_CYC_AOP, 3 );		// wait cycles
	SDC_CHIP_SELECT_HIGH;
	temp = sdc_crc16_calc( buff, 32, crc );						// crc check
	if( !temp )
		{
		#ifdef SDCARD_DEBUG
		if (sdc_debug_flag & SDCARD_DEBUG_BIT)
			printf("CRC16: OKAY\n\r");
		#endif 		// #ifdef SDCARD_DEBUG
		CSD.error_code = 0;
		return 1;				// success
		}
	else
		{
		// crc16 error
		#ifdef SDCARD_DEBUG
		if (sdc_debug_flag & SDCARD_DEBUG_BIT)
			{
			printf("CRC16: ERROR = [0x%x 0x%x]\n\r", crc[1], crc[0] );
			printf("Status Register: %u\n\r", sdc_send_cmd( SDC_SEND_STATUS, 0, SDC_R2_LEN, 0 ));
			}
		#endif 		// #ifdef SDCARD_DEBUG
		CSD.error_code = SDC_ERROR_READ_CRC16;
		}
    }
else
   	CSD.error_code = SDC_ERROR_WRONG_ADDRESS;
return 0;	// error
}



// ************************************************************************************************
/// \brief		returns the start address of the wp group.
/// @return		32 bit address value
// ************************************************************************************************
unsigned long sdc_get_group_addr(unsigned long group)
{
return CSD.wp_grp_size*group;
}



// ************************************************************************************************
/// \brief		returns the mmc flag.
/// @return		CSD.mmc	-	mmc flag
// ************************************************************************************************
unsigned char sdc_get_mmc_flag(void)
{
return CSD.mmc;
}



// ************************************************************************************************
/// \brief		returns the write protection flag.
/// @return		CSD.wp_grp_enable	-	write protection flag
// ************************************************************************************************
unsigned char sdc_get_wp_grp_enable(void)
{
return CSD.wp_grp_enable;
}
//@}


// ************************************************************************************************
/// \brief		returns the number of well-written blocks.
/// @return		number of well-written blocks (32 bit), otherwise 0
// ************************************************************************************************
unsigned long sdc_get_numwr_blocks(void)
{
unsigned char buff[4], crc[2], cyc[SDC_NUM_WAIT_CYC_AOP];
unsigned int temp;

if(!sdc_status_detect(0))
	return 0;

if(!sdc_send_cmd( SDC_APP_CMD, 0xFFFFFFFF, SDC_R1_LEN, 0 ))
	{
   	if(!sdc_send_cmd( SDC_SEND_NUM_WR_BLOCKS, 0, SDC_R1_LEN, 1 ))
	   	{
	   	SDC_CHIP_SELECT_LOW;
		sdc_data_exchange_spi( buff, 4, 1 );				// read data block
		sdc_data_exchange_spi( crc, 2, 3 );					// read crc
		sdc_data_exchange_spi( cyc, SDC_NUM_WAIT_CYC_AOP, 3 );	// wait cycles
		SDC_CHIP_SELECT_HIGH;
		temp = sdc_crc16_calc( buff, 4, crc );						// crc check
		if( !temp )
			{
			#ifdef SDCARD_DEBUG
			if (sdc_debug_flag & SDCARD_DEBUG_BIT)
				printf("CRC16: OKAY\n\r");
			#endif 		// #ifdef SDCARD_DEBUG
			CSD.error_code = 0;
			return sdc_cctli(buff);			// success
			}
		else
			{
			// crc16 error
			#ifdef SDCARD_DEBUG
			if (sdc_debug_flag & SDCARD_DEBUG_BIT)
				{
				printf("CRC16: ERROR = [0x%x 0x%x]\n\r", crc[1], crc[0] );
				printf("Status Register: %u\n\r", sdc_send_cmd( SDC_SEND_STATUS, 0, SDC_R2_LEN, 0 ));
				}
			#endif		// #ifdef SDCARD_DEBUG
			CSD.error_code = SDC_ERROR_READ_CRC16;
			}
		}
	}
return 0;
}



// ************************************************************************************************
/// \brief		returns the status register.
/// @return		response format R2
// ************************************************************************************************
unsigned int sdc_get_status_reg(void)
{
if(!sdc_status_detect(1))
	return 0;
return sdc_send_cmd( SDC_SEND_STATUS, 0, SDC_R2_LEN, 0 );
}



// ************************************************************************************************
/// \brief		returns the code of the last error message.
/// @return		CSD.error_code	-	refer to sdcard.h for detailed information
// ************************************************************************************************
unsigned char sdc_get_error_code(void)
{
return CSD.error_code;
}



// ************************************************************************************************
/// \brief		reads the card identification data (CID) register.
/// @param[in]	*buff	-	pointer to array (supposed to be 16 bytes long)
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char sdc_read_CID_Reg(unsigned char *buff)
{
unsigned char crc[2], cyc[SDC_NUM_WAIT_CYC_AOP];

if(!sdc_status_detect(1))
	return 0;
// read CID register
if(!sdc_send_cmd( SDC_SEND_CID, 0, SDC_R1_LEN, 1 ))
	{
	SDC_CHIP_SELECT_LOW;
	sdc_data_exchange_spi( buff, 16, 1 );   				// read data block
	sdc_data_exchange_spi( crc, 2, 1 );    					// read crc value
	sdc_data_exchange_spi( cyc, SDC_NUM_WAIT_CYC_AOP, 3 );		// wait cycles
	SDC_CHIP_SELECT_HIGH;
	if( !sdc_crc16_calc( buff, 16, crc ) )		// crc check
		{
		#ifdef SDCARD_DEBUG
		if (sdc_debug_flag & SDCARD_DEBUG_BIT)
			printf("CRC16: OKAY\n\r");
		#endif		// #ifdef SDCARD_DEBUG
		CSD.error_code = 0;
		return 1;	// success
		}
	else
		{
		// crc16 error
		#ifdef SDCARD_DEBUG
		if (sdc_debug_flag & SDCARD_DEBUG_BIT)
			printf("CRC16: ERROR = [0x%x 0x%x]\n\r", crc[1], crc[0] );
		#endif		// #ifdef SDCARD_DEBUG
		CSD.error_code = SDC_ERROR_WRITE_CRC16;
		}
 	}
return 0;
}



// ************************************************************************************************
/// \brief		reads the card specific data (CSD) register.
/// @param[in]	*buff	-	pointer to array (supposed to be 16 bytes long)
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char sdc_read_CSD_Reg(unsigned char *buff)
{
unsigned char crc[2], cyc[SDC_NUM_WAIT_CYC_AOP];

if(!sdc_status_detect(1))
	return 0;
if(!sdc_send_cmd(SDC_SEND_CSD, 0, SDC_R1_LEN, 1 ))
	{
	SDC_CHIP_SELECT_LOW;
	sdc_data_exchange_spi( buff, 16, 1 );   			// read data block
	sdc_data_exchange_spi( crc, 2, 1 );    				// read crc value
	sdc_data_exchange_spi( cyc, SDC_NUM_WAIT_CYC_AOP, 3 );	// wait cycles
	SDC_CHIP_SELECT_HIGH;
	if( !sdc_crc16_calc( buff, 16, crc ) )		// crc check
		{
		#ifdef SDCARD_DEBUG
		if (sdc_debug_flag & SDCARD_DEBUG_BIT)
			printf("CRC16: OKAY\n\r");
		#endif		// #ifdef SDCARD_DEBUG
		CSD.error_code = 0;
		return 1;	// success
		}
	else
		{
		// crc16 error
		#ifdef SDCARD_DEBUG
		if (sdc_debug_flag & SDCARD_DEBUG_BIT)
			printf("CRC16: ERROR = [0x%x 0x%x]\n\r", crc[1], crc[0] );
		#endif		// #ifdef SDCARD_DEBUG
		CSD.error_code = SDC_ERROR_READ_CRC16;
		}
	}
return 0;
}



// ************************************************************************************************
/// \brief		reads the operating condition (OCR) register.
/// @param[in]	*buff	-	pointer to array (supposed to be 4 bytes long)
/// @retval		1	-	success
///	@retval		0	-	error
// ************************************************************************************************
unsigned char sdc_read_OCR_Reg(unsigned char *buff)
{
unsigned char cyc[SDC_NUM_WAIT_CYC_AOP];

if(!sdc_status_detect(1))
   	return 0;
if(!sdc_send_cmd(SDC_READ_OCR, 0, SDC_R1_LEN, 1 ))
	{
	SDC_CHIP_SELECT_LOW;
	sdc_data_exchange_spi( buff, SDC_R3_LEN - SDC_R1_LEN, 3 );   	 // read data block
	sdc_data_exchange_spi( cyc, SDC_NUM_WAIT_CYC_AOP, 3 );		 // wait cycles
	SDC_CHIP_SELECT_HIGH;
	CSD.error_code = 0;
	return 1;				// success
	}
return 0;
}



// ************************************************************************************************
/// \brief		converts long integer values into 4 byte char arrays.
/// @param[in]	*byte	-	pointer to array
/// @param[in]	value	-	32 bit value
// ************************************************************************************************
void sdc_clitc(unsigned char *byte, unsigned long value)
{
unsigned char i;

for( i = 4; i > 0; i -- )
	{
	byte[i-1] = value;
	value = value >> 8;
	}
}



// ************************************************************************************************
/// \brief		converts 4 byte char arrays into long integer values.
/// @param[in]	*byte	-	pointer to array
/// @return		value	-	32 bit value
// ************************************************************************************************
unsigned long sdc_cctli(unsigned char *byte)
{
unsigned long value = 0;
unsigned char i;

for( i = 0; i < 4; i ++ )
	value = ((value << 8) | byte[i]);
return value;
}



// ************************************************************************************************
/// \brief		calculates 16 bit crc values used for payload protection.
/// @param[in]	*buff 	- 	pointer to array
/// @param[in]	len		-	array length (max = 65535)
///	@param[out]	*p_crc	-   pointer to 2 bytes long crc array
/// @retval		crc		-	16 bit crc value: CRC[15...0]
// ************************************************************************************************
#pragma optsize-
unsigned int sdc_crc16_calc(unsigned char *buff, unsigned int len, unsigned char *p_crc)
{
unsigned int crc_calc = 0, crc_check = 0;

crc_check = p_crc[0];
crc_check = (crc_check << 8) | p_crc[1];
crc_calc = crc16_calculate(crc_calc, buff, len);
crc_calc ^= crc_check;
p_crc[1] = (unsigned char) crc_calc;
p_crc[0] = (unsigned char)(crc_calc >> 8);
return crc_calc;
}
#pragma optsize+



#ifdef SDC_CMD_CRC_ENABLE
// ************************************************************************************************
/// \brief		calculates 7 bit crc values used for command protection.
//				The 7 bit crc value is calculated as follows:
//					- generator polynomial: G(x) = x^7+x^3+x^0 = 0x89
//					- highest polynomial:	H(x) = x^7 = 0x80
//					- bit string:	M(x) = x^n+...+x^0 = buff[]
//			   		- equation:		CRC[6...0] = Remainder[(M(x)*H(x))/G(x)]
///	\note		Multiplying the bit string with the highest polynomial (M(x)*H(x)) means adding 7
///				bits too it. The pointer to an Nth byte long bit string array assumed to be N+1 bytes
///				long. In this case the unsigned char array passed trough the function needs one byte
///				more filled with zeros (bit0 of the additional byte will be ignored -> don't care).
//				1) Refer to example below: CRC calc/check
/// @param[in]	*buff 	- 	pointer to array
/// @param[in]	len		-	array length (max = 255)
/// @retval		crc		-	7 bit crc value: CRC[7...1]
// ************************************************************************************************
#pragma optsize-
unsigned char crc7_calc( unsigned char *buff, unsigned char len )
{
unsigned char crc, i, j;

i = 7;				// bit position
j = 0;				// array position
crc = 0;			// 7 bit crc value

while(!((j == len - 1) && (i == 0)) )		// crc7
	{
	if((crc = (crc << 1) | ((buff[j] >> i) & 1 )) & 0x80 ) crc ^= 0x89;
	if( i-- == 0 ){ j++; i = 7; }
	}
return crc << 1;	// shift left once
}
#pragma optsize+
/* 1) Example: crc7 for sd card command structure
unsigned char cmd[6], count;

	// clear byte array
	for( count = 0; count < 6; count ++ ) cmd[count] = 0;

	cmd[0] = START_BIT | GO_IDLE_STATE;		// set start bit and command (CMD0) -> 0x40

	// for other commands: cmd[1...4] = argument -> not necessary for CMD0

	// additional byte
	cmd[5] = STOP_BIT;						// set stop bit -> 0x01 (bit0 don't care for crc7 calc)

	// calc and set the crc7 value
	// crc calc for [0x40 0x00 0x00 0x00 0x00 (0x01)] gives 0x4A -> the func returns (0x4A << 1) = 0x94
	cmd[5] = crc7( cmd, 6);					// result for CMD0 with stop bit: cmd[5] -> 0x95

	// check crc7 value
	if( crc7( cmd, 6) != 0 ) printf("crc7 error: CMD%u\n\r", GO_IDLE_STATE);
	else ... // do something
 */
#endif      // #ifdef SDC_CMD_CRC_ENABLE


#endif	// #ifdef SDCARD_ENABLE