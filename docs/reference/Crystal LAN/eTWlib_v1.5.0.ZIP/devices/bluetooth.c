// ************************************************************************************************
///
/// \file 			bluetooth.c
/// \brief			Interfacing bluetooth module
///
/// \todo			Revise whole bluetooth module interface
/// \date	 		$LastChangedDate: 2007-03-06 08:50:49 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 591 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"		// Project configuration


#include <io.h>
#include <delay.h>
#ifdef WEB_DEBUG
#include "web_debug.h"
#endif
#ifdef WEB_DEBUG_BLUETOOTH
#include "bluetooth_debug.h"
#endif

#include "board.h"

#pragma regalloc-
#pragma regalloc+


//*********************************************************************************
// Description	: reset of Bluetooth-Interface
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
void bluetooth_reset(void)
{
RESET1_OUTPUT;	// /RES_BL
RESET1_L;		// /RES_BL
delay_ms(100);
RESET1_H;		// /RES_BL
}

//*********************************************************************************
// Description	: 
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
void bluetooth_at_command_flash(flash char* command)
{
while(*command!=0)
	uart1_putchar(*command++);
uart1_putchar(0x0D);	// CR
}


//*********************************************************************************
// Description	: 
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
void bluetooth_at_command_sram(char* command)
{
        while(*command!=0) uart1_putchar(*command++);
        uart1_putchar(0x0D);	// CR
}


//*********************************************************************************
// Description	: function to handle modem-receive
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
void bluetooth_receive_data(unsigned char data)
{
#ifdef WEB_DEBUG_BLUETOOTH
bluetooth_debug_data(data);
#endif
}
