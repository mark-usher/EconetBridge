// ************************************************************************************************
///
/// \file 			cs8900_debug.c
/// \brief			Debug functions for cs8900.c
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// \par History
///					1.) 08.08.2003 Version 2.00
///					2.) 26.08.2003 Version 2.01
///						a.)	- new function "cs8900_debug_do_cmd", see also web_debug.c 
///					3.) 01.06.2004 Version 2.04
///						a.)	- 2 new debug-commands:  
///								"cs8900-reg" - displays all PacketPage-Register
///								"cs8900-stat" - displays the Miss- and Collision-Register
///					--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef CS8900_DEBUG

#include <stdlib.h>
#include <stdio.h>
#include "cs8900.h"
#include "cs8900_debug.h"
#include "debug.h"

eeprom unsigned char cs8900_debug_flag = 0x00;	// default: debug output off


// prototypes
void cs8900_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);


// ************************************************************************************************
/// \brief	    Registers CS8900 debug handler with debug framework
///
// ************************************************************************************************
void cs8900_debug_init(void)
{
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &cs8900_debug_handler;
p_struct.id_string = "cs8900";
debug_register_handler(&p_struct);
}


//*********************************************************************************
// Description	: displays the ID and the Voltage of CS8900
// Input      	: none
// Output      	: none
// Indication	: none
//*********************************************************************************
void cs8900_debug_info(void)
{
unsigned int	ident_code_l, ident_code_h;

ident_code_h = cs8900_read_packetpage16_be(CS8900_PP_CHIP_ID);
ident_code_l = cs8900_read_packetpage16_be(CS8900_PP_CHIP_ID+2);
printf("CS8900A-Rev ");
switch(ident_code_l & 0x1f)
	{
	case 0x7: printf("B"); break; 
	case 0x8: printf("C"); break;
	case 0x9: printf("D"); break;
	case 0xa: printf("E"); break;
	default:  printf("unknown");
	} 
printf(" (0x%04x%04x); ", ident_code_h, ident_code_l); 

ident_code_l = cs8900_read_packetpage16_le(CS8900_PP_SELF_ST); // read SelfST-Register-Address (Register 16)
if(ident_code_l & SELF_ST_33V_ACTIVE)
	putsf("3.3Volt\r"); 
else
	putsf("5.0Volt\r"); 
}


//*********************************************************************************
// Description	: write a pattern to all IO-Register of CS8900 and read back
// Input      	: none
// Output      	: none
// Indication	: none
//*********************************************************************************
void cs8900_debug_io_register(void)
{
unsigned char Lva;
unsigned int data0, data1;

putsf("Interface Test (All IO-Register)\r"); 
data0=0x01;
for(Lva=0;Lva<16;Lva++)
	{
	cs8900_write_io_reg16(IO_PORT_ADD, data0);
	data1=cs8900_read_io_reg16_le(IO_PORT_ADD);		// read back the ADD-PORT
	printf("%d) 0x%04x!=0x%04x\r\n", Lva, data0, data1); 
	data0<<=1;
	}
}


flash unsigned int packetpage_reg[60]={0x000, 0x002, 0x020, 0x022,
                                       0x024, 0x026, 0x028, 0x02a,
                                       0x02c, 0x02e, 0x030, 0x032,
                                       0x034, 0x036, 0x040, 0x042,
                                       0x050, 
                                       0x100, 0x102, 0x104, 0x106,
                                       0x108, 0x10a, 0x10c, 0x10e,
                                       0x110, 0x112, 0x114, 0x116,
                                       0x118, 0x11a, 0x11c, 0x11e,
                                       0x120, 0x122, 0x124, 0x126,
                                       0x128, 0x12a, 0x12c, 0x12e,
                                       0x130, 0x132, 0x134, 0x136,
                                       0x138, 0x13a, 0x13c, 0x13e,
                                       0x144, 0x146, 0x150, 0x152,
                                       0x154, 0x156, 0x158, 0x15a,
                                       0x15c, 0x400, 0x402};

//*********************************************************************************
// Description	: reads all PacketPage-Register of CS8900
// Input      	: none
// Output      	: none
// Indication	: none
//*********************************************************************************
void cs8900_debug_packetpage_reg(void)
{
unsigned char Lva;
unsigned int data;

putsf("All PacketPage-Register\r"); 
for(Lva=0; Lva<(sizeof(packetpage_reg)/2); Lva++)
	{
	data=cs8900_read_packetpage16_le(packetpage_reg[Lva]);
	printf("0x%03x=0x%04x ", packetpage_reg[Lva], data); 
	if((Lva>0)&&(((Lva+1) % 4)==0))
		putsf("\r"); 
	}
}

//*********************************************************************************
// Description	: reads and displays the miss and collision register
// Input      	: mode==0 - delete the miss and collision variables
//                mode!=0 - no action
// Output      	: none
// Indication	: none
//*********************************************************************************
void cs8900_debug_miss_collision(unsigned char mode)
{
static unsigned int collision_count=0;
static unsigned int miss_count=0;

miss_count+=cs8900_miss_counter();
printf("RX-Miss: %u\r\n", miss_count); 
collision_count+=cs8900_collision_counter();
printf("TX-Collision: %u\r\n", collision_count); 
if(mode==0)
	{
	miss_count=0;
	collision_count=0;
	}
}


// ************************************************************************************************
/// \brief	    command handler for debug commands
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void cs8900_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
unsigned int data;

if (mode == DEBUG_HANDLER_MODE_INFO)
	{
	cs8900_debug_info();
	putsf("DEVICE_CS8900\r");
	#ifdef CS8900_MEMORY
	putsf("CS8900_MEMORY\r");
	#endif
	#ifdef CS8900_IO_PORT8
	putsf("CS8900_IO_PORT8\r");
	#endif
	#ifdef CS8900_IO_PORT16
	putsf("CS8900_IO_PORT16\r");
	#endif
	#ifdef CS8900_I2C_HW_8
	putsf("CS8900_I2C_HW_8\r");
	#endif
	#ifdef CS8900_I2C_HW_16
	putsf("CS8900_I2C_HW_16\r");
	#endif
	#ifdef CS8900_I2C_SW_8
	putsf("CS8900_I2C_SW_8\r");
	#endif
	#ifdef CS8900_I2C_SW_16
	putsf("CS8900_I2C_SW_16\r");
	#endif
	printf("CS8900_DEBUG");
	if (cs8900_debug_flag)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
	}
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
    // add output for 'help' command here
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
    {
	if (strncmpf(command, "cs8900", 4)==0)
	    {
    	cs8900_debug_flag ^= 0xFF;
    	if (cs8900_debug_flag)
			putsf("CS8900_DEBUG ON\r");
		else
			putsf("CS8900_DEBUG OFF\r");
	    }
	}
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-info", 5)==0)
		{
		cs8900_debug_info();
		data=cs8900_read_packetpage16_le(CS8900_PP_TEST_CTL);
		printf("TestCTL.DisableLT=="); 
		if (data & DISABLE_LT)
			putsf("1\r"); 
		else
			putsf("0\r"); 
		data=cs8900_read_packetpage16_le(CS8900_PP_LINE_ST);
		printf("LineST.LinkOK=="); 
		if (data & LINK_OK)
			putsf("not failed(1)\r"); 
		else
			putsf("has failed(0)\r"); 
		printf("LineST.PolarityOK=="); 
		if (data & POLARITY_OK)
			putsf("correct(1)\r"); 
		else
			putsf("reversed(0)\r"); 
		data=cs8900_read_packetpage16_le(CS8900_PP_LINE_CTL);
		printf("LineCTL.PolarityDis=="); 
		if (data & POLARITY_DIS)
			putsf("not correct(1)\r"); 
		else
			putsf("is corrected(0)\r"); 
		}
	else if (strncmpf(command, "-test", 5)==0)
		cs8900_debug_io_register();
	else if (strncmpf(command, "-reg", 4)==0)
		cs8900_debug_packetpage_reg();
	else if (strncmpf(command, "-stat", 5)==0)
		{
		data=debug_get_int_parameter(command);
		cs8900_debug_miss_collision(data);
		}
	else if(strncmpf(command, "-prom", 5)==0)
		{
		data=cs8900_read_packetpage16_le(CS8900_PP_RX_CTL);
		data^=RX_PROM_ACCEPT;
		printf("RxCTL.PromiscuousA=="); 
		if(data & RX_PROM_ACCEPT)
			putsf("1\r"); 
		else
			putsf("0\r"); 
		cs8900_write_packetpage16(CS8900_PP_RX_CTL, data);
		}
	else if (strncmpf(command, "-fdx", 4)==0)
		{
		data=cs8900_read_packetpage16_le(CS8900_PP_TEST_CTL);
		data^=FDX_8900;
		printf("TestCTL.FDX=="); 
		if(data & FDX_8900)
			putsf("full duplex\r"); 
		else
			putsf("half-duplex\r"); 
		cs8900_write_packetpage16(CS8900_PP_TEST_CTL, data);
		}
	else if (strncmpf(command, "-link", 5)==0)
		{
		data=cs8900_read_packetpage16_le(CS8900_PP_TEST_CTL);
		data^=DISABLE_LT;
		printf("TestCTL.DisableLT=="); 
		if(data & DISABLE_LT)
			putsf("1\r"); 
		else
			putsf("0\r"); 
		cs8900_write_packetpage16(CS8900_PP_TEST_CTL, data);
		}
	else if (strncmpf(command, "-pol", 4)==0)
		{
		data=cs8900_read_packetpage16_le(CS8900_PP_LINE_CTL);
		data^=POLARITY_DIS;
		printf("LineCTL.PolarityDis=="); 
		if(data & POLARITY_DIS)
			putsf("not correct(1)\r"); 
		else
			putsf("is corrected(0)\r"); 
		cs8900_write_packetpage16(CS8900_PP_LINE_CTL, data);
		}
	else if (strncmpf(command, "-sleep", 6)==0)
		cs8900_software_sleep();
	else if (strncmpf(command, "-wakeup", 7)==0)
		cs8900_software_wakeup();
	}
}

#endif	// #ifdef CS8900_DEBUG
