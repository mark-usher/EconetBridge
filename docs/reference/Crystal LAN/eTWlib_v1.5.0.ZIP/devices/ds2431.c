// ************************************************************************************************
///
/// \file 			ds2431.c
/// \brief			Functions for DS2431 1wire eeprom
///
/// \date	 		$LastChangedDate: 2007-04-16 09:20:31 +0200 (Mo, 16 Apr 2007) $
/// \version 		$Rev: 665 $
///	\author  		Udo Jakobza, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#ifdef DS2431_ENABLE

#include "1wire_irq.h"
#include "ds2431.h"


// *********************************************************************************
/// \brief                  searches for ds2431 devices on the 1wire bus
/// \param[out] romcode     pointer to romcodes of all ds2431 devices found
/// \return                 number of ds2431 devices found
// *********************************************************************************
unsigned char ds2431_find(unsigned char *romcode_buffer)
{
unsigned char devices_1wire, ds2421_count=0;
unsigned char romcodes_1wire[BOARD_MAX_1WIRE_DEVICES,9];

#ifdef WIRE_IRQ		// controls the use of disable and enable of global IRQ
unsigned char sreg;
sreg=SREG;
#asm("cli");
#endif
devices_1wire=w1_search(0xf0, romcodes_1wire);	// search all 1Wire-Devices
if(devices_1wire>BOARD_MAX_1WIRE_DEVICES)
	devices_1wire = 0;		// return error (no devices found)
#ifdef WIRE_IRQ			    // controls the use of disable and enable of global IRQ
SREG=sreg;
#endif
while(devices_1wire--)
	{
	if(romcodes_1wire[ds2421_count,0]==DS2431_FAMILY_CODE)	// found DS2431
	    {
		if(romcode_buffer!=0)
			memcpy(romcode_buffer, &romcodes_1wire[ds2421_count,0], 9);
	    ds2421_count++;
        }
	}
return ds2421_count;
}


// *********************************************************************************
/// \brief                  selects a specific ds2431 device on the bus
/// \param[in] romcode      pointer to romcode of device to select
///                         (if NULL then only one 1 Wire device can be used)
/// \return                 0 - 1wire device not present; !=0 - 1wire device(s) found
// *********************************************************************************
unsigned char ds2431_select(unsigned char *romcode)
{
unsigned char i;
if(!W1_INIT()) return 0;
if(romcode)
   {
   W1_WRITE(0x55);
   for(i=0;i<8;i++) W1_WRITE(*romcode++);
   }
else return W1_WRITE(0xCC);
}


// *********************************************************************************
/// \brief                  read a block bytes from ds2431 memory
/// \param[in] romcode      pointer to romcode of device
/// \param[in] addr         start address for reading
/// \param[in] size         number of bytes to read
/// \param[out] dest        pointer to destination sram memory
/// \return                 0 - error; !=0 - success
// *********************************************************************************
unsigned char ds2431_read_eeprom(unsigned char *romcode, unsigned char *dest, unsigned char addr, unsigned char size)
{
// read EEPROM contents to scratchpad and
// read the scratchpad contents
if(!ds2431_select(romcode)) return 0;
W1_WRITE(0xF0);
if(!W1_WRITE(addr)) return 0;
if(!W1_WRITE(0x00)) return 0;
while(size--) *dest++=W1_READ();
return 1;
}


// *********************************************************************************
/// \brief                  write a block of bytes to ds2431 memory
/// \param[in] romcode      pointer to romcode of device
/// \param[in] addr         start address for writing (must be valid row boundary, lsb 000b)
/// \param[in] size         number of bytes to write 
/// \param[in] src          pointer to source sram memory
/// \return                 0 - error; !=0 - success
/// \remarks                if the last data row is smaller than DS2431_SCRATCHPAD_SIZE
///                         it will be padded with 0
// *********************************************************************************
unsigned char ds2431_write_eeprom(unsigned char *romcode, unsigned char *src, unsigned char addr, unsigned char size)
{
unsigned char buffer[DS2431_SCRATCHPAD_SIZE];
unsigned char i, e_s_byte, Lva;
                   
while(size)
    {
    // write new data to the scratchpad
    if(!ds2431_select(romcode)) return 0;
    W1_WRITE(0x0F);
    W1_WRITE(addr);
    W1_WRITE(0x00);     // high address byte always 0x00
    //for(i=0;i<size;i++) W1_WRITE(*p++);
    memset(buffer, 0, DS2431_SCRATCHPAD_SIZE);  
    if(size<DS2431_SCRATCHPAD_SIZE)
        Lva = size;
    else
        Lva = DS2431_SCRATCHPAD_SIZE;
    memcpy(buffer, src, Lva);
    size -= Lva;
    for(i=0;i<DS2431_SCRATCHPAD_SIZE;i++) 
        W1_WRITE(buffer[i]);
    // verify that the new data written in the scratchpad is correct
    if(!ds2431_select(romcode)) return 0;
    W1_WRITE(0xAA);
    if(W1_READ()!=addr) return 0;
    if(W1_READ()!=0x00) return 0;
    e_s_byte=W1_READ();
    if(addr<DS2431_REGISTER_ADD)
        for(i=0;i<DS2431_SCRATCHPAD_SIZE;i++)
            if(W1_READ()!=buffer[i]) return 0;
    #ifndef DS2431_PROG_ENABLE
    else
        return 0;
    #endif
    // copy the scratchpad to the EEPROM
    if(!ds2431_select(romcode)) return 0;
    W1_WRITE(0x55);
    W1_WRITE(addr);
    W1_WRITE(0x00);     // high address byte always 0x00
    W1_WRITE(e_s_byte);
    // wait for the write process to complete
    delay_ms(15);
    // read copy status
    if(W1_READ()!=0xAA) return 0;
    if(size==0) 
        return 1;
    else
        {
        addr += DS2431_SCRATCHPAD_SIZE;
        src += DS2431_SCRATCHPAD_SIZE;
        }
    }
return 0;
}
#endif   // DS2431_ENABLE
