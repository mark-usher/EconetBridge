// ************************************************************************************************
///
/// \file 			ds2408.c
/// \brief			DS2408 device driver
///
///					DS2408 is an 1-wire Port Expander
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Carsten K�gler, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#ifdef DS2408_ENABLE

#include "1wire_irq.h"
#include "ds2408.h"

#ifdef DS2408_BUFFER
signed int ds2408_buffer=-1;
#endif

// **********************************************************************************
/// \brief  	DS2408 Ausgaenge setzen (Channel Access Write)
/// @param[in]  data 8-Bit data
///
// **********************************************************************************
void ds2408_write_output(unsigned char data)
{
#ifdef DS2408_BUFFER
if (ds2408_buffer==data)
	return;
else
	ds2408_buffer = data;
#endif
// channel-access-write
if (W1_INIT())
    {
    W1_WRITE(SKIP_ROM);
    W1_WRITE(CAW);
    W1_WRITE(data);			// write byte to PIO
    W1_WRITE(~data);		// write inverted byte to PIO
    }
}


// **********************************************************************************
/// \brief  	Zustand der Ausgaenge des DS2408 einlesen  (Read PIO Register)
/// @return  	8-Bit Data Status
///
// **********************************************************************************
unsigned char ds2408_read_output(void)
{
#ifdef DS2408_BUFFER
return ds2408_buffer;
#else
if (W1_INIT())
    {
    W1_WRITE(SKIP_ROM);
    W1_WRITE(READ_PIO);
    W1_WRITE(OUT_LATCH_STATE);
    W1_WRITE(ADR_NULL);
    return W1_READ();	// read PIO Output Latch State Register
    }
return 0;
#endif
}


// **********************************************************************************
/// \brief  	DS2408 Eingaenge lesen (Channel Access Read)
/// @return  	8-Bit data
///
// **********************************************************************************
unsigned char ds2408_read_input(void)
{
if (W1_INIT())
    {
    W1_WRITE(SKIP_ROM);
    W1_WRITE(READ_PIO);
    W1_WRITE(LOGIC_STATE);
    W1_WRITE(ADR_NULL);
    return W1_READ();
    }
return 0;
}


// **********************************************************************************
/// \brief  	Mehrere Bit am DS2408 auf vorgegebenen Wert schreiben (setzen+l�schen)
/// @param[in] 	bitmask - Bitmaske f�r die Bits, die beeinflusst werden sollen
/// @param[in] 	value - neuer Wert f�r die Bits -> bitmask
// **********************************************************************************
void ds2408_write_bits(unsigned char bitmask, unsigned char value)
{
unsigned char pattern;

pattern = ds2408_read_output();
pattern &= ~bitmask;		// alten Wert l�schen
pattern |= value;			// neuen Wert einspielen
ds2408_write_output(pattern);
}


// **********************************************************************************
/// \brief  	Mehrere Bit am DS2408 setzen
/// @param[in] 	bitmask - Bitmaske f�r die Bits, die gesetzt werden sollen
///
// **********************************************************************************
void ds2408_set_bits(unsigned char bitmask)
{
unsigned char pattern;

pattern = ds2408_read_output();
pattern |= bitmask;
ds2408_write_output(pattern);
}


// **********************************************************************************
/// \brief  	Mehrere Bit am DS2408 l�schen
/// @param[in] 	bitmask - Bitmaske f�r die Bits, die gel�scht werden sollen
///
// **********************************************************************************
void ds2408_clear_bits(unsigned char bitmask)
{
unsigned char pattern;

pattern = ds2408_read_output();
pattern &= ~bitmask;
ds2408_write_output(pattern);
}

#endif	// #ifdef DS2408_ENABLE