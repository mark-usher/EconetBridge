// ************************************************************************************************
///
/// \file 			dataflash.h
///
/// \date	 		$LastChangedDate: 2007-01-15 12:56:42 +0100 (Mo, 15 Jan 2007) $
/// \version 		$Rev: 490 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _DATAFLASH_INCLUDED_
#define _DATAFLASH_INCLUDED_

#include "project.h"		// defines DATAFLASH_AT45DBxxx
#include "avr_spi.h"

//#define DATAFLASH_AT45DB011
//#define DATAFLASH_AT45DB021
//#define DATAFLASH_AT45DB041
//#define DATAFLASH_AT45DB081
//#define DATAFLASH_AT45DB161
//#define DATAFLASH_AT45DB321

#if !defined(DATAFLASH_AT45DB011)&&\
	!defined(DATAFLASH_AT45DB021)&&\
	!defined(DATAFLASH_AT45DB041)&&\
	!defined(DATAFLASH_AT45DB081)&&\
	!defined(DATAFLASH_AT45DB161)&&\
	!defined(DATAFLASH_AT45DB321)
#error ERROR: CS8900-INTERFACE (NO Dataflash available - use "#define DATAFLASH_AT45DBxxx") !!!
//#define DATAFLASH_AT45DB081
#endif

// --------------------------------------------------------------------------------
// See also Atmel Application Note AN-4 "Using Atmel�s Serial DataFlash" for details

// Maximum Bus Speed  : 20 MHz for AT45DB161B
//                      15 MHz for AT45DB161B (2.5V Version)

// only SPI mode 0 and 3 supported
// "The SPI operating mode determines the clock phase and polarity for 
// transmitting or receiving data. In other words, the mode  determines which edge 
// of the clock signal controls the direction of data transfer"
// SPI mode 0 : CPHA==0 CPOL==0
// SPI mode 3 : CPHA==1 CPOL==1
// CPHA and CPOL are bits in the SPI control register

// Virtual Continuous Write Buffer Operation -NOT- implemented
// -------------------------------------------------------------------------------- 


// --------------------------------------------------------------------------------
// Mode 0 == Inactive clock polarity low or high
// Mode 1 == SPI mode 0 or 3
// -------------------------------------------------------------------------------- 
#define DATAFLASH_READ_MODE      1


#if (DATAFLASH_READ_MODE==0)
   #define COMM_CONT_READ        0x68
   #define COMM_PAGE_READ        0x52
   #define COMM_READ_BUF_1       0x54
   #define COMM_READ_BUF_2       0x56
   #define COMM_STATUS_REG       0x57
#else
   #define COMM_CONT_READ        0xE8
   #define COMM_PAGE_READ        0xD2
   #define COMM_READ_BUF_1       0xD4
   #define COMM_READ_BUF_2       0xD6
   #define COMM_STATUS_REG       0xD7
#endif

typedef enum {FLASH_BUFFER1=0, FLASH_BUFFER2} FLASH_BUFFER_NUM;

// --------------------------------------------------------------------------------
// Chip-Select-Line
// -------------------------------------------------------------------------------- 
#define CS_FLASH_LOW			PORTB&=~0x01	// Flash-Chip-Select Low-Level
#define CS_FLASH_HIGH			PORTB|=0x01	// Flash-Chip-Select High-Level
#define CS_FLASH_PASSIV			DDRB&=~0x01	// Flash-Chip-Select Input-Level
#define CS_FLASH_ACTIV			DDRB|=0x01	// Flash-Chip-Select Output-Level

#define DATAFLASH_SPI_MODE	(SPCR_SPE | SPCR_MSTR | SPCR_4 | SPCR_CPOL | SPCR_CPHA)	// SCK=HIGH und steigende Flanke

// --------------------------------------------------------------------------------
// AT45DB011B-512 Pages x 264 byte
// -------------------------------------------------------------------------------- 
#ifdef DATAFLASH_AT45DB011
#define FLASH_PAGE_COUNT			512		// 0..511
#define FLASH_PAGE_SIZE				264
#define FLASH_SIZE_KBYTE			132

// set Page (9Bit) and Byte Address (9Bit)
#define ADR_P_B_1(page)				(unsigned char)(page>>7)				// 6 res.bits + 2 bits of 9-bit address
#define ADR_P_B_2(page, address)	(unsigned char)(page<<1)|(address>>8)	// 7 bit page-number and 1bit page-address
#define ADR_P_B_3(address)		    (unsigned char)address					// 8 bit page-address

// set Byte Address (9Bit)
#define ADR_B_1(address)   			(unsigned char)(address>>8)				// 7 don't care + Bit8 of address (1bit address)
#define ADR_B_2(address)			(unsigned char)(address)				// bit7 .. Bit0 of address (8bit address)

// set Page Address (9Bit)
#define ADR_P_1(page)				(unsigned char)(page>>7)				// 6 res.bits + 2 bits of 9-bit address
#define ADR_P_2(page)				((unsigned char)(page))<<1				// 7 bit of 9-bit address + 1 don't care
#endif


// --------------------------------------------------------------------------------
// AT45DB021B-1024 Pages x 264 byte
// -------------------------------------------------------------------------------- 
#ifdef DATAFLASH_AT45DB021
#define FLASH_PAGE_COUNT			1024		// 0..1023
#define FLASH_PAGE_SIZE				264
#define FLASH_SIZE_KBYTE			264

// set Page (9Bit) and Byte Address (10Bit)
#define ADR_P_B_1(page)				(unsigned char)(page>>7)				// 5 res.bits + 3 bits of 10-bit address
#define ADR_P_B_2(page, address)	(unsigned char)(page<<1)|(address>>8)	// 7 bit page-number and 1bit page-address
#define ADR_P_B_3(address)		    (unsigned char)address					// 8 bit page-address

// set Byte Address (9Bit)
#define ADR_B_1(address)   			(unsigned char)(address>>8)				// 7 don't care + Bit8 of address (1bit address)
#define ADR_B_2(address)			(unsigned char)(address)				// bit7 .. Bit0 of address (8bit address)

// set Page Address (10Bit)
#define ADR_P_1(page)				(unsigned char)(page>>7)				// 5 res.bits + 3 bits of 10-bit address
#define ADR_P_2(page)				((unsigned char)(page))<<1				// 7 bit of 10-bit address + 1 don't care
#endif

// --------------------------------------------------------------------------------
// AT45DB041B-2048 Pages x 264 byte
// -------------------------------------------------------------------------------- 
#ifdef DATAFLASH_AT45DB041
//#define FLASH_PAGE_COUNT			128	// 0..127
#define FLASH_PAGE_COUNT			2048	// 0..2047
#define FLASH_PAGE_SIZE				264
#define FLASH_SIZE_KBYTE			528

// Sector Addresses to handle the rewrite command to preserve data integrity
#define FLASH_SECTOR0_ADR			0x007	// 8 pages with 2112 bytes (2k + 64)
#define FLASH_SECTOR1_ADR			0x0ff	// 248 pages with 65472 bytes (62k +1984)
#define FLASH_SECTOR2_ADR			0x1ff	// 256 pages with 67584 bytes (64k +2k)
#define FLASH_SECTOR3_ADR			0x3ff	// 512 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR4_ADR			0x5ff	// 512 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR5_ADR			0x7ff	// 512 pages with 135168 bytes (128k +4k)

// set Page (11Bit) and Byte Address (9Bit)
#define ADR_P_B_1(page)				(unsigned char)(page>>7)				// 4 res.bits + 4 bits of 11-bit address
#define ADR_P_B_2(page, address)	(unsigned char)(page<<1)|(address>>8)	// 7 bit page-number and 1bit page-address
#define ADR_P_B_3(address)		    (unsigned char)address					// 8 bit page-address

// set Byte Address (9Bit)
#define ADR_B_1(address)   			(unsigned char)(address>>8)				// 7 don't care + Bit8 of address (1bit address)
#define ADR_B_2(address)			(unsigned char)(address)				// bit7 .. Bit0 of address (8bit address)

// set Page Address (11Bit)
#define ADR_P_1(page)				(unsigned char)(page>>7)				// 4 res.bits + 4 bits of 11-bit address
#define ADR_P_2(page)				((unsigned char)(page))<<1				// 7 bit of 11-bit address + 1 don't care
#endif


// --------------------------------------------------------------------------------
// AT45DB081B-4096 Pages x 264 byte
// -------------------------------------------------------------------------------- 
#ifdef DATAFLASH_AT45DB081
#define FLASH_PAGE_COUNT			4096	// 0..4095
#define FLASH_PAGE_SIZE				264
#define FLASH_SIZE_KBYTE			1056

// Sector Addresses to handle the rewrite command to preserve data integrity
#define FLASH_SECTOR0_ADR			0x007	// 8 pages with 2112 bytes (2k + 64)
#define FLASH_SECTOR1_ADR			0x0ff	// 248 pages with 65472 bytes (62k +1984)
#define FLASH_SECTOR2_ADR			0x1ff	// 256 pages with 67584 bytes (64k +2k)
#define FLASH_SECTOR3_ADR			0x3ff	// 512 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR4_ADR			0x5ff	// 512 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR5_ADR			0x7ff	// 512 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR6_ADR			0x9ff	// 512 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR7_ADR			0xbff	// 512 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR8_ADR			0xdff	// 512 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR9_ADR			0xfff	// 512 pages with 135168 bytes (128k +4k)

// set Page (12Bit) and Byte Address (9Bit)
#define ADR_P_B_1(page)				(unsigned char)(page>>7)				// 3 res.bits + 5 bits of 12-bit address
#define ADR_P_B_2(page, address)	(unsigned char)(page<<1)|(address>>8)	// 7 bit page-number and 1-bit Byte-address
#define ADR_P_B_3(address)		    (unsigned char)address					// 8 bit Byte-address

// set Byte Address (9Bit)
#define ADR_B_1(address)   			(unsigned char)(address>>8)				// 7 don't care + Bit8 of address (1bit address)
#define ADR_B_2(address)			(unsigned char)(address)				// bit7 .. Bit0 of address (8bit address)

// set Page Address (12Bit)
#define ADR_P_1(page)				(unsigned char)(page>>7)				// 3 res.bits + 5 bits of 12-bit address
#define ADR_P_2(page)				((unsigned char)(page))<<1				// 7 bit of 12-bit address + 1 don't care
#endif


// --------------------------------------------------------------------------------
// AT45DB161B-4096 Pages x 528 byte
// -------------------------------------------------------------------------------- 
#ifdef DATAFLASH_AT45DB161
#define FLASH_PAGE_COUNT			4096	// 0..4095
#define FLASH_PAGE_SIZE				528
#define FLASH_SIZE_KBYTE			2112

// Sector Addresses to handle the rewrite command to preserve data integrity
#define FLASH_SECTOR0_ADR			0x007	// 8 pages with 2112 bytes (4k + 128)
#define FLASH_SECTOR1_ADR			0x0ff	// 248 pages with 65472 bytes (124k +3968)
#define FLASH_SECTOR2_ADR			0x1ff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR3_ADR			0x2ff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR4_ADR			0x3ff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR5_ADR			0x4ff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR6_ADR			0x5ff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR7_ADR			0x6ff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR8_ADR			0x7ff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR9_ADR			0x8ff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR10_ADR			0x9ff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR11_ADR			0xaff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR12_ADR			0xbff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR13_ADR			0xcff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR14_ADR			0xdff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR15_ADR			0xeff	// 256 pages with 135168 bytes (128k +4k)
#define FLASH_SECTOR16_ADR			0xfff	// 256 pages with 135168 bytes (128k +4k)

// set Page (12Bit) and Byte Address (10Bit)
#define ADR_P_B_1(page)				(unsigned char)(page>>6)				// 2 res.bits + 6 bits of 12-bit page-address
#define ADR_P_B_2(page, address)	(unsigned char)(page<<2)|(address>>8)	// 6 bit page-address and 2bit Byte-address
#define ADR_P_B_3(address)		    (unsigned char)address					// 8 bit Byte-address

// set Byte Address (10Bit)
#define ADR_B_1(address)   			(unsigned char)(address>>8)				// 6 don't care + Bit8,9 of address (2bit address)
#define ADR_B_2(address)			(unsigned char)(address)				// bit7 .. Bit0 of address (8bit address)

// set Page Address (12Bit)
#define ADR_P_1(page)				(unsigned char)(page>>6)				// 2 res.bits + 6 bits of 12-bit page-address
#define ADR_P_2(page)				((unsigned char)(page))<<2				// 6 bit of 12-bit page-address + 2 don't care
#endif

// --------------------------------------------------------------------------------
// AT45DB321B-8192 Pages x 528 byte
// -------------------------------------------------------------------------------- 
#ifdef DATAFLASH_AT45DB321
#define FLASH_PAGE_COUNT			8192	// 0..8191
#define FLASH_PAGE_SIZE				528
#define FLASH_SIZE_KBYTE			4224

// set Page (13Bit) and Byte Address (10Bit)
#define ADR_P_B_1(page)				(unsigned char)(page>>6)				// 1 res.bits + 7 bits of 13-bit page-address
#define ADR_P_B_2(page, address)	(unsigned char)(page<<2)|(address>>8)	// 6 bit page-address and 2bit Byte-address
#define ADR_P_B_3(address)		    (unsigned char)address					// 8 bit Byte-address

// set Byte Address (10Bit)
#define ADR_B_1(address)   			(unsigned char)(address>>8)				// 6 don't care + Bit8,9 of address (2bit address)
#define ADR_B_2(address)			(unsigned char)(address)				// bit7 .. Bit0 of address (8bit address)

// set Page Address (13Bit)
#define ADR_P_1(page)				(unsigned char)(page>>6)				// 1 res.bits + 6 bits of 13-bit page-address
#define ADR_P_2(page)				((unsigned char)(page))<<2				// 6 bit of 13-bit page-address + 2 don't care
#endif

// --------------------------------------------------------------------------------
///////// prototypes  /////////  
// -------------------------------------------------------------------------------- 
#pragma used+
void		  dataflash_init();
unsigned char dataflash_cfg_spi(unsigned int spi_mode);
// --------------------------------------------------------------------------------
// Read Commands
// -------------------------------------------------------------------------------- 
unsigned char dataflash_read_flash(unsigned char* data, unsigned int page, unsigned int address, unsigned int size);
unsigned char dataflash_read_buffer(unsigned char* data, unsigned int address, unsigned int size, FLASH_BUFFER_NUM buffer_num);
unsigned char dataflash_read_status(void);

// --------------------------------------------------------------------------------
// Programm and Erase Commands
// -------------------------------------------------------------------------------- 
unsigned char dataflash_write_buffer(unsigned char* data, unsigned int address, unsigned int size, FLASH_BUFFER_NUM buffer_num);
unsigned char dataflash_write_buffer2flash_e(FLASH_BUFFER_NUM buffer_num, unsigned int page);
unsigned char dataflash_write_buffer2flash(FLASH_BUFFER_NUM buffer_num, unsigned int page);
unsigned char dataflash_erase_page(unsigned int page);
unsigned char dataflash_erase_block(unsigned int page);
unsigned char dataflash_write2flash(unsigned char* data, unsigned int page, unsigned int address, unsigned int size, FLASH_BUFFER_NUM buffer_num);

// --------------------------------------------------------------------------------
// Additional Commands
// -------------------------------------------------------------------------------- 
unsigned char dataflash_read_flash2buffer(FLASH_BUFFER_NUM buffer_num, unsigned int page);
unsigned char dataflash_compare(FLASH_BUFFER_NUM buffer_num, unsigned int page);
unsigned char dataflash_rewrite(FLASH_BUFFER_NUM buffer_num, unsigned int page);
unsigned char dataflash_erase_all(void);
   
#define dataflash_write_page(buffer, page_no) dataflash_write2flash(buffer, page_no, 0, FLASH_PAGE_SIZE, FLASH_BUFFER1)
#define dataflash_read_page(buffer, page_no) dataflash_read_flash(buffer, page_no, 0, FLASH_PAGE_SIZE)         
#pragma used-
         
#ifdef COMMON_LIBRARY_ENABLE
#pragma library dataflash.c
#endif

#endif	// #ifndef _DATAFLASH_INCLUDED_