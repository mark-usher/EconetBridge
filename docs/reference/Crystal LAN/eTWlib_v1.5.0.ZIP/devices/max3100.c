// ************************************************************************************************
///
/// \file 			max3100.c
/// \brief			Interfacing MAX3100 SPI-UART
///
/// \todo			Switch to new debug handler framework
/// \date	 		$LastChangedDate: 2007-01-09 16:27:50 +0100 (Di, 09 Jan 2007) $
/// \version 		$Rev: 458 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#ifdef MAX3100_ENABLE

#include <io.h>
#include <stdio.h>
#include <delay.h>
#include "max3100.h"
#ifdef MAX3100_SPI_HARDWARE
	#include "avr_spi.h"
#endif

bit max3100_rx_flag;

// local prototypes
#pragma used+
void            spi_soft_init(void);
unsigned char   spi_soft_write(unsigned char data_out);
#pragma used-

//*********************************************************************************
// Description	: max3100 Initialization
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void max3100_init(void)
{                        
MAX3100_SPI_INIT();
MAX3100_CS_HIGH;		// sets cs-line for MAX3100 high
MAX3100_CS_ACTIV;		// CS - Output
max3100_write_config();

#ifdef MAX3100_INTERRUPT_MODE
// External Interrupt(s) initialization
MAX3100_IRQ_PORT;			// Sets /IRQ-line to High - enable Pullup
MAX3100_IRQ_DDR;			// DDR-Register for MAX3100 /IRQ-Line
MAX3100_IRQ_DIR;			// enable direction of MAX3100 interrupt
MAX3100_IRQ_FLAG_CLEAR;		// clear Interrupt Flag (General Interrupt Flag Register)				   
MAX3100_IRQ_ENABLE;			// enable Interrupt Request (General Interrupt Control Register)				   
max3100_rx_data = 0;
#endif
}

#if defined(MAX3100_POLLING_MODE) && defined(MAX3100_SPI_SOFTWARE)
//*********************************************************************************
// Description	: 
// Input     	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void spi_soft_init(void)
{
SPI_SOFT_SCK_LOW;
SPI_SOFT_SCK_ACTIV;
SPI_SOFT_MOSI_ACTIV;
SPI_SOFT_MISO_PASSIV;
SPI_SOFT_MISO_HIGH;		// enable pullup on MISO-line
}


//*********************************************************************************
// Description	: SCLK Fall to DOUT Valid
// Input     	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
unsigned char spi_soft_write(unsigned char data_out)
{
unsigned char data_in=0, Lva;

// MAX3100 SPI-Takt bis 4 MHz
// vor SCK High MOSI setzen
// nach SCK LOW MISO einlesen
for (Lva=0;Lva<8;Lva++)
	{
	delay_us(1);
	data_in<<=1;
	data_in|=SPI_SOFT_MISO_PIN;

	if (data_out&0x80)      // highest bit set?
	    SPI_SOFT_MOSI_HIGH;
	else
	    SPI_SOFT_MOSI_LOW;
	data_out<<=1;
	SPI_SOFT_SCK_HIGH;
	delay_us(1);
	SPI_SOFT_SCK_LOW;
//	printf("%x ", SPI_POLL_MISO_PIN);
	}
//printf("\r\n");
//printf("Result: %04X\r\n", data_in);

return data_in;
}
#endif



//*********************************************************************************
// Description	: writes the config-data to MAX3100
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void max3100_write_config(void)
{
MAX3100_CS_LOW;		// sets cs-line for MAX3100 low
#ifdef MAX3100_INTERRUPT_MODE
MAX3100_SPI_WRITE(0b11000100);
       // BIT 7         == 1
       // BIT 6         == 1  -  write configuration
       // BIT 5 (/FEN)  == 0  -  FIFO buffer enable
       // BIT 4 (SHDNi) == 0  -  no software shutdown
       // BIT 3 (/TM)   == 0  -  Transmit buffer empty interrupt mask bit (interrupt disable)
       // BIT 2 (/RM)   == 1  -  Receive interrupt mask bit   (interrupt enable)
       // BIT 1 (/PM)   == 0  -  Parity interrupt mask bit  (interrupt disable)
       // BIT 0 (/RAM)  == 0  -  RX-transistion (RA) / framing error (FE) mask bit  (interrupt disable)
#endif
#ifdef MAX3100_POLLING_MODE
MAX3100_SPI_WRITE(0b11000000);
       // BIT 7         == 1
       // BIT 6         == 1  -  write configuration
       // BIT 5 (/FEN)  == 0  -  FIFO buffer enable
       // BIT 4 (SHDNi) == 0  -  no software shutdown
       // BIT 3 (/TM)   == 0  -  Transmit buffer empty interrupt mask bit (interrupt disable)
       // BIT 2 (/RM)   == 0  -  Receive interrupt mask bit   (interrupt disable)
       // BIT 1 (/PM)   == 0  -  Parity interrupt mask bit  (interrupt disable)
       // BIT 0 (/RAM)  == 0  -  RX-transistion (RA) / framing error (FE) mask bit  (interrupt disable)
#endif

MAX3100_SPI_WRITE(0b00000001);
       // BIT 7 (IR)    == 0  -  disable IrDa timing mode
       // BIT 6 (ST)    == 0  -  transmit only 1 stop bit
       // BIT 5 (PE)    == 0  -  parity bit disable
       // BIT 4 (L)     == 0  -  transmission word length = 8
       // BIT 3 (B3)    == 0  -  baudrate divisor select bits
       // BIT 2 (B2)    == 0     (equals baudrate of 115200 bps for f_osc = 3,6864 MHz)
       // BIT 1 (B1)    == 0    
       // BIT 0 (B0)    == 1    
MAX3100_CS_HIGH;		// sets cs-line for MAX3100 high
}


//*********************************************************************************
// Description	: reades the config-data of MAX3100
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
unsigned int max3100_read_config(void)
{
unsigned int	data;

MAX3100_CS_LOW;			  			// sets cs-line for MAX3100 low
data=MAX3100_SPI_WRITE(0b01000000);				// reads upper 8bits
          // BIT 7         == 0  -  
          // BIT 6         == 1  -  read config
          // BIT 5         == 0
          // BIT 4         == 0
          // BIT 3         == 0
          // BIT 2         == 0
          // BIT 1         == 0
          // BIT 0         == 0
data<<=8;
data|=MAX3100_SPI_WRITE(0x00);				// reads lower 8bits
MAX3100_CS_HIGH;					// sets cs-line for MAX3100 high
return data;
}


#ifdef MAX3100_INTERRUPT_MODE
//*********************************************************************************
// Description	: interrupt service routine for receive interrupt from max3100
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
interrupt [MAX3100_IRQ_NUMBER] void max3100_int(void)
{             
max3100_rx_data=1;
MAX3100_IRQ_DISABLE;		// disable Interrupt Request (General Interrupt Control Register)
}
#endif


#ifdef MAX3100_POLLING_MODE
//*********************************************************************************
// Description	: reads data from MAX3100
// Input   		: none
// Output  		: 0 - no data available
//              : 1 - new character available
// Indication	: 
//*********************************************************************************
unsigned char max3100_poll(void)
{
unsigned char data_h;

MAX3100_CS_LOW;			 		// sets cs-line for MAX3100 low
data_h = MAX3100_SPI_WRITE(0x00);			// read upper 8bits
MAX3100_CS_HIGH;				// sets cs-line for MAX3100 high
if (data_h & 0x38)				// Bits 3-5 always '0'!
	{
	#ifdef MAX3100_DEBUG
	putsf("Max3100 Frame error!\r");
	#endif
	return 0;
	}
if (data_h & 0x80)				// receive buffer empty bit
    max3100_rx_flag = 1;
else
    max3100_rx_flag = 0;

return max3100_rx_flag;
}
#endif


// ************************************************************************************************
/// \brief		Check for received data from MAX3100
///
/// @retvalue	-1   - no character received
/// @retvalue	>=0  - reveived character
// ************************************************************************************************
signed int max3100_check_rx(void)
{
unsigned char data_h, data_1;

MAX3100_CS_LOW;			 		// sets cs-line for MAX3100 low
data_h = MAX3100_SPI_WRITE(0x00);			// read upper 8bits
if (data_h & 0x38)				// Bits 3-5 always '0'!
	{
	#ifdef MAX3100_DEBUG
	putsf("Max3100 Frame error!\r");
	#endif
	return -1;
	}
delay_us(20);
data_1 = MAX3100_SPI_WRITE(0x00);	// read upper 8bits
MAX3100_CS_HIGH;					// sets cs-line for MAX3100 high

if (data_h & 0x80)					// buffer empty bit
	return data_1;
else
	return -1;
}


//*********************************************************************************
// Description	: reads data from MAX3100
// Input   		: none
// Output  		: new character
// Indication	: waits until receive a character, like getchar()
//*********************************************************************************
unsigned char max3100_getchar(void)
{
unsigned char data_h, data_l=0x00;

while (max3100_rx_flag==0)
    {
    #ifdef MAX3100_POLLING_MODE
    max3100_poll();
    #endif
    }

MAX3100_CS_LOW;			 						// sets cs-line for MAX3100 low
data_h = MAX3100_SPI_WRITE(0x00);				// read upper 8bits
if (data_h & 0x80)								// receive buffer empty bit
	data_l = MAX3100_SPI_WRITE(0x00);			// read lower 8bits
MAX3100_CS_HIGH;									// sets cs-line for MAX3100 high
max3100_rx_flag=0;

#ifdef MAX3100_INTERRUPT_MODE
MAX3100_IRQ_FLAG_CLEAR;			// clear Interrupt Flag (General Interrupt Flag Register)				   
MAX3100_IRQ_ENABLE;				// enable Interrupt Request (General Interrupt Control Register)				   
#endif
return data_l;
}


//*********************************************************************************
// Description	: writes data to MAX3100
// Input   		: c: character to write to UART (MAX3100)
// Output  		: none
// Indication	: waits until transmit-buffer empty, like putchar()
//*********************************************************************************
void max3100_putchar(char c)
{
unsigned char data_h;
unsigned int  timeout_counter;

timeout_counter = 0x0FFF;
do
    {
    MAX3100_CS_LOW;					// sets cs-line for MAX3100 low
    data_h = MAX3100_SPI_WRITE(0b10000010);		// write upper 8bits
              // BIT 7         == 1  -  
              // BIT 6         == 0  -  write data
              // BIT 5         == 0
              // BIT 4         == 0
              // BIT 3         == 0
              // BIT 2 (/TE)   == 0  -  transmit enable bit (transmit enabled)
              // BIT 1 (RTS)   == 1  -  Request-to-send Bit (/RTS-pin logic high)
              // BIT 0 (Pt)    == 0  -  Transmit-Parity Bits
    if (data_h & 0x38)				// Bits 3-5 always '0'!
    	{
    	#ifdef MAX3100_DEBUG
    	putsf("Max3100 Frame error!\r");
    	#endif
    	break;
    	}
    if (--timeout_counter == 0)
    	{
    	// 1x spi_soft_write() ca. 10-20 us bei 16 Mhz
    	// Timeout: 4096*(10..20)us = 40ms..80ms
    	#ifdef MAX3100_DEBUG
    	putsf("Max3100 Timeout!\r");
    	#endif
    	break;
    	}
    if (!(data_h & 0x40))	   		// transmit buffer not empty
    	MAX3100_CS_HIGH;	   		// sets cs-line for MAX3100 high - break transmission
    }
while (!(data_h & 0x40));	   	 	// transmit buffer not empty
delay_us(100);
MAX3100_SPI_WRITE(c);		  		// write lower 8bits
MAX3100_CS_HIGH;		    		// sets cs-line for MAX3100 high
}


//*********************************************************************************
// Description	: writes string to MAX3100
// Input   		: 1.) str: pointer to flash with string
// Output  		: none
// Indication	: function to write directly to MAX3100
//*********************************************************************************
void max3100_putsf(char flash *str) 
{
while (*str!=0)
	{
	if(*str=='\r')
		max3100_putchar('\n');
	max3100_putchar(*str);
	str++;
	}
}

#ifdef MAX3100_DEBUG
//*********************************************************************************
// Description	: displays all infos to MAX3100
// Input	 	: none
// Output    	: none
// Indication	: none
//*********************************************************************************
void max3100_info(void)
{
unsigned int data;

data=max3100_read_config();
printf("MAX3100-Config: 0x%04x\r\n", data);
if(data & 0x8000)
	putsf("R-new data\r");
else
	putsf("R-FIFO empty\r");
if(data & 0x4000)
	putsf("T-FIFO empty\r");
else
	putsf("T-FIFO full\r");
if(data & 0x2000)
	putsf("/FEN-Receive FIFO disable\r");
else
	putsf("/FEN-Receive FIFO enable\r");
if(data & 0x1000)
	putsf("/SHDNo-shutdown\r");
else
	putsf("/SHDNo-no shutdown\r");
if(data & 0x0800)
	putsf("/TM-IRQ-UnMask of T-bit\r");
else
	putsf("/TM-IRQ-Mask of T-bit\r");
if(data & 0x0400)
	putsf("/RM-IRQ-UnMask of R-bit\r");
else
	putsf("/RM-IRQ-Mask of R-bit\r");
if(data & 0x0200)
	putsf("/PM-IRQ-UnMask of Pr-bit\r");
else
	putsf("/PM-IRQ-Mask of Pr-bit\r");
if(data & 0x0100)
	putsf("/RAM-IRQ-UnMask of RA/FE-bit\r");
else
	putsf("/RAM-IRQ-Mask of RA/FE-bit\r");
if(data & 0x0080)
	putsf("IR-IrDa enable\r");
else
	putsf("IR-IrDa disable\r");
if(data & 0x0040)
	putsf("ST-Transmit-2 Stopbits\r");
else
	putsf("ST-Transmit-1 Stopbit\r");
if(data & 0x0020)
	putsf("PE-Parity enable\r");
else
	putsf("PE-Parity disable\r");
if(data & 0x0010)
	putsf("L-7bit Data\r");
else
	putsf("L-8bit Data\r");
printf("Baudrate: ");
switch(data & 0x000f)
	{
	case 0x0: putsf("230.4kBaud\r");break;
	case 0x1: putsf("115.2kBaud\r");break;
	case 0x2: putsf("57.6kBaud\r");break;
	case 0x3: putsf("28.8kBaud\r");break;
	case 0x4: putsf("14.4kBaud\r");break;
	case 0x5: putsf("7.2kBaud\r");break;
	case 0x6: putsf("3.6kBaud\r");break;
	case 0x7: putsf("1.8kBaud\r");break;
	case 0x8: putsf("76.8kBaud\r");break;
	case 0x9: putsf("38.4kBaud\r");break;
	case 0xa: putsf("19.2kBaud\r");break;
	case 0xb: putsf("9.6kBaud\r");break;
	case 0xc: putsf("4.8kBaud\r");break;
	case 0xd: putsf("2.4kBaud\r");break;
	case 0xe: putsf("1.2kBaud\r");break;
	case 0xf: putsf("0.6kBaud\r");break;
	}
}


//*********************************************************************************
// Description	: process debug command string for max3100
// Input     	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void max3100_debug_cmd(unsigned char *command)
{
if(strncmpf(command, "max3100-info", 11)==0)
	{
	max3100_info();
	return;
	}
if(strncmpf(command, "max3100-init", 12)==0)
	{
	putsf("Max3100 inititialisiert!\r");
	max3100_init();
	return;
	}
if(strncmpf(command, "max3100-cs", 10)==0)
	{
	if (MAX3100_CS_PIN)
	    {
	    MAX3100_CS_LOW;
    	putsf("Max3100 /CS-Line Low!\r");
	    }
	else
	    {
	    MAX3100_CS_HIGH;
    	putsf("Max3100 /CS-Line high!\r");
	    }
	return;
	}
#ifdef MAX3100_SPI_SOFTWARE
if (strncmpf(command, "max3100-miso", 10)==0)
	{
	if (SPI_SOFT_MISO_PIN)
	    {
	    SPI_SOFT_MISO_LOW;
    	putsf("Max3100 MISO-Line Low!\r");
	    }
	else
	    {
	    SPI_SOFT_MISO_HIGH;
    	putsf("Max3100 MISO-Line high!\r");
	    }
	return;
	}
if (strncmpf(command, "max3100-mosi", 10)==0)
	{
	if (SPI_SOFT_MOSI_PIN)
	    {
	    SPI_SOFT_MOSI_LOW;
    	putsf("Max3100 MOSI-Line Low!\r");
	    }
	else
	    {
	    SPI_SOFT_MOSI_HIGH;
    	putsf("Max3100 MOSI-Line high!\r");
	    }
	return;
	}
if (strncmpf(command, "max3100-sck", 10)==0)
	{
	if (SPI_SOFT_SCK_PIN)
	    {
	    SPI_SOFT_SCK_LOW;
    	putsf("Max3100 SCK-Line Low!\r");
	    }
	else
	    {
	    SPI_SOFT_SCK_HIGH;
    	putsf("Max3100 SCK-Line high!\r");
	    }
	return;
	}
#endif	// #ifdef MAX3100_SPI_SOFTWARE
}
#endif // #ifdef MAX3100_DEBUG
#endif // #ifdef MAX3100_ENABLE