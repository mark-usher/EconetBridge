// ************************************************************************************************
///
/// \file 			keys.c
/// \brief			Read keys including debounce routines
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Carsten K�gler, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#ifdef _DOXYGEN_PARSER_
#define KEYS_ENABLE
#endif

#ifdef KEYS_ENABLE

#include "gpio.h"
#include "keys.h"


#ifndef GPIO_ENABLE
#error "KEYS: GPIO module needed. Define GPIO_ENABLE in project.h!"
#endif

#pragma regalloc-
unsigned int keys_state;
#pragma regalloc+
GPIO_CFG_STRUCT_FLASH keys_config[KEYS_INPUT_COUNT] = {
										 {KEYS_PORT0, KEYS_BITMASK0}
		#if (KEYS_INPUT_COUNT>1)
										,{KEYS_PORT1, KEYS_BITMASK1} 
		#endif
		#if (KEYS_INPUT_COUNT>2)		
										,{KEYS_PORT2, KEYS_BITMASK2} 
		#endif
		#if (KEYS_INPUT_COUNT>3)		
										,{KEYS_PORT3, KEYS_BITMASK3} 
		#endif
		#if (KEYS_INPUT_COUNT>4)		
										,{KEYS_PORT4, KEYS_BITMASK4} 
		#endif
		#if (KEYS_INPUT_COUNT>5)		
										,{KEYS_PORT5, KEYS_BITMASK5} 
		#endif
		#if (KEYS_INPUT_COUNT>6)		
										,{KEYS_PORT6, KEYS_BITMASK6} 
		#endif
		#if (KEYS_INPUT_COUNT>7)		
										,{KEYS_PORT7, KEYS_BITMASK7} 
		#endif
		#if (KEYS_INPUT_COUNT>8)		
										,{KEYS_PORT8, KEYS_BITMASK8} 
		#endif
		#if (KEYS_INPUT_COUNT>9)		
										,{KEYS_PORT9, KEYS_BITMASK9} 
		#endif
		#if (KEYS_INPUT_COUNT>10)		
										,{KEYS_PORT10, KEYS_BITMASK10} 
		#endif
		#if (KEYS_INPUT_COUNT>11)		
										,{KEYS_PORT11, KEYS_BITMASK11} 
		#endif
		#if (KEYS_INPUT_COUNT>12)		
										,{KEYS_PORT12, KEYS_BITMASK12} 
		#endif
		#if (KEYS_INPUT_COUNT>13)		
										,{KEYS_PORT13, KEYS_BITMASK13} 
		#endif
		#if (KEYS_INPUT_COUNT>14)		
										,{KEYS_PORT14, KEYS_BITMASK14} 
		#endif
		#if (KEYS_INPUT_COUNT>15)		
										,{KEYS_PORT15, KEYS_BITMASK15} 
		#endif
										};
// local prototype
unsigned int keys_read_pattern(void);

// ************************************************************************************************
/// \brief		Initialization of keys module
///				
// ************************************************************************************************
void keys_init(void)
{
unsigned char i;

for (i=0; i<KEYS_INPUT_COUNT; i++)
	{
	gpio_cfg_in_mask(keys_config[i].port, keys_config[i].bitmask);
	#ifdef KEYS_PULLUP_ENABLE
	gpio_set_pin_mask(keys_config[i].port, keys_config[i].bitmask);	// enable pullup
	#endif
	}
keys_state = keys_read_pattern();
}


// ************************************************************************************************
/// \brief		Reads the Key inputs
///
/// @return		key pattern
// ************************************************************************************************
unsigned int keys_read_pattern(void)
{
unsigned int pattern=0;
signed char	 i;

for (i=KEYS_INPUT_COUNT-1; i>=0; i--)
	{
	pattern <<= 1;
	pattern |= (gpio_read_pin_mask(keys_config[i].port, keys_config[i].bitmask) != 0);
	}
return pattern;
}


// ************************************************************************************************
/// \brief		Processing key debounce
///
/// \note		Called every 10 ms from main()
// ************************************************************************************************
void keys_poll_10ms(void)
{
static char 		key_press_counter[KEYS_INPUT_COUNT]={0}; 
static char 		key_release_counter[KEYS_INPUT_COUNT]={0};
static unsigned int key_press_candidate=0;
static unsigned int key_release_candidate=0;
static unsigned int key_last_pattern=0;
unsigned int 		key_now_pattern=0;
unsigned char 		i;
unsigned int 		bitmask;

bitmask = 0x01;
key_now_pattern = keys_read_pattern();
//printf("KEYS: %u\r\n", key_now_pattern);

for (i=0; i<KEYS_INPUT_COUNT; i++)
	{
	if (key_press_candidate & bitmask)
		{
		if (key_press_counter[i])
			key_press_counter[i]--;
		else
			{
			#ifdef KEYS_DEBUG
			printf("KEYS: Press-Key(%u): %x\r\n", i, key_now_pattern);
			#endif
			key_press_candidate &= ~bitmask;
			keys_state |= bitmask;
			}
		}
	if (key_release_candidate & bitmask)
		{
		if (key_release_counter[i])
			key_release_counter[i]--;
		else
			{
			#ifdef KEYS_DEBUG
			printf("KEYS: Release-Key(%u): %x\r\n", i, key_now_pattern);
			#endif
			key_release_candidate &= ~bitmask;
			keys_state &= ~bitmask;
			}
		}
		
	if ((key_last_pattern^key_now_pattern) & bitmask)	// Status of input has changed
		{
		// 4 cases:
		// (1) Key is candidate Pressing and didn't made the required time 
		//												-> out of key_press_candidate
		// (2) Key is candidate Releasing and didn't made the required time
		//												-> out of key_release_candidate
		// (3) Key is no candidate (state low) and pressed
		//												-> start timer & in key_press_candidate
		// (4) Key is no candidate (state high) and released
		//												-> start timer & in key_release_candidate
		key_release_candidate &= ~bitmask;
		key_press_candidate &= ~bitmask;
		if (key_now_pattern&bitmask && !(keys_state&bitmask))
			{
			// case (3)
			#ifdef KEYS_DEBUG
			printf("KEYS: Press-Start(%u): %x\r\n", i, key_now_pattern);
			#endif
			key_press_candidate |= bitmask;
			key_press_counter[i] = KEYS_PRESSED_COUNTER;
			}
		else if (!(key_now_pattern&bitmask) && keys_state&bitmask)
			{
			// case (4)
			#ifdef KEYS_DEBUG
			printf("KEYS: Release-Start(%u): %x\r\n", i, key_now_pattern);
			#endif
			key_release_candidate |= bitmask;
			key_release_counter[i] = KEYS_RELEASED_COUNTER;
			}
		}
	bitmask <<= 1;
	}
key_last_pattern = key_now_pattern;
}


// ************************************************************************************************
/// \brief		Get actual key state
///
/// @retval		0 - no change
/// @retval		1 - key has changed
// ************************************************************************************************
unsigned int keys_get_state(void)
{
return keys_state;
}

#endif