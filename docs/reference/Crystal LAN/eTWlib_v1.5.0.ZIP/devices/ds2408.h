// ************************************************************************************************
///
/// \file 			ds2408.h
/// \brief			header file of ds2408.c
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Carsten K�gler, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************
                         
#ifndef _DS2408_H_INCLUDED_
#define _DS2408_H_INCLUDED_
                               
              
//DS2408 commands
#define SKIP_ROM			0xCC	// skip rom command
#define READ_PIO			0xF0    // read pio registers command
#define CAW					0x5A	// channel-access-write command

//DS2408 target addresses
#define LOGIC_STATE			0x88	// address of PIO Logic State Register
#define OUT_LATCH_STATE		0x89	// address of PIO Output Latch State Register
#define ADR_NULL			0x00


#include <1wire.h>

#pragma used+
void 			ds2408_write_output(unsigned char data);
unsigned char   ds2408_read_output(void);
unsigned char   ds2408_read_input(void);
void 			ds2408_write_bits(unsigned char bitmask, unsigned char value);
void 			ds2408_set_bits(unsigned char bitmask);
void 			ds2408_clear_bits(unsigned char bitmask);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library ds2408.c
#endif

#endif	// #ifndef _DS2408_H_INCLUDED_