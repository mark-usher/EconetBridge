// ************************************************************************************************
///
/// \file 			ds2430a.c
/// \brief			Dallas DS2430A 1-Wire EEPROM
///
/// \date	 		$LastChangedDate: 2007-03-05 14:11:23 +0100 (Mo, 05 Mrz 2007) $
/// \version 		$Rev: 581 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include "1wire_irq.h"
#include "ds2430a.h"


//********************************************************************************
// Description	: init the 1-wire-Interface and read the PROM of DS2430
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
unsigned char ds2430a_init_read_prom(unsigned char *data_buffer)
{
unsigned char devices_1wire;
unsigned char romcodes_1wire[BOARD_MAX_1WIRE_DEVICES,9];

#ifdef	WIRE_IRQ		// controls the use of disable and enable of global IRQ
unsigned char sreg;
sreg=SREG;
#asm("cli");
#endif
devices_1wire=w1_search(0xf0, romcodes_1wire);	// search all 1Wire-Devices
if(devices_1wire>BOARD_MAX_1WIRE_DEVICES)
	devices_1wire = 0;		// return error (no devices found)
#ifdef	WIRE_IRQ			// controls the use of disable and enable of global IRQ
SREG=sreg;
#endif
while(devices_1wire)
	{
	devices_1wire--;
	if(romcodes_1wire[devices_1wire, 0] == DS2430_FAMILY_CODE)	// found DS2430A
		if(data_buffer!=0)
			return ds2430a_read_prom(&romcodes_1wire[devices_1wire,0], data_buffer, 0, DS2430_PROM_SIZE);
	}
return 0;
}


// ********************************************************************************
// Description	: selects a specific DS2430 on the bus
// Input	   	: none
// Output      	: 1.) return==0x00 - 1wire device not present
//				      return!=0x00 - 1wire device found
// Indication	: if romcode is NULL then only one 1 Wire device can be used
// *********************************************************************************
unsigned char ds2430a_select(unsigned char *romcode)
{
unsigned char i;
if (!W1_INIT()) return 0;
if (romcode)
   {
   W1_WRITE(0x55);	// write "Match ROM" command
   for (i=0;i<8;i++) W1_WRITE(*romcode++);
   }
else return W1_WRITE(0xCC);	// write "Skip ROM"
}


// ********************************************************************************
// Description	: reads the status-register of Ds2430 and checks whether lock or unlock 
// Input	   	: 1.) *romcode - pointer to 9Byte-Array with ROM-number
// Output      	: 1.) return==0xff - unlock
//				      return==0xfc - lock
//				      return==0x00 - error
// Indication	: none
// *********************************************************************************
unsigned char ds2430a_read_status(unsigned char *romcode)
{
// reads the data from the scratchpad
if (!ds2430a_select(romcode)) return 0;
W1_WRITE(0x66);
W1_WRITE(0);
// check if the application register is locked
return W1_READ();
}


// ********************************************************************************
// Description	: read a block of size bytes starting from memory address addr 
//                and stores it at dest
// Input	   	: none
// Output      	: 1.) return==0x00 - error
//				      return!=0x00 - succesful
// Indication	: none
// *********************************************************************************
unsigned char ds2430a_read_eeprom(unsigned char *romcode, unsigned char *dest,unsigned char addr,unsigned char size)
{
// read EEPROM contents to scratchpad and
// read the scratchpad contents
if (!ds2430a_select(romcode)) return 0;
W1_WRITE(0xF0);
if(!W1_WRITE(addr)) return 0;
while (size--) *dest++=W1_READ();
return 1;
}


// ********************************************************************************
// Description	: write a block of size bytes, located at source, starting from memory address addr
// Input	   	: none
// Output      	: 1.) return==0x00 - error
//				      return!=0x00 - succesful
// Indication	: none
// *********************************************************************************
unsigned char ds2430a_write_eeprom(unsigned char *romcode, unsigned char *source,unsigned char addr,unsigned char size)
{
unsigned char i;
unsigned char *p;
p=source;
// read EEPROM's contents to the scratchpad               
if (!ds2430a_select(romcode)) return 0;
W1_WRITE(0xF0);
// write new data to the scratchpad
if (!ds2430a_select(romcode)) return 0;
W1_WRITE(0x0F); 
W1_WRITE(addr);
for (i=0;i<size;i++) W1_WRITE(*p++);
// verify that the new data written in the scratchpad is correct
if (!ds2430a_select(romcode)) return 0;
W1_WRITE(0xAA);
W1_WRITE(addr);
for (i=0;i<size;i++)
    if (W1_READ()!=*source++) return 0;
// copy the scratchpad to the EEPROM
if (!ds2430a_select(romcode)) return 0;
W1_WRITE(0x55);
if (!W1_WRITE(0xA5)) return 0;
// wait for the write process to complete
delay_ms(15);
return 1;
}


// ********************************************************************************
// Description	: read a block of size bytes, starting from application
// Input	   	: 1.) *romcode - pointer to 9Byte-Array with ROM-number
//                2.) *dest - pointer to Data-Array
//                3.) addr - addr of PROM
//                4.) size - size to read from PROM
// Output      	: 1.) return==0xff - unlock (DS2430_PROM_UNLOCK)
//				      return==0xfc - lock (DS2430_PROM_LOCK)
//				      return==0x00 - error (DS2430_PROM_ERROR)
// Indication	: none
// *********************************************************************************
unsigned char ds2430a_read_prom(unsigned char *romcode, unsigned char *dest,unsigned char addr,unsigned char size)
{
// reads the data from the scratchpad
if (!ds2430a_select(romcode)) return 0;
W1_WRITE(0xC3);
if (!W1_WRITE(addr)) return 0;
while (size--) *dest++=W1_READ();
return ds2430a_read_status(romcode);
}


// ********************************************************************************
// Description	: writes a block of size bytes, located at source,starting from 
//                application register address addr
// Input	   	: 1.) *romcode - pointer to 9Byte-Array with ROM-number
//                2.) *source - pointer to data-Array
//                3.) addr - addr of PROM
//                4.) size - size to write to PROM
// Input	   	: 1.) *romcode - pointer to 9Byte-Array with ROM-number
// Output      	: 1.) return==0x01 - OK
//				      return==0x00 - error
// Indication	: none
// *********************************************************************************
unsigned char ds2430a_write_prom(unsigned char *romcode, unsigned char *source,unsigned char addr,unsigned char size)
{
unsigned char i;
unsigned char *p;
p=source;
// check if the application register is locked
if (ds2430a_read_status(romcode)==0xFC) return 0;	// DS2430_PROM_LOCK==0xFC
// read application register's contents to the scratchpad               
if (!ds2430a_select(romcode)) return 0;
W1_WRITE(0xC3);
// write new data to the scratchpad
if (!ds2430a_select(romcode)) return 0;
W1_WRITE(0x99); 
W1_WRITE(addr);
for (i=0;i<size;i++) W1_WRITE(*p++);
// verify that the new data in the scratchpad is correct
if (!ds2430a_select(romcode)) return 0;
W1_WRITE(0xC3);
W1_WRITE(addr);
for (i=0;i<size;i++)
    if (W1_READ()!=*source++) return 0;
// copy & lock the application register
if (!ds2430a_select(romcode)) return 0;
W1_WRITE(0x5A);
if (!W1_WRITE(0xA5)) return 0;
// wait for the write process to complete
delay_ms(15);
return 1;
}
