// ************************************************************************************************
///
/// \file 			ad5242.h
///
///					I�C Digital Potentiometer from Analog Devices
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \addtogroup Device_Driver
/// @{
/// \defgroup AD5242
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define AD5242_ENABLE		///< Enables the AD5242 module
//@}
#endif

#if defined AD5242_ENABLE && !defined TWI_CVAVR_ENABLE && !defined TWI_AVR_ENABLE
#error "AD5242 needs TWI_CVAVR_ENABLE defined in project.h"
#endif

#ifndef _AD5242_INCLUDED_
#define _AD5242_INCLUDED_

#include "twi.h"

#define AD5242_OUT1			0x10	///< Set Digital Output1 high, see parameter "digout_value"
#define AD5242_OUT2			0x08	///< Set Digital Output2 high, see parameter "digout_value"

#define AD5242_AD0			0x01	///< Specifies chip address pins, see parameter "addr_pins"
#define AD5242_AD1			0x02	///< Specifies chip address pins, see parameter "addr_pins"

#pragma used+
void 	  ad5242_init(void);
T_TWI_ERR ad5242_write(unsigned char addr_pins, unsigned char rdac_no, 
  					   unsigned char rdac_value, unsigned char digout_value);
T_TWI_ERR ad5242_read(unsigned char  addr_pins, unsigned char  rdac_no, 
  				  	  unsigned char* p_value, unsigned char  digout_value);
#pragma used-


#ifdef COMMON_LIBRARY_ENABLE
#pragma library ad5242.c
#endif

#endif	// #ifdef AD5242_ENABLE