// ************************************************************************************************
///
/// \file 			max7301.c
/// \brief			MAX7301 device driver
///
/// 				Functions for interfacing MAX7301 SPI port expander
/// \note			After Reset, all chips start in shutdown mode. You have to config them with 
///					void max7301_write_config() in order to use them. Otherwise all ports are
///					working as inputs.
///	\note			An single pin at the chip is called an 'port'
/// \todo			document initialization order in detail
///
/// \date	 		$LastChangedDate: 2007-08-07 18:21:04 +0200 (Di, 07 Aug 2007) $
/// \version 		$Rev: 675 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#ifdef _DOXYGEN_PARSER_
#define MAX7301_ENABLE
#define MAX7301_DEBUG
#endif

#ifdef MAX7301_ENABLE

#include <stdio.h>
#include <string.h>
#include "max7301.h"
#include "avr_spi.h"
#include "gpio.h"
#include "debug.h"


#pragma regalloc-
MAX7301_DEV  max7301_dev[MAX7301_MAX_CHIPS];	 ///< saves configuration of all registered chips
#pragma regalloc+

#define READ_BIT 		0x80	///< special bitmask. Used in many functions in max7301 module

// prototypes
#pragma used+
void max7301_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);
#pragma used-


// ************************************************************************************************
/// \brief		Initializes MAX7301 module
///
// ************************************************************************************************
void max7301_init(void)
{
#ifdef MAX7301_DEBUG
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &max7301_debug_handler;
p_struct.id_string = "max7301";
debug_register_handler(&p_struct);
#endif

// SPI initialization
// SPI Type: Master
// SPI Clock Rate: 2*4000,000 kHz
// SPI Clock Phase: Cycle Start
// SPCR_CPHA = 0 -> Daten an MISO und MOSI are sampled on the leading edge
// leading edge == rising edge (because of SPCR_CPOL == 0)
// SPI Clock Polarity: Low
// SPCR_CPOL == 0 -> clock im ruhezustand low
// SPI Data Order: MSB First
spi_init(SPCR_SPE | SPCR_MSTR | SPCR_2);

memset(max7301_dev, 0xFF, sizeof(max7301_dev));
}

// ************************************************************************************************
/// \brief		Registers a new MAX7301 device
///
/// @param[in]	p_dev - Pointer to device struct, see max7301.h
/// @retval		0 - error
/// @retval		1 - success
// ************************************************************************************************
unsigned char max7301_register(MAX7301_DEV* p_dev)
{
if (p_dev->id >= MAX7301_MAX_CHIPS)
	{
	#ifdef MAX7301_DEBUG
	printf("MAX7301_MAX_CHIPS too small!\r\n");
	#endif
	return 0;
	}
memcpy(&max7301_dev[p_dev->id], (unsigned char*)p_dev, sizeof(MAX7301_DEV));

// set SlaveSelect(SS) line high and output
gpio_set_pin_mask(p_dev->ss_port, p_dev->ss_pin);
gpio_cfg_out_mask(p_dev->ss_port, p_dev->ss_pin);

return 1;
}


// ************************************************************************************************
/// \brief		Configure pins of MAX7301 as input or output / enable pullups
///
/// @param[in]	id     - number of device in device array max7301_dev[]
/// @param[in]	nibble - number of nibbles range 1..7 (nibble 1 equals P4-P7 ...)
/// @param[in]	data   - port-configuration
///                      2 Byte pro Kanal (nibble1: Bits 0,1 f�r Port4)
///                      upper bit = 0: output
///                      upper bit = 1: input
///                      lower bit = 0: Schnitt-Trigger input
///                      lower bit = 1: Schnitt-Trigger input with pullup
///						 0x55 for output
///						 0xAA for input with pullup
// ************************************************************************************************
void max7301_nibble_config(unsigned char id, unsigned char nibble, unsigned char data)
{
unsigned char sreg_tmp;

#ifdef MAX7301_CHECK_PARAMS
if (nibble==0 || nibble>8 || id>=MAX7301_MAX_CHIPS)
	{   	
	#ifdef MAX7301_DEBUG
	putsf("MAX7301 nibble_config Error!\r");
	#endif
	return;
	}
#endif

sreg_tmp = SREG;
#asm("cli");

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(0x08 + nibble);          					// command byte (r/w == 0)  
spi_transfer(data);                   					// config_byte
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

SREG = sreg_tmp;
}


// ************************************************************************************************
/// \brief		Configure single pin of MAX7301 as input or output / enable pullups
///
/// @param[in]	id    - number of device in device array max7301_dev[]
/// @param[in]	port  - number of port, range 4..31
/// @param[in]	mode  - bitwise OR of macros MAX7301_OUTPUT, MAX7301_INPUT, MAX7301_PULLUP_ON and 
/// 					MAX7301_PULLUP_OFF. With MAX7301_OUTPUT, pullup configuration is ignored!
// ************************************************************************************************
void max7301_port_config(unsigned char id, unsigned char port, unsigned char mode)
{
unsigned char config;
unsigned char sreg_tmp;

#ifdef MAX7301_CHECK_PARAMS
if (port<4 || port>31 || id>=MAX7301_MAX_CHIPS || mode>0x03)
	{   	
	#ifdef MAX7301_DEBUG
	putsf("MAX7301 port_config Error!\r");
	#endif
	return;
	}
#endif // #ifdef MAX7301_CHECK_PARAMS

sreg_tmp = SREG;
#asm("cli");

config = max7301_read_address(id, port/4+0x08);
config &= ~(0b11<<((port%4)*2));
config |=  mode << ((port%4)*2);
max7301_write_address(id, port/4+0x08, config);

SREG = sreg_tmp;
}


// ************************************************************************************************
/// \brief		Clear or set single bit
///
/// @param[in]	id    - number of device in device array max7301_dev[]
/// @param[in]	port  - number of port, range 4..31
/// @param[in]	data  - output value 
///							0 -> clear bit
//                          1 -> set bit
// ************************************************************************************************
void max7301_write_bit(unsigned char id, unsigned char port, unsigned char data)
{
unsigned char sreg_tmp;

#ifdef MAX7301_CHECK_PARAMS
if (port<4 || port>31 || id>=MAX7301_MAX_CHIPS || data>1)
	{   	
	#ifdef MAX7301_DEBUG
	putsf("MAX7301 write_bit Error!\r");
	#endif
	return;
	}
#endif

sreg_tmp = SREG;
#asm("cli");

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(0x20 + port);                  				// command byte (r/w == 0)  
spi_transfer(data);
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

SREG = sreg_tmp;
}


// ************************************************************************************************
/// \brief		Read single bit
///
/// @param[in]	id    - number of device in device array max7301_dev[]
/// @param[in]	port  - number of port, range 4..31
/// @return		state of input
// ************************************************************************************************
unsigned char max7301_read_bit(unsigned char id, unsigned char port)
{
unsigned char data;
unsigned char sreg_tmp;

#ifdef MAX7301_CHECK_PARAMS
if (port<4 || port>31 || id>=MAX7301_MAX_CHIPS)
	{   	
	#ifdef MAX7301_DEBUG
	putsf("MAX7301 read_bit Error!\r");
	#endif
	return;
	}
#endif

sreg_tmp = SREG;
#asm("cli");

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(READ_BIT | (0x20+port));   					// command byte (r/w == 1)  
spi_transfer(0x00);                    					// dummy data
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high
#asm("nop");
gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(0x00);                    					// nop
data = spi_transfer(0x00);             					// dummy data
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

SREG = sreg_tmp;
return data;
}


// ************************************************************************************************
/// \brief		Write single bit + check for edge + update transition detection register
///
/// \todo		max7301_write_bit_isr() is project-specific. This function should be removed 
///				from this module
/// 
/// \note		This function is executed in an interrupt.
/// @param[in]	id   - number of device in device array max7301_dev[]
/// @param[in]	data - bit to write
/// @retval		0    - transistion was a HL-Edge; data written
/// @retval		0xFF - transistion was a LH-Edge; data not written
// ************************************************************************************************
unsigned char max7301_write_bit_isr(unsigned char id, unsigned char data)
{
unsigned char clock;

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(READ_BIT | (0x20+30));    					// command byte (r/w == 1)  Port30==WCP2
spi_transfer(0x00);                    					// dummy data
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(0x04);                    					// write transition control register
clock = spi_transfer(MAX7301_SHUT_DISABLE | MAX7301_INT_ENABLE); // reenable transition detection
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

if (clock == 0)               					// wenn der clock low ist ... (->HL-Flanke)
	{
	gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
	spi_transfer(0x20 + 22);           					// command byte (r/w == 0)  Port22==WDT2
	if (data == 0)
		spi_transfer(0x00);             					// data
	else
		spi_transfer(0x01);             					// data
	gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high
	return 0;
    }
return 0xFF;
}


// ************************************************************************************************
/// \brief		Read single bit + check for edge + update transition detection register
///
/// \todo		max7301_read_bit_isr() is project-specific. This function should be removed
///				from this module
/// 
/// \note		This function is executed in an interrupt.
/// @param[in]	id     - number of device in device array max7301_dev[]
/// @retval		!=0xFF - transistion was a HL-Edge; return value equals read bit value
/// @retval		0xFF   - transistion was a LH-Edge; no data read
// ************************************************************************************************
unsigned char max7301_read_bit_isr(unsigned char id)
{
unsigned char clock;
unsigned char data;

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(READ_BIT | (0x20+25));    					// command byte (r/w == 1)  Port25==RCP2
spi_transfer(0x00);                    					// dummy data
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(READ_BIT | (0x20+10));    					// command byte (r/w == 1)  Port10==RDP2
clock = spi_transfer(0x00);            					// dummy data
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(0x04);                    							// transition control register
data = spi_transfer(MAX7301_SHUT_DISABLE | MAX7301_INT_ENABLE); // reenable transition detection
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);			// SS high

if (clock != 0)   // wenn es keine high-low-Flanke war..
	return 0xFF;
else
	return data;
}


// ************************************************************************************************
/// \brief		Writes 8 bits at once beginning with "start"
///
/// @param[in]	id    - number of device in device array max7301_dev[]
/// @param[in]	start - Number of start port, range 4 .. 24
/// @param[in]	data  - 8 Bit to write
// ************************************************************************************************
void max7301_write_8bit(unsigned char id, unsigned char start, unsigned char data)
{
unsigned char sreg_tmp;
#ifdef MAX7301_CHECK_PARAMS
if (start<4 || start>31 || id>=MAX7301_MAX_CHIPS)
	{   	
	#ifdef MAX7301_DEBUG
	putsf("MAX7301 write_8bit Error!\r");
	#endif
	return;
	}
#endif

sreg_tmp = SREG;
#asm("cli");

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(0x40 + start);                       		// command byte (r/w == 0)  
spi_transfer(data);
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

SREG = sreg_tmp;
}


// ************************************************************************************************
/// \brief		Reads 8 bits at once beginning with "start"
///
/// @param[in]	id    - number of device in device array max7301_dev[]
/// @param[in]	start - Number of start port, range 4 .. 24
/// @return		state of 8 pins
// ************************************************************************************************
unsigned char max7301_read_8bit(unsigned char id, unsigned char start)
{
unsigned char data;
unsigned char sreg_tmp;

#ifdef MAX7301_CHECK_PARAMS
if (start<4 || start>31 || id>=MAX7301_MAX_CHIPS)
	{   	
	#ifdef MAX7301_DEBUG
	putsf("MAX7301 read_8bit Error!\r");
	#endif
	return;
	}
#endif
sreg_tmp = SREG;
#asm("cli");

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(READ_BIT | (0x40+start));   				// command byte (r/w == 1)
spi_transfer(0x00);                      				// dummy data
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high
#asm("nop");
gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(0x00);                      				// nop
data = spi_transfer(0x00);               				// dummy data
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high
   
SREG = sreg_tmp;
return data;
}


// ************************************************************************************************
/// \brief		Configure transition mask (interrupt mask) for Port 24..30
///
/// @param[in]	id    - number of device in device array max7301_dev[]
/// @param[in]	mask  - bitmask for ports 24..30. Bitwise OR of macros MAX7301_TR_P24... _P30
// ************************************************************************************************
void max7301_write_int_mask(unsigned char id, unsigned char mask)
{
unsigned char sreg_tmp;
#ifdef MAX7301_CHECK_PARAMS
if (id>=MAX7301_MAX_CHIPS)
	{   	
	#ifdef MAX7301_DEBUG
	putsf("MAX7301 write_int_mask Error!\r");
	#endif
	return;
	}
#endif
sreg_tmp = SREG;
#asm("cli");

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(0x06);                						// command byte (r/w == 0)  
spi_transfer(mask);
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

SREG = sreg_tmp;
}


// ************************************************************************************************
/// \brief		Write config (shutdown-mode & interrupt activ)
///
/// @param[in]	id    - number of device in device array max7301_dev[]
/// @param[in]	mode  - bitweise OR of macros MAX7301_SHUT_ENABLE, MAX7301_SHUT_DISABLE, 
///				     	MAX7301_INT_ENABLE and MAX7301_INT_DISABLE
// ************************************************************************************************
void max7301_write_config(unsigned char id, unsigned char mode)
{
unsigned char sreg_tmp;

#ifdef MAX7301_CHECK_PARAMS
if (id>=MAX7301_MAX_CHIPS)
	{   	
	#ifdef MAX7301_DEBUG
	putsf("MAX7301 write_config Error!\r");
	#endif
	return;
	}
#endif

sreg_tmp = SREG;
#asm("cli");

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(0x04);               						// command byte (r/w == 0)  
spi_transfer(mode);
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

SREG = sreg_tmp;
}


// ************************************************************************************************
/// \brief		Write 8 bits in MAX7301 internal address space 
///
/// @param[in]	id      - number of device in device array max7301_dev[]
/// @param[in]	address - Memory address, range 0x00 .. 0x5F
/// @param[in]	data    - data to write
// ************************************************************************************************
void max7301_write_address(unsigned char id, unsigned char address, unsigned char data)
{
unsigned char sreg_tmp;

#ifdef MAX7301_CHECK_PARAMS
if (id>=MAX7301_MAX_CHIPS || address>0x5F)
	{   	
	#ifdef MAX7301_DEBUG
	putsf("MAX7301 write_address Error!\r");
	#endif
	return;
	}
#endif

sreg_tmp = SREG;
#asm("cli");

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(address);   // command byte (r/w == 0)  
spi_transfer(data);
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

SREG = sreg_tmp;
}


// ************************************************************************************************
/// \brief		Reads 8 bits from MAX7301 internal address space 
///
/// @param[in]	id      - number of device in device array max7301_dev[]
/// @param[in]	address - Memory address, range 0x00 .. 0x5F
/// @return		data    - 8 Bit data
// ************************************************************************************************
unsigned char max7301_read_address(unsigned char id, unsigned char address)
{
unsigned char data;
unsigned char sreg_tmp;

#ifdef MAX7301_CHECK_PARAMS
if (id>=MAX7301_MAX_CHIPS || address>0x5F)
	{   	
	#ifdef MAX7301_DEBUG
	putsf("MAX7301 read_address Error!\r");
	#endif
	return;
	}
#endif

sreg_tmp = SREG;
#asm("cli");

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(READ_BIT | address);   // command byte (r/w == 1)
spi_transfer(0x00);                 // dummy data
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high
#asm("nop");
gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS low
spi_transfer(0x00);                 // nop
data = spi_transfer(0x00);          // dummy data
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

SREG = sreg_tmp;
return data;
}


#ifdef MAX7301_DEBUG
// ************************************************************************************************
/// \brief	    Checks SPI communication to MAX7301
///
/// @param[in]	id - number of device in device array max7301_dev[]
/// @retval		0  - error
/// @retval		1  - success
// ************************************************************************************************
unsigned char max7301_debug_probe(unsigned char id)
{
unsigned char tmp1, tmp2;

gpio_clear_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);// SS low
spi_transfer(0x55);
spi_transfer(0xAA);
tmp1 = spi_transfer(0x00);
tmp2 = spi_transfer(0x00);
gpio_set_pin_mask(max7301_dev[id].ss_port, max7301_dev[id].ss_pin);	// SS high

if (tmp1==0x55 && tmp2==0xAA)
	return 1;
else
	return 0;
}


// ************************************************************************************************
/// \brief	    Outputs MAX7301-internal memory
///
/// @param[in]	id - number of device in device array max7301_dev[]
// ************************************************************************************************
void max7301_debug_display_mem(unsigned char id)
{
unsigned char tmp, i;

printf("register map: \r\n");
for(i=0x04; i<0x60; i++)
	{
	tmp = max7301_read_address(id, i);
	printf("Add 0x%02X: 0x%02X \r\n", i, tmp);
	}
}


// ************************************************************************************************
/// \brief	    Output status of MAX7301 chip
///
/// @param[in]	id  - number of device in device array max7301_dev[]
// ************************************************************************************************
void max7301_debug_info(unsigned char id)
{
unsigned char tmp1;
unsigned char i;
   
printf("--MAX7301-Info Device-ID: %u--\r\n", id);
printf("Configuration:\r\n");
tmp1 = max7301_read_address(id, 0x04);
printf(" Shutdown Mode: ");
if (tmp1 & 0x01)
	printf("Disable\r\n");
else
	printf("Enable\r\n");
printf(" Transition Detection: ");
if (tmp1 & 0x80)
	{
	printf("Enable\r\n");
	printf(" Mask Register: ");
	tmp1 = max7301_read_address(id, 0x06);
	debug_display_8bit_pattern(tmp1);
	printf("\r\n");
	}
else
	printf("Disable\r\n");

printf("Port I/O:\r\n");
for (i=4; i<32; i++)
	{
	tmp1 = max7301_read_address(id, (i/4) + 0x08);
	tmp1 >>= ((i%4)*2);
	printf(" Port %2u: ", i);
	if ((tmp1&0x01) && !(tmp1&0x02))
		printf("OUTPUT  ");
	if (!(tmp1&0x01) && !(tmp1&0x02))
		printf("NOT DEF  ");
	if ((tmp1&0x01) && (tmp1&0x02))
		printf("IN With PULLUP  ");
	if (!(tmp1&0x01) && (tmp1&0x02))
		printf("IN Without PULLUP  ");
	tmp1 = max7301_read_address(id, i + 0x20);
	printf("Value: ");
	if (tmp1==1)
		printf("HIGH");
	else
		printf("LOW");
	printf("\r\n");
	}
}


// ************************************************************************************************
/// \brief	    Checks the id number of MAX7301s
///
/// @param[in]	id  - number of device in device array max7301_dev[]
/// @retval		0  - error
/// @retval		1  - id OK
// ************************************************************************************************
unsigned char max7301_debug_check_id(unsigned char id)
{
if (((id+1)>MAX7301_MAX_CHIPS)||(*(unsigned char*)max7301_dev[id] == 0xFF))
	{
	printf("MAX7301 Device-ID %u not registered!\r\n", id);
	return 0;
	}
if (!max7301_debug_probe(id))
	{
	putsf("SPI communication failed\r");
	return 0;
	}
return 1;
}


// ************************************************************************************************
/// \brief		Help infos to the terminal commands of MAX7301
///
// ************************************************************************************************
void max7301_debug_help(void)
{
putsf("\"max7301-info\" - all infos around the MAX7301\r");
putsf("\"max7301-mem <id>\" - displays all register of MAX7301 with correct <id>\r");
putsf("\"max7301-out <id> <port> <mode>\" - sets the <port> of <id> MAX7301 with <mode>\r");
putsf("\t\t(1==Output; 2==Input; 3==Input+Pullup)\r");
}


// ************************************************************************************************
/// \brief	    Command handler for debug commands
///
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void max7301_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
unsigned char i;
unsigned char registered_devices;
signed char param1, param2, param3;

if (mode == DEBUG_HANDLER_MODE_INFO)
    {
    putsf("MAX7301_DEBUG\r");
    }                   
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
	max7301_debug_help();
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
    {
    // add output for 'debug' command here
    }
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-info", 5)==0)
		{
		registered_devices = 0;
		for (i=0; i<MAX7301_MAX_CHIPS; i++)
			{
			if (*(unsigned char*)max7301_dev[i] != 0xFF)
				{
				registered_devices++;
				if (!max7301_debug_probe(i))
					{
					putsf("SPI communication failed\r");
					return;
					}
				else
					max7301_debug_info(i);
				}
			}
		printf("%1u MAX7301 devices found.\r\n", registered_devices);
		}
	else if (strncmpf(command, "-mem", 4)==0)
		{
		param1 = debug_get_int_parameter(command);
		if(max7301_debug_check_id(param1))
			max7301_debug_display_mem(param1);
		}
	else if (strncmpf(command, "-out", 4)==0)
		{
		param1 = debug_get_int_parameter(command);
		command = debug_search_parameter(command);	// steps over first parameter
		param2 = debug_get_int_parameter(command);
		command = debug_search_parameter(command);	// steps over second parameter
		param3 = debug_get_int_parameter(command);
		if (param2<4)
			param2=4;
		if (param2>31)
			param2=31;
		if (((param3<1)||(param3>3))&&(param3!=-1))
			param3=MAX7301_INPUT;
		if(max7301_debug_check_id(param1))
			{
			if (param3!=-1)
				max7301_port_config(param1, param2, param3);
		    printf("MAX7301-%u Port %u ", param1, param2);
			i = max7301_read_address(param1, param2/4+0x08);	// read config
		 	//printf("%x ", i);
			i >>=((param2%4)*2);	// shift the correct bits to the lowest 2 bits
			i &=0x03;				// delete upper 6 bits
		    //printf("%x ", i);
			if(i == MAX7301_OUTPUT)
			    printf("Output");
			if(i == MAX7301_INPUT)
			    printf("Input");
			if(i == (MAX7301_INPUT | MAX7301_PULLUP_ON))
			    printf("Input+Pullup");
			if (max7301_read_bit(param1, param2) != 0)
				{
			    max7301_write_bit(param1, param2, 0);
				putsf(" cleared\r");
		    	}
			else
				{
			    max7301_write_bit(param1, param2, 1);
				putsf(" set\r");
		    	}
	    	}
		}
	}
}
#endif 	// #ifdef MAX7301_DEBUG
#endif	// #ifdef MAX7301_ENABLE