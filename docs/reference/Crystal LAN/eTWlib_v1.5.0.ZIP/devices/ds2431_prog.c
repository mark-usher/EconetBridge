// ************************************************************************************************
///
/// \file 			ds2431_prog.c
/// \brief			Programming DS2431 1-wire EEPROM
///
/// \todo			contains stack-specific functions. They should be removed.
///
/// \date	 		$LastChangedDate: 2007-04-16 09:20:31 +0200 (Mo, 16 Apr 2007) $
/// \version 		$Rev: 665 $
///	\author  		Udo Jakobza, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#if defined(DS2431_PROG_ENABLE) && defined(DEBUG)

#include "1wire_irq.h"
#include "ds2431.h"
#include "ds2431_prog.h"
#include "debug.h"


// local prototypes
void ds2431_prog_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);
                                              
// ************************************************************************************************
/// \brief      init the ds2431_prog software module
/// \remarks    this function should be called once after reset
// ************************************************************************************************
void ds2431_prog_init(void)
{
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &ds2431_prog_debug_handler;
p_struct.id_string = "ds2431";
debug_register_handler(&p_struct);
}


// *********************************************************************************
/// \brief                      eeprom protection
/// \param[in] romcode          romcode of device to protect
/// \param[in] page_address     memory page to protect
/// \param[in] mode             protect mode
/// \return                     1 - success; 0 - failure
// *********************************************************************************
unsigned char ds2431_prog_protect_eeprom(unsigned char *romcode, unsigned char page_no, unsigned char mode)
{
unsigned char   data[DS2431_SCRATCHPAD_SIZE]={0};
unsigned char   Lva;
signed int      rx_char;

if(page_no>DS2431_MEMORY_PAGE_3)
    return 0;
data[page_no] = mode;
printf("Protect page %u with mode 0x%02x?\r\n", page_no, mode);
putsf("Press \"1\" to continue \"ESC\" to abort!\r");
while(1)
	{
	#asm("wdr");   		 	    // Reset Watchdog
	rx_char = debug_check_rx();	// Debug data Receive Complete
   	if(rx_char>0)
   	    {
   	    Lva = (unsigned char)rx_char;
		if(Lva==0x1b)	        // ESC-Sign
    		return 0;
		if(Lva=='1')
			return ds2431_write_eeprom(romcode, data, DS2431_REGISTER_ADD, DS2431_SCRATCHPAD_SIZE);
		}
	}
return 0;
}


unsigned char mac[8];		// MAC-Size + 2dummy bytes
// *********************************************************************************
/// \brief                  get MAC address from string
/// \param[in] command      string to find MAC address in
/// \return                 1 - MAC address found; 0 - none found
// *********************************************************************************
unsigned char ds2431_prog_string2mac(unsigned char *command)
{
unsigned char	Lva=0, Lvc=0;

if(command[Lva]!=0x0)
	{
	for(Lva=Lva;Lva<strlen(command);Lva++)
		{
		if(command[Lva]==':')
	  		{
			mac[Lvc]=(toint(command[Lva-2])<<4);
			mac[Lvc]|=toint(command[Lva-1]);
			Lvc++;
			}
		if(Lvc==5)
		    break;		// stops the conversion
		}
	if(Lvc<5)
	    return 0;		// wrong count of MAC-address-parts
	mac[Lvc]=(unsigned char)(toint(command[Lva+1])<<4);
	mac[Lvc]|=(unsigned char)toint(command[Lva+2]);
	mac[6]=(unsigned char)((__CODEVISIONAVR__)&0x00ff);
	mac[7]=(unsigned char)(((__CODEVISIONAVR__)>>8)&0x00ff);
	return 1;
	}
return 0;
}


// *********************************************************************************
/// \brief                  writes the new MAC address to DS2431-EEPROM
///                         and protects memory page if necessary
/// \param[in] command      string containing MAC address
/// \param[in] address      eeprom address to write MAC at
/// \return                 1 - success; 0 - failure
/// \remarks                mac address must be stored in page DS2431_EEPROM_PAGE_MAC
///                         to work properly
// *********************************************************************************
void ds2431_prog_mac(unsigned char *command, unsigned char address)
{
unsigned char romcodes_1wire[BOARD_MAX_1WIRE_DEVICES, 9];
          
if(ds2431_find(romcodes_1wire) && ds2431_prog_string2mac(command))
	{
    if(ds2431_write_eeprom(&romcodes_1wire[0,0], mac, address, DS2431_SCRATCHPAD_SIZE))
        {
        printf("DS2431 mac address:\r\n%02x:%02x:%02x:%02x:%02x:%02x\r\n", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
        printf("DS2431 successfully written at EEPROM address 0x%02x\r\n\n", address);
        if(ds2431_prog_protect_eeprom(&romcodes_1wire[0,0], DS2431_EEPROM_PAGE_MAC, DS2431_WRITE_PROTECT))
            putsf("DS2431 write protection ok!\r\n");
        else
            putsf("DS2431 write protection failed!\r\n");
        return;
        }
	}
printf("DS2431 writing mac address failed!\r\n");
}


// *********************************************************************************
/// \brief               debug command handler
/// \param[in] command   pointer to command string
// *********************************************************************************
void ds2431_prog_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
unsigned char romcodes_1wire[BOARD_MAX_1WIRE_DEVICES,9];
unsigned char data_dummy[DS2431_MEMORY_SIZE];
unsigned int  param1=0, param2=0;
unsigned char i;

if(mode==DEBUG_HANDLER_MODE_INFO)
    {
	}
else if(mode==DEBUG_HANDLER_MODE_HELP)
    {
//    ds2431_prog_debug_cmd_list();
    // add output for 'help' command here
    }
else if(mode==DEBUG_HANDLER_MODE_SWITCH)
	{
	}
// if(mode==DEBUG_HANDLER_MODE_CMD) 
else if(strncmpf(command, "-find", 5)==0)
	{
	param1 = ds2431_find(romcodes_1wire);
	printf("DS2431 found %u 1-wire-devices (only DS2431 listed)!\r\n", param1);
    for(i=0;i<param1;i++)
        debug_display_mem_hex(&romcodes_1wire[i][0], DS2431_SCRATCHPAD_SIZE, 0);
	}
else if(strncmpf(command, "-read", 5)==0)
	{
	ds2431_find(romcodes_1wire);
    if(ds2431_read_eeprom(&romcodes_1wire[0][0], data_dummy, 0, DS2431_MEMORY_SIZE)) // read 1st device
	    {
    	printf("DS2431 read (size: %u)\r\n", DS2431_MEMORY_SIZE);
        debug_display_mem_hex(data_dummy, DS2431_MEMORY_SIZE, DS2431_SCRATCHPAD_SIZE);    
    	}
    else
    	printf("DS2431 read error\r\n");
	}
else if(strncmpf(command, "-write", 6)==0)      // test write 1st device
	{
	param1 = debug_get_int_parameter(command);
	command = debug_search_parameter(command);
	param2 = debug_get_int_parameter(command);
	memset(data_dummy, param2, sizeof(data_dummy));
	ds2431_find(romcodes_1wire);
   	printf("DS2431 address: %u / data: %u (%u bytes)\r\n", param1, param2, param2);
    if(ds2431_write_eeprom(&romcodes_1wire[0][0], data_dummy, param1, param2))
        printf("DS2431 data (0x%02x) written (add: %u / size: %u)!\r\n", param2, param1, param2);
    else
        printf("S2431 writing EEPROM failed!\r\n");
	}
else if(strncmpf(command, "-clr", 4)==0)      // clear 1st device
    {
	memset(data_dummy, 0, sizeof(data_dummy));
	ds2431_find(romcodes_1wire);
    ds2431_write_eeprom(&romcodes_1wire[0][0], data_dummy, 0, DS2431_MEMORY_SIZE);
    }
else if(strncmpf(command, "-wp", 3)==0)
    {
	param1 = debug_get_int_parameter(command);
	command = debug_search_parameter(command);
	param2 = debug_get_int_parameter(command);
    ds2431_find(romcodes_1wire);
    if(ds2431_prog_protect_eeprom(&romcodes_1wire[param1][0], param2, DS2431_WRITE_PROTECT))
        printf("DS2431 write protection device %u enabled!\r\n", param2);
    else
        printf("DS2431 write protection failed!\r\n");
    }
else if(strncmpf(command, "-mac", 4)==0)     // prog mac to 1st device
    {
    command = debug_search_parameter(command);
    ds2431_prog_mac(command, DS2431_EEPROM_ADD_MAC);
    }
else if(strncmpf(command, "-sn", 3)==0)     // prog serial to 1st device
    {
    command = debug_search_parameter(command);
	ds2431_find(romcodes_1wire);
    if(ds2431_write_eeprom(&romcodes_1wire[0][0], command, DS2431_EEPROM_ADD_SERIAL, strlen(command)))
         printf("DS2431 serial number sccessfully written!\r\n");
    else
         printf("DS2431 writing of serial number failed!\r\n");
    }
}
#endif   // #if defined(DS2431_PROG_ENABLE) && defined(DEBUG)
