// ************************************************************************************************
///
/// \file 			keys.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup Device_Driver
/// \addtogroup Device_Driver
/// @{
/// \defgroup Keys
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define KEYS_ENABLE
#define KEYS_DEBUG
#define KEYS_INPUT_COUNT				1
#define KEYS_PULLUP_ENABLE
#define KEYS_PRESSED_COUNTER			2
#define KEYS_RELEASED_COUNTER			2
#define KEYS_PORT0						GPIO_PORTD
#define KEYS_BITMASK0					(1<<2)
//@}
#endif


#ifndef _KEYS_INCLUDED_
#define _KEYS_INCLUDED_
              
///	\def KEYS_ENABLE
///		This macro enables the whole keys module. It must be defined in project.h
///
///	\def KEYS_DEBUG
///		Defines debug output in keys module. No debug command handler is defined.
///
///	\def KEYS_INPUT_COUNT
///		Number of debounced inputs. Max. 16 Inputs are supported.
///
///	\def KEYS_PULLUP_ENABLE
///		During keys_init() the AVR internal pullup resistors are enabled.
///
///	\def KEYS_PRESSED_COUNTER
///		Number of 10ms-ticks until key input is considered as stable.
///
///	\def KEYS_RELEASED_COUNTER
///		Number of 10ms-ticks until key input is considered as stable.
///
///	\def KEYS_PORT0
///		The macros KEYS_PORTx define the port number for the input x.
///
///	\def KEYS_BITMASK0
///		The macros KEYS_BITMASKx define the bitmask for the input x.
///

#ifdef KEYS_ENABLE

#if (KEYS_INPUT_COUNT>16)
#error "KEYS: Only 16 channels supported. Reduce KEYS_INPUT_COUNT."
#endif

#ifndef KEYS_PRESSED_COUNTER
#define KEYS_PRESSED_COUNTER		5	// x*10ms ticks for first key-pressing
#endif
#ifndef KEYS_RELEASED_COUNTER
#define KEYS_RELEASED_COUNTER		5	// x*10ms ticks for key-realeasing
#endif

#if (KEYS_PRESSED_COUNTER<2)
#error "KEYS: KEYS_PRESSED_COUNTER too small (use >=2 only) !"
#endif
#if (KEYS_PRESSED_COUNTER>20)
#error "KEYS: KEYS_PRESSED_COUNTER too big (use <=20 only) !"
#endif
#if (KEYS_RELEASED_COUNTER<2)
#error "KEYS: KEYS_RELEASED_COUNTER too small (use >=2 only) !"
#endif
#if (KEYS_RELEASED_COUNTER>20)
#error "KEYS: KEYS_RELEASED_COUNTER too big (use <=20 only) !"
#endif

#pragma used+
void 	 		keys_init(void);
void 			keys_poll_10ms(void);
unsigned int 	keys_get_state(void);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library keys.c
#endif
#endif	// #ifdef KEYS_ENABLE
#endif	// #ifndef _KEYS_INCLUDED_

/// @}
/// @}