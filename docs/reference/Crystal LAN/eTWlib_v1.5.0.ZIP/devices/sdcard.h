// ************************************************************************************************
///
/// \file 			sdcard.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Nico M�ding, Hubert Nestler, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \addtogroup Device_Driver
/// @{
/// \defgroup SD_Card
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{

#define SDCARD_ENABLE
#define SDCARD_DEBUG
#define SDCARD_MMC_COMPATIBILITY
#define SDC_HW_DETECT_ENABLE		// enables hardware detection
#define CMD_CRC_ENABLE
#define POLL_BUSY_FLAG_SPI			(SPSR & 0x80)
#define SHIFT_REGISTER_SPI	   		SPDR
#define SDC_CHIP_SELECT_ACTIV		DDRB|=0x40
#define SDC_CHIP_SELECT_LOW			PORTB&=~0x40
#define SDC_CHIP_SELECT_HIGH		PORTB|=0x40
#define SDC_INIT_CARD_DETECTION		DDRB&=~0x01
#define SDC_POLL_CARD_DETECTION		(PINB.0)
#define SDC_INIT_WP_DETECTION		DDRB&=~0x02
#define SDC_POLL_WP_DETECTION   	((PINB&0x02)!=0)
//@}
#endif

#ifndef _SDCARD_INCLUDED_
#define _SDCARD_INCLUDED_


///	\def SDCARD_ENABLE
///		This macro enables the whole SD-Card Module. It must be defined in project.h
///
///	\def SDCARD_DEBUG
///		This macro enables all debug output and debug handler in sdcard.c and sdcard_debug.c.
///		It must be defined in project.h.
///
///	\def SDCARD_MMC_COMPATIBILITY
///		
///
///	\def SDC_HW_DETECT_ENABLE
///		
///
///	\def CMD_CRC_ENABLE
///		
///
///	\def POLL_BUSY_FLAG_SPI
///		
///
///	\def SHIFT_REGISTER_SPI
///		
///
///	\def SDC_CHIP_SELECT_ACTIV
///		
///
///	\def SDC_CHIP_SELECT_LOW
///		
///
///	\def SDC_CHIP_SELECT_HIGH
///		
///
///	\def SDC_INIT_CARD_DETECTION
///		
///
///	\def SDC_POLL_CARD_DETECTION
///		
///
///	\def SDC_INIT_WP_DETECTION
///		
///
///	\def SDC_POLL_WP_DETECTION
///		
///


// ************************************************************************************************
/// @name 	Macro Definition
/// \note 	The sd card commands are separated into several classes 
///			(class numbers which are not shown are irrelevant for the SPI mode).
/// \brief 	Command classes SPI mode: CLASS 0
//@{
#define SDC_GO_IDLE_STATE	 	 	 0		///< CMD0:  reset sd card
#define SDC_SEND_OP_COND	 	 	 1		///< CMD1:  send card initialization process
#define SDC_SEND_CSD	 	 	 	 9		///< CMD9:  send card specific data (CSD)
#define SDC_SEND_CID				10		///< CMD10: send card identification (CID)
#define SDC_STOP_TRANSMISSION   	12		///< CMD12: stop transmission during multiple block read operation
#define SDC_SEND_STATUS				13		///< CMD13: send status register
#define SDC_READ_OCR				58		///< CMD58: read OCR register
#define SDC_CRC_ON_OFF				59		///< CMD59: CRC option on or off
//@}

// ************************************************************************************************
/// @name Macro Definition
/// \brief 	Block read: CLASS 2
//@{
#define SDC_SET_BLOCKLEN			16		///< CMD16: block length definition
#define SDC_READ_SINGLE_BLOCK		17		///< CMD17: read block (length defined by -> SDC_SET_BLOCKLEN)
#define SDC_READ_MULTIPLE_BLOCK		18		///< CMD18: continouse block read operation (interrupted by -> SDC_STOP_TRANSMISSION)
//@}

// ************************************************************************************************
/// @name Macro Definition
/// \brief 	Block write: CLASS 4
//@{
#define SDC_WRITE_BLOCK				24		///< CMD24: write block (fixed block length of 512 bytes)
#define SDC_WRITE_MULTIPLE_BLOCK	25		///< CMD25: continouse block write operation (interrupted by -> SDC_STOP_TRANSMISSION)
#define	SDC_PROGRAM_CSD				27		///< CMD26: CSD programming
//@}

// ************************************************************************************************
/// @name Macro Definition
/// \brief Erase: CLASS 5
//@{
#define SDC_ERASE_WR_BLK_START_ADDR	32		///< CMD32: set first write block address
#define SDC_ERASE_WR_BLK_END_ADDR	33		///< CMD33: set last write block address
#define SDC_ERASE_SELECTED_BLOCK	38		///< CMD38: erase all previously selected write blocks
//@}

// ************************************************************************************************
/// @name Macro Definition
/// \brief Write-protection: CLASS 6
//@{
#define SDC_SET_WRITE_PROT			28		///< CMD28: set write protection bit (addressed group)
#define SDC_CLR_WRITE_PROT			29		///< CMD29: clear write protection bit (addressed group)
#define SDC_SEND_WRITE_PROT			30		///< CMD30: send status of write protection bit (next 32 wp-groups)
//@}

// ************************************************************************************************
/// @name Macro Definition
/// \brief Application specific: CLASS 8
//@{
#define SDC_APP_CMD					55		///< CMD55: application specific command
#define SDC_GEN_CMD					56		///< CMD56: get data block for application specific command (length defined by -> SDC_SET_BLOCKLEN)
//@}


// ************************************************************************************************
/// @name Macro Definition
/// \brief Application specific commands (used and reserved by the sd card)
/// \note The following commands must preceded by SDC_APP_CMD (CMD55):
//@{
#define SDC_CARD_STATUS				13		///< ACMD13: send card status
#define SDC_SEND_NUM_WR_BLOCKS		22		///< ACMD22: send number of well-written blocks
#define SDC_SET_WR_BLK_ERASE_COUNT	23		///< ACMD23: set number of write blocks to be pre-erased before writing
#define SDC_APP_OP_COND			    41		///< ACMD41: reset sd card (same meaning as -> SDC_GO_IDLE_STATE)
//@}


// ************************************************************************************************
/// @name Macro Definition
/// \brief Data bit-stream definition:
/// \note Commands are 6 bytes long and structured like follows:
//@{
#define SDC_START_BIT				64		///< initiated by a start bit (bit47 = 0), host bit (bit46 = 1) and ...
#define SDC_STOP_BIT   				 1		///< ... terminated by a stop bit (bit0 = 1)
#define SDC_CMD_LEN					 6  	///< all commands are 6 bytes (48 bit) long
#define SDC_NCR_DEL		 			 1		///< delay between command and response: NCR = 8 clock cycles (1 byte)
//@}


// ************************************************************************************************
/// @name Macro Definition
/// \brief Data block response token:
//@{
#define SDC_START_SINGLE_BLOCK		0xFE	///< start byte single block write
#define SDC_START_MULTIPLE_BLOCK	0xFC	///< start byte multiple block write
#define SDC_DATA_BLOCK_ACCEPTED		0x05	///< status byte data accepted
#define SDC_BLOCK_ERROR_CRC			0x0B	///< status byte CRC error
#define SDC_BLOCK_ERROR_WRITE		0x0D	///< status byte write error
#define SDC_STOP_MULT_BLOCK_WRITE	0xFD	///< stop byte transmission multiple block write
//@}


// ************************************************************************************************
/// @name Macro Definition
/// \brief SD Card response token:
/// \note There are 3 different response formats.
//@{
#define SDC_R1_LEN		1			///< R1/R1b -> 1 byte
#define SDC_R2_LEN		2			///< R2 -> 2 byte
#define SDC_R3_LEN		5			///< R3 -> 5 byte (only for READ_OCR command)
//@}


// ************************************************************************************************
/// @name Marco Definition
/// \brief Application specific error codes:
//@{
#define SDC_ERROR_RESET_CARD         1      ///< card reset failed
#define SDC_ERROR_NO_CARD			 2		///< no card inserted
#define SDC_ERROR_CARD_LOCKED		 3		///< card is locked (write protection)
#define SDC_ERROR_IDLE_STATE_TAAC    4		///< time out idle state process
#define SDC_ERROR_INIT_FAILED		 5		///< card was not initialized
#define SDC_ERROR_WRONG_ADDRESS		 6		///< misaligned address

#define SDC_ERROR_WRITE_TAAC		 7		///< time out after write (TAAC: time access)
#define SDC_ERROR_WRITE_CRC16		 8		///< write crc error
#define SDC_ERROR_WRITE_CARD		 9		///< write error card
#define SDC_ERROR_DATA_REJECTED		10		///< data rejected (write protection)

#define SDC_ERROR_READ_TAAC			11		///< time out read
#define SDC_ERROR_READ_CRC16		12		///< read crc error

#define SDC_ERROR_ERASE_SECTOR		13		///< erase error
#define SDC_ERROR_ADDR_SECTOR		14		///< address error sector
#define SDC_ERROR_SPI_BUSY_FLAG     15      ///< busy flag error spi-interface
//@}


// ************************************************************************************************
/// @name Marco Definition
/// \brief Counter configuration init sequence:
//@{
#define SDC_ERROR_COUNT_INIT     3          ///< init sequence after abort
#define SDC_ERROR_COUNT_RESET    6          ///< reset after error
#define SDC_ERROR_COUNT_IDLE  1000          ///< idle state after fail
//@}


// ************************************************************************************************
/// @name Marco Definition
/// \brief Additional timing configuration:
/// \note 1 cycle is equivalent to 8 SPI clocks.
//@{
#define SDC_NUM_WAIT_CYC_APU	  4000	    ///< number of wait cycles after power up (MAX: 65535)
#define SDC_NUM_WAIT_CYC_AOP	     1	    ///< number of wait cycles after each operation (MAX: 65535)
//@}


// ************************************************************************************************
/// @name Marco Definition
/// \brief Mode selection:
//@{
#define SDC_CMD_CRC_ENABLE				    ///< enable CRC checking for cmd (recommended)
//#define SDC_HW_DETECT_ENABLE
///< polls the detection input pins (hardware solution). If disabled the software sends cmd0 to detect the card (software solution).
//@}


// ************************************************************************************************
/// @name Marco Definition
/// \brief Status bit definition: sd card detection
//@{
#define SDC_STATUS_DETECTED		0x01				///< sd card detect indication
#define SDC_STATUS_LOCKED		0x02				///< sd card write protection
#define SDC_STATUS_INITIALIZED	0x04				///< sd card init procces done
//@}


// ************************************************************************************************
/// \struct csd
/// \brief  Card Specific Data (CSD) structure
// ************************************************************************************************
typedef struct {
	unsigned char reg_detect;						///< card detection register
	unsigned char error_code;						///< card error code
	unsigned int  block_size;						///< physical block size
	unsigned char sector_size;						///< erasable sector size
	unsigned long max_blocks;					    ///< max. number of blocks
	unsigned long memory_capacity;				    ///< device memory capacity
	unsigned long max_read_access_cyc;			    ///< max. read access time specification
	unsigned long max_write_access_cyc;			    ///< max. write access time specification
	unsigned char mmc;                              ///< mmc software detect flag
	unsigned int  erase_grp_size;					///< erasable group size (only for mmc)
	unsigned int  wp_grp_size;						///< write protection group size
	unsigned char wp_grp_enable;					///< write protection enable flag
	} CSD_STRUCTURE;


// prototypes
#pragma used+
void 		  sdc_main(void);
void          sdc_init(void);
void 		  sdc_check_detection(void);
unsigned char sdc_init_card(void);
unsigned char sdc_init_module(void);
unsigned char sdc_get_error_code(void);
unsigned int  sdc_get_block_size(void);
unsigned int  sdc_get_sector_size(void);
unsigned int  sdc_get_status_reg(void);
unsigned long sdc_get_mem_cap(void);
unsigned long sdc_get_num_blocks(void);
unsigned char sdc_status_detect(unsigned char opt);
unsigned int  sdc_send_cmd(unsigned char cmd, unsigned long arg, unsigned int res_len, unsigned char opt);
unsigned long sdc_get_addr_block(unsigned long block);
unsigned long sdc_get_numwr_blocks(void);

unsigned char sdc_read_data(unsigned long addr, unsigned char *buff, unsigned int len);
unsigned char sdc_write_data(unsigned long addr, unsigned char *buff, unsigned int len);
unsigned char sdc_erase_sector(unsigned long first_block, unsigned int num_sector);

unsigned char sdc_read_single_block(unsigned long addr, unsigned char *buff, unsigned int block_len);
unsigned char sdc_read_multiple_blocks(unsigned long block, unsigned char *buff, unsigned int num_blocks);

unsigned char sdc_write_single_block(unsigned long block, unsigned char *buff );
unsigned char sdc_write_multiple_blocks(unsigned long block, unsigned char *buff, unsigned int num_blocks);

unsigned char sdc_read_CID_Reg(unsigned char *buff);
unsigned char sdc_read_CSD_Reg(unsigned char *buff);
unsigned char sdc_read_OCR_Reg(unsigned char *buff);
unsigned long sdc_cctli(unsigned char *byte);

// @name Write protection & MMC ?!
// \note I have not tested the following functions by myself (done by Hubert Nestler as project work).
unsigned char sdc_clear_wp (unsigned long first_block, unsigned int num_groups);
unsigned char sdc_set_wp (unsigned long first_block, unsigned int num_groups);
unsigned char sdc_get_wp_status (unsigned long addr, unsigned char *buff);
unsigned long sdc_get_group_addr (unsigned long group);
unsigned char sdc_get_mmc_flag (void);
unsigned char sdc_get_wp_grp_enable (void);
#pragma used-


#ifdef COMMON_LIBRARY_ENABLE
#pragma library sdcard.c
#endif

#endif	// #ifndef _SDCARD_INCLUDED_
/// @}
/// @}