// ************************************************************************************************
///
/// \file 			cs8900.c
/// \brief			Driver for CS8900 LAN Controller
///
/// \todo			There are some problems with the I2C-SW8 interface after reset
/// \todo			I2C-SW16 interface doesn't work yet
/// \date	 		$LastChangedDate: 2007-03-08 14:30:10 +0100 (Do, 08 Mrz 2007) $
/// \version 		$Rev: 610 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// \par History
///					1.) 08.08.2003 Version 2.00
///					2.) 26.08.2003 Version 2.01
///						a.)	- CS8900-Interface supports now "CS8900_IO_PORT8", "CS8900_IO_PORT16"
///							"CS8900_I2C_HW_8", "CS8900_I2C_HW_16", "CS8900_I2C_SW_8" and 
///                         "CS8900_I2C_SW_16"
///					3.) 01.06.2004 Version 2.04
///						a.)	- new functions:
///					           "cs8900_rx_skip()" - Skip-Command, 
///                                      see CS8900-PacketPage-Register RxCFG (0x102)
///					           "cs8900_collision_counter()" - reads the TX-Collision-Counter, 
///                                      see CS8900-PacketPage-Register TxCOL (0x132)
///					           "cs8900_miss_counter()" - reads the RX-Miss-Counter, 
///                                      see CS8900-PacketPage-Register RxMISS (0x130)
///					4.) 12.08.2004 Version 2.04
///						a.)	- function "cs8900_init()" now with timeout (400ms);
///					--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef DEVICE_CS8900

// PORTA.x (address 0x1B)
// PORTB.x (address 0x18)
// PORTC.x (address 0x15)
// PORTD.x (address 0x12)
// the I2C Wire bus is connected to PORTC
// PORTC.2 (the data signal is bit 2)
#if defined(CS8900_I2C_SW_8)||defined(CS8900_I2C_SW_16)	// data to/from CS8900 over I2C-SW-Bus
#asm
	.equ __i2c_port=0x15
	.equ __sda_bit=1
	.equ __scl_bit=0
#endasm
#include <i2c.h>
#endif 		// #if defined(CS8900_I2C_SW_8)||defined(CS8900_I2C_SW_16)

#include <io.h>
#include <stdio.h>
#include <delay.h>
#include "cs8900.h"
#include "debug.h"
#include "cs8900_debug.h"

#if defined BOOTLOADER
	#include "bl_io_device.h"
#else 
	#include "device.h"
#endif	


CS8900_INIT_DATA cs8900_init_data[5] ={
	CS8900_PP_IA       , MAC_DEFAULT_1 | (MAC_DEFAULT_2 << 8),		// set our MAC as Individual Address
	CS8900_PP_IA + 2   , MAC_DEFAULT_3 | (MAC_DEFAULT_4 << 8),
	CS8900_PP_IA + 4   , MAC_DEFAULT_5 | (MAC_DEFAULT_6 << 8),
	CS8900_PP_LINE_CTL , SERIAL_RX_ON | SERIAL_TX_ON,				// configure the Physical Interface
	#ifdef CS8900_TX_PADDING_DISABLE
	CS8900_PP_RX_CTL   , RX_RUNT_ACCEPT | RX_IA_ACCEPT | RX_BROADCAST_ACCEPT};
	#else
	CS8900_PP_RX_CTL   , RX_OK_ACCEPT | RX_IA_ACCEPT | RX_BROADCAST_ACCEPT};
	#endif

#ifdef CS8900_IO_PORT8		// data to/from CS8900 over Port-IO
void			_cs8900_w_port8(unsigned char address, unsigned char data);
unsigned char 	_cs8900_r_port8(unsigned char address);
#endif

#ifdef CS8900_IO_PORT16		// data to/from CS8900 over Port-IO
void			_cs8900_w_port16(unsigned char address, unsigned int data);
unsigned int 	_cs8900_r_port16(unsigned char address, ENDIAN_MODE mode);
#endif

#if defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_HW_16)	// data to/from CS8900 over I2C-HW-Bus
void 		  	i2c_write_hw(unsigned char i2c_device, unsigned char address_data);
unsigned char 	i2c_read_hw(unsigned char i2c_device);
void 		  	i2c_wait(void);
void 		  	i2c_send(void);
#endif

#ifdef CS8900_I2C_HW_8
void			_cs8900_w_i2c_hw8(unsigned char address, unsigned char data);
unsigned char 	_cs8900_r_i2c_hw8(unsigned char address);
#endif

#ifdef CS8900_I2C_HW_16
void			_cs8900_w_i2c_hw16(unsigned char address, unsigned int data);
unsigned int 	_cs8900_r_i2c_hw16(unsigned char address, ENDIAN_MODE mode);
#endif

#if defined(CS8900_I2C_SW_8)||defined(CS8900_I2C_SW_16)	// data to/from CS8900 over I2C-SW-Bus
void 		  	i2c_write_sw(unsigned char i2c_device, unsigned char address_data);
unsigned char 	i2c_read_sw(unsigned char i2c_device);
#endif

#ifdef CS8900_I2C_SW_8
void			_cs8900_w_i2c_sw8(unsigned char address, unsigned char data);
unsigned char 	_cs8900_r_i2c_sw8(unsigned char address);
#endif

#ifdef CS8900_I2C_SW_16
void			_cs8900_w_i2c_sw16(unsigned char address, unsigned int data);
unsigned int 	_cs8900_r_i2c_sw16(unsigned char address, ENDIAN_MODE mode);
#endif

// ************************************************************************************************
/// \brief		Initializes the CS8900 module
///
/// \note		Should be called only once
/// @retval		0 - Error, wrong interface 
/// @retval		1 - OK
// ************************************************************************************************
unsigned char cs8900_init(void)
{
#ifdef CS8900_DEBUG
cs8900_debug_init();
#endif

return cs8900_controller_init();
}


// ************************************************************************************************
/// \brief		Initializes the LAN-controller
///
/// 			Resets the controller and sends the configuration-sequence (cs8900_init_data[])
/// @retval		0 - Error, wrong interface 
/// @retval		1 - OK
// ************************************************************************************************
unsigned char cs8900_controller_init(void)
{
unsigned char Lva=0;

// --------------------------------------------------------------------------------
// Init CS8900-Power- and Reset-lines
// -------------------------------------------------------------------------------- 
CS8900_RESET_L;				// RES_CS89
CS8900_RESET_OUTPUT;		// RES_CS89 Output
CS8900_SLEEP_H;				// /SLEEP
CS8900_SLEEP_OUTPUT;		// /SLEEP Output

// --------------------------------------------------------------------------------
// Init CS8900-Traffic-lines
// -------------------------------------------------------------------------------- 
CS8900_TRAFFIC_RECEIVE_H;			// disable Receive Traffic
CS8900_TRAFFIC_RECEIVE_OUTPUT;		// activate Receive Traffic
CS8900_TRAFFIC_TRANSMIT_H;			// disable Transmit Traffic
CS8900_TRAFFIC_TRANSMIT_OUTPUT;		// activate Transmit Traffic

// --------------------------------------------------------------------------------
// Init CS8900-Control-lines
// -------------------------------------------------------------------------------- 
#if defined(CS8900_IO_PORT8)||defined(CS8900_IO_PORT16)||\
    defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_8)||defined(CS8900_I2C_SW_16)
CS8900_SBHE_H;				// /SBHE High
CS8900_SBHE_OUTPUT;			// /SBHE Output
CS8900_IOR_H;				// /IOR_ETH
CS8900_IOR_OUTPUT;			// /IOR_ETH
CS8900_IOW_H;				// /IOW_ETH
CS8900_IOW_OUTPUT;			// /IOW_ETH
#endif	// #if defined(CS8900_IO_PORT8)||defined(CS8900_IO_PORT16)|| ...

// --------------------------------------------------------------------------------
// Init CS8900-16bit-function
// -------------------------------------------------------------------------------- 
#if defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)||defined(CS8900_IO_PORT16)
CS8900_SBHE_L;				// /SBHE Low
#asm("nop");	 			// nesessary to set PORT-Pin
CS8900_SBHE_H;				// /SBHE High
#endif	// #if defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)||defined(CS8900_IO_PORT16)

// --------------------------------------------------------------------------------
// Init CS8900-Port-Interface
// -------------------------------------------------------------------------------- 
#if defined(CS8900_IO_PORT8)||defined(CS8900_IO_PORT16)
CS8900_ADR_DDR;				// A0..A3
CS8900_DATA_INPUT;			// AD0..AD7
CS8900_DATA_W=0xff;	   		// AD0..AD7 enable Pullup 
#endif	// #if defined(CS8900_IO_PORT8)||defined(CS8900_IO_PORT16)

#ifdef CS8900_IO_PORT16
CS8900_DATA16_INPUT;		// AD8..AD15
CS8900_DATA16_W=0xff;		// AD8..AD15 enable Pullup
#endif	// #ifdef CS8900_IO_PORT16

// --------------------------------------------------------------------------------
// Init CS8900-I2C-Interface
// -------------------------------------------------------------------------------- 
#if defined(CS8900_I2C_SW_8)||defined(CS8900_I2C_SW_16)
i2c_init();
#endif	// #if defined(CS8900_I2C_SW_8)||defined(CS8900_I2C_SW_16)
#if defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_HW_16)
TWCR=0x01;                  // twi enable
TWSR=I2C_TWPS1 | I2C_TWPS0;	// dividerexponent=1
TWBR=0x03;					// ->400kHz
#endif	// #if defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_HW_16)

cs8900_software_wakeup();
if((cs8900_read_io_reg16_le(IO_PORT_ADD) & 0x3000)==0)	// reads the SelfST-Register-Address (Register 16)
	{
	#ifdef CS8900_DEBUG
	if(cs8900_debug_flag)
		printf("CS8900 IObase+0Ah: 0x%04x\r\n", cs8900_read_io_reg16_le(IO_PORT_ADD));
	#endif	// #ifdef CS8900_DEBUG
	return 0;
	}
cs8900_software_reset();
delay_ms(10);
cs8900_write_io_reg16(IO_PORT_ADD, CS8900_PP_SELF_ST);			    // set the SelfST-Register-Address (Register 16; addess 0x0136)
while(!(cs8900_read_io_reg16_le(IO_PORT_DATA) & SELF_ST_INITD))		// wait until chip-reset is done
	{
	delay_ms(100);
	Lva++;
	if(Lva>4)
		{
		#ifdef CS8900_DEBUG
		if (cs8900_debug_flag)
			printf("CS8900 CS8900_PP_SELF_ST: 0x%04x\r\n", cs8900_read_io_reg16_le(IO_PORT_DATA));
		#endif	// #ifdef CS8900_DEBUG
		return 0;
		}
	}
for (Lva = 0; Lva < sizeof(cs8900_init_data)/sizeof(CS8900_INIT_DATA); Lva++)	// configure the CS8900
	cs8900_write_packetpage16(cs8900_init_data[Lva].addr, cs8900_init_data[Lva].data);
return 1;
}


//*********************************************************************************
// Description	: set a new MAC to Ethernetcontroller
// Input	   	: *new_mac: pointer to 6 Byte of MAC-Number
// Output      	: none
// Indication	: none
//*********************************************************************************
void cs8900_set_mac(unsigned char *new_mac)
{
cs8900_init_data[0].data=new_mac[0] | ((unsigned int)new_mac[1] << 8);	// set our MAC as Individual Address
cs8900_init_data[1].data=new_mac[2] | ((unsigned int)new_mac[3] << 8);
cs8900_init_data[2].data=new_mac[4] | ((unsigned int)new_mac[5] << 8);
}


//*********************************************************************************
// Description	: writes a word in little-endian byte order to a specified port-address
// Input  	 	: address - to CS8900 I/O Port
//              : data - data to write
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void cs8900_write_io_reg16(unsigned char address, unsigned int data)
{
#if defined(CS8900_MEMORY)||defined(CS8900_IO_PORT8)||defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_SW_8)
ETHER_IO_W(address, LO(data));
ETHER_IO_W(address+1, HI(data));   
#endif
#if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
ETHER_IO_W(address, data);
#endif
}


//*********************************************************************************
// Description	: reads a 16bit value
// Input	   	: address: to CS8900 I/O Port
// Output  	 	: RETURN - new 16bit value
// Indication	: reads a word in little-endian byte order from a specified port-address
//*********************************************************************************
unsigned int cs8900_read_io_reg16_le(unsigned char address)
{
#if defined(CS8900_MEMORY)||defined(CS8900_IO_PORT8)||defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_SW_8)
unsigned char value_low;
unsigned int value_high;

value_low=ETHER_IO_R(address);
value_high=ETHER_IO_R(address+1);
value_high<<=8;
value_high|=value_low;
return value_high;
#endif

#if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
return ETHER_IO_R_LE(address);
#endif
}

//********************************************************************************
// Description	: reads a 16bit value
// Input	   	: address: to CS8900 I/O Port
// Output  	 	: RETURN new 16bit value
// Indication	: reads a word in big-endian byte order from a specified port-address
//*********************************************************************************
unsigned int cs8900_read_io_reg16_be(unsigned char address)
{
#if defined(CS8900_MEMORY)||defined(CS8900_IO_PORT8)||defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_SW_8)
unsigned int	value;

value=ETHER_IO_R(address);
value<<=8;
value|=ETHER_IO_R(address+1);
return value;
#endif
#if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
return ETHER_IO_R_BE(address);
#endif
}

//*********************************************************************************
// Description	: reads a word in little-endian byte order from a specified port-address
// Input	   	: address: to CS8900 I/O Port
// Output  	 	: RETURN new 16bit value
// Indication	: this func. xfers the high-byte 1st, must be used to access some 
//				  special registers (e.g. RxStatus)
//*********************************************************************************
unsigned int cs8900_read_io_reg16_HB1ST(unsigned char address)
{
#if defined(CS8900_MEMORY)||defined(CS8900_IO_PORT8)||defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_SW_8)
unsigned int value;

value=ETHER_IO_R(address+1);
value<<=8;
value|=ETHER_IO_R(address);
return value;
#endif
#if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
return ETHER_IO_R_LE(address);
#endif
}

//*********************************************************************************
// Description	: write to PacketPage-Register of CS8900
// Input  	 	: address: address of internal register
//                data: data to write
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void cs8900_write_packetpage16(unsigned int address, unsigned int data)
{
cs8900_write_io_reg16(IO_PORT_ADD, address);  	// set address to ADD-PORT
cs8900_write_io_reg16(IO_PORT_DATA, data);		// write from DATA-Port
}

//*********************************************************************************
// Description	: reads from PacketPage-Register of CS8900
// Input  	 	: address: address of internal register
// Output  	 	: RETURN - data of register
// Indication	: reads a word in little-endian byte order from a register-address
//*********************************************************************************
unsigned int cs8900_read_packetpage16_le(unsigned int address)
{
cs8900_write_io_reg16(IO_PORT_ADD, address);		// set address to ADD-PORT
return cs8900_read_io_reg16_le(IO_PORT_DATA);		// read data from ADD-PORT addressed register
}

//*********************************************************************************
// Description	: reads from PacketPage-Register of CS8900
// Input  	 	: address: address of internal register
// Output  	 	: RETURN - data of register
// Indication	: reads a word in big-endian byte order from a register-address
//*********************************************************************************
unsigned int cs8900_read_packetpage16_be(unsigned int address)
{
cs8900_write_io_reg16(IO_PORT_ADD, address);		// set address to ADD-PORT
return cs8900_read_io_reg16_be(IO_PORT_DATA);		// read data from ADD-PORT addressed register
}


//*********************************************************************************
// Description	: copies bytes from MCU-memory to frame port
// Input	   	: *source: pointer to data from MC
//			   	  size: size of data
// Output  	 	: none
// Indication	: an odd number of byte may only be transfered
//				  if the frame is written to the end!
//*********************************************************************************
void cs8900_write_frame(void *source, unsigned int byte_size)
{
#if defined(CS8900_MEMORY)||defined(CS8900_IO_PORT8)||defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_SW_8)
unsigned char	*p_data;
#endif
#if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
unsigned int	*p_data;
#endif

CS8900_TRAFFIC_TRANSMIT_L;
p_data=source;
while(byte_size > 1)
	{
	ETHER_IO_W(IO_PORT_TX_RX, *p_data);
	p_data++;
	#if defined(CS8900_MEMORY)||defined(CS8900_IO_PORT8)||defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_SW_8)
	ETHER_IO_W(IO_PORT_TX_RX+1, *p_data);
	p_data++;
	#endif
	byte_size-=2;
	#asm("wdr");			// Reset Watchdog
	}
if(byte_size)			   		// if odd num. of bytes...
	{
	ETHER_IO_W(IO_PORT_TX_RX, *p_data);
	#if defined(CS8900_MEMORY)||defined(CS8900_IO_PORT8)||defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_SW_8)
	p_data++;
	ETHER_IO_W(IO_PORT_TX_RX+1, *p_data);
	#endif
	}
CS8900_TRAFFIC_TRANSMIT_H;
}										


//*********************************************************************************
// Description	: copies bytes from frame port to MCU-memory
// Input	   	: *source: pointer to buffer from MC
//			   	  size: size of data
// Output	   	: *source: data inside of pointer to buffer from MC
// Indication	: an odd number of byte may only be transfered if the frame is read to the end!
//*********************************************************************************
void cs8900_read_frame(void *dest, unsigned int byte_size)
{
#if defined(CS8900_MEMORY)||defined(CS8900_IO_PORT8)||defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_SW_8)
unsigned char	*p_data;
#endif
#if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
unsigned int	*p_data;
#endif

CS8900_TRAFFIC_RECEIVE_L;
p_data=dest;
while(byte_size > 1)
	{
	#if defined(CS8900_MEMORY)||defined(CS8900_IO_PORT8)||defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_SW_8)
	*p_data=ETHER_IO_R(IO_PORT_TX_RX);	// get 1st byte from data bus (low-byte)
	p_data++;
	*p_data=ETHER_IO_R(IO_PORT_TX_RX+1);// get 2nd byte from data bus (high-byte)
    #endif
	#if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
	*p_data=ETHER_IO_R_LE(IO_PORT_TX_RX);	// get 1st byte from data bus (low-byte)
    #endif
	p_data++;
	byte_size -= 2;
	#asm("wdr");			// Reset Watchdog
	}
if(byte_size)								// check for leftover byte...
	{
	#if defined(CS8900_MEMORY)||defined(CS8900_IO_PORT8)||defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_SW_8)
	*p_data=ETHER_IO_R(IO_PORT_TX_RX);	// get last byte from data bus (low-byte)
	#pragma warn-
	ETHER_IO_R(IO_PORT_TX_RX+1);		// get 2nd byte from data bus (high-byte)
										// the LAN-Controller will return 0 for the highbyte
	#pragma warn+
	#endif // #if defined(CS8900_MEMORY)||defined(CS8900_IO_PORT8)||defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_SW_8)
	#if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
	*p_data=ETHER_IO_R_LE(IO_PORT_TX_RX);	// get last byte from data bus (low-byte)
    #endif
	}
CS8900_TRAFFIC_RECEIVE_H;
}


//*********************************************************************************
// Description	: discards an EVEN number of bytes from RX-fifo
// Input	   	: size: size of data
// Output  	 	: none
// Indication	: only an even number of bytes is read!
//*********************************************************************************
void cs8900_read_dummyframe(unsigned int size)
{
while(size > 1)
	{
	CS8900_TRAFFIC_RECEIVE_L;
	#pragma warn-
	#if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
	ETHER_IO_R_LE(IO_PORT_TX_RX);		// get 2 bytes from data bus
	#endif
	#if defined(CS8900_MEMORY)||defined(CS8900_IO_PORT8)||defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_SW_8)
	ETHER_IO_R(IO_PORT_TX_RX);		// get 1st byte from data bus (low-byte)
	ETHER_IO_R(IO_PORT_TX_RX+1);	// get 2nd byte from data bus (high-byte)
	#endif
	#pragma warn+
	size -= 2;
	#asm("wdr");			// Reset Watchdog
	CS8900_TRAFFIC_RECEIVE_H;
	}
}

//*********************************************************************************
// Description	: requests space in CS8900's on-chip memory for storing an outgoing frame
//				  and check if CS8900 is ready to accept the frame we want to send
// Input	   	: frame_size: size of frame
// Output  	 	: equal 0 no ready; unequally 0 - ready
// Indication	: none
//*********************************************************************************
unsigned int cs8900_transmit_ready(unsigned int frame_size)
{
#ifdef CS8900_TX_PADDING_DISABLE
cs8900_write_io_reg16(IO_PORT_TX_CMD, TX_CMD_PAD_DIS | TX_CMD_START_ALL_BYTES);
#else
cs8900_write_io_reg16(IO_PORT_TX_CMD, TX_CMD_START_ALL_BYTES);
#endif
cs8900_write_io_reg16(IO_PORT_TX_LEN, frame_size);
cs8900_write_io_reg16(IO_PORT_ADD, CS8900_PP_BUS_ST);
return (cs8900_read_io_reg16_le(IO_PORT_DATA) & READY_FOR_TX_NOW);
}

//*********************************************************************************
// Description	: activates the Software-Suspend Mode
// Input	   	: none
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void	cs8900_software_sleep(void)
{
cs8900_write_io_reg16(IO_PORT_ADD, CS8900_PP_SELF_CTL);			 	// dummy write to Wakeup
delay_ms(10);
cs8900_write_packetpage16(CS8900_PP_SELF_CTL, SELF_CTL_SW_SUSPEND);         // set the Software Suspend Mode
}	

//*********************************************************************************
// Description	: deactivates the Software-Suspend Mode
// Input	   	: none
// Output  	 	: RETURN 1 every time
// Indication	: none
//*********************************************************************************
void	cs8900_software_wakeup(void)
{
cs8900_write_io_reg16(IO_PORT_ADD, CS8900_PP_SELF_CTL);			 		// dummy write to Wakeup
delay_ms(10);
}

//*********************************************************************************
// Description	: software reset of CS8900
// Input	  	: none
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void cs8900_software_reset(void)
{
cs8900_write_packetpage16(CS8900_PP_SELF_CTL, SELF_CTL_RESET);		// Software-Reset the Ethernet-Controller
#if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
CS8900_SBHE_L;			// /SBHE Low
#asm("nop");	 		// nesessary to set PORT-Pin
CS8900_SBHE_H;			// /SBHE High
#endif	// #if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
}


//*********************************************************************************
// Description	: hardware reset of CS8900
// Input	  	: none
// Output  	 	: none
// Indication	: available only with define of CS8900_RESET_H and CS8900_RESET_H
//*********************************************************************************
void cs8900_hardware_reset(void)
{
CS8900_RESET_H;			// RES_CS89
delay_us(20);			// nesessary, because 100nF has about 8�s rise/fall time
CS8900_RESET_L;			// RES_CS89
#if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
CS8900_SBHE_L;			// /SBHE Low
#asm("nop");	 		// nesessary to set PORT-Pin
CS8900_SBHE_H;			// /SBHE High
#endif	// #if defined(CS8900_IO_PORT16)||defined(CS8900_I2C_HW_16)||defined(CS8900_I2C_SW_16)
}


//*********************************************************************************
// Description	: skip the actual frame
// Input	 	: none
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void cs8900_rx_skip(void)
{
cs8900_write_packetpage16(CS8900_PP_RX_CFG, SKIP_1);
}


//*********************************************************************************
// Description	: count of collisions during sending
// Input	 	: none
// Output  	 	: RETURN content of CS8900_PP_TX_COL
// Indication	: none
//*********************************************************************************
unsigned int cs8900_collision_counter(void)
{
unsigned int data;

data=cs8900_read_packetpage16_le(CS8900_PP_TX_COL);
data>>=6;  		// delete lower 6Bits
return data;
}

//*********************************************************************************
// Description	: count of miss frames
// Input	 	: none
// Output  	 	: RETURN content of CS8900_PP_RX_MISS
// Indication	: register "CS8900_PP_RX_MISS" will be deleted
//*********************************************************************************
unsigned int cs8900_miss_counter(void)
{
unsigned int data;

data=cs8900_read_packetpage16_le(CS8900_PP_RX_MISS);
data>>=6;  		// delete lower 6Bits
return data;  
}


#ifdef CS8900_I2C_SW_8		// data to/from CS8900 over I2C-SW-Bus
//*********************************************************************************
// Description	: writes a byte to CS8900
// Input  	 	: 1.) address: hardware-address of CS8900
//               2.) data: data to CS8900
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void _cs8900_w_i2c_sw8(unsigned char address, unsigned char data)
{
i2c_write_sw(I2C_ADDRESS_EXPANDER & I2C_AND_WRITE_MODE, address);
i2c_write_sw(I2C_DATA8_EXPANDER & I2C_AND_WRITE_MODE, data);
//delay_us(4);			// delay of 4�sec (see Spec of PCF8574; tpv)
CS8900_IOW_L;        	// /IOW_ETH
#asm("nop");	 		// nesessary to set PORT-Pin
CS8900_IOW_H;			// /IOW_ETH
}

//*********************************************************************************
// Description	: reads a byte from CS8900
// Input  	 	: 1.) address: hardware-address of CS8900
// Output  	 	: data - data from CS8900
// Indication	: none
//*********************************************************************************
unsigned char 	_cs8900_r_i2c_sw8(unsigned char address)
{
unsigned char data=0x00;

i2c_write_sw(I2C_ADDRESS_EXPANDER & I2C_AND_WRITE_MODE, address);
//delay_us(4);			// delay of 4�sec (see Spec of PCF8574; tpv)
CS8900_IOR_L;			// /IOR_ETH
data=i2c_read_sw(I2C_DATA8_EXPANDER | I2C_OR_READ_MODE);
CS8900_IOR_H;		  	// /IOR_ETH
return data;
}
#endif	// #ifdef CS8900_I2C_SW_8


#ifdef CS8900_I2C_SW_16		// data to/from CS8900 over I2C-SW-Bus
//*********************************************************************************
// Description	: writes a WORD to CS8900
// Input  	 	: 1.) address: hardware-address of CS8900
//               2.) data: data to CS8900
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void _cs8900_w_i2c_sw16(unsigned char address, unsigned int data)
{
CS8900_SBHE_L;			// /SBHE Low
i2c_write_sw(I2C_ADDRESS_EXPANDER & I2C_AND_WRITE_MODE, address);
i2c_write_sw(I2C_DATA16_EXPANDER & I2C_AND_WRITE_MODE, data>>8);
i2c_write_sw(I2C_DATA8_EXPANDER & I2C_AND_WRITE_MODE, data);
//delay_us(4);			// delay of 4�sec (see Spec of PCF8574; tpv)
CS8900_IOW_L;        	// /IOW_ETH
#asm("nop");	 		// nesessary to set PORT-Pin
CS8900_IOW_H;			// /IOW_ETH
CS8900_SBHE_H;			// /SBHE High
}

//*********************************************************************************
// Description	: reads a byte from CS8900
// Input  	 	: 1.) address: hardware-address of CS8900
// Output  	 	: data - data from CS8900
// Indication	: none
//*********************************************************************************
unsigned int 	_cs8900_r_i2c_sw16(unsigned char address, ENDIAN_MODE mode)
{
unsigned int data_2;
unsigned char data_1;

CS8900_SBHE_L;				// /SBHE Low
i2c_write_sw(I2C_ADDRESS_EXPANDER & I2C_AND_WRITE_MODE, address);
//delay_us(4);													// delay of 4�sec (see Spec of PCF8574; tpv)
CS8900_IOR_L;											   		// /IOR_ETH
if(mode==LITTLE_ENDIAN)
	{
	data_2= i2c_read_sw(I2C_DATA16_EXPANDER | I2C_OR_READ_MODE);	// AD8..AD15
	data_1= i2c_read_sw(I2C_DATA8_EXPANDER | I2C_OR_READ_MODE);		// AD0..AD7
	}
else
	{
	data_1= i2c_read_sw(I2C_DATA16_EXPANDER | I2C_OR_READ_MODE);	// AD8..AD15
	data_2= i2c_read_sw(I2C_DATA8_EXPANDER | I2C_OR_READ_MODE);		// AD0..AD7
	}	
CS8900_IOR_H;		  		// /IOR_ETH
CS8900_SBHE_H;				// /SBHE High
data_2<<=8;
data_2|=data_1;
return data_2;
}
#endif	// #ifdef CS8900_I2C_SW_16


#ifdef CS8900_I2C_HW_8		// data to/from CS8900 over I2C-hw-Bus
//*********************************************************************************
// Description	: writes a byte to CS8900
// Input  	 	: 1.) address: hardware-address of CS8900
//               2.) data: data to CS8900
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void _cs8900_w_i2c_hw8(unsigned char address, unsigned char data)
{
i2c_write_hw(I2C_ADDRESS_EXPANDER & I2C_AND_WRITE_MODE, address);	// write address over i2c-address-expander to CS8900 address-input
i2c_write_hw(I2C_DATA8_EXPANDER & I2C_AND_WRITE_MODE, data);		// write data over i2c-data-expander to CS8900 data-input
//delay_us(4);			// delay of 4�sec (see Spec of PCF8574; tpv)
CS8900_IOW_L;        	// /IOW_ETH
#asm("nop");	 		// nesessary to set PORT-Pin
CS8900_IOW_H;			// /IOW_ETH
}

//*********************************************************************************
// Description	: reads a byte from CS8900
// Input  	 	: 1.) address: hardware-address of CS8900
// Output  	 	: data - data from CS8900
// Indication	: none
//*********************************************************************************
unsigned char 	_cs8900_r_i2c_hw8(unsigned char address)
{
unsigned char data=0x00;

i2c_write_hw(I2C_ADDRESS_EXPANDER & I2C_AND_WRITE_MODE, address);	// write address over i2c-address-expander to CS8900 address-input
//delay_us(4);													// delay of 4�sec (see Spec of PCF8574; tpv)
CS8900_IOR_L;											   		// /IOR_ETH
data = i2c_read_hw(I2C_DATA8_EXPANDER | I2C_OR_READ_MODE);			// supply the data over i2c-data-expander from CS8900 data-lines
CS8900_IOR_H;		  											// /IOR_ETH
return data;
}
#endif	// #ifdef CS8900_I2C_HW_8

#ifdef CS8900_I2C_HW_16		// data to/from CS8900 over I2C-hw-Bus
//*********************************************************************************
// Description	: writes a byte to CS8900
// Input  	 	: 1.) address: hardware-address of CS8900
//               2.) data: data to CS8900
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void _cs8900_w_i2c_hw16(unsigned char address, unsigned int data)
{
CS8900_SBHE_L;			// /SBHE Low
i2c_write_hw(I2C_ADDRESS_EXPANDER & I2C_AND_WRITE_MODE, address);	// write address over i2c-address-expander to CS8900 address-input
i2c_write_hw(I2C_DATA16_EXPANDER & I2C_AND_WRITE_MODE, data>>8);	// write high-data over i2c-data-expander to CS8900 data-input
i2c_write_hw(I2C_DATA8_EXPANDER & I2C_AND_WRITE_MODE, data);		// write low-data over i2c-data-expander to CS8900 data-input
//delay_us(4);			// delay of 4�sec (see Spec of PCF8574; tpv)
CS8900_IOW_L;        	// /IOW_ETH
#asm("nop");	 		// nesessary to set PORT-Pin
CS8900_IOW_H;			// /IOW_ETH
CS8900_SBHE_H;			// /SBHE High
}

//*********************************************************************************
// Description	: reads a byte from CS8900
// Input  	 	: 1.) address: hardware-address of CS8900
// Output  	 	: data - data from CS8900
// Indication	: none
//*********************************************************************************
unsigned int 	_cs8900_r_i2c_hw16(unsigned char address, ENDIAN_MODE mode)
{
unsigned int data_2;
unsigned char data_1;

CS8900_SBHE_L;				// /SBHE Low
i2c_write_hw(I2C_ADDRESS_EXPANDER & I2C_AND_WRITE_MODE, address);	// write address over i2c-address-expander to CS8900 address-input
//delay_us(4);													// delay of 4�sec (see Spec of PCF8574; tpv)
CS8900_IOR_L;											   		// /IOR_ETH
if(mode==LITTLE_ENDIAN)
	{
	data_2= i2c_read_hw(I2C_DATA16_EXPANDER | I2C_OR_READ_MODE);	// AD8..AD15
	data_1= i2c_read_hw(I2C_DATA8_EXPANDER | I2C_OR_READ_MODE);		// AD0..AD7
	}
else
	{
	data_1= i2c_read_hw(I2C_DATA16_EXPANDER | I2C_OR_READ_MODE);	// AD8..AD15
	data_2= i2c_read_hw(I2C_DATA8_EXPANDER | I2C_OR_READ_MODE);		// AD0..AD7
	}	
CS8900_IOR_H;		  		// /IOR_ETH
CS8900_SBHE_H;				// /SBHE High
data_2<<=8;
data_2|=data_1;
return data_2;
}
#endif	// #ifdef CS8900_I2C_HW_16


#ifdef CS8900_IO_PORT8		// data to/from CS8900 over Port-IO
//*********************************************************************************
// Description	: writes a byte to CS8900
// Input  	 	: 1.) address: hardware-address of CS8900
//                2.) data: data to CS8900
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void _cs8900_w_port8(unsigned char address, unsigned char data)
{
CS8900_ADR(address);	// A0..A3
CS8900_DATA_W=data;		// AD0..AD7
CS8900_DATA_OUTPUT;		// AD0..AD7
#asm("nop");	 		// nesessary to set PORT-Pin
CS8900_IOW_L;			// /IOW_ETH
#asm("nop");	 		// nesessary to set PORT-Pin
CS8900_IOW_H;			// /IOW_ETH
CS8900_DATA_INPUT;		// AD0..AD7
CS8900_DATA_W=0xff;		// AD0..AD7 enable Pullup 
}

//*********************************************************************************
// Description	: reads a byte from CS8900
// Input  	 	: 1.) address: hardware-address of CS8900
// Output  	 	: data - data from CS8900
// Indication	: none
//*********************************************************************************
unsigned char 	_cs8900_r_port8(unsigned char address)
{
unsigned char data;

CS8900_ADR(address);	// A0..A3
#asm("nop");	 		// nesessary to set PORT-Pin
CS8900_IOR_L;			// /IOR_ETH
// time between "CS8900_IOR_L" and "CS8900_DATA_R" is very critical, because CS8900 needs about 135ns to setup the 
// new data to bus
// 2 NOP's are nesessary with 7,3728Mhz Mainclock
#asm("nop");	 		// nesessary to set PORT-Pin
#if(_MCU_CLOCK_FREQUENCY_>4000000)
#asm("nop");	 		// nesessary to set PORT-Pin
#endif
#if(_MCU_CLOCK_FREQUENCY_>8000000)
#asm("nop");	 		// nesessary to set PORT-Pin
#endif
#if(_MCU_CLOCK_FREQUENCY_>12000000)
#asm("nop");	 		// nesessary to set PORT-Pin
#endif
#if(_MCU_CLOCK_FREQUENCY_>16000000)
#asm("nop");	 		// nesessary to set PORT-Pin
#endif
data=CS8900_DATA_R;		// AD0..AD7
CS8900_IOR_H;			// /IOR_ETH
return data;
}
#endif		//#ifdef CS8900_IO_PORT8


#ifdef CS8900_IO_PORT16		// data to/from CS8900 over Port-IO
//*********************************************************************************
// Description	: writes a 2byte to CS8900
// Input  	 	: 1.) address: hardware-address of CS8900
//                2.) data: data to CS8900
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void _cs8900_w_port16(unsigned char address, unsigned int data)
{
CS8900_SBHE_L;				// /SBHE Low
CS8900_ADR(address);		// A0..A3
CS8900_DATA_W=LO(data);		// AD0..AD7
CS8900_DATA_OUTPUT;			// AD0..AD7
CS8900_DATA16_W=HI(data);	// AD8..AD15
CS8900_DATA16_OUTPUT;		// AD8..AD15
#asm("nop");	 			// nesessary to set PORT-Pin
CS8900_IOW_L;				// /IOW_ETH
#asm("nop");	 			// nesessary to set PORT-Pin
CS8900_IOW_H;				// /IOW_ETH
CS8900_SBHE_H;				// /SBHE High
CS8900_DATA_INPUT;			// AD0..AD7
CS8900_DATA_W=0xff;			// AD0..AD7 enable Pullup 
CS8900_DATA16_INPUT;  		// AD8..AD15 
CS8900_DATA16_W=0xff; 		// AD8..AD15 enable Pullup
}


//*********************************************************************************
// Description	: reads a 2 bytes from CS8900
// Input  	 	: 1.) address: hardware-address of CS8900
// Output  	 	: data - data from CS8900
// Indication	: none
//*********************************************************************************
unsigned int 	_cs8900_r_port16(unsigned char address, ENDIAN_MODE mode)
{
unsigned int data_2;
unsigned char data_1;

CS8900_SBHE_L;			// /SBHE Low
CS8900_ADR(address);	// A0..A3
#asm("nop");	 		// nesessary to set PORT-Pin
CS8900_IOR_L;			// /IOR_ETH
// time between "CS8900_IOR_L" and "CS8900_DATA_R" is very critical, because CS8900 needs about 135ns to setup the 
// new data to bus
// 2 NOP's are nesessary with 7,3728Mhz Mainclock
#asm("nop");	 		// nesessary to set PORT-Pin
#if(_MCU_CLOCK_FREQUENCY_>4000000)
#asm("nop");	 		// nesessary to set PORT-Pin
#endif
#if(_MCU_CLOCK_FREQUENCY_>8000000)
#asm("nop");	 		// nesessary to set PORT-Pin
#endif
#if(_MCU_CLOCK_FREQUENCY_>12000000)
#asm("nop");	 		// nesessary to set PORT-Pin
#endif
#if(_MCU_CLOCK_FREQUENCY_>16000000)
#asm("nop");	 		// nesessary to set PORT-Pin
#endif
if(mode==LITTLE_ENDIAN)
	{
	data_1= CS8900_DATA_R;		// AD0..AD7
	data_2= CS8900_DATA16_R;	// AD8..AD15
	}
else
	{
	data_2= CS8900_DATA_R;		// AD0..AD7
	data_1= CS8900_DATA16_R;	// AD8..AD15
	}	
CS8900_IOR_H;		  		// /IOR_ETH
CS8900_SBHE_H;				// /SBHE High
data_2<<=8;
data_2|=data_1;
return data_2;
}
#endif		//#ifdef CS8900_IO_PORT16

#if defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_HW_16)	// data to/from CS8900 over I2C-HW-Bus
//*********************************************************************************
// Description	: reads a byte from CS8900
// Input  	 	: none
// Output  	 	: data - data from CS8900
// Indication	: none
//*********************************************************************************
unsigned char 	i2c_read_hw(unsigned char i2c_device)
{
unsigned char data=0x00;

TWCR = I2C_TWINT | I2C_TWSTA | I2C_TWEN;	// send start-condition
i2c_wait();
if(((TWSR&0xf8)==0x08) | ((TWSR&0xf8)==0x10))// if start-condition are acknowledge
	{
	TWDR = i2c_device;					// write address+read-bit of expander in data-register
	i2c_send();
	}
else
	{
	#ifdef CS8900_DEBUG
	if (cs8900_debug_flag)
		putsf("CS8900 I2C read-error!!\r");
	#endif	// #ifdef CS8900_DEBUG
	return;
	}
if ((TWSR&0xf8)==0x40)			// if i2c-expander received address and read-mode and transmit acknowledge
	{
//	TWCR=TWCR | I2C_TWEA		// ACK will be send
	TWCR=TWCR & ~I2C_TWEA;		// send notacknowledge to marke the end of transmission
	i2c_wait();
	data=TWDR;					// read out data from data-register
	} 
else
	{
	#ifdef CS8900_DEBUG
	if (cs8900_debug_flag)
		putsf("CS8900 I2C read-error!!\r");
	#endif	// #ifdef CS8900_DEBUG
	return;
	}
if((i2c_device & I2C_DATA8_EXPANDER)==I2C_DATA8_EXPANDER)
	TWCR = I2C_TWINT | I2C_TWSTO | I2C_TWEN;			//send stop-condition
return data;                                    //return the received data
}


//*********************************************************************************
// Description	: writes a address- or data-byte to CS8900
// Input  	 	:	1.) address: hardware-address of CS8900 or data: data to CS8900
//						2.) i2c_expander_address: which io-expander is access (expander for address or for data)
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void i2c_write_hw(unsigned char i2c_device, unsigned char address_data)
{
TWCR = I2C_TWINT | I2C_TWSTA | I2C_TWEN;	// send start-condition
i2c_wait();
if(((TWSR&0xf8)==0x08) | ((TWSR&0xf8)==0x10))	// if start-condition are acknowledge
	{
	TWDR = i2c_device;					// write address of expander in data-register
	i2c_send();												
	}
else
	{
	#ifdef CS8900_DEBUG
	if (cs8900_debug_flag)
		putsf("CS8900 I2C write-error!!\r");
	#endif	// #ifdef CS8900_DEBUG
	return;
	}
if((TWSR&0xf8)==0x18)			// if i2c-expander received address and write-mode and transmit acknowledge
	{
	TWDR = address_data;		// write address in data-register
	i2c_send();
	}                                     
else
	{
	#ifdef CS8900_DEBUG
	if (cs8900_debug_flag)
		putsf("CS8900 I2C write-error!!\r");
	#endif	// #ifdef CS8900_DEBUG
	return;
	}
if((i2c_device & I2C_DATA8_EXPANDER)==I2C_DATA8_EXPANDER)
	TWCR = I2C_TWINT | I2C_TWSTO | I2C_TWEN;			//send stop-condition
}

//*********************************************************************************
// Description	: wait till communication ends
// Input  	 	: none
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void i2c_wait(void)
{
while (!(TWCR & I2C_TWINT));             //wait for end of transmision
}

//*********************************************************************************
// Description	: send data of TWDR to the i2c-device
// Input  	 	: none
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void i2c_send(void)
{
TWCR = I2C_TWINT | I2C_TWEN;               //send data on i2c-bus
i2c_wait();
}
#endif	// #if defined(CS8900_I2C_HW_8)||defined(CS8900_I2C_HW_16)


#if defined(CS8900_I2C_SW_8)||defined(CS8900_I2C_SW_16)	// data to/from CS8900 over I2C-HW-Bus
//*********************************************************************************
// Description	: reads a byte from CS8900
// Input  	 	: none
// Output  	 	: data - data from CS8900
// Indication	: none
//*********************************************************************************
unsigned char 	i2c_read_sw(unsigned char i2c_device)
{
unsigned char data;

if(i2c_start())
	{
	i2c_write(i2c_device);
	data=i2c_read(0);		// Write-mode
	if((i2c_device & I2C_DATA8_EXPANDER)==I2C_DATA8_EXPANDER)
		i2c_stop();
	}
#ifdef CS8900_DEBUG
else
	{
	if (cs8900_debug_flag)
		putsf("CS8900 I2C read-error!!\r");
	}
#endif	// #ifdef CS8900_DEBUG
return data;                                    //return the received data
}


//*********************************************************************************
// Description	: writes a address- or data-byte to CS8900
// Input  	 	:	1.) address: hardware-address of CS8900 or data: data to CS8900
//					2.) i2c_expander_address: which io-expander is access (expander for address or for data)
// Output  	 	: none
// Indication	: none
//*********************************************************************************
void i2c_write_sw(unsigned char i2c_device, unsigned char address_data)
{
if(i2c_start())
	{
	i2c_write(i2c_device);
	i2c_write(address_data);
	if((i2c_device & I2C_DATA8_EXPANDER)==I2C_DATA8_EXPANDER)
		i2c_stop();
	}
#ifdef CS8900_DEBUG
else
	{
	if (cs8900_debug_flag)
		putsf("CS8900 I2C write-error!!\r");
	}
#endif	// #ifdef CS8900_DEBUG
}
#endif	// #if defined(CS8900_I2C_SW_8)||defined(CS8900_I2C_SW_16)

#endif  // #ifdef DEVICE_CS8900

