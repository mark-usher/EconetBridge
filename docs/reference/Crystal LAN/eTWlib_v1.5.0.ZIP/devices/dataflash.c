// ************************************************************************************************
///
/// \file 			dataflash.c
/// \brief			Device driver for AT45 dataflash
///
/// \todo			Rename Macro CS_FLASH_LOW and make it configurable via project.h
/// \date	 		$LastChangedDate: 2007-01-15 12:56:42 +0100 (Mo, 15 Jan 2007) $
/// \version 		$Rev: 490 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef DATAFLASH_ENABLE

#include "dataflash.h"
#include "dataflash_debug.h"
#include "debug.h"
#include "avr_spi.h"

#pragma regalloc-
#pragma regalloc+

#ifndef SPI_ENABLE
#error "SPI Module is needed for Dataflash. Define SPI_ENABLE."
#endif

// ************************************************************************************************
/// \brief		Init dataflash module
///
// ************************************************************************************************
void dataflash_init(void)
{
#ifdef DEBUG_DATAFLASH
dataflash_debug_init();
#endif
dataflash_cfg_spi(DATAFLASH_SPI_MODE);
}


// **********************************************************************************
// Description  : init the dataflash-port
// Input        : spi_mode - see avr_spi.h
// Output     	: 0 - Dataflash not ready
//				: 1 - Dataflash ok
// Indication	: none
// **********************************************************************************
unsigned char dataflash_cfg_spi(unsigned int spi_mode)
{
unsigned char data;

CS_FLASH_HIGH;		   		// Flash-Chip-Select High-Level
CS_FLASH_ACTIV;		   		// Flash-Chip-Select Output-Level
spi_init(spi_mode);	        // SCK=HIGH und steigende Flanke
data = dataflash_read_status();
if (data==0xff || data==0x00)
	{
	#ifdef DEBUG_DATAFLASH
	putsf("DataFlash: not ready\r"); 
	#endif	// #ifdef DEBUG_DATAFLASH
	return 0; 
	}
switch (data & 0x38)
	{
	case 0x08:	
				#ifndef DATAFLASH_AT45DB011
				return 0; 
				#endif
				break;
	case 0x10:	
				#ifndef DATAFLASH_AT45DB021
				return 0; 
				#endif
				break;
	case 0x18:	
				#ifndef DATAFLASH_AT45DB041
				return 0; 
				#endif
				break;
	case 0x20:	
				#ifndef DATAFLASH_AT45DB081
				return 0; 
				#endif
				break;
	case 0x28:	
				#ifndef DATAFLASH_AT45DB161
				return 0; 
				#endif
				break;
	case 0x30:	
				#ifndef DATAFLASH_AT45DB321
				return 0; 
				#endif
				break;
	}
return 1; 
}


#define DATAFLASH_BUSY_BIT				0x80
// **********************************************************************************
// Description  : checks the Status-Byte and wait until Busy-Flag==1
// Input        : none
// Output     	: 1 - OK
//				: 0 - Timeout-Error
// Indication	: none
// **********************************************************************************
unsigned char dataflash_wait_busy(void)
{
unsigned int	timeout_counter=0;

while((dataflash_read_status() & DATAFLASH_BUSY_BIT) == 0)
	{
	timeout_counter++;
	if(timeout_counter==0)	// timeout
		{
		#ifdef DEBUG_DATAFLASH
		putsf("DataFlash: busy timeout\r"); 
		#endif	// #ifdef DEBUG_DATAFLASH
		return 0;
		}
	}
return 1;
}


// **********************************************************************************
// Description	: Continuous read from main memory
// Input		: data    - Pointer to buffer inside of SRAM from Microcontroller
//            	: page    - page-address in dataflash
//            	: address - byte address within the flash-page
//          	: size    - count of Byte
// Output     	: 1 - OK
//				: 0 - read error
// Indication	: see "Continuous Array Read"
// **********************************************************************************
unsigned char dataflash_read_flash(unsigned char* data, unsigned int page, unsigned int address, unsigned int size)
{
unsigned int i;

if(dataflash_wait_busy())
	{
	CS_FLASH_LOW;					// Flash-Chip-Select Low-Level
	spi_transfer(COMM_CONT_READ);			// 8-bit opcode
	spi_transfer(ADR_P_B_1(page));
	spi_transfer(ADR_P_B_2(page, address));  
	spi_transfer(ADR_P_B_3(address));
	spi_transfer(0x00);                       // don't care
	spi_transfer(0x00);                       // don't care
	spi_transfer(0x00);                       // don't care
	spi_transfer(0x00);                       // don't care
	for (i=0; i<size; i++)               
		data[i] = spi_transfer(0x00);
	CS_FLASH_HIGH;					// Flash-Chip-Select High-Level
	return 1;
	}
return 0;
}


// **********************************************************************************
// Description 	: Reads Data from Dataflash SRAM-buffer
// Input        : data - Pointer to buffer inside of SRAM from Microcontroller
//              : address - Adresse im Buffer
//              : size - count of Byte
//              : buffer_num - Buffer 1 - 0
//              :              Buffer 2 - 1   
// Output     	: 1 - OK
//				: 0 - read error
// Indication	: see "Buffer Read"
// **********************************************************************************
unsigned char dataflash_read_buffer(unsigned char* data, unsigned int address, unsigned int size, FLASH_BUFFER_NUM buffer_num)
{
unsigned int i;

if(dataflash_wait_busy())
	{
	CS_FLASH_LOW;					// Flash-Chip-Select Low-Level
	if (buffer_num == FLASH_BUFFER1)
		spi_transfer(COMM_READ_BUF_1);
	else 
		spi_transfer(COMM_READ_BUF_2);
	spi_transfer(0x00);                        // 8 don't care
	spi_transfer(ADR_B_1(address));
	spi_transfer(ADR_B_2(address));
	spi_transfer(0x00);                        // 8 don't care
	for (i=0; i<size; i++)               
		data[i] = spi_transfer(0x00);
	CS_FLASH_HIGH;					// Flash-Chip-Select High-Level
	return 1;
	}
return 0;
}


// **********************************************************************************
// Description   : Returns Flash Status Byte
// Input         : none
// Output  	 	 : unsigned char - status-Byte
// Indication	 : see "Status Register Read"
// **********************************************************************************
unsigned char dataflash_read_status(void)
{
unsigned char data;

CS_FLASH_LOW;					// Flash-Chip-Select Low-Level
spi_transfer(COMM_STATUS_REG);
data = spi_transfer(0x00);
CS_FLASH_HIGH;					// Flash-Chip-Select High-Level
return data;
}


// **********************************************************************************
// Description 	: Writes Data in Dataflash buffer
// Input        : data - Pointer to DataFlash-Data
//              : address - Address of Buffer
//              : size - count of Byte
//              : buffer_num - Buffer 1 - 0
//              :              Buffer 2 - 1   
// Output     	: 1 - OK
//				: 0 - write error
// Indication	: see "Buffer Write" WITH Wait-Busy
// **********************************************************************************
unsigned char dataflash_write_buffer(unsigned char* data, unsigned int address, unsigned int size, FLASH_BUFFER_NUM buffer_num)
{
unsigned int i;

if(dataflash_wait_busy())
	{
	CS_FLASH_LOW;					// Flash-Chip-Select Low-Level
	if(buffer_num == FLASH_BUFFER1)
		spi_transfer(0x84);
	else 
		spi_transfer(0x87);
	spi_transfer(0x00);                      		 // don't care 0..7
	spi_transfer(ADR_B_1(address));
	spi_transfer(ADR_B_2(address));
	for (i=0; i<size; i++)               
   		spi_transfer(data[i]);
	CS_FLASH_HIGH;					// Flash-Chip-Select High-Level
	return 1;
	}
return 0;
}


// **********************************************************************************
// Description	: Writes Data from Buffer to Main memory
// Input        : buffer_num - number of buffer to transfer
//              :             Buffer 1 - 0
//              :             Buffer 2 - 1   
//              : page   - page-number in main memory
// Output     	: 1 - OK
//				: 0 - write error
// Indication	: see "Buffer To Main Memory Page Programm WITH Built-In Erase"
// **********************************************************************************
unsigned char dataflash_write_buffer2flash_e(FLASH_BUFFER_NUM buffer_num, unsigned int page)
{
if(dataflash_wait_busy())
	{
	CS_FLASH_LOW;					// Flash-Chip-Select Low-Level
	if (buffer_num == FLASH_BUFFER1)
		spi_transfer(0x83);
	else 
		spi_transfer(0x86);
	spi_transfer(ADR_P_1(page));  
	spi_transfer(ADR_P_2(page)); 
	spi_transfer(0x00);                     // 8 don't care bits
	CS_FLASH_HIGH;					// Flash-Chip-Select High-Level
	return 1;
	}
return 0;
}


// **********************************************************************************
// Description  : Writes Data from Buffer to Main memory
// Input        : buffer_num - number of buffer to transfer
//              :             Buffer 1 - 0
//              :             Buffer 2 - 1   
//              : page   - page-number in main memory
// Output    	: 1 - OK
//				: 0 - write error
// Indication	: see "Buffer To Main Memory Page Programm WITHOUT Built-In Erase"
// **********************************************************************************
unsigned char dataflash_write_buffer2flash(FLASH_BUFFER_NUM buffer_num, unsigned int page)
{
if(dataflash_wait_busy())
	{
	CS_FLASH_LOW;					// Flash-Chip-Select Low-Level
	if (buffer_num == FLASH_BUFFER1)
		spi_transfer(0x88);
	else 
		spi_transfer(0x89);
	spi_transfer(ADR_P_1(page));  
	spi_transfer(ADR_P_2(page)); 
	spi_transfer(0x00);                       // 8 don't care bits
	CS_FLASH_HIGH;					// Flash-Chip-Select High-Level
	return 1;
	}
return 0;
}


// **********************************************************************************
// Description 	: Erases Page in Main Memory
// Input        : page - page number in main memory
// Output    	: 1 - OK
//				: 0 - erase error
// Indication	: see "Page Erase"
// **********************************************************************************
unsigned char dataflash_erase_page(unsigned int page)
{
if(dataflash_wait_busy())
	{
	CS_FLASH_LOW;					// Flash-Chip-Select Low-Level
	spi_transfer(0x81);
	spi_transfer(ADR_P_1(page));  
	spi_transfer(ADR_P_2(page)); 
	spi_transfer(0x00);                       // 8 don't care bits
	CS_FLASH_HIGH;					// Flash-Chip-Select High-Level
	return 1;
	}
return 0;
}


// **********************************************************************************
// Description	: Erases Page in Main Memory
// Input        : page - page number in main memory
// Output    	: 1 - OK
//				: 0 - erase error
// Indication   : see "Block Erase"
// **********************************************************************************
unsigned char dataflash_erase_block(unsigned int page)
{
if(dataflash_wait_busy())
	{
	CS_FLASH_LOW;					// Flash-Chip-Select Low-Level
	spi_transfer(0x50);
	spi_transfer(ADR_P_1(page));  
	spi_transfer(ADR_P_2(page)); 
	spi_transfer(0x00);                  // 8 don't care bits
	CS_FLASH_HIGH;				// Flash-Chip-Select High-Level
	return 1;
	}
return 0;
}


// **********************************************************************************
// Description	: Main Memory Page Program through buffer - Is a combination of 
//              : "Buffer Write" and "Buffer To Main Page Program with Built-In Erase"
// Input        : data    - Zeiger auf Daten f�r den Flash
//              : page    - page-number in flash-memory
//              : address - page-address in flash-memory
//              : size    - Anzahl Byte, die geschrieben werden sollen
//              : buffer_num - Nummer des Puffers, �ber den geschrieben werden soll
// Output    	: 1 - OK
//				: 0 - write error
// Indication	: see "Main Memory Page Programm Through Buffer"
//              : Attention: write the data of buffer back and destroy old data, if
//              : not reload before (only when write a part of page) 
// *********************************************************************************
unsigned char dataflash_write2flash(unsigned char* data, unsigned int page, unsigned int address, unsigned int size, FLASH_BUFFER_NUM buffer_num)
{
unsigned int i;

if(dataflash_wait_busy())
   {
	CS_FLASH_LOW;					// Flash-Chip-Select Low-Level
	if(buffer_num == FLASH_BUFFER1)
		spi_transfer(0x82);
	else 
		spi_transfer(0x85);
	spi_transfer(ADR_P_B_1(page));
	spi_transfer(ADR_P_B_2(page, address));  
	spi_transfer(ADR_P_B_3(address));
	for (i=0; i<size; i++)               
		spi_transfer(data[i]);
	CS_FLASH_HIGH;					// Flash-Chip-Select High-Level
	return 1;
	}
return 0;
}


// **********************************************************************************
// Description 	: Transfers a page from Main memory to selected buffer
// Input        : buffer_num - number of buffer to transfer
//              :             Buffer 1 - 0
//              :             Buffer 2 - 1   
//              : page   - page address in main memory
// Output    	: 1 - OK
//				: 0 - read error
// Indication	: see "Main Memory Page To Buffer Transfer"
// **********************************************************************************
unsigned char dataflash_read_flash2buffer(FLASH_BUFFER_NUM buffer_num, unsigned int page)
{
if(dataflash_wait_busy())
	{
	CS_FLASH_LOW;					// Flash-Chip-Select Low-Level
	if (buffer_num == FLASH_BUFFER1)
		spi_transfer(0x53);
	else 
		spi_transfer(0x55);                  // 8-bit opcode
	spi_transfer(ADR_P_1(page));  
	spi_transfer(ADR_P_2(page)); 
	spi_transfer(0x00);						// 8 don't care bits
	CS_FLASH_HIGH;					// Flash-Chip-Select High-Level
	return 1;
	}
return 0;
}


#define DATAFLASH_COMP_BIT				0x40
// **********************************************************************************
// Description 	: Compares a page from Main memory to selected buffer
// Input        : buffer_num - number of buffer to transfer
//              :             Buffer 1 - 0
//              :             Buffer 2 - 1   
//              : page   - page address in main memory
// Output    	: 1 - OK and Match Data
//				: 0 - Read-Error or no Match
// Indication	: see "Main Memory Page To Buffer Compare"
// **********************************************************************************
unsigned char dataflash_compare(FLASH_BUFFER_NUM buffer_num, unsigned int page)
{
if(dataflash_wait_busy())
	{
	CS_FLASH_LOW;					// Flash-Chip-Select Low-Level
	if (buffer_num == FLASH_BUFFER1)
		spi_transfer(0x60);
	else 
		spi_transfer(0x61);                  // 8-bit opcode
	spi_transfer(ADR_P_1(page));  
	spi_transfer(ADR_P_2(page)); 
	spi_transfer(0x00);						// 8 don't care bits
	CS_FLASH_HIGH;					// Flash-Chip-Select High-Level
	if(dataflash_wait_busy())
		{
		if((dataflash_read_status() & DATAFLASH_COMP_BIT) == 0)
			return 1;
		}
	}
return 0;
}


// **********************************************************************************
// Description	: Rewrites a page from Main memory over the selected buffer
// Input        : buffer_num - number of buffer to transfer
//              :             Buffer 1 - 0
//              :             Buffer 2 - 1   
//              : page   - page address in main memory
// Output    	: 1 - OK
//				: 0 - rewrite error
// Indication   : see "Auto Page Rewrite"
// **********************************************************************************
unsigned char dataflash_rewrite(FLASH_BUFFER_NUM buffer_num, unsigned int page)
{
if(dataflash_wait_busy())
	{
	CS_FLASH_LOW;					// Flash-Chip-Select Low-Level
	if (buffer_num == FLASH_BUFFER1)
		spi_transfer(0x58);
	else 
		spi_transfer(0x59);                  // 8-bit opcode
	spi_transfer(ADR_P_1(page));  
	spi_transfer(ADR_P_2(page)); 
	spi_transfer(0x00);						// 8 don't care bits
	CS_FLASH_HIGH;					// Flash-Chip-Select High-Level
	return 1;
	}
return 0;
}


// **********************************************************************************
// Description	: Erases all Pages in Main Memory
// Input       	: none
// Output    	: 1 - OK
//				: 0 - Erase-Error
// Indication	: see "dataflash_erase_block()" and "Block Erase"
// **********************************************************************************
unsigned char dataflash_erase_all(void)
{
unsigned int Lva;

for(Lva=0;Lva<FLASH_PAGE_COUNT;Lva+=8)
	{
	#asm("wdr");	// Reset Watchdog
	if(!dataflash_erase_block(Lva))
		return 0;
	}
return 1;
}

#endif	// #ifdef DATAFLASH_ENABLE