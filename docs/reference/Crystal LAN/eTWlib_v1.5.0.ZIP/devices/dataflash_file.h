// ************************************************************************************************
///
/// \file 			dataflash_file.h
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// \par History
///					1.) 08.10.2003 Version 2.02
///						a.)	- add check, whether file open, see "dataflash_file_open()"
///					2.) 01.10.2004 Version 2.05b
///						a.)	- function "dataflash_file_check()" checks now the storage typ
///						--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#ifndef _DATAFLASH_FILE_INCLUDED_
#define _DATAFLASH_FILE_INCLUDED_

#include "project.h"		// Project configuration

#include "dataflash.h"

// --------------------------------------------------------------------------------
// Compiler-ERROR 
// -------------------------------------------------------------------------------- 
#ifndef DATAFLASH_ENABLE
#error ERROR: No Dataflash ("#define DATAFLASH_ENABLE") !!!
#endif

//  --------------------------------------------------------------------------------
//	Info structure
//  -------------------------------------------------------------------------------- 
typedef flash struct{
	unsigned long		label;			// identification of file system
	unsigned int		version;		// actual version of file system
	unsigned int		storage_typ;	// actual version of file system
	unsigned char		date[12];		// date of compile
	unsigned char		time[12];		// time of compile
	unsigned int		dir_count;		// max. count of directory entries
	unsigned int		file_count;		// max. count of file entries
	unsigned char		info[66];		// info
} INFO_FLASH_STRUCT;

typedef struct{
	unsigned long		label;			// identification of file system
	unsigned int		version;		// actual version of file system
	unsigned int		storage_typ;	// actual version of file system
	unsigned char		date[12];		// date of compile
	unsigned char		time[12];		// time of compile
	unsigned int		dir_count;		// max. count of directory entries
	unsigned int		file_count;		// max. count of file entries
	unsigned char		info[66];		// info
} INFO_STRUCT;               

//#if(FLASH_PAGE_SIZE < (sizeof(INFO_STRUCT)))
//#error ERROR: too big "INFO_STRUCT"!!!
//#endif

typedef struct{
	unsigned char		year;			// 0..255 years
	unsigned char		month:4;		// 1..12 months
	unsigned char		day:5;			// 1..31 days
	unsigned char		hour:5;			// 0..23 hours
	unsigned char		minute:6;		// 0..59 minutes
	unsigned char		second:6;		// 0..59 seconds
} DATE_STRUCT;                                    	

#define FILE_NAME_SIZE			13
#define FILE_NAME_LAST_SIGN		(FILE_NAME_SIZE-1)
//  --------------------------------------------------------------------------------
//	File-name structure
//  -------------------------------------------------------------------------------- 
typedef struct{
	unsigned int		startpage;		// first page-number
	unsigned int		lastpage;		// last page-number
	unsigned int		countpage;		// count of used page
	unsigned int		lastpage_byte;	// rest of databyte of the last page
	unsigned char		dir_number;		// dir-number, 0xff == root directory
	unsigned char		option;			// options to handle the file
	DATE_STRUCT			date;			// see DATE_STRUCT
	unsigned char		name[FILE_NAME_SIZE];	// name of file
} FILE_NAME_STRUCT;
                 
#define DIR_NAME_SIZE			13
#define DIR_NAME_LAST_SIGN		(DIR_NAME_SIZE-1)
#define DIR_NAME_ROOT			0xff
//  --------------------------------------------------------------------------------
//	Directory-name structure
//  -------------------------------------------------------------------------------- 
typedef struct{
	unsigned char		option;			// options to handle the file
	DATE_STRUCT			date;			// see DATE_STRUCT
	unsigned char		name[DIR_NAME_SIZE];	// name of directory
} DIR_NAME_STRUCT;


#ifndef FILE_HANDLE_COUNT
#define FILE_HANDLE_COUNT			1
#endif	
#define FILE_HANDLE_DISABLE			0xff	// disable handle-entry
//  --------------------------------------------------------------------------------
//	File-Handler structure
//  -------------------------------------------------------------------------------- 
typedef struct{
	unsigned int		startpage;			// first page-number
	unsigned int		lastpage;			// last page-number
	unsigned int		countpage;	  		// count of used page
	unsigned int		lastpage_byte;		// rest of byte of the last page
	unsigned char		dir_number;			// dir-number, 0xff == root directory
	unsigned char		option;				// options to handle the file
	DATE_STRUCT			date;				// see DATE_STRUCT
	unsigned char		name[FILE_NAME_SIZE];	// name of file
	unsigned int		file_entry;			// pointer to entry inside of FILE_NAME_PAGE_ADDR
	unsigned int		act_absolut_page;	// actual page position of data-pointer (absolut inside of DATAFLASH)
	unsigned int		act_absolut_byte;	// actual byte position inside of act_absolut_page
} FILE_HANDLE;                                    	

// --------------------------------------------------------------------------------
// constants to actual file system
// -------------------------------------------------------------------------------- 
#define FILE_INFO_LABEL				0x11aa22bb
#define FILE_INFO_VERSION			0x000a
#ifdef DATAFLASH_AT45DB011
#define STORAGE_TYP					0x0011
#endif
#ifdef DATAFLASH_AT45DB021
#define STORAGE_TYP					0x0021
#endif
#ifdef DATAFLASH_AT45DB041
#define STORAGE_TYP					0x0041
#endif
#ifdef DATAFLASH_AT45DB081
#define STORAGE_TYP					0x0081
#endif
#ifdef DATAFLASH_AT45DB161
#define STORAGE_TYP					0x0161
#endif
#ifdef DATAFLASH_AT45DB321
#define STORAGE_TYP					0x0321
#endif
#define FILE_INFO_STRING			"eTW Data-File-System Copyright(C)2005 FTZ-Leipzig Udo Jakobza"

// --------------------------------------------------------------------------------
// Page structure of file-system
// -------------------------------------------------------------------------------- 
#define FILE_INFO_PAGE_ADDR			0		// Page to save some infos
#define FILE_INFO_PAGE_COUNT		1		// size of Info-Page
#define FILE_INFO_BYTE_SIZE			(FILE_INFO_PAGE_COUNT*FLASH_PAGE_SIZE)		// Byte-size
// -------------------------------------------------------------------------------- 
#define FILE_FF_PAGE_ADDR			(FILE_INFO_PAGE_ADDR+FILE_INFO_PAGE_COUNT)	// Page to clear DataFlash-SRAM-Buffer
#define FILE_FF_PAGE_COUNT			1		// size of FF-Page
#define FILE_FF_BYTE_SIZE			(FILE_FF_PAGE_COUNT*FLASH_PAGE_SIZE)		// Byte-size
// -------------------------------------------------------------------------------- 
#define FILE_DIR_COUNT_MAX			254
#define FILE_DIR_PAGE_ADDR			(FILE_FF_PAGE_ADDR+FILE_FF_PAGE_COUNT)		// Page to save the directory data
#define FILE_DIR_PAGE_COUNT			1	 										// size of Directory-Page
#define FILE_DIR_BYTE_SIZE			(FILE_DIR_PAGE_COUNT*FLASH_PAGE_SIZE)		// Byte-size
#define FILE_DIR_COUNT_PAGE			(FLASH_PAGE_SIZE/sizeof(DIR_NAME_STRUCT)) 	// count of directories per Page
#define FILE_DIR_COUNT				(FILE_DIR_COUNT_PAGE*FILE_DIR_PAGE_COUNT)
#define FILE_DIR_PAGE_END			(FILE_DIR_PAGE_ADDR+FILE_DIR_PAGE_COUNT)	// End of Dir-Name Pages

/*
#if(FILE_DIR_COUNT > FILE_DIR_COUNT_MAX)
#error ERROR: TOO MANY DIRECTORY-ENTRIES !!!
#define FILE_DIR_COUNT	FILE_DIR_COUNT_MAX
#endif
*/
// -------------------------------------------------------------------------------- 
#define FILE_ALLOCATION_ENTRY		4											// size of Allocation-Entry
#define FILE_ALLOCATION_PAGE_ADDR	(FILE_DIR_PAGE_ADDR+FILE_DIR_PAGE_COUNT)   	// Page to allocation the data
#define FILE_ALLOCATION_PAGE_COUNT	((FLASH_PAGE_COUNT*FILE_ALLOCATION_ENTRY)/FLASH_PAGE_SIZE+1)	// size of Allocation-Page
#define FILE_ALLOCATION_BYTE_SIZE	(FILE_ALLOCATION_PAGE_COUNT*FLASH_PAGE_SIZE)	// Byte-size
#define FILE_ALLOCATION_PAGE_ENTRY	(FLASH_PAGE_SIZE/FILE_ALLOCATION_ENTRY)		// count of entries per Flashpage
#define FILE_ALLOCATION_COUNT		(FILE_ALLOCATION_PAGE_ENTRY*FILE_ALLOCATION_PAGE_COUNT)		// count of entries in Allocation Table
#define FILE_ALLOCATION_PAGE_END    (FILE_ALLOCATION_PAGE_ADDR+FILE_ALLOCATION_PAGE_COUNT)
// -------------------------------------------------------------------------------- 
#define FILE_NAME_PAGE_ADDR			(FILE_ALLOCATION_PAGE_ADDR+FILE_ALLOCATION_PAGE_COUNT)	// Page to save filenames
#define FILE_NAME_PAGE_COUNT		20											// pages of File-Names
#define FILE_NAME_BYTE_SIZE			(FILE_NAME_PAGE_COUNT*FLASH_PAGE_SIZE)		// Byte-size
#define FILE_NAME_COUNT_PAGE		(FLASH_PAGE_SIZE/sizeof(FILE_NAME_STRUCT)) 	// count of files per Page
#define FILE_NAME_COUNT				(FILE_NAME_COUNT_PAGE*FILE_NAME_PAGE_COUNT)	// count of files
#define FILE_NAME_PAGE_END			(FILE_NAME_PAGE_ADDR+FILE_NAME_PAGE_COUNT)	// End of Filename Pages
// -------------------------------------------------------------------------------- 
#define FILE_DATA_ENTRY				4											// size of Data-Entry (16bit Startpage; 16bit Nextpage)
#define FILE_DATA_PAGE_ADDR			(FILE_NAME_PAGE_ADDR+FILE_NAME_PAGE_COUNT)	// Data-Page
#define FILE_DATA_PAGE_COUNT		(FLASH_PAGE_COUNT-FILE_INFO_PAGE_COUNT-FILE_FF_PAGE_COUNT-FILE_DIR_PAGE_COUNT-\
										FILE_ALLOCATION_PAGE_COUNT-FILE_NAME_PAGE_COUNT) 		// count of Data-Area
#define FILE_DATA_PAGE_SIZE			(FLASH_PAGE_SIZE-FILE_DATA_ENTRY)			// size of Data-Page
#define FILE_DATA_BYTE_SIZE			(FILE_DATA_PAGE_COUNT*FILE_DATA_PAGE_SIZE)	// Data-Byte-size
#define	FILE_DATA_PAGE_END			(FLASH_PAGE_COUNT-1)

// --------------------------------------------------------------------------------
// typedef for function "dataflash_file_search()"
// -------------------------------------------------------------------------------- 
typedef enum {SEARCH_FIRST=1, SEARCH_NEXT} SEARCH_MODE;

// --------------------------------------------------------------------------------
// typedef for function "dataflash_file_search()"
// -------------------------------------------------------------------------------- 
typedef enum{
	FILE_TYPE_NONE,
	FILE_TYPE_HTML,
	FILE_TYPE_JPEG,
	FILE_TYPE_CLASS,		// Java Application
	FILE_TYPE_TEXT
} FILE_TYP;

// --------------------------------------------------------------------------------
///////// prototypes  /////////  
// -------------------------------------------------------------------------------- 
#pragma used+
extern unsigned char directory_actual;

unsigned char 	dataflash_file_format(void);
unsigned char 	dataflash_file_init(unsigned int spi_mode);
unsigned char 	dataflash_file_search(unsigned char *file_name, FILE_NAME_STRUCT *file_name_struct, unsigned int *file_entry, SEARCH_MODE mode);
unsigned char 	dataflash_file_open(unsigned char *file_name, unsigned char *handle);
unsigned char 	dataflash_file_close(unsigned char *handle);
void 			dataflash_file_close_all(void);
unsigned int 	dataflash_file_read(unsigned char handle, unsigned char *data, unsigned int data_size);
unsigned char 	dataflash_file_eof(unsigned char handle);
unsigned char 	dataflash_file_size(unsigned char handle, unsigned long *file_size);
unsigned char 	dataflash_file_seek(unsigned char handle, unsigned long file_pos);
unsigned char 	dataflash_file_new(unsigned char *file_name);
unsigned int 	dataflash_file_write(unsigned char handle, unsigned char *data, unsigned int data_size);
unsigned char 	dataflash_file_delete(unsigned char handle);
unsigned char 	dataflash_file_gettype(unsigned char handle, FILE_TYP *file_typ);
unsigned char 	dataflash_file_gettime(unsigned char handle, DATE_STRUCT *file_time);
unsigned char 	dataflash_dir_search(unsigned char *dir_name, unsigned char *dir_number, DIR_NAME_STRUCT *dir_struct);
unsigned char	dataflash_dir_new(unsigned char *dir_name);
unsigned char	dataflash_dir_change(unsigned char *dir_name);
unsigned char 	dataflash_dir_delete(unsigned char *dir_name);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library dataflash_file.c
#endif

#endif	// #ifndef _DATAFLASH_FILE_INCLUDED_