// ************************************************************************************************
///
/// \file 			ad5242.c
///
///					I2C Digital Potentiometer from Analog Devices
/// \date	 		$LastChangedDate: 2007-03-13 11:20:38 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 629 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"
#include "ad5242.h"

#ifdef AD5242_ENABLE

#include <stdio.h>
#include <string.h>
#include "twi.h"
#include "debug.h"

// local prototypes
#pragma used+
void ad5242_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);
#pragma used-

// ************************************************************************************************
/// \brief		Initializes AD5242 module
///
// ************************************************************************************************
void ad5242_init(void)
{
#ifdef AD5242_DEBUG
T_DEBUG_HANDLER_STRUCT p_struct;
                      
p_struct.fp_handler = &ad5242_debug_handler;
p_struct.id_string = "ad5242";
debug_register_handler(&p_struct);
#endif
}


#define AD5242_RDAC1			0x00
#define AD5242_RDAC2			0x80
#define AD5242_MIDSCALE			0x40
#define AD5242_SHUTDOWN			0x20
#define AD5242_ADDRESS_OFFSET	0b0101100
// ************************************************************************************************
/// \brief		Writes new values for resistors and digital output to AD5242
/// @param[in]	addr_pins    - specifies the chip. Logical OR of AD5242_AD0 and AD5242_AD1.
/// @param[in]	rdac_no      - number of chip-internal resistor. Range 1..2.
/// @param[in]	rdac_value   - new value for variable resistor. Range 0..0xff
/// @param[in]	digout_value - new value for digital output. Logical OR of AD5242_OUT1 and AD5242_OUT2
/// @return		error code, see T_TWI_ERR
// ************************************************************************************************
T_TWI_ERR ad5242_write( unsigned char addr_pins, unsigned char rdac_no, 
						unsigned char rdac_value, unsigned char digout_value)
{
unsigned char data_buffer[2];
unsigned char i2c_address;
unsigned char retval;

data_buffer[0] = digout_value;
if (rdac_no == 2)
	data_buffer[0] |= AD5242_RDAC2;

data_buffer[1] = rdac_value;
i2c_address = AD5242_ADDRESS_OFFSET | addr_pins;
//printf("AD5242 i2c_address: 0x%02x \r\n", i2c_address);
//printf("AD5242 data_buffer[0]: 0x%02X\r\n", data_buffer[0]);
//printf("AD5242 data_buffer[1]: 0x%02X\r\n", data_buffer[1]);
retval = twi_write_msg(i2c_address, 2, data_buffer);
//printf("AD5242 retval: %u\r\n", retval);

return retval;
}


// ************************************************************************************************
/// \brief		Initializes AD5242 module
/// @param[in]	addr_pins - 
/// @param[in]	rdac_no - 
/// @param[in]	value - 
/// @return		error code, see T_TWI_ERR
// ************************************************************************************************
T_TWI_ERR ad5242_read(unsigned char  addr_pins, 
  						  unsigned char  rdac_no, 
  						  unsigned char* p_value,
						  unsigned char  digout_value)
{
unsigned char data_buffer[1];
unsigned char i2c_address;
unsigned char retval;

// to select the right rdac channel, we must issue an short i2c write command
// we need the last logic output value
data_buffer[0] = digout_value;
if (rdac_no == 2)
	data_buffer[0] |= AD5242_RDAC2;
i2c_address = AD5242_ADDRESS_OFFSET | addr_pins;
//printf("AD5242 i2c_address: 0x%02x \r\n", i2c_address);
//printf("AD5242 data_buffer[0]: 0x%02X\r\n", data_buffer[0]);
// we write only one byte (otherwise we would overwrite the resistor value
retval = twi_write_msg(i2c_address, 1, data_buffer);
if (retval != 0)
	return retval;		// write failed

// now the rdac channel is selected and we can issue the i2c read command
retval = twi_read_msg(i2c_address, 1, p_value);

return retval;
}


#ifdef AD5242_DEBUG
// ************************************************************************************************
/// \brief		Command handler for incoming commands
///
/// @param[in] 	command	pointer to received string
// ************************************************************************************************
void ad5242_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
signed int    address, rdac_no, res_value;
unsigned char  retval;
unsigned char* p_resvalue;


if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-write", 2)==0)
		{
		printf("AD5242-write\r\n");
		// first parameter: pin-coded address: range 0..3
		address = debug_get_int_parameter(command);
		if (address<0 || address>3)
			address = 0;
		command = debug_search_parameter(command);
		// second parameter: chip-internal resistor number: range 1..2
		rdac_no = debug_get_int_parameter(command);
		if (rdac_no<1 || rdac_no>2)
			rdac_no = 1;
		command = debug_search_parameter(command);
		// third parameter: resistor value: range 0..255
		res_value = debug_get_int_parameter(command);
		if (res_value < 0)
			res_value = 0;
		retval = ad5242_write(address, rdac_no, res_value, 0);
		if (retval != 0)
			printf("AD5242 Error: %u\r\n", retval);
		}
	if (strncmpf(command, "-read", 2)==0)
		{
		printf("AD5242-read\r\n");
		// first parameter: pin-coded address: range 0..3
		address = debug_get_int_parameter(command);
		if (address<0 || address>3)
			address = 0;
		command = debug_search_parameter(command);
		// second parameter: chip-internal resistor number: range 1..2
		rdac_no = debug_get_int_parameter(command);
		if (rdac_no<1 || rdac_no>2)
			rdac_no = 1;
		retval = ad5242_read(address, rdac_no, p_resvalue, 0);
		if (retval != 0)
			printf("AD5242 Error: %u\r\n", retval);
		else
			printf("AD5242 Value: %u\r\n", *p_resvalue);
		}
	if (strncmpf(command, "-search", 2)==0)
		{
		for (address=0; address<=(AD5242_AD0|AD5242_AD1); address++)
			{
			retval = ad5242_write(address, 1, 0, 0);
			printf("AD5242 address: 0x%02x / retval: %u\r\n", address, retval);
			}
		}
	}
}
#endif	// #ifdef AD5242_DEBUG
#endif	// #ifdef AD5242_ENABLE
