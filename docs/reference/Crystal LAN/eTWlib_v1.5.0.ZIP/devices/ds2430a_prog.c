// ************************************************************************************************
///
/// \file 			ds2430a_prog.c
/// \brief			Programming the DS2430
///
/// \todo			convert to new debug handler framework
/// \todo			contains stack-specific functions. They should be removed.
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef DS2430_WRITE_PROM

#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "ds2430a.h"
#include "ds2430a_prog.h"
#include "debug.h"

#pragma regalloc-
// allocate SRAM space for the ROM codes & status bit vom 1-Wire
#pragma warn-
#define			MAX_1WIRE_DEVICES	8	// specify the maximum number of devices connected to the 1 Wire bus
#pragma warn+
unsigned char	romcodes_1wire[MAX_1WIRE_DEVICES, 9];
unsigned char	devices_1wire=0;
#pragma regalloc+


unsigned char ds2430_buffer[DS2430_EEPROM_SIZE];
//*********************************************************************************
// Description	: init the 1-wire-Interface and read the PROM of DS2430
// Input	   		: none
// Output   		: none
// Indication	: none
//*********************************************************************************
unsigned char ds2430_prog_init(void)
{
#ifdef WIRE_IRQ			// controls the use of disable and enable of global IRQ
unsigned char sreg;
sreg=SREG;
#asm("cli");
#endif
devices_1wire=w1_search(0xf0,romcodes_1wire);	// search all 1Wire-Devices
#ifdef	WIRE_IRQ		// controls the use of disable and enable of global IRQ
SREG=sreg;
#endif
return 0;
}


//*********************************************************************************
// Description	: test und read ID-Code 1-WIRE-Devices
// Input	  	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
unsigned char ds2430_prog_info(void)
{
unsigned char i, j, crc;
unsigned char status;

ds2430_prog_init();
if(devices_1wire)
	{
	printf("%-u 1WIRE-DEVICE(S)\n\r", devices_1wire);
	for (i=0;i<devices_1wire;i++)
		{
		crc=w1_dow_crc8(&romcodes_1wire[i,0], 7);
		if(crc==romcodes_1wire[i,7])
			{
			printf("BIT07..00 - Family Code  : 0x%02x - ", romcodes_1wire[i,0]);
			switch(romcodes_1wire[i,0])
				{
				case 0x01: printf("DS2401");break;
				case 0x10: printf("DS1820");break;
				case DS2430_FAMILY_CODE: printf("DS2430A");break;
				default: printf("unknown");
				}
			putsf("\r");
			printf("BIT56..08 - Serial Number: 0x");
			for (j=6;j>0;j--)
				printf("%02x",romcodes_1wire[i,j]);
			putsf("\r");
			printf("BIT63..57 - CRC          : 0x%02x\n\r", romcodes_1wire[i,7]);
			if(romcodes_1wire[i,0]==DS2430_FAMILY_CODE)		// found DS2430A
				{
        	    printf("DS2430-EEPROM:");
				if(ds2430a_read_eeprom(&romcodes_1wire[i,0], ds2430_buffer, 0, DS2430_EEPROM_SIZE))
					{
		            putsf("\r");
					debug_display_mem_hex(ds2430_buffer, DS2430_EEPROM_SIZE, 0);
					}
				else				
		            putsf("ERROR\r");
        	    printf("DS2430-PROM");
				status=ds2430a_read_prom(&romcodes_1wire[i,0], ds2430_buffer, 0, DS2430_PROM_SIZE);
				if(status==0)
					{
	    	        putsf("-ERROR\r");
					return;
	            	}
				if(status==DS2430_PROM_UNLOCK)
		            printf("-Scratchpad: ");
				if(status==DS2430_PROM_LOCK)
	        	    printf(": ");
				debug_display_mem_hex(ds2430_buffer, DS2430_PROM_SIZE, 0);
				}
			}
		else
			printf("CRC-Error: 0x%02x/0x%02x\r", romcodes_1wire[i,7], crc);
		}
	}
else
	putsf("no 1-WIRE-DEVICE available\r");
return devices_1wire;
}



unsigned char	mac[8];		// MAC-Size + 2dummy bytes
//*********************************************************************************
// Description	: convert MAC from string
// Input	 	: none
// Output    	: none
// Indication	: none
//*********************************************************************************
unsigned char	ds2430_prog_string2mac(unsigned char *command, unsigned char *device_number)
{
unsigned char	Lva=0, Lvc;

*device_number=0;
while((command[Lva]!=' ')&&(command[Lva]!=0x0))	// delete the first part of command
	Lva++;
while((command[Lva]==' ')&&(command[Lva]!=0x0))	// delete the space-signs between command and parameter
	Lva++;
if(command[Lva]!=0x0)
	{
	Lvc=0;
	for(Lva=Lva;Lva<strlen(command);Lva++)
		{
		if(command[Lva]==':')
	  		{
			mac[Lvc]=(toint(command[Lva-2])<<4);
			mac[Lvc]|=toint(command[Lva-1]);
			Lvc++;
			}
		if(Lvc==5)break;		// stops the conversion
		}
	if(Lvc<5)return 0;		// wrong count of MAC-address-parts
	mac[Lvc]=(unsigned char)(toint(command[Lva+1])<<4);
	mac[Lvc]|=(unsigned char)toint(command[Lva+2]);
	mac[6]=(unsigned char)((__CODEVISIONAVR__)&0x00ff);
	mac[7]=(unsigned char)(((__CODEVISIONAVR__)>>8)&0x00ff);
	while((command[Lva]!=' ')&&(command[Lva]!=0x0))	// delete the last signs of first parameter
		Lva++;
	while((command[Lva]==' ')&&(command[Lva]!=0x0))	// delete the space-signs between 1st parameter and second one
		Lva++;
	if(command[Lva]!=0x0)
		*device_number=atoi(&command[Lva]);
	return 1;
	}
return 0;
}


//********************************************************************************
// Description	: writes the new MAC to DS2430-PROM
// Input		: none
// Output      	: 1.) return==0x00 - values not changed from DS2430-PROM
//				      return==0x01 - new values to DS2430-PROM
// Indication	: none
//********************************************************************************
unsigned char ds2430_prog_write_mac(unsigned char *command)
{
unsigned char lva;
signed int act_key;
unsigned char device_number=0;

ds2430_prog_init();
if((devices_1wire)&&(ds2430_prog_string2mac(command, &device_number)))
	{
	if(device_number>=devices_1wire)
		{
		putsf("wrong number of 1Wire-Device\r");
		return 0;
		}
	if(romcodes_1wire[device_number,0]!=DS2430_FAMILY_CODE)
		{
		printf("wrong 1Wire-Device: 0x%x\n\r", romcodes_1wire[device_number,0]);
		return 0;
		}
	printf("BIT56..08 - Serial Number: 0x");
	for(lva=6;lva>0;lva--)
		printf("%02x",romcodes_1wire[device_number, lva]);
	putsf("\r");
	for (lva=0; lva<sizeof(mac); lva++)
		printf("mac[%u]: 0x%02x\n\r", lva, mac[lva]);
	if(device_number==0)
		putsf("Press '0' if OK else \"ESC\"\r");
	if(device_number==1)
		putsf("Press '1' if OK else \"ESC\"\r");
	while(1)
		{
		#asm("wdr");   					// Reset Watchdog
		act_key = debug_check_rx();
		if(act_key!=-1)			// Debug data Receive Complete
			{
			lva=act_key;
			if(lva==0x1b)	// ESC-Sign
				break;
			lva=atoi(&lva);
			if(device_number==lva)
				{
				return ds2430a_write_prom(&romcodes_1wire[device_number,0], mac, 0, DS2430_PROM_SIZE);
				}
			else
				{
				if(device_number==0)
					putsf("Press '0' if OK else \"ESC\"\r");
				if(device_number==1)
					putsf("Press '1' if OK else \"ESC\"\r");
				}
			}
		}
	}
return 0;
}

//********************************************************************************
// Description	: help infos to the terminal commands
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ds2430a_prog_help(void)
{
putsf("\"ds2430-info\" - all informations to the DS2430\r"); 
putsf("\"write-mac\" - write a mac to DS2430-PROM\r"); 
putsf("        example:\"write-mac 00:50:c2:21:10:f9\"\r"); 
putsf("                \"write-mac 00:50:c2:21:10:f9 1\"\r"); 
}


//********************************************************************************
// Description	: command handler
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void ds2430_prog_cmd(unsigned char *command)
{
if(strncmpf(command, "help", 4)==0)
	{
	ds2430a_prog_help();
	}
if(strncmpf(command, "ds2430-info", 8)==0)
	{
	ds2430_prog_info();
	}
if(strncmpf(command, "write-mac", 9)==0)
	{
	if(ds2430_prog_write_mac(command))
		{
		putsf("DS2430-PROM written\r"); 
		ds2430_prog_info();
		}
	else
		putsf("DS2430-PROM no changed (see command syntax or PROM already changed)\r"); 
	}
}

#endif		// #ifdef DS2430_WRITE_PROM
