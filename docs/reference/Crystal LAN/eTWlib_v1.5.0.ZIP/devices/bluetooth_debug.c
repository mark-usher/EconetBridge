// ************************************************************************************************
///
/// \file 			bluetooth_debug.c
/// \brief			Debug functions for bluetooth.c
///
/// \todo			Convert module to new debug handler framework
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef WEB_DEBUG_BLUETOOTH

#include <stdio.h>
#include <string.h> 
#include <delay.h> 
#include <io.h>
#include "board.h"
#include "bluetooth_debug.h"
#include "bluetooth.h"
#include "debug.h"
#include "web_debug.h"
#include "board.h"


#define MAX_BLUETOOTH_DEBUG_BUFFER_SIZE		256

#pragma regalloc-
unsigned char bluetooth_debug_buffer[MAX_BLUETOOTH_DEBUG_BUFFER_SIZE];
unsigned char bluetooth_debug_buffer_pos=0;
unsigned char bluetooth_debug_buffer_flag=0;
#pragma regalloc+

//*********************************************************************************
// Description	: store the debug data
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
void bluetooth_debug_data(unsigned char data)
{
        if(data) {
        	bluetooth_debug_buffer[bluetooth_debug_buffer_pos]=data;
        	bluetooth_debug_buffer_pos++;
        	bluetooth_debug_buffer_flag=1;
       	}
}

//*********************************************************************************
// Description	: displays all data of bluetooth-stack
// Input	   	: none
// Output   	: none
// Indication	: none
//*********************************************************************************
void bluetooth_debug_display(unsigned char init)
{
        static unsigned char last_position=0;
        static unsigned char last_sign=0;
        unsigned char act_position=0, data;
        unsigned char sreg_tmp;
        
        if(init) {
                last_position=0;
                last_sign=0;
                return;
        }
        if(bluetooth_debug_buffer_flag) {
                sreg_tmp = SREG;
                #asm("cli");	 	// Global disable interrupts
                bluetooth_debug_buffer_flag=0;
        	act_position=bluetooth_debug_buffer_pos;
        	SREG = sreg_tmp;    // Global enable interrupts
        	while(act_position!=last_position) {
        		data=bluetooth_debug_buffer[last_position];
        		last_position++;
        		if(data>=0x20) {
        			if(last_sign==0) {
        				last_sign=1;
//      				putsf("\r");
       				}
               			putchar(data);
        		} else {
                                if(last_sign) {
        				last_sign=0;
        				putsf("\r");
       				}
//              		printf("0x%02x ", data);
        		}
                }		
        }
}

//********************************************************************************
// Description	: command handler
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void bluetooth_debug_do_cmd(unsigned char *command)
{
static unsigned char blue_config=0;
static unsigned char blue_remote=0;
//unsigned char *address = 0;
//unsigned char comm[15];
unsigned char Lva;

if(blue_config)
	{
	bluetooth_at_command_sram(command);
	if((strncmpf(command, "quit", 4)==0)||(strncmpf(command, "exit", 4)==0))
		{
		if(blue_remote)
			{
			delay_ms(100);
			bluetooth_at_command_flash("at**brsch=1");		
			blue_remote = 0;
			}
		if(UBRR1L!=(_MCU_CLOCK_FREQUENCY_/(8*115200)-1))
			{
			bluetooth_reset();
        	UBRR1L=_MCU_CLOCK_FREQUENCY_/(8*115200)-1;  	// ==16 bei 115200Baud und 16.0000Mhz (2.1% Fehler)
        	}
		putsf("Blue DISABLE Configurator\r");
		blue_config=0;
		}
	}
if((strncmpf(command, "AT", 2)==0)||(strncmpf(command, "at", 2)==0))
	{
	bluetooth_at_command_sram(command);    // 
	if((strncmpf(command, "ATCONF", 6)==0)||(strncmpf(command, "atconf", 6)==0))
		{
		putsf("Blue ENABLE Configurator\r");
		blue_config=1;
		}
	return;
	}
if(strncmpf(command, "blue-reset", 8)==0)
	{
	bluetooth_reset();
	putsf("Blue RESET\r");
	return;
	}
if(strncmpf(command, "blue-config", 6)==0)
	{
	DSR1_INPUT;		// set DSR to Input
	if(DSR1_PIN)	// reads the DSR-Line
		{
		putsf("Blue Adapter not available\r");
		return;
		}
	UBRR1L=_MCU_CLOCK_FREQUENCY_/(8*9600)-1; 		// ==207 bei 9600kBaud und 16.0000Mhz (0.2% Fehler)
	memset(bluetooth_debug_buffer, 0, sizeof(bluetooth_debug_buffer));
	bluetooth_debug_buffer_pos=0;
	bluetooth_debug_display(1);		// clear the internal variables
	bluetooth_reset();
	putsf("Blue Configuration with 9600Baud - please wait 5 sec\r");
	for(Lva=0;Lva<25;Lva++)
		{
		printf("#");
		delay_ms(200);
		if(strpbrkf(bluetooth_debug_buffer, "configurator +++"))
			break;
		}
	putsf("\r");
	if(Lva<25)
		{
		uart1_putchar(0x0d);	// CR
		uart1_putchar(0x0d);	// CR
		uart1_putchar(0x1b);	// ESC
		uart1_putchar(0x1b);	// ESC
		blue_config=1;
		bluetooth_debug_display(0);
		}
	else
		{
		putsf("Blue Configuration Timeout\r");
               	UBRR1L=_MCU_CLOCK_FREQUENCY_/(8*115200)-1;  	// ==16 bei 115200Baud und 16.0000Mhz (2.1% Fehler)
       	}
	return;
	}
if(strncmpf(command, "blue-esc", 6)==0)
	{
	uart1_putchar('+');
	uart1_putchar('+');
	uart1_putchar('+');
	putsf("Blue AT-command\r");
	return;
	}
if(strncmpf(command, "blue-send", 6)==0)
	{
	command=debug_search_parameter(command);
	bluetooth_at_command_sram(command);
	putsf("Blue data sent\r");
 	return;
	}
/*
if(strncmpf(command, "blue-auto", 6)==0)
	{
	DTR1_H;
	DTR1_OUTPUT;
	DTR1_L;
	putsf("Blue-RS Autoconnect DTR\r");
	return;
	}
if((strncmpf(command, "blue-remote", 8)==0))
	{
	bluetooth_at_command_flash("at**brsch=30");
	delay_ms(100);
	printf("Enter Remote Address: ");
	while(address == 0) 
		address = debug_command();
	strcpyf(comm, "atd ");
	strcat(comm, address);
	bluetooth_at_command_sram(comm);
	delay_ms(3000);
	uart1_putchar(0x0d);
	blue_config=1;
	putsf("\rRemote Control established\r");
	blue_remote=1;
	return;
	}
*/
}

#endif	// #ifdef WEB_DEBUG_BLUETOOTH
