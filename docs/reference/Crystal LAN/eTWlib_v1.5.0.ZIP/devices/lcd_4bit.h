// ************************************************************************************************
///
/// \file 			lcd_4bit.h
/// \brief			header file of lcd_4bit.c
///
/// \date	 		$LastChangedDate: 2007-02-22 09:58:39 +0100 (Do, 22 Feb 2007) $
/// \version 		$Rev: 565 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************
/// \defgroup Device_Driver
/// \addtogroup Device_Driver
/// @{
/// \defgroup LCD_4Bit
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define LCD_4BIT
#define LCD_X_SIZE						20
#define LCD_Y_SIZE						4
#define LCD_BUFFER_ENABLE
#define LCD_4BIT_DEBUG
#define LCD_CONTROLLER_KS0073
#define LCD_CONTROLLER_HD44780
#define LCD_FIX_DELAY					// _lcd_ready waits a fix time
#define LCD_RS_ACTIV					DDRF|=0x01
#define LCD_RS_PASSIV					DDRF&=~0x01
#define LCD_RS_HIGH						PORTF|=0x01
#define LCD_RS_LOW						PORTF&=~0x01
#define LCD_RS_PIN						(PINF & 0x01)
#define LCD_EN_ACTIV					DDRF|=0x04
#define LCD_EN_PASSIV					DDRF&=~0x04
#define LCD_EN_HIGH						PORTF|=0x04
#define LCD_EN_LOW					 	PORTF&=~0x04
#define LCD_EN_PIN						(PINF & 0x04)
#define LCD_RD_ACTIV					DDRF|=0x02
#define LCD_RD_PASSIV					DDRf&=~0x02
#define LCD_RD_READ						PORTF|=0x02
#define LCD_RD_WRITE  					PORTF&=~0x02
#define LCD_RD_PIN		   				(PINC & 0x02)
#define LCD_DATA_ACTIV				 	DDRF|=0xf0
#define LCD_DATA_PASSIV					DDRF&=~0xf0
#define LCD_DATA_WRITE(d)				PORTF = ((PORTF&0x0f) | d)   // data is passed as high nibble of 'd'
#define LCD_DATA_READ	  				(PINF & 0xf0)
//@}
#endif

#ifndef _LCD_4BIT_INCLUDED_
#define _LCD_4BIT_INCLUDED_

#include "project.h"


///	\def LCD_4BIT
///		This Macro enables the complete LCD module. Define it in project.h to use the module
///
///	\def LCD_X_SIZE
///		X size of the used display in characters. If not defined in project.h, default value is 
///		used.
///
///	\def LCD_Y_SIZE
///		Y size of the used display in characters. If not defined in project.h, default value is 
///		used.
///
///	\def LCD_BUFFER_ENABLE
///		The LCD Module features an data buffer. If LCD_BUFFER_ENABLE is defined in project.h,
///		you can use the lcd_buffer_.. functions to write to an local display buffer. The data
///		will then be transfered to the LCD with lcd_buffer_write(). This reduces the number of
///		hardware accesses when composing display contents.
///
///	\def LCD_4BIT_DEBUG
///		Enables Debug functions and debug command handler in the LCD module. Define it in your
///		project.h
///
///	\def LCD_CONTROLLER_KS0073
///		Must be defined in project.h to be compatible with KS0073 display controller.
///
///	\def LCD_CONTROLLER_HD44780
///		If neither LCD_CONTROLLER_KS0073, nor LCD_CONTROLLER_HD44780 is defined in project.h, 
///		LCD_CONTROLLER_HD44780 is used. HD44780 is the most common dotmatrix display controller
///
///	\def LCD_FIX_DELAY
///		Libray can use an fixed delay or polling of the busy bit in the lcd module to check, 
///		whether display is ready to proceed next command. An timeout is NOT implemented yet.
///
///	\def LCD_RS_ACTIV
///		Configures the Register-Select-Line as output. Example: #define LCD_RS_ACTIV   DDRB|=0x40
///		Must be defined in project.h to use the module.
///
///	\def LCD_RS_PASSIV
///		Configures the Register-Select-Line as input. Must be defined in project.h.
///
///	\def LCD_RS_HIGH
///		Sets Register-Select-Line high. Must be defined in project.h.
///
///	\def LCD_RS_LOW
///		Sets Register-Select-Line low. Must be defined in project.h.
///
///	\def LCD_RS_PIN
///		Reads the state of the Register-Select-Line. Example: #define LCD_RS_PIN   (PINB&0x40)
///
///	\def LCD_EN_ACTIV
///		Configures the Enable signal as output. Must be defined in project.h.
///
///	\def LCD_EN_PASSIV
///		Configures the Enable signal as input. Must be defined in project.h.
///
///	\def LCD_EN_HIGH
///		Sets Enable signal high. Must be defined in project.h.
///
///	\def LCD_EN_LOW
///		Sets Enable signal low. Must be defined in project.h.
///
///	\def LCD_EN_PIN
///		Reads the state of the Enable signal. Must be defined in project.h.
///
///	\def LCD_RD_ACTIV
///		Configures the Read/Write signal as output. Must be defined in project.h.
///
///	\def LCD_RD_PASSIV
///		Configures the Read/Write signal as input. Must be defined in project.h.
///
///	\def LCD_RD_READ
///		Sets Read/Write signal to high. This means 'Read'. Must be defined in project.h.
///
///	\def LCD_RD_WRITE
///		Sets Read/Write signal to low. This means 'Write'. Must be defined in project.h.
///
///	\def LCD_RD_PIN
///		Reads the state of the Read/Write signal. Must be defined in project.h.
///
///	\def LCD_DATA_ACTIV
///		Configures the data lines as output. Must be defined in project.h.
///
///	\def LCD_DATA_PASSIV
///		Configures the data lines as input. Must be defined in project.h.
///
///	\def LCD_DATA_WRITE
///		Writes 4 Bit of data to the data lines. The Parameter 'd' contains the 4 bit
///		in the high nibble. Must be defined in project.h.
///
///	\def LCD_DATA_READ
///		Reads 4 Bit of data. 4 data bits are stored in the high nibble of the return byte
///		Must be defined in project.h.


#if !defined(LCD_CONTROLLER_KS0073) && !defined(LCD_CONTROLLER_HD44780)
#define LCD_CONTROLLER_HD44780
#endif

#ifndef LCD_Y_SIZE
#define LCD_Y_SIZE		4
#endif
#if (LCD_Y_SIZE>4)
#error "LCD: LCD_Y_SIZE too high. modify _base_y to work with LCD_Y_SIZE>4"
#endif

#ifndef LCD_X_SIZE
#define LCD_X_SIZE		16
#endif

#pragma used+
void 			lcd_init(void);
void 			lcd_controller_init(void);
unsigned char 	lcd_check(void);
unsigned char 	lcd_read_busy_ac(void);
void 			lcd_write_dd_cg_ram(unsigned char addr, unsigned char data);
void 			lcd_write_cgram(unsigned char c, unsigned char row, unsigned char data);
unsigned char 	lcd_read_dd_cg_ram(unsigned char addr);
void 			lcd_gotoxy(unsigned char x, unsigned char y);
void 			lcd_clear(void);
void 			lcd_clear_line(unsigned char x, unsigned char y);
void 			lcd_putchar(char c);
void 			lcd_puts(char *str);
void 			lcd_putsf(char flash *str);
void 			lcd_puts_line(char *str, unsigned char line);
void 			lcd_putsf_line(char flash *str, unsigned char line);
#ifdef LCD_BUFFER_ENABLE
void 			lcd_buffer_copy(void);
void 			lcd_buffer_clear(void);
void 			lcd_buffer_gotoxy(unsigned char x, unsigned char y);
void 			lcd_buffer_putchar(char c);
void 			lcd_buffer_puts(char *str);
void 			lcd_buffer_putsf(char flash *str);
void 			lcd_buffer_write(void);
#endif
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library lcd_4bit.c
#endif

#endif	// #ifndef _LCD_4BIT_INCLUDED_

/// @}
/// @}