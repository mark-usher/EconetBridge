// ************************************************************************************************
///
/// \file 			ds2415.h
///
/// \date	 		$LastChangedDate: 2007-03-07 15:45:14 +0100 (Mi, 07 Mrz 2007) $
/// \version 		$Rev: 608 $
///	\author  		Nico M�ding<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _DS2415_INCLUDED_
#define _DS2415_INCLUDED_  

// Rom search family code 
#define DS2415_FAMILY_CODE	0x24

// Definition: 1st of January 2004
#define REFP_DATE_YEAR		2004		// Reference date
#define REFP_DATE_MONTH	   	1
#define REFP_DATE_DAY	   	1

// Typedef stuctures
typedef struct{
	unsigned char sec;
	unsigned char min;
	unsigned char hour;
	unsigned char day;
	unsigned char month;
	unsigned int  year;
	} TIME_DATE;

// Functions
#pragma used+
extern unsigned char ds2415_write_clock(unsigned char control, unsigned long rtc_counter);
extern unsigned char ds2415_read_clock(unsigned char *control, unsigned long *rtc_counter);
extern unsigned char ds2415_set_time_date(TIME_DATE *time_date);
extern unsigned char ds2415_get_time_date(TIME_DATE *time_date);
#ifdef DS2415_DEBUG
extern void ds2415_debug_print_time(void);
#endif
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library ds2415.c
#endif

#endif