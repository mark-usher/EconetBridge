// ************************************************************************************************
///
/// \file 			ds2415.c
/// \brief			DS2415 1-Wire Real Time Chip
///
/// \date	 		$LastChangedDate: 2007-03-07 15:45:14 +0100 (Mi, 07 Mrz 2007) $
/// \version 		$Rev: 608 $
///	\author  		Nico M�ding, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"			// Project configuration

#include <stdio.h>
#include "debug.h"
#include "1wire_irq.h"
#include "ds2415.h"

// Lokale Funktionen
void 		  ds2415_calc_time_date(TIME_DATE *time_date, unsigned long rtc_counter);
unsigned long ds2415_calc_rtc(TIME_DATE *time_date);
unsigned int  ds2415_get_days_per_year(unsigned int year );
unsigned char ds2415_get_days_per_month(unsigned int year, unsigned char month );
#ifdef DS2415_DEBUG
void ds2415_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);
#endif

// Clock Function Commands
#define DS2415_READ_CLOCK	0x66		// Z�hler lesen
#define DS2415_WRITE_CLOCK	0x99		// Z�hler schreiben

// Control register bit definitions
#define DS2415_OSC_ENB		0x0C	    // Oszillator aktivieren
#define DS2415_OSC_DIS		0x00		// Oszillator deaktivieren 

// *********************************************************************************
/// \brief		Checks the 1-Wire bus wether a DS2415 is present
///
/// @param[in]	romcode - pointer to 1-Wire rom code buffer
/// @param[out]	romcode - data of DS2425 romcode
/// @retval	 	1       - DS2415 present
///	@retval		0       - error
// *********************************************************************************
unsigned char ds2415_init(unsigned char **romcode)
{
#ifdef	WIRE_IRQ		// controls the use of disable and enable of global IRQ
unsigned char sreg;
#endif
#ifdef DS2415_DEBUG
T_DEBUG_HANDLER_STRUCT p_struct;
#endif
unsigned char romcodes_1wire[BOARD_MAX_1WIRE_DEVICES, 9];
unsigned char devices_1wire;
static unsigned char ds2415_romcode[1, 9];	// memory to save the DS2415 rom code	
static unsigned char ds2415_ok=0;

if (ds2415_ok == 1)
	{
	if (romcode)
		*romcode=&ds2415_romcode[0, 0];
	return 1;
	}
if (romcode)
	*romcode=0;
#ifdef DS2415_DEBUG
p_struct.fp_handler = &ds2415_debug_handler;
p_struct.id_string = "ds2415";
debug_register_handler(&p_struct);
#endif	// #ifdef DS2415_DEBUG
#ifdef	WIRE_IRQ		// controls the use of disable and enable of global IRQ
sreg=SREG;
#asm("cli");
#endif
devices_1wire = w1_search(0xf0, romcodes_1wire);	// search all 1Wire-Devices
if (devices_1wire > BOARD_MAX_1WIRE_DEVICES)
	devices_1wire = 0;		// return error (no devices found)
#ifdef	WIRE_IRQ			// controls the use of disable and enable of global IRQ
SREG=sreg;
#endif
while (devices_1wire)
	{
	devices_1wire--;
	if (romcodes_1wire[devices_1wire, 0] == DS2415_FAMILY_CODE)	// found DS2415
		{
		memcpy(ds2415_romcode, &romcodes_1wire[devices_1wire, 0], sizeof(ds2415_romcode));
		if (romcode)
			*romcode = &ds2415_romcode[0, 0];
		ds2415_ok=1;
		return 1;
		}
	}
return 0;
}


// ********************************************************************************
/// \brief		Selects a specific DS2415 on the bus
/// \note		If romcode NULL then only one 1 Wire device can be used
/// @retval 	1       - 1wire device found
///	@retval		0       - 1wire device not present
// *********************************************************************************
unsigned char ds2415_select(void)
{
unsigned char  i;
unsigned char* romcode;

if(!ds2415_init(&romcode))
	return 0;
if(!W1_INIT())
	return 0;
if(romcode)
	{
	W1_WRITE(0x55);		// write "Match ROM" command
	for (i=0;i<8;i++)
   		W1_WRITE(*romcode++);
	}
else 
	return W1_WRITE(0xCC);	// write "Skip ROM" command
}


// *********************************************************************************
/// \brief		Writes DS2415 control byte and rTC data.
///
/// @param[in]	control	- control byte
/// @param[in]	rtc_counter	- 32 Bit count of RTC data
/// @retval 	1       - control byte and RTC data writed
///	@retval		0       - error
// *********************************************************************************
unsigned char ds2415_write_clock(unsigned char control, unsigned long rtc_counter)
{
unsigned char count;

if (!ds2415_select()) return 0;		// selects the DS2415 on 1-Wire Bus
W1_WRITE(DS2415_WRITE_CLOCK);		// write command
W1_WRITE(control); 				 	// control byte
for (count=0; count<4; count ++ )	// LSB first
	{
	W1_WRITE((unsigned char)rtc_counter);
	rtc_counter = rtc_counter >> 8;
	}
W1_INIT();
return 1;
}


// *********************************************************************************
/// \brief		Reads DS2415 control byte and RTC data.
///
/// @param[in]	control - pointer control byte
/// @param[in]	rtc_counter	- 32 Bit count of RTC data
/// @retval 	1       - control byte and RTC data writed
///	@retval		0       - error
// *********************************************************************************
unsigned char ds2415_read_clock(unsigned char *control, unsigned long *rtc_counter)
{
unsigned char count;
unsigned long data;

if (!ds2415_select())				// selects the DS2415 on 1-Wire Bus
	return 0;	
W1_WRITE(DS2415_READ_CLOCK);		// write command
*control = W1_READ(); 			 	// reads control byte
*rtc_counter = 0;
for (count=0; count<32; count+=8)	// LSB first
	{
	data = W1_READ();
	*rtc_counter |= (data << count);
	}
return 1;
}


// *********************************************************************************
/// \brief		Writes time and date
///
/// @param[in]	time 	- pointer of time structure
/// @param[in]	date 	- pointer of date structure
/// @retval 	1       - time and date ready
///	@retval		0       - error
// *********************************************************************************
unsigned char ds2415_set_time_date(TIME_DATE *time_date)
{
unsigned long rtc_counter;

// check time ?
if ((time_date->hour > 23)||(time_date->min > 60)||(time_date->sec > 60))
	return 0;
// check date ?
if ((time_date->year<REFP_DATE_YEAR) || 
	(time_date->year > (REFP_DATE_YEAR+135)) ||
	(time_date->month > 12))
	return 0;
else
   	if (time_date->day > ds2415_get_days_per_month(time_date->year, time_date->month))
      	return 0;
rtc_counter = ds2415_calc_rtc(time_date);	// calculate RTC counter
return ds2415_write_clock(DS2415_OSC_ENB, rtc_counter);
}


// *********************************************************************************
/// \brief		Reads time and date.
///
/// @param[in]	time_date- pointer of time and date structure
/// @retval 	1       - time and date ready
///	@retval		0       - error
// *********************************************************************************
unsigned char ds2415_get_time_date(TIME_DATE *time_date)
{
unsigned char control;
unsigned long rtc_counter;

if(ds2415_read_clock(&control, &rtc_counter))			// reads the Real Time Clock
	{
	if(time_date)
		ds2415_calc_time_date(time_date, rtc_counter);	// calculate time and date
	return 1;
	}
return 0;
}


// *********************************************************************************
/// \brief 		Calculation of time and date from 32 Bit counter
///
/// @param[in]	time_date 	- pointer to time and date structure
/// @param[in]	RTC_Zahler	- 32 Bit counter
// *********************************************************************************
void ds2415_calc_time_date(TIME_DATE *time_date, unsigned long rtc_counter)
{
unsigned int dpy, dpm;		// Tage pro Jahr / Tage pro Monat

// Referenzpunkt Datum
time_date->year = REFP_DATE_YEAR;
time_date->month = REFP_DATE_MONTH;
time_date->day = REFP_DATE_DAY;
dpy = ds2415_get_days_per_year(REFP_DATE_YEAR);
dpm = ds2415_get_days_per_month(REFP_DATE_YEAR, REFP_DATE_MONTH);

// calculation of seconds, minutes and hours
time_date->sec = (unsigned char) (rtc_counter % 60);
time_date->min = (unsigned char) ((rtc_counter /= 60) % 60 );  // minus seconds
time_date->hour = (unsigned char) ((rtc_counter /= 60) % 24 ); // minus minutes
rtc_counter /= 24;	// minus hour

// calculation of years
while (rtc_counter >= dpy)
	{
   	rtc_counter -= dpy;
   	dpy = ds2415_get_days_per_year(++time_date->year );
	}
// calculation of months
while (rtc_counter >= dpm )
	{
   	rtc_counter -= dpm;
   	dpm = ds2415_get_days_per_month(time_date->year, ++time_date->month );
	}
// calculation of days
time_date->day += (unsigned char) rtc_counter;
}



// *********************************************************************************
/// \brief 		Calculation from 32 Bit counter to time and date
///
/// @param[in]	time_date 	- pointer to time and date structure
/// @retval 	RTC_counter	- 32 Bit count
// *********************************************************************************
unsigned long ds2415_calc_rtc(TIME_DATE *time_date)
{
unsigned long counter;
unsigned int hour, min;

// days
counter = time_date->day - 1;
// months converted in days
while (time_date->month > 1)
	counter += ds2415_get_days_per_month(time_date->year, --time_date->month );
// years converted in days
while (time_date->year > 2004)
   	counter += ds2415_get_days_per_year(--time_date->year );
// Tage und Zeit in Z�hlerwert umrechnen
hour = time_date->hour;
min = time_date->min;

return (counter*24*60*60 + hour*60*60 + min*60 + time_date->sec);
}



// *********************************************************************************
/// \brief		days of year.
///
/// @param[in]	year	- count of year with 16 Bit
/// @retval		days of year
// *********************************************************************************
unsigned int ds2415_get_days_per_year(unsigned int year)
{
if (((year % 4)== 0) && year!=2000)
   	return 366;		// leap year
else
   	return 365;		// normal year
}



// *********************************************************************************
/// \brief		days of months
///
/// @param[in]	year	- count of year with 16 Bit
/// @param[in]	month	- count of month with 8 Bit
/// @retval		days of months
// *********************************************************************************
unsigned char ds2415_get_days_per_month(unsigned int year, unsigned char month)
{
if (month == 2)				// Februar
   	if (((year % 4) == 0) && year!=2000)
      	return 29;			// leap year
   	else
      	return 28;			// normal year
else if( (month == 4) ||    // April
   	 	 (month == 6) ||    // Juni
		 (month == 9) ||    // September
   	 	 (month == 11) )    // November
	return 30;
else						// rest of months
   	return 31;
}

#ifdef DS2415_DEBUG
// ************************************************************************************************
/// \brief		Help infos to the terminal commands of DS2415
///
// ************************************************************************************************
void ds2415_debug_help(void)
{
putsf("\"ds2415-init\" - search the DS2415 and init internal data\r");
putsf("\"ds2415-write\" - writes 0 to RTC counter\r");
putsf("\"ds2415-read\" - reads and display the RTC counter\r");
putsf("\"ds2415-time\" - reads and display date and time from RTC counter\r");
}

// ************************************************************************************************
/// \brief		Help infos to the terminal commands of DS2415
///
// ************************************************************************************************
void ds2415_debug_print_time(void)
{
TIME_DATE time_date;

ds2415_get_time_date(&time_date);
printf("DS2415 date/time: %02d:%02d:%02d / ", time_date.day, time_date.month, time_date.year);
printf("%02d:%02d:%02d\r\n", time_date.hour, time_date.min, time_date.sec);
}

// ************************************************************************************************
/// \brief	    command handler for debug commands
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void ds2415_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
signed long data=0;	
unsigned char control;

if (mode == DEBUG_HANDLER_MODE_INFO)
	ds2415_debug_print_time();
else if (mode == DEBUG_HANDLER_MODE_HELP)
	ds2415_debug_help();
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-init", 5)==0)
		{
		if(ds2415_init(0))
			printf("DS2415 init\r\n");
		else
			printf("DS2415 error\r\n");
		return;
		}
	if (strncmpf(command, "-write", 6)==0)
		{
		data = debug_get_long_parameter(command);
		if(data==-1)
			data=0;
		ds2415_write_clock(DS2415_OSC_ENB, data);
		printf("DS2415 write\r\n");
		return;
		}
	if (strncmpf(command, "-read", 5)==0)
		{
		ds2415_read_clock(&control, &data);
		printf("DS2415 read: %d (0x%x)\r\n", data, data);
		if(control & DS2415_OSC_ENB)
			printf("DS2415 running\r\n");
		else
			printf("DS2415 not running\r\n");
		return;
		}
	if (strncmpf(command, "-time", 5)==0)
		{
		ds2415_debug_print_time();
		return;
		}
	}
}
#endif	// #ifdef DS2415_DEBUG
