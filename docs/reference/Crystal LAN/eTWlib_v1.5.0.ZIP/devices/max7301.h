// ************************************************************************************************
///
/// \file 			max7301.h
///
/// \date	 		$LastChangedDate: 2007-01-12 15:13:47 +0100 (Fr, 12 Jan 2007) $
/// \version 		$Rev: 485 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup Device_Driver
/// \addtogroup Device_Driver
/// @{
/// \defgroup MAX7301
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define MAX7301_ENABLE
#define MAX7301_DEBUG
#define MAX7301_MAX_CHIPS
#define MAX7301_CHECK_PARAMS
//@}
#endif


#ifndef _MAX7301_INCLUDED_
#define _MAX7301_INCLUDED_

#include "project.h"

#ifdef MAX7301_ENABLE
#include "gpio.h"


///	\def MAX7301_ENABLE
///		This Macro enables the complete MAX7301 module. Define it in project.h to use the module
///
///	\def MAX7301_DEBUG
///		Enables debug output and debug handler in for the whole module.
///
///	\def MAX7301_MAX_CHIPS
///		Limits the number of MAX7301 devices, which can be registered with max7301_register()
///
///	\def MAX7301_CHECK_PARAMS
///		If defined, function parameters will be checked for validity
///

#ifndef GPIO_ENABLE
#error "GPIO Module is needed for Max7301. Define GPIO_ENABLE."
#endif
#ifndef SPI_ENABLE
#error "SPI Module is needed for Max7301. Define SPI_ENABLE."
#endif

#ifndef MAX7301_MAX_CHIPS
#define MAX7301_MAX_CHIPS	1
#endif


// ---------------------------------------------------------------------------
/// \typedef MAX7301_DEV
/// \brief   This structure identifies an MAX7301 device. Is is used as 
///			 parameter of the function max7301_register()
// ---------------------------------------------------------------------------
typedef struct{
	unsigned char 	id;						///< chip id, used in all further function calls
	GPIO_PORT_ENUM 	ss_port;				///< name of port of SPI slave select signal
	unsigned char 	ss_pin;					///< pin number of SPI slave select signal
    } MAX7301_DEV;							///< struct to identify max7301 device.
    

#define MAX7301_OUTPUT			0x01		///< describes port configuration
#define MAX7301_INPUT			0x02		///< describes port configuration
#define MAX7301_PULLUP_ON		0x01		///< describes port configuration
#define MAX7301_PULLUP_OFF		0x00		///< describes port configuration

#define MAX7301_SHUT_ENABLE		0x00		///< used as parameter in max7301_write_config()
#define MAX7301_SHUT_DISABLE	0x01		///< used as parameter in max7301_write_config()
#define MAX7301_INT_ENABLE		0x80		///< used as parameter in max7301_write_config()
#define MAX7301_INT_DISABLE		0x00		///< used as parameter in max7301_write_config()

#define MAX7301_TR_P24			0x01		///< used as parameter in max7301_write_int_mask()
#define MAX7301_TR_P25			0x02		///< used as parameter in max7301_write_int_mask()
#define MAX7301_TR_P26			0x04		///< used as parameter in max7301_write_int_mask()
#define MAX7301_TR_P27			0x08		///< used as parameter in max7301_write_int_mask()
#define MAX7301_TR_P28			0x10		///< used as parameter in max7301_write_int_mask()
#define MAX7301_TR_P29			0x20		///< used as parameter in max7301_write_int_mask()
#define MAX7301_TR_P30			0x40		///< used as parameter in max7301_write_int_mask()

// prototypes
#pragma used+
void 			max7301_init(void);
unsigned char 	max7301_register(MAX7301_DEV* p_dev);
void 			max7301_nibble_config(unsigned char id, unsigned char nibble, unsigned char data);
void 			max7301_port_config(unsigned char id, unsigned char port, unsigned char mode);
void 			max7301_write_bit(unsigned char id, unsigned char port, unsigned char data);
unsigned char 	max7301_read_bit(unsigned char id, unsigned char port);
unsigned char 	max7301_write_bit_isr(unsigned char id, unsigned char data);
unsigned char 	max7301_read_bit_isr(unsigned char id);
void 			max7301_write_8bit(unsigned char id, unsigned char start, unsigned char data);
unsigned char 	max7301_read_8bit(unsigned char id, unsigned char start);
void 			max7301_write_int_mask(unsigned char id, unsigned char mask);
void 			max7301_write_config(unsigned char id, unsigned char mode);
void 			max7301_write_address(unsigned char id, unsigned char address, unsigned char data);
unsigned char 	max7301_read_address(unsigned char id, unsigned char address);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library max7301.c
#endif

#endif	// #ifdef MAX7301_ENABLE
#endif	// #ifndef _MAX7301_INCLUDED_

/// @}
/// @}