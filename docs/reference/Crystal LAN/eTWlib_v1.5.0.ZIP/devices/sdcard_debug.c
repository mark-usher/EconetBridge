// ************************************************************************************************
///
/// \file 			sdcard_debug.c
/// \brief			Debug functions for SD-Card Module
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Nico M�ding, Hubert Nestler, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#if  defined(SDCARD_ENABLE) && defined(SDCARD_DEBUG)

#include <io.h>
#include <math.h>
#include "sdcard.h"
#include "sdcard_debug.h"
#include "debug.h"

#define SDCARD_DEBUG_SPEED_READ_SINGLE		0
#define SDCARD_DEBUG_SPEED_WRITE_SINGLE		1
#define SDCARD_DEBUG_SPEED_READ_MULTIPLE	2
#define SDCARD_DEBUG_SPEED_WRITE_MULTIPLE	3


eeprom unsigned char sdc_debug_flag = 0x00;	// default: debug output off

// prototypes
void sdc_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);

// ************************************************************************************************
/// \brief		displays the Card Specific Data (CSD) register
/// @retval		1 - success <br>
/// @retval     0 - error
// ************************************************************************************************
void sdc_debug_init(void)
{
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &sdc_debug_handler;
p_struct.id_string = "sdc";
debug_register_handler(&p_struct);
}

// ************************************************************************************************
/// \brief		displays the Card Specific Data (CSD) register
/// @retval		1 - success <br>
/// @retval     0 - error
// ************************************************************************************************
unsigned char sdc_display_CSD_Reg(void)
{
unsigned char buff[16];
unsigned int temp, POS = 0;

if(sdc_read_CSD_Reg( buff ))
	{
	printf("---------------- Card Specific Data (CSD) Register ----------------\n\r");
   	printf("CSD Structure:				Version 1.%u\n\r", buff[0+POS]>>6 );
   	printf("Data read access time: 			TAAC = %x\n\r", buff[1+POS] );
   	printf("Data read access time (CLK cycles):	NSCA = %x\n\r", buff[2+POS]);
   	printf("Max. data transfer rate: 		TRAN_SPEED = %x\n\r", buff[3+POS]);
   	printf("Max. read data block length:		READ_BL_LEN = %u byte\n\r", (unsigned int) ldexp(1,(buff[5+POS] & 0x0F)));
   	temp = buff[4+POS];
   	/*printf("Card command classes: 			CCC = %x\n\r",
   			(((temp << 4) & 0x0FF0 ) | (buff[5+POS] >> 4) & 0x0F ) );*/
   	printf("Card command classes: 			CCC = %x%x\n\r", buff[4+POS],buff[5+POS]);
   	printf("Partial blocks for read allowed: 	READ_BL_PARTIAL = %u\n\r", ((buff[6+POS] >> 7) & 0x01) );
   	printf("Write block misalignment: 		WRITE_BLK_MISALIGN = %u\n\r", ((buff[6+POS] >> 6) & 0x01) );
   	printf("Read block misalignment: 		READ_BLK_MISALIGN = %u\n\r", ((buff[6+POS] >> 5) & 0x01) );
   	printf("DSR implemented: 			DSR_IMP = %u\n\r", ((buff[6+POS] >> 4) & 0x01) );
   	temp = buff[6+POS] & 0x03; temp = ((temp << 8) & 0x0300) | buff[7+POS];
   	printf("Device size:				C_SIZE = %u\n\r",
   			(((temp << 2) & 0x0FFF ) | ((buff[8+POS] >> 6) & 0x03)) );
   		// current consumptions missing -> buff[7-9] -> 12 bit
   	temp = buff[9+POS] & 0x03;
   	printf("Device size multiplier:			C_SIZE_MULT = %u / MULT = %u\n\r",
   			(((temp << 1) & 0x0007) | ((buff[10+POS] >> 7) & 0x01)),
   			(unsigned int) ldexp( 1, 2 + ((temp << 1) & 0x0007) | ((buff[10+POS] >> 7) & 0x01)) );
   	printf("Erase single block enable:		ERASE_BLK_EN = %u\n\r",
   			((buff[10+POS] >> 6) & 0x01) );
   	if (sdc_get_mmc_flag()==0)     //if sdcard
 		{
   		temp = ((buff[10+POS] << 1) & 0x7E);
   		printf("Erase sector size:			SECTOR_SIZE = %u\n\r", (temp | ((buff[11+POS] >> 7) & 0x01)) + 1 );
   		printf("Write protected group size:		WP_GPR_SIZE = %u\n\r", (buff[11+POS] & 0x7F) + 1 );
   		}
   	if (sdc_get_mmc_flag()==1)		//if mmccard
   		{
   		printf("Erase sector size:			SECTOR_SIZE = %u\n\r", ((buff[10] >> 2) & 0x1F) + 1);
   	   	temp = ((buff[10]& 0x03) << 3);
   	   	temp = ((temp |  ((buff[11]>>5))& 0x07)+1);
   		printf("Erase group size:			ERASE_GRP_SIZE = %u\n\r", (temp*((buff[10] >> 2) & 0x1F) + 1));
   	 	temp = (temp*((buff[10] >> 2) & 0x1F) + 1);
   		printf("Write protected group size:		WP_GPR_SIZE = %u\n\r", (((buff[11]) & 0x1F)+1)*temp);
   		}
	printf("Write protected group enable:		WP_GPR_ENABLE = %u\n\r", ((buff[12+POS] >> 7) & 0x01) );
   	printf("Write speed factor:			R2W_FACTOR = %u\n\r", ((buff[12+POS] >> 2) & 0x07) );
   	temp = ((buff[12+POS] << 2) & 0x0C);
   	printf("Max. write data block length:		WRITE_BL_LEN = %u byte\n\r", (unsigned int) ldexp( 1, (temp | ((buff[13+POS] >> 6) & 0x03))));
   	printf("Partial blocks for write allowed:	WRITE_BL_PARTIAL = %u\n\r", ((buff[13+POS] >> 5) & 0x01) );
   	printf("File format group:			FFG = %u\n\r", ((buff[14+POS] >> 7) & 0x01) );
  	printf("Copy flag (OTP):			COPY = %u\n\r",	((buff[14+POS] >> 6) & 0x01) );
  	printf("Permanent write protection:		PERM_WRITE_PROTECT = %u\n\r", ((buff[14+POS] >> 5) & 0x01) );
   	printf("Temporary write protection:		TMP_WRITE_PROTECT = %u\n\r", ((buff[14+POS] >> 4) & 0x01) );
  	printf("File format:				FILE_FORMAT = %u\n\r", ((buff[14+POS] >> 2) & 0x03) );
  	return 1;
	}
return 0;
}



// ************************************************************************************************
/// \brief		displays the Card Identification Data (CID) register
/// @retval		1 - success <br>
/// @retval     0 - error
// ************************************************************************************************
unsigned char sdc_display_CID_Reg(void)
{
unsigned char buff[16];
unsigned int POS = 0;

if(sdc_read_CID_Reg(buff))
	{
	printf("---------------- Card Identification (CID) Register ----------------\n\r");
  	printf("Manufacture ID:		MID = %d\n\r", buff[0+POS]);
   	printf("OEM/Application ID:	OID = ");
   	debug_display_mem_ascii(&buff[1+POS], 2, 0);
   	printf("\n\rProduct Name:		PNM = ");
   	debug_display_mem_ascii(&buff[3+POS], 5, 0);
   	printf("\n\rProduct Reversion:	PRV = %u\n\r", buff[8+POS]);
   	printf("Product Serial Number:	PSN = %lu\n\r",  sdc_cctli( &buff[9+POS] ) );
   	printf("Manufacture Date Code:	MDT[my] = %u.0%u\n\r\n\r", (buff[14+POS] & 0x0F),
   			(((buff[13+POS] << 4) & 0xF0) | ((buff[14+POS] >> 4) & 0x0F)) );
	return 1;
}
return 0;
}



// ************************************************************************************************
/// \brief 	  	displays the Operating Condition Register (OCR)
/// @retval		1 - success <br>
/// @retval     0 - error
// ************************************************************************************************
unsigned char sdc_display_OCR_Reg(void)
{
unsigned char buff[SDC_R3_LEN-SDC_R1_LEN];

if(sdc_read_OCR_Reg(buff))
	{
	printf("---------------- Operating Condition (OCR) Register ----------------\n\r");
	debug_display_mem_hex(buff, SDC_R3_LEN-SDC_R1_LEN, 16);
	return 1;
	}
return 0;
}



// ************************************************************************************************
/// \brief			  	displays the error code
///
// ************************************************************************************************
void sdc_disp_error_code(unsigned char opcode)
{
if(opcode != 0)
	printf("SDC ERROR CODE: ");
switch( opcode )
	{
	case 0: putsf("Init prozess done (seems to be working)!\r"); break;
	case SDC_ERROR_RESET_CARD: putsf("card reset failed!\r"); break;
	case SDC_ERROR_NO_CARD:	putsf("no card available!\r"); break;
	case SDC_ERROR_CARD_LOCKED: putsf("card is locked (write protection enabled)!\r"); break;
	case SDC_ERROR_IDLE_STATE_TAAC:	putsf("time out idle state process!\r"); break;
	case SDC_ERROR_INIT_FAILED:	putsf("card not initailized!\r"); break;
	case SDC_ERROR_WRONG_ADDRESS: putsf("misaligned address!\r"); break;
	case SDC_ERROR_WRITE_TAAC: putsf("time out after write (TAAC: time access)!\r"); break;
	case SDC_ERROR_WRITE_CRC16:	putsf("crc error write operation!\r"); break;
	case SDC_ERROR_WRITE_CARD: putsf("write error card!\r"); break;
	case SDC_ERROR_DATA_REJECTED: putsf("data rejected (write protection)!\r");	break;
	case SDC_ERROR_READ_TAAC: putsf("time out read!\r"); break;
	case SDC_ERROR_READ_CRC16: putsf("crc error read operation!\r"); break;
	case SDC_ERROR_ERASE_SECTOR: putsf("erase error!\r"); break;
	case SDC_ERROR_ADDR_SECTOR: putsf("address error sector!\r"); break;
	case SDC_ERROR_SPI_BUSY_FLAG: putsf("abort polling spi busy flag (collision detected)!\r");	break;
	default:
		putsf("unknown error!\r");
	}
}



// ************************************************************************************************
/// \brief			  	displays the detection register
///
// ************************************************************************************************
void sdc_disp_detect_reg(unsigned char opcode)
{
switch(opcode)
	{
	case SDC_STATUS_DETECTED: putsf("Card detetced!\r"); break;
	case (SDC_STATUS_DETECTED | SDC_STATUS_LOCKED):	putsf("Card detected, but locked!\r"); break;
	case (SDC_STATUS_DETECTED | SDC_STATUS_INITIALIZED): putsf("Card detected and initialized!\r");	break;
	case (SDC_STATUS_DETECTED | SDC_STATUS_INITIALIZED |  SDC_STATUS_LOCKED):putsf("Card detected and initialized but locked!\r"); break;
	case 0:	putsf("No card available!\r"); break;
	default:
	putsf("Further expansion, card changed !?\r");
	}
}


// ************************************************************************************************
/// \brief		  	command list for debug commands
//
// ************************************************************************************************
void sdc_debug_cmd_list(void)
{
putsf("\"sdc-xxx\" - scd/mmc debug commands:\r");
putsf("\tsdc-init         sdc-sector-size  sdc-block-size\r");
putsf("\tsdc-mem-cap      sdc-detection    sdc-error      sdc-num-blocks\r");
putsf("\tsdc-read-csd     sdc-read-cid     sdc-read-ocr   sdc-read-block <#>\r");
putsf("\tsdc-write-block  sdc-speed-read   sdc-speed-write<#>\r");
}

#define SDC_RW_MULTIPLE_BLOCKS		16
unsigned char sdc_debug_speed_buffer[512*SDC_RW_MULTIPLE_BLOCKS];
// ************************************************************************************************
/// \brief		  	command list for debug commands
//
// ************************************************************************************************
void sdc_debug_speed_read(unsigned long start_block, unsigned long count_block, unsigned char mode)
{
unsigned long error=0, ok=0, counter;
unsigned int counter_10ms_start, display_count=0;

printf("SDC-Speed #%li @ addr 0x%lx to #%li @ addr 0x%lx\n\r", start_block, sdc_get_addr_block(start_block),
										start_block+count_block-1, sdc_get_addr_block(start_block+count_block-1));
counter=count_block;
memset(sdc_debug_speed_buffer, 0xaa, sizeof(sdc_debug_speed_buffer));
counter_10ms_16bit=0;
while(counter)
	{
	if(mode==SDCARD_DEBUG_SPEED_READ_SINGLE)
		{
		if(sdc_read_single_block(sdc_get_addr_block(start_block), sdc_debug_speed_buffer, 512))
			ok++;
		else
			error++;
		counter--;
		start_block++;
		}
	if(mode==SDCARD_DEBUG_SPEED_WRITE_SINGLE)
		{
		if(sdc_write_single_block(start_block, sdc_debug_speed_buffer))
			ok++;
		else
			error++;
		counter--;
		start_block++;
		}
	if(mode==SDCARD_DEBUG_SPEED_READ_MULTIPLE)
		{
		if(sdc_read_multiple_blocks(sdc_get_addr_block(start_block), sdc_debug_speed_buffer, SDC_RW_MULTIPLE_BLOCKS))
			ok+=SDC_RW_MULTIPLE_BLOCKS;
		else
			error+=SDC_RW_MULTIPLE_BLOCKS;
		if(counter>=SDC_RW_MULTIPLE_BLOCKS)
			counter-=SDC_RW_MULTIPLE_BLOCKS;
		else
			counter=0;
		start_block+=SDC_RW_MULTIPLE_BLOCKS;
		}
	if(mode==SDCARD_DEBUG_SPEED_WRITE_MULTIPLE)
		{
		if(sdc_write_multiple_blocks(start_block, sdc_debug_speed_buffer, SDC_RW_MULTIPLE_BLOCKS))
			ok+=SDC_RW_MULTIPLE_BLOCKS;
		else
			error+=SDC_RW_MULTIPLE_BLOCKS;
		if(counter>=SDC_RW_MULTIPLE_BLOCKS)
			counter-=SDC_RW_MULTIPLE_BLOCKS;
		else
			counter=0;
		start_block+=SDC_RW_MULTIPLE_BLOCKS;
		}
	display_count++;
	if(display_count==64)
		{
		printf("\r%u", start_block);	// this command needs about xxxms
		display_count=0;
		}
	}
counter_10ms_start=counter_10ms_16bit;
start_block=count_block;					// save old count of blocks
count_block*=(sdc_get_block_size()*100);	// *"sdc_get_block_size" in Byte and *100
count_block/=counter_10ms_start;
printf("\rSDC-");
if(mode==SDCARD_DEBUG_SPEED_READ_SINGLE)
	printf("Read");
if(mode==SDCARD_DEBUG_SPEED_WRITE_SINGLE)
	printf("Write");
if(mode==SDCARD_DEBUG_SPEED_READ_MULTIPLE)
	printf("Multiple-Read");
if(mode==SDCARD_DEBUG_SPEED_WRITE_MULTIPLE)
	printf("Multiple-Write");
printf(": %ukByte - %u0ms - %ukByte/sec, error:%ld, ok:%ld\r\n", (unsigned int)(start_block*sdc_get_block_size()/1024),
					counter_10ms_start, (unsigned int)(count_block/1024), error, ok);
}



// ************************************************************************************************
/// \brief	    command handler for debug commands
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void sdc_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
unsigned char block[512];
signed long number, start_block;

if (mode == DEBUG_HANDLER_MODE_INFO)
    {
    printf("SDCARD_DEBUG");
	if (sdc_debug_flag & SDCARD_DEBUG_BIT)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
    printf("SDCARD_CMD_DEBUG");
	if (sdc_debug_flag & SDCARD_CMD_DEBUG_BIT)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
	}
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
    sdc_debug_cmd_list();
    // add output for 'help' command here
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
	{
	if (strncmpf(command, "sdccmd", 6)==0)
	    {
    	sdc_debug_flag ^= SDCARD_CMD_DEBUG_BIT;
    	if (sdc_debug_flag & SDCARD_CMD_DEBUG_BIT)
    		putsf("SDCARD_CMD_DEBUG ON\r");
    	else
    		putsf("SDCARD_CMD_DEBUG OFF\r");
	    }
	else if (strncmpf(command, "sdc", 3)==0)
	    {
    	sdc_debug_flag ^= SDCARD_DEBUG_BIT;
    	if (sdc_debug_flag & SDCARD_DEBUG_BIT)
    		putsf("SDCARD_DEBUG ON\r");
    	else
    		putsf("SDCARD_DEBUG OFF\r");
	    }
	}
else if (strncmpf(command, "-init", 5)==0)
	{
	sdc_init_card();
	sdc_disp_error_code(sdc_get_error_code());
	}
else if (strncmpf(command, "-sector-size", 12)==0)
	{
	if(sdc_status_detect(1))
		printf("Sector size: %i blocks\n\r", sdc_get_sector_size());
	else
		sdc_disp_error_code(sdc_get_error_code());
	}
else if (strncmpf(command, "-block-size", 11)==0)
	{
	if(sdc_status_detect(1))
		printf("Block size: %i bytes\n\r", sdc_get_block_size());
	else
		sdc_disp_error_code(sdc_get_error_code());
	}
else if (strncmpf(command, "-mem-cap", 8)==0)
	{
	if(sdc_status_detect(1))
		printf("Memory capacity: %li bytes\n\r", sdc_get_mem_cap());
	else
		sdc_disp_error_code(sdc_get_error_code());
	}
else if (strncmpf(command, "-num-blocks", 11)==0)
	{
	if(sdc_status_detect(1))
		printf("Number of blocks: %li \n\r", sdc_get_num_blocks());
	else
		sdc_disp_error_code(sdc_get_error_code());
	}
else if (strncmpf(command, "-detection", 10)==0)
	sdc_disp_detect_reg(sdc_init_module());
else if (strncmpf(command, "-error", 6)==0)
	sdc_disp_error_code(sdc_get_error_code());
else if (strncmpf(command, "-read-csd", 9)==0)
	{
	if(sdc_display_CSD_Reg() != 1)
		sdc_disp_error_code(sdc_get_error_code());
	}
else if (strncmpf(command, "-read-cid", 9)==0)
	{
	if(sdc_display_CID_Reg() != 1)
		sdc_disp_error_code(sdc_get_error_code());
	}
else if (strncmpf(command, "-read-ocr", 9)==0)
	{
	if(sdc_display_OCR_Reg() != 1)
		sdc_disp_error_code(sdc_get_error_code());
	}
else if (strncmpf(command, "-read-block", 11)==0)
	{
	number = debug_get_long_parameter(command);
	if (number == -1)
		number= 0;
	if (sdc_status_detect(1))
		{
		printf("Single block #%li @ addr 0x%lx:\n\r", number, sdc_get_addr_block(number));
		if (sdc_read_single_block(sdc_get_addr_block(number), block, sizeof(block)) == 1)
			{
			debug_display_mem_hex(block, 512, 16);
			}
		else
			{
			sdc_disp_error_code(sdc_get_error_code());
			}
		}
	}
else if (strncmpf(command, "-write-block", 12)==0)
	{
	memset(block, 0xaa, sizeof(block));
	number = debug_get_long_parameter(command);
	if (number == -1)
		number= 0;
	if (sdc_status_detect(1))
		{
		printf("Single block #%li @ addr 0x%lx:\n\r", number, sdc_get_addr_block(number));
		if (sdc_write_single_block(number, block) == 1)
			{
			debug_display_mem_hex(block, 512, 16);
			}
		else
			{
			sdc_disp_error_code(sdc_get_error_code());
			}
		}
	}
/*
else if (strncmpf(command, "-set-wp ", 8)==0)
	{
	if (sdc_get_wp_grp_enable()==1)
		{
		number = debug_get_long_parameter(command);
		sdc_set_wp(sdc_get_group_addr(number), unsigned int num_groups);
    	//sdc_disp_error_code(sdc_get_error_code());
    	}
  	else
  		printf("wird nicht unterst�tzt!\n\r");
	}
else if (strncmpf(command, "-clr-wp ", 8)==0)
	{
	if (sdc_get_wp_grp_enable()==1)
		{
		number = debug_get_long_parameter(command);
	   sdc_clear_wp(sdc_get_group_addr(number), unsigned int num_groups)
	   //sdc_disp_error_code(sdc_get_error_code());
    	}
	else
  		printf("wird nicht unterst�tzt!\n\r");
	}*/
else if (strncmpf(command, "-get-wpstatus", 13)==0)
	{
	unsigned char buff[4];
	number = debug_get_long_parameter(command);
	if (sdc_get_wp_status(sdc_get_group_addr(number), buff )==1)
	    {
//	    printf("write protection status (group %u to %u): %x%x%x%x\n\r",number,number+32,block[0],block[1],block[2],block[3]);
	    printf("write protection status (group %u to %u): %x%x%x%x\n\r",number,number+32,buff[0],buff[1],buff[2],buff[3]);
	    }
    else
    	{
		sdc_disp_error_code(sdc_get_error_code());
		}
    }
else if (strncmpf(command, "-test1", 6)==0)
	{
	sdc_send_cmd(SDC_APP_CMD, 0, SDC_R1_LEN, 1 );
 	if (sdc_send_cmd(SDC_APP_OP_COND, 0, SDC_R1_LEN, 1 )!=0)
 			{
 			printf("MMCard identified.\n\r");
 			}
 		 else
 		 	{
 		 	printf("SDCard identified.\n\r");
 		 	}
 	sdc_send_cmd( SDC_APP_CMD,0, SDC_R1_LEN, 0 );
 	if (sdc_send_cmd( SDC_APP_OP_COND, 0, SDC_R1_LEN, 1 )!=0)
 			{
 			printf("MMCard identified.\n\r");
 			}
 		 else
 		 	{
 		 	printf("SDCard identified.\n\r");
 		 	}
	}
else if (strncmpf(command, "-speed-read", 8)==0)
	{
	start_block = debug_get_long_parameter(command);
	if (start_block < 0)
		start_block= 0;
	command = debug_search_parameter(command);		// dummy search to set the command until second parameter
	number = debug_get_long_parameter(command);
	if (number < 1)
		number= 1;
	command = debug_search_parameter(command);		// dummy search to set the command to second parameter
	command = debug_search_parameter(command);		// dummy search to set the command to third parameter
	if (sdc_status_detect(1))
		{
		if((command!=0)&&(strncmpf(command, "m", 1)==0))
			sdc_debug_speed_read(start_block, number, SDCARD_DEBUG_SPEED_READ_MULTIPLE);
		else
			sdc_debug_speed_read(start_block, number, SDCARD_DEBUG_SPEED_READ_SINGLE);
		}
	}
else if (strncmpf(command, "-speed-write", 8)==0)
	{
	start_block = debug_get_long_parameter(command);
	if (start_block < 0)
		start_block= 0;
	command = debug_search_parameter(command);		// dummy search to set the command until second parameter
	number = debug_get_long_parameter(command);
	if (number < 1)
		number= 1;
	command = debug_search_parameter(command);		// dummy search to set the command to second parameter
	command = debug_search_parameter(command);		// dummy search to set the command to third parameter
	if (sdc_status_detect(0))
		{
		if ((command!=0)&&(strncmpf(command, "m", 1)==0))
			sdc_debug_speed_read(start_block, number, SDCARD_DEBUG_SPEED_WRITE_MULTIPLE);
		else
			sdc_debug_speed_read(start_block, number, SDCARD_DEBUG_SPEED_WRITE_SINGLE);
		}
	}
else if (strncmpf(command, "-pins", 5)==0)
	{
	printf("SDC_Card Detect: %1u\r\n",   SDC_POLL_CARD_DETECTION);
	printf("SDC_Write Protect: %1u\r\n", SDC_POLL_WP_DETECTION);
	}
}
#endif