// ************************************************************************************************
///
/// \file 			ds2431.h
/// \brief			header file of ds2431.c
///
/// \date	 		$LastChangedDate: 2007-04-16 09:20:31 +0200 (Mo, 16 Apr 2007) $
/// \version 		$Rev: 665 $
///	\author  		Udo Jakobza, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _DS2431_INCLUDED_
#define _DS2431_INCLUDED_

#include <1wire.h>

#define DS2431_FAMILY_CODE          0x2D
#define DS2431_MEMORY_SIZE          144     // bytes (eeprom memory + registers)
#define DS2431_EEPROM_SIZE          1024    // bit (only eeprom memory)
#define DS2431_SCRATCHPAD_SIZE	    8
#define DS2431_REGISTER_ADD         0x0080

#ifndef BOARD_MAX_1WIRE_DEVICES
#define BOARD_MAX_1WIRE_DEVICES     1
#endif

typedef enum{
    DS2431_MEMORY_PAGE_0,
    DS2431_MEMORY_PAGE_1,
    DS2431_MEMORY_PAGE_2,
    DS2431_MEMORY_PAGE_3
} DS2431_MEMORY_PAGE_NO;

#define LOW(x) ((unsigned char)((x)&0x00ff))		// returns the lower end byte of an integer
#define HIGH(x) ((unsigned char)(((x)>>8)&0x00ff))	// returns the higher end byte of an integer

#pragma used+
unsigned char ds2431_find(unsigned char *romcode_buffer);
unsigned char ds2431_read_eeprom(unsigned char *romcode, unsigned char *dest, unsigned char addr, unsigned char size);
unsigned char ds2431_write_eeprom(unsigned char *romcode, unsigned char *source, unsigned char addr, unsigned char size);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library ds2431.c
#endif

#endif   // #ifndef _DS2431_INCLUDED_
