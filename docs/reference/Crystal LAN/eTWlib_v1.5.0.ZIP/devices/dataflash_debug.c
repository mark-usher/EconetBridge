// ************************************************************************************************
///
/// \file 			dataflash_debug.c
/// \brief			Debug functions for dataflash.c
///
/// \date	 		$LastChangedDate: 2007-03-13 15:08:20 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 631 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef DEBUG_DATAFLASH

#include <stdio.h>
#include <math.h>
#include "dataflash.h"
#include "dataflash_debug.h"
#include "board.h"
#include "debug.h"
#include "web_debug.h"

#pragma regalloc-
#pragma regalloc+

flash unsigned char 	SPI_CLOCK_DIV[4]={4, 16, 64, 128};		// SPI-Clock-Divider

// prototypes
void dataflash_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);

// ************************************************************************************************
/// \brief	    Registers Dataflash debug handler with debug framework
///
// ************************************************************************************************
void dataflash_debug_init(void)
{
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &dataflash_debug_handler;
p_struct.id_string = "df";
debug_register_handler(&p_struct);
}


//*********************************************************************************
// Description	: reads the status-register of dataflash and display some infos
// Input	   	: none
// Output      	: none
// Indication	: none
//*********************************************************************************
void dataflash_debug_info(void)
{
unsigned char data;
unsigned int speed;

#ifdef DATAFLASH_AT45DB011
printf("AT45DB011 ");
#endif
#ifdef DATAFLASH_AT45DB021
printf("AT45DB021 ");
#endif
#ifdef DATAFLASH_AT45DB041
printf("AT45DB041 ");
#endif
#ifdef DATAFLASH_AT45DB081
printf("AT45DB081 ");
#endif
#ifdef DATAFLASH_AT45DB161
printf("AT45DB161 ");
#endif
#ifdef DATAFLASH_AT45DB321
printf("AT45DB321 ");
#endif
data=dataflash_read_status();
if((data==0xff)||(data==0x00))
	{
	putsf("ATTENTION: DataFlash not ready!!!!!\r"); 
	return; 
	}
switch(data & 0x38)
	{
	case 0x08:	
				#ifdef DATAFLASH_AT45DB011
				printf("OK");
				#else
				printf("wrong DataFlash-Typ");
				#endif
	            printf(" 512 Pages x 264 byte - 132kbyte");
				break;
	case 0x10:	
				#ifdef DATAFLASH_AT45DB021
				printf("OK");
				#else
				printf("wrong DataFlash-Typ");
				#endif
				printf(" 1024 Pages x 264 byte - 264kbyte");
				break;
	case 0x18:	
				#ifdef DATAFLASH_AT45DB041
				printf("OK");
				#else
				printf("wrong DataFlash-Typ");
				#endif
				printf(" 2048 Pages x 264 byte - 528kbyte");
				break;
	case 0x20:	
				#ifdef DATAFLASH_AT45DB081
				printf("OK");
				#else
				printf("wrong DataFlash-Typ");
				#endif
				printf(" 4096 Pages x 264 byte - 1056kbyte");
				break;
	case 0x28:	
				#ifdef DATAFLASH_AT45DB161
				printf("OK");
				#else
				printf("wrong DataFlash-Typ");
				#endif
				printf(" 4096 Pages x 528 byte - 2112kbyte");
				break;
	case 0x30:	
				#ifdef DATAFLASH_AT45DB321
				printf("OK");
				#else
				printf("wrong DataFlash-Typ");
				#endif
				printf(" 8192 Pages x 528 byte - 4224kbyte");
				break;
	case 0x38:	printf(" 8192 Pages x 1056 byte - 8448kbyte");
				break;
	default: printf("DataFlash");
	}
speed=(_MCU_CLOCK_FREQUENCY_/1000)/SPI_CLOCK_DIV[SPCR & 0x03];		// SPI-Clock * 1000 in kHz
if(SPSR.0==1)		// enable double speed
	speed*=2;
printf(" (SPI: %ukHz)\r\n", speed); 
}

unsigned char flash_write_buffer[FLASH_PAGE_SIZE*1];
unsigned char flash_read_buffer[FLASH_PAGE_SIZE*1];
// **********************************************************************************
// Description	: writes a pattern to dataflash and read back
// Input	   	: none
// Output      	: none
// Indication	: none
// **********************************************************************************
void dataflash_debug_verify(void)
{
unsigned int Lva, Lvc;
unsigned int counter_10ms_start; 
unsigned long count=0;
unsigned char Lvb=0;
FLASH_BUFFER_NUM act_buffer=FLASH_BUFFER1;
unsigned int read_page=0;
unsigned int error=0;
signed int act_key;

putsf("Break with 'b' or 'B'\r");
counter_10ms_start=0;
counter_10ms_16bit=0;
for(Lva=0;Lva<FLASH_PAGE_COUNT;Lva++)
	{
	#asm("wdr");	// Reset Watchdog
	memset(flash_write_buffer, (unsigned char)Lva, sizeof(flash_write_buffer));
	dataflash_write_buffer(flash_write_buffer, 0, FLASH_PAGE_SIZE, act_buffer);         // 0 -> Buffer1
//	dataflash_write_buffer_nobusy(flash_write_buffer, 0, FLASH_PAGE_SIZE, act_buffer);         // 0 -> Buffer1
	if(dataflash_write_buffer2flash_e(act_buffer, Lva))
		{
		if(dataflash_read_flash(flash_read_buffer, read_page, 0, FLASH_PAGE_SIZE))
			{
			for(Lvc=0;Lvc<FLASH_PAGE_SIZE;Lvc++)
				{
				if(flash_read_buffer[Lvc]!=(unsigned char)Lva)
					{
					printf("page: %u\r\n", read_page);
					debug_display_mem_hex(&flash_write_buffer[0], FLASH_PAGE_SIZE, 0);
					debug_display_mem_hex(&flash_read_buffer[0], FLASH_PAGE_SIZE, 0);
					error++;
					return;
					}
				}
			read_page++;
			}
		if(act_buffer==FLASH_BUFFER1)
			act_buffer=FLASH_BUFFER2;
		else
			act_buffer=FLASH_BUFFER1;
		count+=FLASH_PAGE_SIZE;
		Lvb++;
		if(Lvb==8)
			{
			printf("Verify: %ukByte\r", (unsigned int)(count>>10));
            act_key = debug_check_rx();
            if(act_key != -1)				// character received?
                {
				if((act_key=='b')||(act_key=='B'))
					{
					putsf("Break\r");
					break; 
					}
				}
			Lvb=0;
			}
		}
	}
counter_10ms_start=abs(counter_10ms_16bit-counter_10ms_start);
count=FLASH_SIZE_KBYTE;
count*=100;
count/=counter_10ms_start;
printf("DataFlash-Verify: %ukByte - %u0ms - %ukbyte/sec - Error: %u\r\n", FLASH_SIZE_KBYTE, counter_10ms_start, 
															(unsigned int)count, error);
}


#define FLASH_PAGE_COUNT_READ	FLASH_PAGE_COUNT/(sizeof(flash_read_buffer)/FLASH_PAGE_SIZE)		
// **********************************************************************************
// Description	: reads the full dataflash and measure the time
// Input	   	: parameter 0 - reads in DataFlash-Buffer
//				:			1 - reads direct in MC-Buffer
// Output      	: none
// Indication	: none
// **********************************************************************************
void dataflash_debug_read(unsigned char parameter)
{
unsigned char result, Lvb=0;
unsigned int Lva;
unsigned long count=0;
unsigned int counter_10ms_start; 
unsigned int page_address=0;
signed int act_key;

putsf("Break with 'b' or 'B'\r");
counter_10ms_start=0;
counter_10ms_16bit=0;
for(Lva=0;Lva<FLASH_PAGE_COUNT_READ;Lva++)
	{
	#asm("wdr");	// Reset Watchdog
	if(parameter)
		result=dataflash_read_flash(flash_read_buffer, page_address, 0, sizeof(flash_read_buffer));
	else
		result=dataflash_read_flash2buffer(FLASH_BUFFER1, page_address);
	if(result)
		{
		if(parameter)
			{
			count+=sizeof(flash_read_buffer);
			page_address+=sizeof(flash_read_buffer)/FLASH_PAGE_SIZE;
			Lvb++;
			if(Lvb==64)
				{
				printf("Read: %ukByte\r", (unsigned int)(count>>10));	// this command needs about 250ms
                act_key = debug_check_rx();
                if(act_key != -1)				// character received?
					{
					if((act_key=='b')||(act_key=='B'))
						{
						putsf("Break\r");
						break; 
						}
					}
				Lvb=0;
				}
			}
		else
			{
			count+=FLASH_PAGE_SIZE;
			page_address++;
			}
		}
	}
counter_10ms_start=abs(counter_10ms_16bit-counter_10ms_start);
count=FLASH_SIZE_KBYTE;
count*=100;
count/=counter_10ms_start;
printf("DataFlash-Read: %ukByte - %u0ms - %ukbyte/sec (buffersize:%ubyte)\r\n", FLASH_SIZE_KBYTE, counter_10ms_start, 
															(unsigned int)count, sizeof(flash_read_buffer));
}


// **********************************************************************************
// Description	: writes the full dataflash and measure the time
// Input	   	: none
// Output      	: none
// Indication	: none
// **********************************************************************************
void dataflash_debug_write(void)
{
unsigned int Lva;
unsigned int counter_10ms_start; 
unsigned long count=0;
unsigned char Lvb=0;
FLASH_BUFFER_NUM act_buffer=FLASH_BUFFER1;
signed int act_key;

putsf("Break with 'b' or 'B'\r");
counter_10ms_start=0;
counter_10ms_16bit=0;
for(Lva=0;Lva<FLASH_PAGE_COUNT;Lva++)
	{
	#asm("wdr");	// Reset Watchdog
	memset(flash_write_buffer, (unsigned char)Lva, sizeof(flash_write_buffer));
	dataflash_write_buffer(flash_write_buffer, 0, FLASH_PAGE_SIZE, act_buffer);         // 0 -> Buffer1
//	dataflash_write_buffer_nobusy(flash_write_buffer, 0, FLASH_PAGE_SIZE, act_buffer);         // 0 -> Buffer1
	if(dataflash_write_buffer2flash_e(act_buffer, Lva))
		{
		if(act_buffer==FLASH_BUFFER1)
			act_buffer=FLASH_BUFFER2;
		else
			act_buffer=FLASH_BUFFER1;
		count+=FLASH_PAGE_SIZE;
		Lvb++;
		if(Lvb==8)
			{
			printf("Write: %ukByte\r", (unsigned int)(count>>10));
            act_key = debug_check_rx();
            if(act_key != -1)				// character received?
				{
				if((act_key=='b')||(act_key=='B'))
					{
					putsf("Break\r");
					break; 
					}
				}
			Lvb=0;
			}
		}
	}
counter_10ms_start=abs(counter_10ms_16bit-counter_10ms_start);
count=FLASH_SIZE_KBYTE;
count*=100;
count/=counter_10ms_start;
printf("DataFlash-Write: %ukByte - %u0ms - %ukbyte/sec\r\n", FLASH_SIZE_KBYTE, counter_10ms_start, 
															(unsigned int)count);
}


// **********************************************************************************
// Description	: erase the full dataflash and measure the time
// Input	   	: none
// Output      	: none
// Indication	: none
// **********************************************************************************
void dataflash_debug_erase(void)
{
unsigned int Lva, Lvb=0;
unsigned int counter_10ms_start; 
unsigned long count=0;
signed int act_key;

putsf("Break with 'b' or 'B'\r");
counter_10ms_start=0;
counter_10ms_16bit=0;
for(Lva=0;Lva<FLASH_PAGE_COUNT;Lva+=8)
	{
	#asm("wdr");	// Reset Watchdog
	if(dataflash_erase_block(Lva))
		{
		count+=FLASH_PAGE_SIZE*8;
		Lvb++;
		if(Lvb==8)
			{
			printf("Erase: %ukByte\r", (unsigned int)(count>>10));
            act_key = debug_check_rx();
            if(act_key != -1)				// character received?
				{
				if((act_key=='b')||(act_key=='B'))
					{
					putsf("Break\r");
					break; 
					}
				}
			Lvb=0;
			}
		}
	}
counter_10ms_start=abs(counter_10ms_16bit-counter_10ms_start);
count=FLASH_SIZE_KBYTE;
count*=100;
count/=counter_10ms_start;
printf("DataFlash-Erase: %ukByte - %u0ms - %ukbyte/sec\r\n", FLASH_SIZE_KBYTE, counter_10ms_start, 
															(unsigned int)count);
}


// **********************************************************************************
// Description	: reads a page and displays the data
// Input	   	: read_page - page number to read
// Output      	: none
// Indication	: none
// **********************************************************************************
void dataflash_debug_read_display(unsigned int read_page)
{
if(dataflash_read_flash(flash_read_buffer, read_page, 0, FLASH_PAGE_SIZE))
	{
	printf("Page: %u (size: %ubyte)\r\n", read_page, FLASH_PAGE_SIZE);
	debug_display_mem_hex(flash_read_buffer, FLASH_PAGE_SIZE, 0);
	}
}


// ************************************************************************************************
/// \brief	    command handler for debug commands
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void dataflash_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
int	data;
unsigned char	retval;

if (mode == DEBUG_HANDLER_MODE_INFO)
	{
	dataflash_debug_info();
	putsf("DATAFLASH_ENABLE\r");
	putsf("DEBUG_DATAFLASH\r");
	}
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
    // add output for 'help' command here
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
    {
    // add output for 'debug' command here
	}
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-info", 5)==0)
		dataflash_debug_info();
	else if (strncmpf(command, "-read", 5)==0)
		dataflash_debug_read(1);
	else if (strncmpf(command, "-buffer", 7)==0)
		dataflash_debug_read(0);
	else if (strncmpf(command, "-write", 6)==0)
		dataflash_debug_write();
	else if (strncmpf(command, "-verify", 7)==0)
		dataflash_debug_verify();
	else if (strncmpf(command, "-erase", 6)==0)
		dataflash_debug_erase();
	else if (strncmpf(command, "-display", 8)==0)
		{
		data=debug_get_int_parameter(command);
		if(data==-1)
			data=0;
		dataflash_debug_read_display(data);
		}
	else if (strncmpf(command, "-spi", 4)==0)
		{
		data=debug_get_int_parameter(command);
		if ((data==-1)||((data!=2)&&(data!=4)&&(data!=8)&&(data!=16)&&(data!=64)&&(data!=128)))
			data=16;
		switch (data)
			{
			case 2: retval = dataflash_cfg_spi(SPCR_SPE | SPCR_MSTR | SPCR_2 | SPCR_CPOL | SPCR_CPHA); break;
			case 4: retval = dataflash_cfg_spi(SPCR_SPE | SPCR_MSTR | SPCR_4 | SPCR_CPOL | SPCR_CPHA); break;
			case 8: retval = dataflash_cfg_spi(SPCR_SPE | SPCR_MSTR | SPCR_8 | SPCR_CPOL | SPCR_CPHA); break;
			case 16: retval = dataflash_cfg_spi(SPCR_SPE | SPCR_MSTR | SPCR_16 | SPCR_CPOL | SPCR_CPHA); break;
			case 64: retval = dataflash_cfg_spi(SPCR_SPE | SPCR_MSTR | SPCR_64 | SPCR_CPOL | SPCR_CPHA); break;
			case 128: retval = dataflash_cfg_spi(SPCR_SPE | SPCR_MSTR | SPCR_128 | SPCR_CPOL | SPCR_CPHA); break;
			}
		data = (_MCU_CLOCK_FREQUENCY_/1000)/SPI_CLOCK_DIV[SPCR & 0x03];		// SPI-Clock * 1000 in kHz
		if (SPSR.0 == 1)		// enable double speed
			data *= 2;
		printf("SPI-Clock: %ukHz with %ukHz Main-Clock\r\n", data, _MCU_CLOCK_FREQUENCY_/1000); 
		printf("Retval: %1u\r\n", retval); 
		}
	}
}

#endif	// #ifdef DEBUG_DATAFLASH