// ************************************************************************************************
///
/// \file 			fat.c
/// \brief			FAT file system implementation
///
/// \todo			Compiler reports unused variables
/// \date	 		$LastChangedDate: 2007-03-06 08:50:49 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 591 $
///	\author  		Nico M�ding, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#ifdef _DOXYGEN_PARSER_
#define FAT_ENABLE
#define FAT_DEBUG
#endif

#ifdef FAT_ENABLE

#include "fat.h"
#include "fat_debug.h"
#include "debug.h"
#ifdef SDCARD_ENABLE
	#include "sdcard.h"
#endif

#pragma used+
// ************************************************************************************************
/// \struct fat
/// \brief  FAT specific data structure
// ************************************************************************************************
struct fat{
unsigned char type;				  	                ///< supported fat types (FAT16 = 2 / FAT32 = 4)
unsigned long sector_table;	                    	///< fat start sector (table entry point)
unsigned long sector_root_dir;			        	///< root directory start sector
unsigned long sector_data;				        	///< data area start sector
unsigned long sector_num;				        	///< sectors per FAT
unsigned int sector_byte;					        ///< bytes per sector
unsigned char sector_cluster;				        ///< sectors per cluster
unsigned char error_code;    			            ///< error code identification
}FAT = {0, 0, 0 ,0, 0, 0, 0, FAT_VOLUME_ERROR};         // default values


// ************************************************************************************************
/// \struct drive
/// \brief  DRIVE specific fat structure
// ************************************************************************************************
struct drive{
unsigned long file_size;			            	///< file size
unsigned long count_cluster;			        	///< number of used clusters
unsigned long last_cluster;                         ///< last cluster with eoc mark
ADDR_FAT addr_dir;						            ///< address: directory entry point
ADDR_FAT addr_data;						            ///< address: data entry point
unsigned char dir_entry[32];                        ///< array: directory entry
}DRIVE = {0, 0, 0, {0, 0}, {0, 0}}; 			        // default values


// ************************************************************************************************
/// \struct heap
/// \brief  HEAP specific SRAM memory structure
// ************************************************************************************************
struct heap{
BUFFER temp;                                        ///< temp buffer (file allocation table)
BUFFER node;                                        ///< node buffer (link list)
unsigned int p_node_update;                         ///< node: update pointer
unsigned char SRAM_type;                            ///< type: static or dynamic SRAM allocation
unsigned char switch_process;                       ///< switch: main process (refer to fat_switch_main_process())
unsigned long addr_table;                           ///< address: table entry point
unsigned long num_cluster;                          ///< current cluster number
}HEAP = {{0, 0, 0, 0}, {0, 0, 0, 0}, 0, 0, 0, 0, 0};    // default values
#pragma used-



/// @name Local Prototypes
//@{
void 		  fat_reset_struct(void);
void 		  fat_def_node_temp(unsigned char *buff, unsigned int buff_size);
void 		  fat_switch_main_process(unsigned char switch_process);
void 		  fat_link_into_node(unsigned long num_cluster);

unsigned char fat_search_free_cluster(void);
unsigned char fat_search_cluster_chain(void);
unsigned long fat_get_free_cluster(void);
unsigned long fat_read_node(unsigned int *p_read, unsigned long cluster);
unsigned long fat_update_table(unsigned long cluster);

unsigned long fat_dir_start_cluster(unsigned char *buff);
unsigned char fat_set_next_addr(ADDR_FAT *drive);

unsigned char fat_search_dir_entry(ADDR_FAT *drive, unsigned char *str_name, unsigned char *str_ext, unsigned char option);
unsigned char fat_make_dir_entry( unsigned char *buff, unsigned char *str_name, unsigned char *str_ext, unsigned char attr);
unsigned char fat_comp_dir_entry(unsigned char *buff, unsigned char *str_name, unsigned char *str_ext);

void 		  fat_update_dir_entry(unsigned char *buff, unsigned long size, unsigned long cluster);
unsigned char fat_read_data(unsigned long addr, unsigned char *buff, unsigned int len);
unsigned char fat_write_data(unsigned long addr, unsigned char *buff, unsigned int len);

void 		  fat_calc_addr_cluster(ADDR_FAT *drive, unsigned long cluster);
unsigned long fat_calc_cluster_addr(ADDR_FAT *drive);
unsigned char fat_clitc(unsigned char *byte, unsigned long value, unsigned char num_byte);
unsigned long fat_cctli(unsigned char *byte, unsigned char num_byte);
unsigned char fat_erase_sector(ADDR_FAT *drive);
//@}



// ************************************************************************************************
/// \brief      Initializes FAT Software module.
/// \remarks    This function should be called once after reset
// ************************************************************************************************
void fat_init(void)
{
#ifdef FAT_DEBUG
fat_debug_init();
#endif
}


// ************************************************************************************************
/// \brief      initializes the application specific SRAM memory buffer.
/// \remarks    The call of this function is mandatory before any action can take place.
///
/// @param[in]  *buff       -   pointer to array (supposed to be greater or equal 14 bytes)
/// @param[in]  buff_size   -   buffer size (range: 14 - 65535)
/// @param[in]	SRAM_type
///                         -	 0: static SRAM (defined global) <br>
///                         -   >0: dynamic SRAM (allocated memory in the heap)
/// @retval		1	-	success
/// @retval		0	- 	error (refer to fat_get_error_code())
// ************************************************************************************************
unsigned char fat_init_buffer(unsigned char *buff, unsigned int buff_size, unsigned char SRAM_type)
{
if(buff_size >= 14)                         // valid buffer size ?
    {
    if(buff)                                // pointer to zero ?
        {
        if(HEAP.temp.buff)                  // SRAM memory still in use ?
            fat_flush_buffer();

        HEAP.node.buff = buff;
        HEAP.node.size = buff_size;
        HEAP.SRAM_type = SRAM_type;

        fat_def_node_temp(HEAP.node.buff, HEAP.node.size);
        if(FAT.sector_table)
            fat_switch_main_process(0);

        FAT.error_code = 0;

        #ifdef SDCARD_DEBUG
        if(fat_debug_flag & FAT_DEBUG_BIT)
            if(!HEAP.SRAM_type)
                putsf("FAT: static SRAM memory allocated.\r");
            else
                putsf("FAT: dynamic SRAM memory allocated.\r");
        #endif      //#ifdef SDCARD_DEBUG
        return 1;
        }
    else
        {
        FAT.error_code = FAT_MEMORY_SRAM_ERROR;
        #ifdef FAT_DEBUG
        if(fat_debug_flag & FAT_DEBUG_BIT)
            fat_disp_error_code(FAT.error_code);
        #endif      //#ifdef FAT_DEBUG
        }
    }
else
    {
    // set error code
    FAT.error_code = FAT_BUFFER_SIZE_ERROR;
    #ifdef FAT_DEBUG
    if(fat_debug_flag & FAT_DEBUG_BIT)
        FAT.error_code = FAT_BUFFER_SIZE_ERROR;
    #endif      // #ifdef FAT_DEBUG
    }
return 0;
}



// ************************************************************************************************
/// \brief      defines two application specific buffers.
/// \note       The function separates the main buffer into two application specific parts, a
///             link list defined as node and a temporary buffer for data storage.
/// @param[in]  *buff       -   pointer to array
/// @param[in]  buff_size   -   buffer size
// ************************************************************************************************
void fat_def_node_temp(unsigned char *buff, unsigned int buff_size)
{
if((FAT.type == 2) || (FAT.type == 4))                      // FAT type specified ?
    {
    // calc the size of the buffer
    HEAP.temp.size = ((HEAP.node.size - FAT.type)/(unsigned char)(FAT.type + 1))*FAT.type;
    HEAP.node.size = HEAP.node.size - HEAP.temp.size;
    HEAP.temp.buff = &HEAP.node.buff[HEAP.node.size];       // separate the buffer

    HEAP.temp.p_write = HEAP.temp.size;                     // init pointer
    HEAP.temp.p_read = 0;
    HEAP.node.p_write = 0;
    HEAP.node.p_read = 0;
    HEAP.num_cluster = 0;
    HEAP.addr_table = 0;
    HEAP.p_node_update = 0;

    #ifdef FAT_DEBUG
	if(fat_debug_flag & FAT_PROCESS_DEBUG_BIT)
        {
        putsf("FAT PROCESS: defined two buffers:\r");
        printf(" - Node @ addr 0x%x with a length of %lu bytes.\n\r", HEAP.node.buff, HEAP.node.size);
        printf(" - Temp @ addr 0x%x with a length of %lu bytes.\n\r", HEAP.temp.buff, HEAP.temp.size);
        }
    #endif      // #ifdef FAT_DEBUG
    }
else
    {
    HEAP.temp.buff = 0;
    }
}



// ************************************************************************************************
/// \brief      flushes the buffer and frees up the main process.
/// \remarks    After using the file system the call of this function is mandatory to free up
///             used memory and the main process itself. If dynamic SRAM was allocated (refer to
///             fat_init_buffer()) the function frees the memory block in the heap.
// ************************************************************************************************
void fat_flush_buffer(void)
{
fat_close_file();                               // just in case

if(HEAP.SRAM_type)                              // static or dynamic SRAM memory buffer ?
    free(HEAP.node.buff);                       // flush buffer
else
    {
    HEAP.node.size += HEAP.temp.size;
    for(HEAP.node.p_write = 0; HEAP.node.p_write < HEAP.node.size; HEAP.node.p_write++)
        HEAP.node.buff[HEAP.node.p_write] = 0;  // flush buffer
    }
HEAP.temp.size = 0;                             // clear pointer and variables
HEAP.node.size = 0;
HEAP.temp.p_write = 0;
HEAP.temp.p_read = 0;
HEAP.node.p_write = 0;
HEAP.node.p_read = 0;
HEAP.addr_table = 0;
HEAP.num_cluster = 0;
HEAP.temp.buff = 0;
HEAP.node.buff = 0;
HEAP.p_node_update = 0;

#ifdef FAT_DEBUG
if(fat_debug_flag & FAT_DEBUG_BIT)
    {
    if(!HEAP.SRAM_type)
        putsf("FAT: static SRAM memory freed up.\r");
    else
        putsf("FAT: dynamic SRAM memory freed up.\r");
    }
#endif      //#ifdef FAT_DEBUG

// maybe additional handlings !!!!!!
}



// ************************************************************************************************
/// \brief      executes the main process to handle file access.
/// \note
/// \remarks    This function should be placed in the main loop and called periodically.
/// @retval		1	-	success
/// @retval		0	- 	error (refer to fat_get_error_code())
// ************************************************************************************************
unsigned char fat_main_process(void)
{
static unsigned char update_volume = 0x80;          // after reset
#ifdef FAT_DEBUG
static unsigned char process_changed = 0x00;
#endif      // #ifdef FAT_DEBUG

// FAT Volume definition
#ifdef SDCARD_ENABLE
if(update_volume != sdc_init_module())           // sdc used as volume
    {
    update_volume = sdc_init_module();
    if((update_volume & SDC_STATUS_INITIALIZED) != 0)
        {
        fat_read_BPB();                             // read BIOS Parameter Block
        fat_switch_main_process(0);                 // search for free cluster
        }
    else
        {
        fat_reset_struct();                         // reset global structures
        }
    }
#else       // #ifdef SDCARD_ENABLE
// ************************************************************************************************
// Note: Place holder for further device drivers.
// Example: Default configuration for none-removable volumes.
if(update_volume)       // read the BPB once after the chip reset
    {
    fat_read_BPB();     // The function returns zero (error), because the volume wasn't not ...
    update_volume = 0;  // specified yet. (refer to fat_read_data() and fat_write_data())
    fat_switch_main_process(0);
    }
// ************************************************************************************************
#endif
else
    {
    if(HEAP.node.buff && FAT.sector_table)                  // buffer and struct init done ?
        {
        if(!HEAP.switch_process)                            // application specific main process
            {
            fat_search_free_cluster();                      // search for free cluster chains
            }
        else if(HEAP.switch_process == 1)
            {
            fat_search_cluster_chain();                     // search for linked cluster chains
            }

        #ifdef FAT_DEBUG
        if(( fat_debug_flag & FAT_DEBUG_BIT) && (process_changed != HEAP.switch_process))
            {
            printf("FAT: main process running [process code: 0x%x] ...\n\r", HEAP.switch_process);
            }
        process_changed = HEAP.switch_process;
        #endif      // #ifdef FAT_DEBUG
        }
    else
        {
        if(!HEAP.node.buff)
            {
            FAT.error_code = FAT_MEMORY_SRAM_ERROR;
            }
        else if(!FAT.sector_table)
            {
            FAT.error_code = FAT_VOLUME_ERROR;
            }
        #ifdef FAT_DEBUG
        if(( fat_debug_flag & FAT_DEBUG_BIT) && (process_changed < 2))
            {
            HEAP.switch_process = process_changed = 2;
            fat_disp_error_code(FAT.error_code);
            printf("FAT: main process suspended [process code: 0x%x].\n\r", HEAP.switch_process);
            }
        #else
        HEAP.switch_process = 2;                            // set process code
        #endif      // #ifdef FAT_DEBUG
        }
    }
return 1;
}



// ************************************************************************************************
/// \brief      searches for free cluster chains.
/// \note       The function loads a particular part of the file allocation table into the
///             temporary buffer and searches for free cluster chains to link them together.
/// @retval		1	-	success
/// @retval		0	- 	error (refer to fat_get_error_code())
// ************************************************************************************************
unsigned char fat_search_free_cluster(void)
{
static unsigned long temp_cluster;

if(!HEAP.temp.p_read)                                               // update necessary ?
    {
    // read a particular part of the file allocation table
    if(!fat_read_data(HEAP.addr_table, HEAP.temp.buff, HEAP.temp.p_write))
        return 0;                                                   // hardware error
    else
        {
        #ifdef FAT_DEBUG
        if(fat_debug_flag & FAT_PROCESS_DEBUG_BIT)
            {
            printf("FAT PROCESS: temp buffer contains data @ addr 0x%lx [size: %u bytes].\n\r", HEAP.addr_table, HEAP.temp.size);
            printf(" - p_write @ offset 0x%x and p_read @ offset 0x%x:\n\r", HEAP.temp.p_write, HEAP.temp.p_read);
            debug_display_mem_hex(HEAP.temp.buff, HEAP.temp.size, 16);
            }
        #endif      // #ifdef FAT_DEBUG
        HEAP.addr_table += HEAP.temp.p_write;                       // update the addr for the next process
        if((HEAP.addr_table + HEAP.temp.p_write) > ((FAT.sector_num + FAT.sector_table)*FAT.sector_byte))
            {
            HEAP.temp.p_write = (FAT.sector_num + FAT.sector_table)*FAT.sector_byte - HEAP.addr_table;
            }
        else if((HEAP.addr_table + HEAP.temp.p_write) == ((FAT.sector_num + FAT.sector_table)*FAT.sector_byte))
            {
            HEAP.temp.p_write = HEAP.temp.size;                     // init pointer
            HEAP.num_cluster = 0;
            // table overflow -> what now, e.g. error message or start again
            HEAP.addr_table = FAT.sector_table*FAT.sector_byte;  // set addr table (entry point)
            }
        }
    }
// searches for free cluster chains
while((HEAP.temp.p_read < HEAP.temp.size) && (HEAP.node.p_write < HEAP.node.size))
    {
    if(!fat_cctli(&HEAP.temp.buff[HEAP.temp.p_read], FAT.type))     // free cluster ?
        {
        fat_link_into_node(HEAP.num_cluster);
        }
    HEAP.num_cluster ++;
    HEAP.temp.p_read += FAT.type;                                   // next process cycle
    }
if(HEAP.node.p_write < HEAP.node.size)                              // end of node ?
    HEAP.temp.p_read = 0;                                           // back to start point

return 1;
}



// ************************************************************************************************
/// \brief      links the cluster number into node.
/// \note       The function links the cluster number and updates the parameter of the node
///             structure.
/// @param[in]	num_cluster     -   cluster number
// ************************************************************************************************
void fat_link_into_node(unsigned long num_cluster)
{
static unsigned long temp_cluster;

if(!HEAP.node.p_write)                                      // set start point (first cluster)
    {
    fat_clitc(&HEAP.node.buff[HEAP.node.p_write], num_cluster, FAT.type);
    HEAP.node.p_write += FAT.type;
    temp_cluster = 0;
    }
else if((num_cluster - temp_cluster) > 0xFF)                // set cluster # (preceded by 0x00)
    {
    if((HEAP.node.p_write + FAT.type) < HEAP.node.size)     // 4 (FAT32) or 2 (FAT16) bytes left ?
        {
        HEAP.node.buff[HEAP.node.p_write++] = 0x00;
        fat_clitc(&HEAP.node.buff[HEAP.node.p_write], num_cluster, FAT.type);
        HEAP.node.p_write += FAT.type;
        }
    else
        {                                                   // temp pointer one step back
        if(!HEAP.temp.p_read)
            HEAP.temp.p_read = 0xFFFC;
        else
            HEAP.temp.p_read -= FAT.type;
        while(HEAP.node.p_write < HEAP.node.size)           // fill node with zeros and go into wait state
            {
            HEAP.node.buff[HEAP.node.p_write++] = 0;
            }
        }
    }
else                                                        // link into node
    {
    HEAP.node.buff[HEAP.node.p_write++] = (num_cluster - temp_cluster);
    }
temp_cluster = num_cluster;                                 // save local
}



// ************************************************************************************************
/// \brief      searches for existing cluster chains.
/// \note       The function loads a particular part of the file allocation table into the
///             temporary buffer and searches for existing cluster chains.
/// @retval		1	-	success
/// @retval		0	- 	error (refer to fat_get_error_code())
// ************************************************************************************************
unsigned char fat_search_cluster_chain(void)
{
unsigned long addr_temp = 0, eoc_mark = 0x0FFFFFF0;
#ifdef FAT_DEBUG
static unsigned char end_of_node;
#endif      // #ifdef FAT_DEBUG

if(DRIVE.addr_data.sector)                                                      // file open ?
    {
    if(FAT.type == 2)                                                           // fat 16 ?
        eoc_mark = 0xFFF0;                                                      // change eoc mark
    if((HEAP.num_cluster != eoc_mark))                                          // end of chain ?
        {
        if(!HEAP.temp.p_read)                                                   // update necessary ?
            {
            // check this range later on
            if((HEAP.addr_table + HEAP.temp.p_write) > ((FAT.sector_num + FAT.sector_table)*FAT.sector_byte))
                {
                HEAP.temp.p_write = (FAT.sector_num + FAT.sector_table)*FAT.sector_byte - HEAP.addr_table;
                }
            else if((HEAP.addr_table + HEAP.temp.p_write) == ((FAT.sector_num + FAT.sector_table)*FAT.sector_byte))
                {
                HEAP.temp.p_write = HEAP.temp.size;                             // init pointer
                HEAP.num_cluster = 0;
                // table overflow -> what now, e.g. error message or start again
                HEAP.addr_table = FAT.sector_table*FAT.sector_byte;          // set addr table (entry point)
                }
            // read a particular part of the file allocation table
            if(!fat_read_data(HEAP.addr_table, HEAP.temp.buff, HEAP.temp.p_write))
                return 0;                                                       // hardware error
            else
                {
                #ifdef FAT_DEBUG
                if(fat_debug_flag & FAT_PROCESS_DEBUG_BIT)
                    {
                    printf("FAT PROCESS: temp buffer contains data @ addr 0x%lx [size: %u bytes].\n\r", HEAP.addr_table, HEAP.temp.size);
                    printf(" - p_write @ offset 0x%x and p_read @ offset 0x%x:\n\r", HEAP.temp.p_write, HEAP.temp.p_read);
                    debug_display_mem_hex(HEAP.temp.buff, HEAP.temp.size, 16);
                    }
                #endif      // #ifdef FAT_DEBUG
                }
            }
        while(HEAP.node.p_write < HEAP.node.size)
            {
            if((HEAP.num_cluster = fat_cctli(&HEAP.temp.buff[HEAP.temp.p_read], FAT.type)) < eoc_mark)      // end of cluster chain ?
                {
                fat_link_into_node(HEAP.num_cluster);
                end_of_node = 1;
                }
            else
                {
                //fat_link_into_node(eoc_mark);
                HEAP.num_cluster = eoc_mark;
                #ifdef FAT_DEBUG
                if(fat_debug_flag & FAT_DEBUG_BIT)
                    {
                    putsf("FAT: found end of cluster chain!\r");
                    }
                #endif          // #ifdef FAT_DEBUG
                return 1;
                }
            addr_temp = HEAP.num_cluster*FAT.type + FAT.sector_table*FAT.sector_byte;
            if((addr_temp > HEAP.addr_table) && (addr_temp < (HEAP.addr_table + HEAP.temp.p_write)))
                {
                HEAP.temp.p_read = addr_temp - HEAP.addr_table;                 // next process cycle
                }
            else                                                                // wait until node was read
                {
                HEAP.addr_table = addr_temp;                                    // update the addr for the next process
                HEAP.temp.p_read = 0;                                           // back to start point
                return 1;
                }
            }
            #ifdef FAT_DEBUG
            if(HEAP.node.p_write >= HEAP.node.size)
                {
                if(( fat_debug_flag & FAT_DEBUG_BIT) && end_of_node)
                    {
                    putsf("FAT: link list updated (end of node).\r");
                    end_of_node = 0;
                    }
                }
            #endif      // #ifdef FAT_DEBUG
        }
    }
return 1;
}



// ************************************************************************************************
/// \brief  switches the main process to handle file access.
/// \note   The function allows changing the main process to search either for free or existing
///         cluster chains.
/// @param[in]	    option
///                             -	 0: search for free cluster chains (used for write operations) <br>
///                             -   >0: search for used cluster chains (used for read operations)
// ************************************************************************************************
void fat_switch_main_process(unsigned char switch_process)
{
static unsigned char status_changed;
static unsigned long temp_addr;
static unsigned long temp_cluster;


// clear node buffer
for(HEAP.node.p_write = 0; HEAP.node.p_write < HEAP.node.size; HEAP.node.p_write ++)
    HEAP.node.buff[HEAP.node.p_write] = 0;


if(!switch_process)             // search free cluster
    {
    HEAP.switch_process = 0;
    HEAP.temp.p_read = 0;
    HEAP.node.p_write = 0;
    HEAP.node.p_read = 0;
    HEAP.num_cluster = 0;
    HEAP.p_node_update = 0;
    if(!HEAP.addr_table)
        {
        HEAP.addr_table = FAT.sector_table*FAT.sector_byte;
        HEAP.num_cluster = 0;
        }
    else
        {
        HEAP.addr_table = temp_addr;
        HEAP.num_cluster = temp_cluster;
        }
    }
else                            // search cluster chain
    {
    if(status_changed != HEAP.switch_process)
        {
        temp_addr = HEAP.addr_table;        // save addr local
        temp_cluster = HEAP.num_cluster;
        }
    HEAP.switch_process = 1;
    HEAP.temp.p_read = 0;
    HEAP.node.p_write = 0;
    HEAP.node.p_read = 1;                   // a value of one marks the first cluster
    HEAP.p_node_update = 0;

    HEAP.num_cluster = fat_dir_start_cluster(DRIVE.dir_entry);
    HEAP.addr_table = HEAP.num_cluster*FAT.type / FAT.sector_byte;
    HEAP.addr_table = HEAP.num_cluster*FAT.type % FAT.sector_byte;
    HEAP.addr_table += FAT.sector_table*FAT.sector_byte;
    fat_link_into_node(HEAP.num_cluster);
    fat_calc_addr_cluster(&DRIVE.addr_data, HEAP.num_cluster);
    }
status_changed = HEAP.switch_process;
DRIVE.last_cluster = 0;
}



#define FAT_BUFF_LEN      512 		// remove this line later on
// ************************************************************************************************
/// \brief      updates the file allocation table.
/// \note
/// @param[in]  cluster
///                             -	 0: create new cluster chain <br>
///                             -   >0: link into existing cluster chain
/// @retval     cluster -   cluster number with eoc mark
/// @retval		0	    - 	error (refer to fat_get_error_code())
// ************************************************************************************************
unsigned long fat_update_table(unsigned long cluster)
{
static unsigned long temp_cluster;
unsigned char buff[FAT_BUFF_LEN];
unsigned long addr_table;
signed int offset = 0;
unsigned int length;

if(HEAP.p_node_update == HEAP.node.p_read)
    return 0;       // something wrong, what's now (give error message to user) ?

if(!cluster)                                                        // new cluster chain ?
    {
    temp_cluster = fat_read_node(&HEAP.p_node_update, temp_cluster);// start cluster
    cluster = temp_cluster;
    }
addr_table = cluster*FAT.type;                                      // calc the table address of the cluster
addr_table += FAT.sector_table*FAT.sector_byte;

length = FAT.type;
if(!fat_read_data(addr_table, buff, FAT_BUFF_LEN))                  // read first table part
    return 0;

#ifdef FAT_DEBUG
if(fat_debug_flag & FAT_PROCESS_DEBUG_BIT)
    {
    printf("FAT PROCESS: read file allocation table [addr: 0x%lx | length: %u].\n\r", addr_table, FAT_BUFF_LEN);
    printf(" - p_update @ offset 0x%x and p_read @ offset 0x%x:\n\r", HEAP.p_node_update, HEAP.node.p_read);
    debug_display_mem_hex(buff, FAT_BUFF_LEN, 16);
    }
#endif      // #ifdef FAT_DEBUG

while(HEAP.p_node_update < HEAP.node.p_read)
    {
    temp_cluster = fat_read_node(&HEAP.p_node_update, temp_cluster);// next cluster
    fat_clitc(&buff[offset], temp_cluster, FAT.type);               // link into existing
    offset += ((temp_cluster - cluster)*FAT.type);                  // calc offset
    cluster = temp_cluster;                                         // for next cycle ...
    if(offset >= length) length = offset + FAT.type;

    if((offset < 0)&&((offset + FAT.type) >= FAT_BUFF_LEN))         // out of range ?
        {
        if(!fat_write_data(addr_table, buff, length))               // write table back
            return 0;

        #ifdef FAT_DEBUG
        if(fat_debug_flag & FAT_DEBUG_BIT)
            {
            printf("FAT PROCESS: file allocation table updated [addr: 0x%lx | length: %u].\n\r", addr_table, length);
            printf(" - p_update @ offset 0x%x and p_read @ offset 0x%x:\n\r", HEAP.p_node_update, HEAP.node.p_read);
            debug_display_mem_hex(buff, length, 16);
            }
        #endif      // #ifdef FAT_DEBUG

        addr_table += offset;
        offset = 0;
        if(!fat_read_data(addr_table, buff, FAT_BUFF_LEN))          // read next part
            return 0;
        }
    }

fat_clitc(&buff[offset], 0x0FFFFFFF, FAT.type);                     // eoc mark
if(!fat_write_data(addr_table, buff, length))                       // write table back
        return 0;

#ifdef FAT_DEBUG
if(fat_debug_flag & FAT_DEBUG_BIT)
    {
    printf("FAT PROCESS: file allocation table updated [addr: 0x%lx | length: %u].\n\r", addr_table, length);
    printf(" - p_update @ offset 0x%x and p_read @ offset 0x%x:\n\r", HEAP.p_node_update, HEAP.node.p_read);
    debug_display_mem_hex(buff, length, 16);
    }
if(fat_debug_flag & FAT_DEBUG_BIT)
    {
    printf("FAT: eoc mark @ cluster #%lu.\n\r", cluster);
    }
#endif      // #ifdef FAT_DEBUG

return cluster;                                                     // cluster # with eoc mark
}



// ************************************************************************************************
/// \brief      reads the next cluster number pointed by.
/// @param[in]	*p_read	-	read pointer
/// @param[in]  cluster -   old cluster number
/// @retval		next cluster number
/// @retval		0	- 	error (refer to fat_get_error_code())
// ************************************************************************************************
unsigned long fat_read_node(unsigned int *p_read, unsigned long cluster)
{
if(*p_read == 1)                                                    // first cluster of file
    {
    (*p_read) --;
    cluster = fat_cctli(&HEAP.node.buff[*p_read], FAT.type);
    *p_read += FAT.type;
    }

if(!*p_read)                                                        // start point ?
    {
    cluster = fat_cctli(&HEAP.node.buff[*p_read], FAT.type);
    *p_read += FAT.type;
    }
else if(!HEAP.node.buff[*p_read])                                   // cluster # preceded by 0x00 ?
    {
    if((*p_read + FAT.type) < HEAP.node.size)                       // end of node ?
        {
        (*p_read) ++;
        cluster = fat_cctli(&HEAP.node.buff[*p_read], FAT.type);
        }
    *p_read += FAT.type;
    }
else                                                                // one byte offset
    {
    cluster += HEAP.node.buff[*p_read];
    (*p_read) ++;
    }

return cluster;
}



// ************************************************************************************************
/// \brief      returns the next cluster number captured by the main process.
/// \note
/// @retval		next cluster number
/// @retval		0	- 	error (refer to fat_get_error_code())
// ************************************************************************************************
unsigned long fat_get_free_cluster(void)
{
static unsigned long temp_cluster;

while(HEAP.node.p_read >= HEAP.node.p_write)            // update node ?
    {
    if(!HEAP.switch_process)
        {
        if(!fat_search_free_cluster())                  // search for free cluster chains
            return 0;
        }
    else if(HEAP.switch_process == 1)
        {
        if(!fat_search_cluster_chain())                 // search for linked cluster chains
            return 0;
        }
    }
temp_cluster = fat_read_node(&HEAP.node.p_read, temp_cluster);
if(HEAP.node.p_read >= HEAP.node.p_write)               // end of node ?
    {
    if(!HEAP.switch_process)                            // update cluster chain ?
        {
        DRIVE.last_cluster = fat_update_table(DRIVE.last_cluster);
        }
    for(HEAP.node.p_write = 0; HEAP.node.p_write < HEAP.node.size; HEAP.node.p_write++)
        HEAP.node.buff[HEAP.node.p_write] = 0;          // clear node

    HEAP.node.p_read = 0;                               // start main process
    HEAP.node.p_write = 0;
    HEAP.p_node_update = 0;
    }
#ifdef FAT_DEBUG
if( fat_debug_flag & FAT_DEBUG_BIT)//FAT_PROCESS_DEBUG_BIT)
    {
    printf("FAT: read cluster #%lu from node.\n\r", temp_cluster);
    }
#endif      // #ifdef FAT_DEBUG
return temp_cluster;
}



// ************************************************************************************************
/// \brief	reads the BIOS Parameter Block (BPB).
/// \note 	The function reads the first partition to determine the sector of the BPB and
///			updates the parameter of the FAT specific data structure.
/// @retval		1	-	success
/// @retval		0	- 	error (refer to fat_get_error_code())
// ************************************************************************************************
unsigned char fat_read_BPB(void)
{
unsigned char buff[40];
unsigned int temp;

// Master Boot Record (MBR) / 1st partition Table
if( fat_read_data( FAT_ADDR_FISRT_PART, buff, 16 ))
    {
   	temp = buff[FAT_OFFSET_TYP_PART];
   	// supported types: 0x04 = FAT16<32MB / 0x06 = FAT16>32MB / 0x0B = FAT32
   	if((temp == 0x04) || (temp == 0x06) || (temp == 0x0B))
        {
        // set FAT entry length
        if(temp == 0x0B)                        // FAT32
   	        FAT.type = 4;
   	    else                                    // FAT16
   	        FAT.type = 2;
        // set the start address of the Volume
   	    FAT.sector_table = fat_cctli(&buff[FAT_OFFSET_NBR_MBR_SECTOR], 4);


        // FAT Volume: BIOS Parameter Block (BPB)
   	    if(fat_read_data( FAT.sector_table*512, buff, 40 ))
            {
   	        // number of reserved sectors
   	        temp = buff[FAT_OFFSET_RESERVED_SECTORS+1];
   	        temp = (temp << 8)|buff[FAT_OFFSET_RESERVED_SECTORS];
   	        // calc the FAT entry point relative to the sector 0 of the MBR
   	        FAT.sector_table += temp;

            // sectors per FAT
   	        FAT.sector_num = buff[FAT_OFFSET_SECTORS_PER_FAT16 + 1];
   	        FAT.sector_num = (FAT.sector_num << 8) | buff[FAT_OFFSET_SECTORS_PER_FAT16];
   	        if( FAT.sector_num == 0 )       // if zero, then FAT32
   	            {
   	            if( FAT.type == 4 )
   	                FAT.sector_num = fat_cctli(&buff[FAT_OFFSET_SECTORS_PER_FAT32], FAT.type);
   	            else
   	                FAT.error_code = FAT_FORMAT_DAMAGED;
   	            }

   	        // calc the start sector of the root directory
   	        FAT.sector_root_dir = FAT.sector_num*buff[FAT_OFFSET_NUMBER_OF_FATS] + FAT.sector_table;

   	        // max. directory entries
   	        temp = buff[FAT_OFFSET_MAX_DIR_ENTRIES + 1];
   	        temp = (temp << 8) | buff[FAT_OFFSET_MAX_DIR_ENTRIES];
   	        // bytes per sector
   	        FAT.sector_byte = buff[FAT_OFFSET_BYTES_PER_SECTOR + 1];
   	        FAT.sector_byte = (FAT.sector_byte << 8) | buff[FAT_OFFSET_BYTES_PER_SECTOR];
   	        // calc the start sector of the data area
   	        FAT.sector_data = temp;
   	        FAT.sector_data = FAT.sector_data*32 + (FAT.sector_byte - 1);
   	        FAT.sector_data /= FAT.sector_byte;
            FAT.sector_data += FAT.sector_root_dir;

            // sectors per cluster
            FAT.sector_cluster = buff[FAT_OFFSET_SECTORS_PER_CLUSTER];

            if( (FAT.sector_table == FAT.sector_root_dir) ||    // FAT format damaged ?
   		        (FAT.sector_table == FAT.sector_data) ||
   		        (FAT.sector_byte == 0) ||
   		        (FAT.sector_cluster == 0))
   		        {
   		        #ifdef FAT_DEBUG
   		        fat_display_format();
   		        #endif      // #ifdef FAT_DEBUG
   		        FAT.error_code = FAT_FORMAT_DAMAGED;
                }
   		    else
   		        FAT.error_code = 0;                             // file system identified

            if(FAT.error_code == 0)
                {
                if(HEAP.node.buff)                              // SRAM allocated ?
                    {
                    if(!HEAP.temp.buff)                         // SRAM defined ?
                        fat_def_node_temp(HEAP.node.buff, HEAP.node.size);
                    }
                else
                    FAT.error_code = FAT_MEMORY_SRAM_ERROR;

                #ifdef FAT_DEBUG
                if (fat_debug_flag & FAT_DEBUG_BIT)
                    {
                    fat_display_format();
                    }
	 		    #endif      // #ifdef FAT_DEBUG
   				return 1;
    			}
            }
        }
    else
        {
        FAT.error_code = FAT_UNKNOWN_FILE_SYSTEM;
        }
    }
FAT.type = 0;
FAT.sector_table = 0;
FAT.sector_root_dir = 0;
FAT.sector_data = 0;
FAT.sector_num = 0;
FAT.sector_byte = 0;
FAT.sector_cluster = 0;

#ifdef FAT_DEBUG
if (fat_debug_flag & FAT_DEBUG_BIT)
    {
    fat_disp_error_code(FAT.error_code);
    }
#endif      // #ifdef FAT_DEBUG
return 0;
}



// ************************************************************************************************
/// \brief		makes a DOS 8.3 formated directory entry.
/// \note		Lower case, space and special characters are not allowed (valid: A-Z and 0-9).
///             Strings with more than the specified size will be truncated and with less will
///             be padded with trailing spaces.
/// @param[out]	buff 		- 	pointer to array (should be 32 bytes long)
/// @param[in]	str_name 	- 	pointer to string name (8 characters)
///	@param[in]	str_ext		- 	pointer to string extension (3 characters)
///	@param[in]	attr 		- 	attribute of the entry
/// @retval		1	-	success
/// @retval		0	- 	error (not a valid DOS 8.3 formated entry)
// ************************************************************************************************
unsigned char fat_make_dir_entry( unsigned char *buff, unsigned char *str_name, unsigned char *str_ext, unsigned char attr)
{
unsigned char count;

// clear buffer; just in case
for( count = 0; count < 32; count ++ )
	buff[count] = 0;

// copy string name
for( count = 0; count < 8; count++ )
	{
	if(str_name[count] == 0)
		str_name[count] = 0x20;
	else if((((str_name[count] < 0x41) || (str_name[count] > 0x5A)) &&		// valid characters: A (0x41) - Z (0x5A)
	   		 ((str_name[count] < 0x30) || (str_name[count] > 0x39))    )	// valid numbers: 0 (0x30) - 9 (0x39)
			 || (str_name[count] == 0x20 ))									// space character
	    {
	    FAT.error_code = FAT_ERROR_DOS83_FORMAT;
	    return 0;		// error, only capital letters and numbers allowed
	    }
	buff[count] = str_name[count];
 	}

// copy string extension
for( count = 0; count < 3; count++ )
	{
	if(str_ext[count] == 0)
		str_ext[count] = 0x20;			// space
	else if( (str_ext[count] != 0x20) &&							        // space character
	         ((str_ext[count] < 0x41) || (str_ext[count] > 0x5A)) &&		// valid characters: A (0x41) - Z (0x5A)
	   		 ((str_ext[count] < 0x30) || (str_ext[count] > 0x39))     )	    // valid numbers: 0 (0x30) - 9 (0x39)

	   	{
	    FAT.error_code = FAT_ERROR_DOS83_FORMAT;
	    return 0;		// error, only capital letters and numbers allowed
	    }
	buff[count+8] = str_ext[count];
 	}
buff[FAT_OFFSET_ATTRIBUTE] = attr;						                        // attribute of the entry
FAT.error_code = 0;
return 1;
}



// ************************************************************************************************
/// \brief 		compares the directory entry.
/// \note		The function compares the name and the extension with the directory
///             structure passed through the buffer.
/// @param[out]	*buff 		- 	pointer to array (should be 32 bytes long)
/// @param[in]	str_name 	- 	pointer to string name (8 characters)
///	@param[in]	str_ext		- 	pointer to string extension (3 characters)
/// @retval		0	-   doesn't match
/// @retval		1	-	match
// ************************************************************************************************
unsigned char fat_comp_dir_entry(unsigned char *buff, unsigned char *str_name, unsigned char *str_ext)
{
unsigned char count = 0;
unsigned char len = 8;

while( count != len )
	{
	if(buff[FAT_OFFSET_NAME+count] == 0x20)
		len = count;
	else
		count ++;
	}
if(!strncmp( &buff[FAT_OFFSET_EXTENSION], str_ext, 3 ))
    if(!strncmp( &buff[FAT_OFFSET_NAME], str_name, len ))
	    return 1;       // match

return 0;               // doesn't match
}



// ************************************************************************************************
/// \brief		searches either for available or existing directory entries.
/// @param[in,out]	*drive		-	pointer to struct ADDR_FAT
/// @param[in]		str_name	-	pointer to string name (max. 8 characters)
/// @param[in]		str_ext		-	pointer to string extension (max. 3 characters)
/// @param[in]	    option
///                             -	 0: next available directory entry <br>
///                             -   >0: existing directory entry
/// @retval         1   -   success
/// @retval			0	-	error (refer to fat_get_error_code())
// ************************************************************************************************
unsigned char fat_search_dir_entry(ADDR_FAT *drive, unsigned char *str_name, unsigned char *str_ext, unsigned char option)
{
unsigned char buff[512], count;
unsigned int addr_offset, count_loop = 1;
unsigned char free_entry = 0, dir_type = 0;
unsigned long addr_sector, cluster;

// root dir entry point ?
if(!drive->sector)
	drive->sector = FAT.sector_root_dir;       			    // start sector root dir
//else
	//sub dir ...
drive->offset = 0;

// dir size and type ?
if(FAT.sector_data > FAT.sector_root_dir)			        // FAT16 root dir
	count_loop = FAT.sector_data - FAT.sector_root_dir;
else
	dir_type = 1;											// FAT16 sub dir, FAT32 root and sub dir

// search dir entry
while(count_loop)
	{
	// read the ... sector of the directory
	if(!fat_read_data(FAT.sector_byte*drive->sector, buff, FAT.sector_byte))
		{
		FAT.error_code = FAT_HARDWARE_ERROR;
		return 0;											// error
		}
	while(drive->offset < FAT.sector_byte)
		{
		if(buff[drive->offset] == 0x00)						// free dir entry ?
			{
			if(!option)
			    {
			    if(free_entry)
				    {
				    drive->sector = addr_sector;            // set entry point
				    drive->offset = addr_offset;
				    }
			    FAT.error_code = 0;
			    #ifdef FAT_DEBUG
			    if(fat_debug_flag & FAT_DEBUG_BIT)
			        printf("FAT: found free directory entry point @ sector #%lu [offset: 0x%x].\n\r", drive->sector, drive->offset);
			    #endif      // #ifdef FAT_DEBUG
			    return 1;									// abort searching ... found next available dir entry
			    }
			else
			    {
			    FAT.error_code = FAT_DIR_ENTRY_NOT_FOUND;
			    return 0;									// abort searching ... dir not found
			    }
			}
   		else if((buff[drive->offset]==0xE5)&&(!free_entry))	// free dir entry ?
			{
			if(!option)
			    {
			    addr_sector = drive->sector;				// save entry point local
			    addr_offset = drive->offset;
	 		    free_entry = 1;							    // go on make sure the dir entry doesn't exist
			    }
			}
   		else if(fat_comp_dir_entry(&buff[drive->offset], str_name, str_ext))
   			{
   			if(!option)
   			    {
   			    FAT.error_code =  FAT_DIR_ENTRY_EXIST;
   			    return 0;                                   // abort searching ... dir entry exist
   			    }
   			else
   			    {
   			    for(count = 0; count < 32; count ++)
   			        DRIVE.dir_entry[count] = buff[drive->offset + count];
   			    FAT.error_code = 0;
   			    #ifdef FAT_DEBUG
			    if(fat_debug_flag & FAT_DEBUG_BIT)
			        printf("FAT: found directory entry @ sector #%lu [offset: 0x%x].\n\r", drive->sector, drive->offset);
			    #endif      // #ifdef FAT_DEBUG
			    return 1; 									// abort searching ... found dir entry
   			    }
   			}
		drive->offset += 32;		                        // offset to the next entry point
		}
	if(dir_type)                                            // FAT16 sub dir, FAT32 root and sub dir
		{
		if(!(count_loop = fat_set_next_addr(drive)))
			return 0;
		if((count_loop == 1) && (!option))                  // update necessary ?
		    {
	        cluster = fat_calc_cluster_addr(drive);
		    fat_calc_addr_cluster(drive, fat_get_free_cluster());
		    fat_update_table(cluster);                      // expand dir entry table
		    fat_erase_sector(drive);
		    FAT.error_code = 0;
			#ifdef FAT_DEBUG
			if(fat_debug_flag & FAT_DEBUG_BIT)
			    printf("FAT: found free directory entry point @ sector #%lu [offset: 0x%x].\n\r", drive->sector, drive->offset);
			#endif      // #ifdef FAT_DEBUG
			return 1;
            }
		}
	else                                                    // FAT16 root dir
		drive->sector++;
	count_loop--;
	drive->offset = 0;
    }
if(!option)
    {
    if(free_entry)
	    {
	    drive->sector = addr_sector;	                    // set entry point
	    drive->offset = addr_offset;
	    FAT.error_code = 0;
	    #ifdef FAT_DEBUG
        if(fat_debug_flag & FAT_DEBUG_BIT)
            printf("FAT: found free directory entry point @ sector #%lu [offset: 0x%x].\n\r", drive->sector, drive->offset);
        #endif      // #ifdef FAT_DEBUG
	    return 1;
	    }
    }
#ifdef FAT_DEBUG
if(fat_debug_flag & FAT_DEBUG_BIT)
    putsf("FAT: directory entry not found!\r");
#endif      // #ifdef FAT_DEBUG
FAT.error_code= FAT_MAX_ROOT_DIR_ACHIEVED;
return 0;
}



// ************************************************************************************************
/// \brief		creates a file system entry.
/// \note
/// @param[in]	str_name	-	pointer to string name (max. 8 characters)
/// @param[in]	str_ext		-	pointer to string extension (max. 3 characters)
/// @retval	  	0	-	error (refer to fat_get_error_code())
/// @retval		1	-	success, file created
// ************************************************************************************************
unsigned char fat_create_file(unsigned char *str_name, unsigned char *str_ext)
{
if(HEAP.node.buff && FAT.sector_table)                          // main process running ?
    {
    if(!DRIVE.addr_data.sector)                                 // file closed ?
        {
        if(fat_make_dir_entry(DRIVE.dir_entry, str_name, str_ext, FAT_ATTR_ARCHIVE_BIT))
            {
            if(fat_search_dir_entry(&DRIVE.addr_dir, str_name, str_ext, 0))
                {
                fat_calc_addr_cluster(&DRIVE.addr_data, fat_get_free_cluster());
                fat_update_dir_entry(DRIVE.dir_entry, 0, fat_calc_cluster_addr(&DRIVE.addr_data));
                #ifdef FAT_DEBUG
    		    if(fat_debug_flag & FAT_DEBUG_BIT)
    		        {
    		        printf("FAT: create file -> \"");
    		        debug_display_mem_ascii(str_name, 8, 0);
   			        putchar('.');
   			        debug_display_mem_ascii(str_ext, 3, 0);
   			        printf("\" [size: %lu bytes].\n\r", DRIVE.file_size);
   			        printf("FAT: data pointer @ sector %lu [offset: %u].\n\r", DRIVE.addr_data.sector, DRIVE.addr_data.offset);
                    }
                #endif      // #ifdef FAT_DEBUG
                return 1;
                }
            }
        }
    else
        FAT.error_code = FAT_ERROR_FILE_ACCESS;
    }
#ifdef FAT_DEBUG
if (fat_debug_flag & FAT_DEBUG_BIT)
    {
    fat_disp_error_code(FAT.error_code);
    }
#endif      // #ifdef FAT_DEBUG

// close file, because somthing was wrong
DRIVE.addr_data.sector = 0;                 // clear drive
DRIVE.addr_data.offset = 0;

return 0;
}



// ************************************************************************************************
/// \brief 		opens a file system entry.
///
/// @param[in]	str_name	-	pointer to string name (max. 8 characters)
/// @param[in]	str_ext		-	pointer to string extension (max. 3 characters)
/// @retval	  	0	-	error (refer to fat_get_error_code())
/// @retval		1	-	success, file open
// ************************************************************************************************
unsigned char fat_open_file(unsigned char *str_name, unsigned char *str_ext)
{
if(HEAP.node.buff && FAT.sector_table)          // main process running ?
    {
    if(!DRIVE.addr_data.sector)                 // file closed ?
        {
        if(fat_search_dir_entry(&DRIVE.addr_dir, str_name, str_ext, 1))
            {
            fat_switch_main_process(1);
            #ifdef FAT_DEBUG
            if(fat_debug_flag & FAT_DEBUG_BIT)
                {
    		    printf("FAT: open file -> \"");
    		    debug_display_mem_ascii( str_name, 8, 0);
   			    putchar('.');
   			    debug_display_mem_ascii( str_ext, 3, 0);
   			    printf("\" [size: %lu bytes].\n\r", DRIVE.file_size);
   		        printf("FAT: data pointer @ sector %lu [offset: %u].\n\r", DRIVE.addr_data.sector, DRIVE.addr_data.offset);
                }
            #endif      // #ifdef FAT_DEBUG
            return 1;
            }
        }
    else
        FAT.error_code = FAT_ERROR_FILE_ACCESS;
    }
//else
    // error code ...
#ifdef FAT_DEBUG
if (fat_debug_flag & FAT_DEBUG_BIT)
    {
    fat_disp_error_code(FAT.error_code);
    }
#endif      // #ifdef FAT_DEBUG

// close file, because somthing was wrong
DRIVE.addr_data.sector = 0;
DRIVE.addr_data.offset = 0;

return 0;					// error
}



// ************************************************************************************************
/// \brief		returns the attribute of the file entry.
/// \note
/// @retval		attribute
/// @retval	  	0	-	error (file closed)
// ************************************************************************************************
unsigned char fat_get_attr(void)
{
if(HEAP.node.buff && FAT.sector_table)          // main process running ?
    {
    if(DRIVE.addr_data.sector)                  // file closed ?
        {
        return DRIVE.dir_entry[FAT_OFFSET_ATTRIBUTE];
        }
    }
return 0;
}



// ************************************************************************************************
/// \brief		sets the attribute of the file entry.
/// \note
/// @retval		1	-	success
/// @retval	  	0	-	error (file closed or wrong value)
// ************************************************************************************************
unsigned char fat_set_attr(unsigned char attr)
{
if(HEAP.node.buff && FAT.sector_table)              // main process running ?
    {
    if(DRIVE.addr_data.sector && (attr < 0x3F))     // file closed ?
        {
        DRIVE.dir_entry[FAT_OFFSET_ATTRIBUTE] = attr;
        return 1;
        }
    }
return 0;
}



// ************************************************************************************************
/// \brief		creates a subdirectory entry.
/// \note
/// @param[in]	str_name	-	pointer to string name (max. 8 characters)
/// @param[in]	str_ext		-	pointer to string extension (max. 3 characters)
/// @retval	  	0	-	error (refer to fat_get_error_code())
/// @retval		1	-	success, file created
// ************************************************************************************************
unsigned char fat_create_folder(unsigned char *str_name)
{
unsigned char str_ext[] = "   ";

if(HEAP.node.buff && FAT.sector_table)                          // main process running ?
    {
    if(!DRIVE.addr_data.sector)                                 // file closed ?
        {
        if(fat_make_dir_entry(DRIVE.dir_entry, str_name, str_ext, FAT_ATTR_SUBDIR_BIT))
            {
            if(fat_search_dir_entry(&DRIVE.addr_dir, str_name, str_ext, 0))
                {
                fat_update_dir_entry(DRIVE.dir_entry, 0, fat_get_free_cluster());
                fat_write_data(DRIVE.addr_dir.sector*FAT.sector_byte+DRIVE.addr_dir.offset, DRIVE.dir_entry, 32);
                fat_calc_addr_cluster(&DRIVE.addr_dir, fat_dir_start_cluster(DRIVE.dir_entry));
                #ifdef FAT_DEBUG
    		    if(fat_debug_flag & FAT_DEBUG_BIT)
    		        {
    		        printf("FAT: create folder -> \"");
    		        debug_display_mem_ascii( str_name, 8, 0);
   		            printf("\"\n\rFAT: dir pointer @ sector %lu [offset: %u].\n\r", DRIVE.addr_dir.sector, DRIVE.addr_dir.offset);
                    }
                #endif      // #ifdef FAT_DEBUG
                return 1;
                }
            }
        }
    else
        FAT.error_code = FAT_ERROR_FILE_ACCESS;
    }
#ifdef FAT_DEBUG
if (fat_debug_flag & FAT_DEBUG_BIT)
    {
    fat_disp_error_code(FAT.error_code);
    }
#endif      // #ifdef FAT_DEBUG

// close file, because somthing was wrong
DRIVE.addr_data.sector = 0;                 // clear drive
DRIVE.addr_data.offset = 0;

return 0;
}



// ************************************************************************************************
/// \brief 		opens a subdirectory entry.
///
/// @param[in]	str_name	-	pointer to string name (max. 8 characters)
/// @retval	  	0	-	error (refer to fat_get_error_code())
/// @retval		1	-	success, folder open
// ************************************************************************************************
unsigned char fat_open_folder(unsigned char *str_name)
{
unsigned char str_ext[] = "   ";

if(HEAP.node.buff && FAT.sector_table)          // main process running ?
    {
    if(!DRIVE.addr_data.sector)                 // file closed ?
        {
        if(fat_search_dir_entry(&DRIVE.addr_dir, str_name, str_ext, 1))
            {
            fat_calc_addr_cluster(&DRIVE.addr_dir, fat_dir_start_cluster(DRIVE.dir_entry));
            #ifdef FAT_DEBUG
            if(fat_debug_flag & FAT_DEBUG_BIT)
                {
    		    printf("FAT: open folder -> \"");
    		    debug_display_mem_ascii( str_name, 8, 0);
   		        printf("\"\n\rFAT: dir pointer @ sector %lu [offset: %u].\n\r", DRIVE.addr_dir.sector, DRIVE.addr_dir.offset);
                }
            #endif      // #ifdef FAT_DEBUG
            return 1;
            }
        }
    else
        FAT.error_code =FAT_ERROR_FOLDER_ACCESS;
    }
//else
    // error code ...
#ifdef FAT_DEBUG
if (fat_debug_flag & FAT_DEBUG_BIT)
    {
    fat_disp_error_code(FAT.error_code);
    }
#endif      // #ifdef FAT_DEBUG
return 0;					// error
}



// ************************************************************************************************
/// \brief 		jumps back to the root directory.
///
/// @retval	  	0	-	error (refer to fat_get_error_code())
/// @retval		1	-	success
// ************************************************************************************************
unsigned char fat_back_root_dir(void)
{
unsigned char str_ext[] = "   ";

if(HEAP.node.buff && FAT.sector_table)          // main process running ?
    {
    if(!DRIVE.addr_data.sector)                 // file closed ?
        {
        DRIVE.addr_dir.sector = FAT.sector_root_dir;
        DRIVE.addr_dir.offset = 0;
        #ifdef FAT_DEBUG
        if(fat_debug_flag & FAT_DEBUG_BIT)
            {
    		printf("FAT: back to root directory\n\r");
   		    printf("FAT: dir pointer @ sector %lu [offset: %u].\n\r", DRIVE.addr_dir.sector, DRIVE.addr_dir.offset);
            }
         #endif      // #ifdef FAT_DEBUG
         return 1;
        }
    else
        FAT.error_code =FAT_ERROR_FOLDER_ACCESS;
    }
//else
    // error code ...
#ifdef FAT_DEBUG
if (fat_debug_flag & FAT_DEBUG_BIT)
    {
    fat_disp_error_code(FAT.error_code);
    }
#endif      // #ifdef FAT_DEBUG
return 0;					// error
}



// ************************************************************************************************
/// \brief 		returns the first cluster number of the directory entry.
/// \note
/// @param[in]	*buff 		- 	pointer to array (should be 32 bytes long)
/// @retval	  	first cluster number
// ************************************************************************************************
unsigned long fat_dir_start_cluster(unsigned char *buff)
{
unsigned char cluster[4];

// first cluster number -> start point cluster chain
cluster[0] = buff[FAT_OFFSET_CLUSTER_MAP];
cluster[1] = buff[FAT_OFFSET_CLUSTER_MAP+1];                // 16 bit value
if(FAT.type == 4)
 	{
	cluster[2] = buff[FAT_OFFSET_CLST_MAP_FAT32];           // 32 bit value
	cluster[3] = buff[FAT_OFFSET_CLST_MAP_FAT32+1];
    }
else
    {
    cluster[2] = 0;
    cluster[3] = 0;
    }

// set file size
DRIVE.file_size = fat_cctli(&buff[FAT_OFFSET_FILE_SIZE], 4);
#ifdef FAT_DEBUG
if( fat_debug_flag & FAT_PROCESS_DEBUG_BIT)
    {
    // calc used cluster
    DRIVE.count_cluster = DRIVE.file_size / (FAT.sector_byte*FAT.sector_cluster);
    if(DRIVE.file_size % (FAT.sector_byte*FAT.sector_cluster))
        DRIVE.count_cluster ++;
    printf("FAT PROCESS: ... returns the start cluster #%lu [used cluster: %lu].\n\r", fat_cctli(cluster, 4), DRIVE.count_cluster);
    }
#endif      // #ifdef FAT_DEBUG
DRIVE.count_cluster = 0;
DRIVE.last_cluster = 0;

return fat_cctli(cluster, 4);
}



// ************************************************************************************************
/// \brief 		reads file data.
///
/// @param[in]		*buff	-	pointer to array
/// @param[in]  	len		-	number of bytes [max. range: len = 0...65535]
/// @retval			0 		-	end of file or error (refer to fat_get_error_code())
/// @retval			len		- 	number of bytes to be read at once
// ************************************************************************************************
unsigned int fat_read_file(unsigned char *buff, unsigned int len)
{
unsigned int block_len, count, offset = 0;
unsigned int bytes_per_cluster;
unsigned long file_size;
#ifdef FAT_DEBUG
unsigned int length;
#endif      // #ifdef FAT_DEBUG

if(DRIVE.addr_data.sector && HEAP.switch_process)           // file open ?
	{
	#ifdef FAT_DEBUG
	length = len;
	#endif      // #ifdef FAT_DEBUG
    bytes_per_cluster = FAT.sector_byte*FAT.sector_cluster;
	file_size = DRIVE.file_size - DRIVE.count_cluster*bytes_per_cluster - DRIVE.addr_data.offset;
	if(!file_size)                                          // end of file ?
	    {
	    #ifdef FAT_DEBUG
        if( fat_debug_flag & FAT_DEBUG_BIT)
            {
            putsf("FAT: end of file!\r");
            }
        #endif      // #ifdef FAT_DEBUG
        FAT.error_code = 0;
	    return 0;
	    }

	while( len != 0 )
        {
        if(DRIVE.addr_data.offset == bytes_per_cluster)	// end of cluster
		    {
		    fat_calc_addr_cluster(&DRIVE.addr_data, fat_get_free_cluster());
		    DRIVE.count_cluster ++;
		    #ifdef FAT_DEBUG
		    if( fat_debug_flag & FAT_DEBUG_BIT)
                {
		        printf("FAT: data pointer @ sector %lu [offset: %u].\n\r", DRIVE.addr_data.sector, DRIVE.addr_data.offset);
		        }
		    #endif  // #ifdef FAT_DEBUG
            }
        // calc the number of bytes refered to the cluster size
		if((DRIVE.addr_data.offset + len) <= bytes_per_cluster) block_len = len;
		else block_len = bytes_per_cluster - DRIVE.addr_data.offset;

		if(!fat_read_data((FAT.sector_byte*DRIVE.addr_data.sector+DRIVE.addr_data.offset), &buff[offset], block_len))
		    {
			return 0;					                    // error
		    }

		if( file_size <= len )                              // null padding
		    {
			for( count = file_size; count < len; count ++ )
				buff[count] = 0;
			#ifdef FAT_DEBUG
            if( fat_debug_flag & FAT_DEBUG_BIT)
                {
                printf("FAT: read %u bytes of data [null padding: %u bytes].\n\r", file_size, len - file_size);
                debug_display_mem_hex(buff, len, 16);
                }
            #endif      // #ifdef FAT_DEBUG
			DRIVE.addr_data.offset += file_size;
			FAT.error_code = 0;
			return file_size;
		    }
		else
		    {
		    offset += block_len;                            // update parameter
		    DRIVE.addr_data.offset += block_len;
		    len -= block_len;
		    }
		}
    #ifdef FAT_DEBUG
	if( fat_debug_flag & FAT_DEBUG_BIT)
        {
        printf("FAT: read %u bytes of data.\n\r", length);
        debug_display_mem_hex(buff, length, 16);
        }
    #endif      // #ifdef FAT_DEBUG
    FAT.error_code = 0;
	return offset;
	}
else
    FAT.error_code = FAT_ERROR_FILE_ACCESS;

return 0;
}



// ************************************************************************************************
/// \brief 		writes file data.
///
/// @param[in]		*buff	-	pointer to array
/// @param[in]  	len		-	number of bytes [max. range: len = 0...65535]
/// @retval			0 		-	end of file or error (refer to fat_get_error_code())
/// @retval			len		- 	number of bytes
// ************************************************************************************************
unsigned int fat_write_file(unsigned char *buff, unsigned int len)
{
unsigned int block_len, offset = 0;
unsigned int length, bytes_per_cluster;

if(DRIVE.addr_data.sector && !HEAP.switch_process)              // file created ?
	{
	length = len;
	bytes_per_cluster = FAT.sector_byte*FAT.sector_cluster;;
	while(len != 0)
	    {
		if(DRIVE.addr_data.offset == bytes_per_cluster)	        // end of cluster ?
			{
			fat_calc_addr_cluster(&DRIVE.addr_data, fat_get_free_cluster());
			DRIVE.count_cluster ++;
		    #ifdef FAT_DEBUG
		    if( fat_debug_flag & FAT_DEBUG_BIT)
                {
		        printf("FAT: data pointer @ sector %lu [offset: %u].\n\r", DRIVE.addr_data.sector, DRIVE.addr_data.offset);
		        }
		    #endif  // #ifdef FAT_DEBUG
            }

		// calc the number of bytes refered to the cluster size
		if((drive->addr_data.offset + len) <= bytes_per_cluster) block_len = len;
		else block_len = bytes_per_cluster - drive->addr_data.offset;

		if(!fat_write_data((FAT.sector_byte*DRIVE.addr_data.sector+DRIVE.addr_data.offset), &buff[offset], block_len))
		    {
			return 0;
			}

		DRIVE.addr_data.offset += block_len;                    // update parameter
		len -= block_len;
		offset += block_len;
		}
	//fat_erase_sector(&DRIVE.addr_data);
    #ifdef FAT_DEBUG
    if( fat_debug_flag & FAT_DEBUG_BIT)
        {
        printf("FAT: wrote %u bytes of data [null padding: %u bytes].\n\r", length, (FAT.sector_byte-DRIVE.addr_data.offset));
        debug_display_mem_hex(buff, length, 16);
        }
    #endif      // #ifdef FAT_DEBUG

	DRIVE.file_size += length;                                  // update file size
	FAT.error_code = 0;
	return length;
	}
else
    FAT.error_code = FAT_ERROR_FILE_ACCESS;

return 0;
}



// ************************************************************************************************
/// \brief 		closes a file system entry.
///	\note       After file access the the call of this function is mandatory to update the
///             directory entry.
/// @param[in]		byte	-	byte number (32 bit address value)
/// @retval			0 		-	error (refer to fat_get_error_code())
/// @retval			1	    - 	success
// ************************************************************************************************
unsigned char fat_close_file(void)
{
unsigned char count;

if(DRIVE.addr_data.sector)                      // file open ?
    {
    if(!HEAP.switch_process)                    // dir update necessary ?
        {
        fat_update_table(DRIVE.last_cluster);
        fat_update_dir_entry(DRIVE.dir_entry, DRIVE.file_size, 0);
        }
    else if(HEAP.switch_process == 1)
        fat_switch_main_process(0);

    DRIVE.addr_data.sector = 0;                 // clear drive
    DRIVE.addr_data.offset = 0;
    DRIVE.file_size = 0;
    DRIVE.count_cluster = 0;
    DRIVE.last_cluster = 0;

    for(count = 0; count < 32; count ++)
        DRIVE.dir_entry[count] = 0;
    }
#ifdef FAT_DEBUG
if( fat_debug_flag & FAT_DEBUG_BIT)
    {
    putsf("FAT: file system entry closed.\r");
    }
#endif      // #ifdef FAT_DEBUG
return 1;
}



// ************************************************************************************************
/// \brief		updates the start cluster or the size of the directory entry.
/// \note       The function writes the directory entry back, if a cluster value of zero
///             was passed through.
/// @param[out]	buff 	- 	pointer to array
/// @param[in]	size 	- 	file size
/// @param[in]	cluster
///						-	0: cluster number will be ignored <br>
///						-	otherwise: first cluster number of the dir entry
// ************************************************************************************************
void fat_update_dir_entry(unsigned char *buff, unsigned long size, unsigned long cluster)
{
if(cluster)
    {
    buff[FAT_OFFSET_CLUSTER_MAP] = cluster;             	        // first cluster of the entry
    buff[FAT_OFFSET_CLUSTER_MAP+1] = cluster >> 8;      	        // 16 bit value

    if(FAT.type == 4)						                        // FAT32
 	    {
	    buff[FAT_OFFSET_CLST_MAP_FAT32] = cluster >> 16;	        // 32 bit value
	    buff[FAT_OFFSET_CLST_MAP_FAT32+1] = cluster >> 24;
 	    }
    DRIVE.count_cluster = 0;
    }
else
    {
    fat_clitc(&buff[FAT_OFFSET_FILE_SIZE], size, 4);
    fat_write_data(DRIVE.addr_dir.sector*FAT.sector_byte + DRIVE.addr_dir.offset, buff, 32);
    #ifdef FAT_DEBUG
    if( fat_debug_flag & FAT_DEBUG_BIT)
        {
        printf("FAT: directory entry updated [file size: %lu].\n\r", size);
        }
    #endif      // #ifdef FAT_DEBUG
    }
}



// ************************************************************************************************
/// \brief      sets the next sector address.
/// \note       The next sector address depends on the link within cluster chain.
/// @param[in,out]	*drive  -	pointer to struct ADDR_FAT
/// @retval			0	-	error (refer to fat_get_error_code())
/// @retval	  		1	-	found eoc mark
///	@retval			2	-	next sector address
// ************************************************************************************************
unsigned char fat_set_next_addr(ADDR_FAT *drive)
{
unsigned long cluster, addr_table;
unsigned char buff[4];

if(drive->sector == 0)											// root dir
    {
	cluster = 2;
    }
else															// sub dir
	{
	cluster = fat_calc_cluster_addr(drive);
	}
addr_table = (cluster*FAT.type) / FAT.sector_byte;
addr_table += (cluster*FAT.type) % FAT.sector_byte;
if(fat_read_data(addr_table + FAT.sector_table*FAT.sector_byte, buff, FAT.type))
    {
    if(FAT.type == 4)									        // FAT32
        {
	    cluster = fat_cctli(buff, FAT.type);
	    if(cluster >= 0x0FFFFFF0)
		    return 1;                                           // end of cluster chain
	    }
    else											            // FAT16
 	    {
	    cluster = fat_cctli(buff, FAT.type);
	    if(cluster >= 0xFFF0)
		    return 1;							                // end of cluster chain
        }
    fat_calc_addr_cluster( drive, cluster);
    return 2;
    }
return 0;
}



// ************************************************************************************************
/// \brief		returns the application specific error code.
/// @return	  	fat error code (refer to header file)
// ************************************************************************************************
unsigned char fat_get_error_code(void)
{
return FAT.error_code;
}



// ************************************************************************************************
/// \brief		returns the logical file size.
/// @retval		size given in bytes
// ************************************************************************************************
unsigned long fat_get_lsize_file(void)
{
return DRIVE.file_size;
}



// ************************************************************************************************
/// \brief		returns the physical file size.
/// @retval		size given in bytes
// ************************************************************************************************
unsigned long fat_get_psize_file(void)
{
unsigned long physical_size;

physical_size = DRIVE.file_size / (FAT.sector_byte*FAT.sector_cluster);
if((DRIVE.file_size % (FAT.sector_byte*FAT.sector_cluster)))
    physical_size ++;

return physical_size*FAT.sector_byte*FAT.sector_cluster;
}



// ************************************************************************************************
/// \brief		updates the time/date stamp of last write.
/// @param[in]		time	-	time stamp (refer to fat_calc_dir_time(hour,min,sec))
/// @param[in]		date	-	date stamp (refer to fat_calc_dir_date(hour,min,sec))
// ************************************************************************************************
unsigned char fat_update_time_date(unsigned int time, unsigned int date)
{
unsigned char time_date[4];

if(DRIVE.addr_dir.sector && !HEAP.switch_process )
	{
	time_date[0] = time;                                            // set time of the last write
	time_date[1] = time >> 8;
	time_date[2] = date;                                            // set date of last write
	time_date[3] = date >> 8;
	strncpy(&DRIVE.dir_entry[FAT_OFFSET_TIME], time_date, 4);       // set time/date stamp
    #ifdef FAT_DEBUG
    if( fat_debug_flag & FAT_DEBUG_BIT)
        {
        putsf("FAT: time/date stamp of last write updated.\r");
        }
    #endif      // #ifdef FAT_DEBUG
    return 1;
	}
 else
    FAT.error_code = FAT_ERROR_FILE_ACCESS;
#ifdef FAT_DEBUG
if (fat_debug_flag & FAT_DEBUG_BIT)
    {
    fat_disp_error_code(FAT.error_code);
    }
#endif      // #ifdef FAT_DEBUG
}



// ************************************************************************************************
/// \brief		calculates and returns the directory time stamp.
/// @param[in]	hour    - hours (valid range: 0-23)
/// @param[in]	min     - minutes (valid range: 0-59)
/// @param[in]	sec     - second count (valid ramge: 0-59)
///	@retval		1	-	time_stamp (16 bit)
/// @retval		0	-	not valid
// ************************************************************************************************
unsigned int fat_calc_dir_time( unsigned char hour, unsigned char min, unsigned char sec )
{
unsigned int time_stamp = 0;

if((hour < 24) && (min < 60) && (sec < 60))     // valid ?
	{
	sec /= 2;                                   // second count of 2
    // mask definition:  second - 0x1F / minute - 0xE0 & 0x07 / hour - 0xF8)
	time_stamp = ((hour << 3) & 0xF8);
	time_stamp |= ((min >> 3) & 07);
	time_stamp = ((time_stamp << 8) | ((min << 5) & 0xE0) | (sec & 0x1F));
	}
return time_stamp;	                            // time stamp
}



// ************************************************************************************************
/// \brief		calculates and returns the directory date stamp.
/// @param[in]	day     - day of month (valid range: 1-31)
/// @param[in]	month 	- month of year (valid range: 1-12)
/// @param[in]	year 	- count of years (valid rang: 1980-2107)
///	@retval		1	-	date_stamp (16 bit)
/// @retval		0	-	not valid
// ************************************************************************************************
unsigned int fat_calc_dir_date( unsigned char day, unsigned char month, unsigned int year )
{
unsigned int date_stamp = 0;

// check if valid
if(((day >= 1) && (day <= 31)) && ((month >= 1) && (month <= 12)) && (year >= 1980) && (year <= 2107))
	{
	year -= 1980;       	    // date relative to the MS-DOS epoch of 01/01/1980

    // mask definition: day - 0x1F / month - 0xE0 & 0x01 / year - 0xFE
	date_stamp = ((year << 1) & 0xFE);
	date_stamp |= ((month >> 3) & 0x01);
	date_stamp = ((date_stamp << 8) | ((month << 5) & 0xE0) | (day & 0x1F));
    }
return date_stamp;		        // date stamp
}



// ************************************************************************************************
/// \brief		reads data continuously.
///
/// @param[in]	addr	-	data address (32 bit address value)
///	@param[in]	*buff	-	pointer to array
/// @param[in]	len		-	array length
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char fat_read_data(unsigned long addr, unsigned char *buff, unsigned int len)
{
//*********************************************************************************
// Note: Modify or expand the following lines to support additional volume entries.
#ifdef SDCARD_ENABLE
return sdc_read_data(addr, buff, len);			// sdc or mmc
#else
/*
 * Note: Place holder for further device drivers.
 */
return 0;										// no volume specified
#endif
//*********************************************************************************
}



// ************************************************************************************************
/// \brief		writes data continuously.
///
/// @param[in]	addr	-	data address
///	@param[in]	*buff	-	pointer to array
/// @param[in]	len		-	array length
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char fat_write_data(unsigned long addr, unsigned char *buff, unsigned int len)
{
//*********************************************************************************
// Note: Modify or expand the following lines to support additional volume entries.
#ifdef SDCARD_ENABLE
return sdc_write_data(addr, buff, len);			// sdc or mmc
#else
/*
 * Note: Place holder for further device drivers.
 */
return 0;										// no volume specified
#endif
//*********************************************************************************
}



// ************************************************************************************************
/// \brief      resets the members of all used variables defined as structures.
/// \note       Used variables: FAT, DRIVE and HEAP.
//
// ************************************************************************************************
void fat_reset_struct(void)
{
HEAP.node.size += HEAP.temp.size;
HEAP.temp.p_read = 0;                       // set pointer to zero
HEAP.temp.p_write = 0;
HEAP.node.p_write = 0;
HEAP.node.p_read = 0;
HEAP.num_cluster = 0;
HEAP.addr_table = 0;
HEAP.temp.buff = 0;

FAT.error_code = FAT_VOLUME_ERROR;
FAT.type = 0;                               // clear FAT specific data structure
FAT.sector_table = 0;
FAT.sector_root_dir = 0;
FAT.sector_data = 0;
FAT.sector_num = 0;
FAT.sector_byte = 0;
FAT.sector_cluster = 0;

HEAP.switch_process = 2;                    // suspend mode
DRIVE.count_cluster = 0;
DRIVE.last_cluster = 0;
DRIVE.file_size = 0;
DRIVE.addr_dir.sector = 0;
DRIVE.addr_dir.offset = 0;
DRIVE.addr_data.sector = 0;
DRIVE.addr_data.offset = 0;
}



// ************************************************************************************************
/// \brief      erases the sector.
///
/// @param[in]	*drive		- pointer to struct ADDR_FAT
/// @retval		1	-	success <br>
///	@retval		0	-	error
// ************************************************************************************************
unsigned char fat_erase_sector(ADDR_FAT *drive)
{
unsigned char buff[FAT_BUFF_LEN], loop;
unsigned int count;

if(!drive->sector)                      // valid sector address ?
    return 0;

if(FAT_BUFF_LEN < FAT.sector_byte)      // erase cycles ?
    {
    loop = ((FAT.sector_byte - drive->offset) - FAT_BUFF_LEN) / FAT_BUFF_LEN;
    count = FAT_BUFF_LEN;
    }
else
    {
    loop = 0;
    count = FAT.sector_byte;
    }

while(count)                            // erase buffer
    {
    count --;
    buff[count] = 0;
    }

while(loop)                             // loop ... cycles
    {
    if(!fat_write_data(FAT.sector_byte*drive->sector + count, buff, FAT_BUFF_LEN))
        return 0;
    count += FAT_BUFF_LEN;
    loop --;
    }

if(FAT.sector_byte - count)             // bytes left ?
    if(!fat_write_data(FAT.sector_byte*drive->sector + count, buff, FAT.sector_byte - count))
        return 0;

#ifdef FAT_DEBUG
if(fat_debug_flag & FAT_DEBUG_BIT)
    {
    printf("FAT: erase sector #%lu [bytes: %u].\n\r", drive->sector, (FAT.sector_byte - drive->offset));
    }
#endif      // #ifdef FAT_DEBUG

return 1;
}



// ************************************************************************************************
/// \brief      calculates the sector address of the cluster number.
///
/// @param[out]	*drive		- pointer to struct ADDR_FAT
/// @param[in]  cluster     - cluster number
// ************************************************************************************************
void fat_calc_addr_cluster(ADDR_FAT *drive, unsigned long cluster)
{
drive->sector = (cluster - 2);
drive->sector *= FAT.sector_cluster;
drive->sector += FAT.sector_data;
drive->offset = 0;
}



// ************************************************************************************************
/// \brief      calculates the cluster number of the sector address.
///
/// @param[in]	*drive		- pointer to struct ADDR_FAT
/// @retval     cluster     - cluster number
// ************************************************************************************************
unsigned long fat_calc_cluster_addr(ADDR_FAT *drive)
{
unsigned long cluster;

cluster = drive->sector;
cluster -= FAT.sector_data;
cluster /= FAT.sector_cluster;
return (cluster += 2);
}



// ************************************************************************************************
/// \brief	converts the byte char array into long integer value.
///
/// @param[in]	*byte	-	pointer to array
/// @retval		value 	- 	32 bit value
/// @retval     0       -   num_byte greater than 4
// ************************************************************************************************
unsigned long fat_cctli(unsigned char *byte, unsigned char num_byte)
{
unsigned long value = 0;
unsigned char i;

if(num_byte <= 4)
    {
	for( i = num_byte; i > 0; i -- )
    	value = ((value << 8) | byte[i-1]);
    return value;
    }
return 0;
}



// ************************************************************************************************
/// \brief	converts the long integer value into byte char array.
///
/// @param[out]	*byte	    -	pointer array
/// @param[in]	value 	    - 	32 bit value
/// @param[in]  num_byte    -   number of bytes to be converted (1 - 4)
/// @retval		1	-	success
/// @retval		0	- 	error (num_byte greater than 4)
// ************************************************************************************************
unsigned char fat_clitc(unsigned char *byte, unsigned long value, unsigned char num_byte)
{
unsigned char i;

if(num_byte <= 4)
    {
	for( i = 0; i < num_byte; i ++ )
	    {
	    byte[i] = value;
	    value = value >> 8;
	    }
	return 1;
	}
return 0;
}

#endif	// #ifdef FAT_ENABLE