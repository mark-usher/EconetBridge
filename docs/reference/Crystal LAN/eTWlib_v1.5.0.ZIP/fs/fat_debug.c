// ************************************************************************************************
///
/// \file 			fat_debug.c
/// \brief			debug functions for fat.c
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Nico M�ding, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#if defined(FAT_ENABLE) && defined(FAT_DEBUG)

#include "fat.h"
#include "fat_debug.h"
#include "sdcard.h"
#include "debug.h"

eeprom unsigned char fat_debug_flag = 0x00;	// default: debug output off
            
// prototype
void fat_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);

// ************************************************************************************************
// \brief		displays all directory entries.
//
// ************************************************************************************************
void fat_debug_init(void)
{
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &fat_debug_handler;
p_struct.id_string = "fat";
debug_register_handler(&p_struct);
}


// ************************************************************************************************
// \brief		displays all directory entries.
//
// ************************************************************************************************
unsigned char fat_display_dir_entries(void)
{
unsigned char buff[512];
unsigned int count_loop = 1;
unsigned char temp, dir_type = 0;
ADDR_FAT dir;

if(!FAT.sector_root_dir)
    return 0;

// root dir entry point ?
if(!DRIVE.addr_dir.sector || (DRIVE.addr_dir.sector == FAT.sector_root_dir))
    {
	dir.sector = FAT.sector_root_dir;       			    // start sector root dir
	temp = 0;
	printf("FAT file system: root directory [DOS 8.3 format]\n\r");
	}
else
    {
    dir.sector = DRIVE.addr_dir.sector;                     // start sector subdir
    temp = 1;
    printf("FAT folder: subdirectory [DOS 8.3 format]\n\r");
    }
dir.offset = 0;
// dir size and type ?
if(FAT.sector_data > FAT.sector_root_dir)			        // FAT16 root dir
	count_loop = FAT.sector_data - FAT.sector_root_dir;
else
	dir_type = 1;											// FAT32 root dir
// search dir entry
while(count_loop)
	{
	// read the ... sector of the directory
    if(!fat_read_data(FAT.sector_byte*dir.sector, buff, FAT.sector_byte))
	    {
	    return 0;											// error
        }
    while(dir.offset < FAT.sector_byte)
	    {
        if((buff[dir.offset] != 0) && (buff[dir.offset] != 0xE5) && (buff[dir.offset] != 0x20) && (buff[dir.offset] != 0x2E))
            {
	        if((buff[dir.offset + FAT_OFFSET_ATTRIBUTE] & FAT_ATTR_VOLUME_BIT) && !temp)
	            {
		        printf(" Volume:\t");
		        debug_display_mem_ascii(&buff[dir.offset], 8, 0);
		        printf("\n\r |\n\r +--");
		        temp = 2;
		        }
            else if(buff[dir.offset + FAT_OFFSET_ATTRIBUTE] & FAT_ATTR_ARCHIVE_BIT)
	            {
		        printf(" File:\t");
		        debug_display_mem_ascii(&buff[dir.offset], 8, 0);
		        putchar('.');
		        debug_display_mem_ascii(&buff[dir.offset + 8], 3, 0);
		        printf("\t");
		        if(buff[dir.offset + FAT_OFFSET_ATTRIBUTE] & FAT_ATTR_READ_ONLY_BIT)
		            printf("[read only] ");
		        if(buff[dir.offset + FAT_OFFSET_ATTRIBUTE] & FAT_ATTR_HIDDEN_BIT)
		            printf("[hidden file] ");
		        if(buff[dir.offset + FAT_OFFSET_ATTRIBUTE] & FAT_ATTR_SYSTEM_BIT)
		            printf("[system file] ");
		        printf("\n\r   -");
		        temp = 2;
		        }
	        else if(buff[dir.offset + FAT_OFFSET_ATTRIBUTE] & FAT_ATTR_SUBDIR_BIT)
		        {
		        printf(" Folder:\t");
		        printf("\n\r     |\n\r     +--\t");
		        debug_display_mem_ascii(&buff[dir.offset], 8, 0);
		        printf(" ->\t[open folder]\n\r   -");
		        temp = 2;
		        }
	        }
	    dir.offset += 32;                                   // next entry point
        }
	if(dir_type)
		{
		if(!(count_loop = fat_set_next_addr(&dir)))
			return 0;							            // error
		}
	else
		dir.sector++;
    dir.offset = 0;
	count_loop--;
    }
if(temp != 2)
    printf(" ? EMPTY!\n\r");
else
    printf("\r    \r");
return 1;
}



// ************************************************************************************************
/// \brief		displays the file system access point.
/// \note       The function displays the members of the structur drive used for file access.
///
// ************************************************************************************************
void fat_display_drive(void)
{
putsf("FAT: members of structure drive\r");
if((DRIVE.dir_entry[0] != 0) && (DRIVE.dir_entry[0] != 0xE5))
    {
    if(DRIVE.dir_entry[FAT_OFFSET_ATTRIBUTE] & FAT_ATTR_ARCHIVE_BIT)
        {
        printf(" - File:\t");
        debug_display_mem_ascii(DRIVE.dir_entry, 8, 0);
        putchar('.');
        debug_display_mem_ascii(&DRIVE.dir_entry[8], 3, 0);
        printf("\t");
        if(DRIVE.dir_entry[FAT_OFFSET_ATTRIBUTE] & FAT_ATTR_READ_ONLY_BIT)
            printf("[read only] ");
        if(DRIVE.dir_entry[FAT_OFFSET_ATTRIBUTE] & FAT_ATTR_HIDDEN_BIT)
            printf("[hidden file] ");
        if(DRIVE.dir_entry[FAT_OFFSET_ATTRIBUTE] & FAT_ATTR_SYSTEM_BIT)
            printf("[system file] ");
        printf("\n\r");
        DRIVE.count_cluster ++;
        }
    }
printf(" - File size: %lu bytes\n\r", DRIVE.file_size);
printf(" - Used clusters: %lu\n\r", DRIVE.count_cluster);
printf(" - DIR: sector = %lu / offset = %lu\n\r", DRIVE.addr_dir.sector, DRIVE.addr_dir.offset );
printf(" - DATA: sector = %lu / offset = %lu\n\r", DRIVE.addr_data.sector, DRIVE.addr_data.offset );
}


// ************************************************************************************************
/// \brief		create a Master Boot Record
/// \note       functions to create a volume for a 64MB memory card (just for test cases)
///
// ************************************************************************************************
void fat_debug_create_mbr( unsigned char *buff )
{
unsigned int count;
unsigned char first_part[16] = {
	0x00,0x01,0x08,0x00,0x06,0x07,0x60,0xde,0x27,0x00,0x00,0x00,0xd9,0xde,0x01,0x00};

    // clear buffer
    for( count = 0; count < sdc_get_block_size(); count ++)
    	buff[count] = 0;

	for( count = 0; count < 16; count ++ )
		buff[FAT_ADDR_FISRT_PART+count] = first_part[count];

	// executable marker
	buff[sdc_get_block_size()-2] = 0x55;
	buff[sdc_get_block_size()-1] = 0xaa;
}

// ************************************************************************************************
/// \brief		create a BPB
/// \note       functions to create a volume for a 64MB memory card (just for test cases)
///
// ************************************************************************************************
void fat_debug_create_bpb( unsigned char *buff )
{
unsigned char fat_debug_bpb[512] = {
	0xeb,0x3c,0x90,0x4d,0x53,0x44,0x4f,0x53,0x35,0x2e,0x30,0x00,0x02,0x02,0x02,0x00,
	0x02,0x00,0x02,0x00,0x00,0xf8,0xef,0x00,0x3f,0x00,0xff,0x00,0x27,0x00,0x00,0x00,
	0xd9,0xde,0x01,0x00,0x00,0x00,0x29,0xfd,0x7f,0xdd,0x76,0x4e,0x4f,0x20,0x4e,0x41,
	0x4d,0x45,0x20,0x20,0x20,0x20,0x46,0x41,0x54,0x31,0x36,0x20,0x20,0x20,0x33,0xc9,
	0x8e,0xd1,0xbc,0xf0,0x7b,0x8e,0xd9,0xb8,0x00,0x20,0x8e,0xc0,0xfc,0xbd,0x00,0x7c,
	0x38,0x4e,0x24,0x7d,0x24,0x8b,0xc1,0x99,0xe8,0x3c,0x01,0x72,0x1c,0x83,0xeb,0x3a,
	0x66,0xa1,0x1c,0x7c,0x26,0x66,0x3b,0x07,0x26,0x8a,0x57,0xfc,0x75,0x06,0x80,0xca,
	0x02,0x88,0x56,0x02,0x80,0xc3,0x10,0x73,0xeb,0x33,0xc9,0x8a,0x46,0x10,0x98,0xf7,
	0x66,0x16,0x03,0x46,0x1c,0x13,0x56,0x1e,0x03,0x46,0x0e,0x13,0xd1,0x8b,0x76,0x11,
	0x60,0x89,0x46,0xfc,0x89,0x56,0xfe,0xb8,0x20,0x00,0xf7,0xe6,0x8b,0x5e,0x0b,0x03,
	0xc3,0x48,0xf7,0xf3,0x01,0x46,0xfc,0x11,0x4e,0xfe,0x61,0xbf,0x00,0x00,0xe8,0xe6,
	0x00,0x72,0x39,0x26,0x38,0x2d,0x74,0x17,0x60,0xb1,0x0b,0xbe,0xa1,0x7d,0xf3,0xa6,
	0x61,0x74,0x32,0x4e,0x74,0x09,0x83,0xc7,0x20,0x3b,0xfb,0x72,0xe6,0xeb,0xdc,0xa0,
	0xfb,0x7d,0xb4,0x7d,0x8b,0xf0,0xac,0x98,0x40,0x74,0x0c,0x48,0x74,0x13,0xb4,0x0e,
	0xbb,0x07,0x00,0xcd,0x10,0xeb,0xef,0xa0,0xfd,0x7d,0xeb,0xe6,0xa0,0xfc,0x7d,0xeb,
	0xe1,0xcd,0x16,0xcd,0x19,0x26,0x8b,0x55,0x1a,0x52,0xb0,0x01,0xbb,0x00,0x00,0xe8,
	0x3b,0x00,0x72,0xe8,0x5b,0x8a,0x56,0x24,0xbe,0x0b,0x7c,0x8b,0xfc,0xc7,0x46,0xf0,
	0x3d,0x7d,0xc7,0x46,0xf4,0x29,0x7d,0x8c,0xd9,0x89,0x4e,0xf2,0x89,0x4e,0xf6,0xc6,
	0x06,0x96,0x7d,0xcb,0xea,0x03,0x00,0x00,0x20,0x0f,0xb6,0xc8,0x66,0x8b,0x46,0xf8,
	0x66,0x03,0x46,0x1c,0x66,0x8b,0xd0,0x66,0xc1,0xea,0x10,0xeb,0x5e,0x0f,0xb6,0xc8,
	0x4a,0x4a,0x8a,0x46,0x0d,0x32,0xe4,0xf7,0xe2,0x03,0x46,0xfc,0x13,0x56,0xfe,0xeb,
	0x4a,0x52,0x50,0x06,0x53,0x6a,0x01,0x6a,0x10,0x91,0x8b,0x46,0x18,0x96,0x92,0x33,
	0xd2,0xf7,0xf6,0x91,0xf7,0xf6,0x42,0x87,0xca,0xf7,0x76,0x1a,0x8a,0xf2,0x8a,0xe8,
	0xc0,0xcc,0x02,0x0a,0xcc,0xb8,0x01,0x02,0x80,0x7e,0x02,0x0e,0x75,0x04,0xb4,0x42,
	0x8b,0xf4,0x8a,0x56,0x24,0xcd,0x13,0x61,0x61,0x72,0x0b,0x40,0x75,0x01,0x42,0x03,
	0x5e,0x0b,0x49,0x75,0x06,0xf8,0xc3,0x41,0xbb,0x00,0x00,0x60,0x66,0x6a,0x00,0xeb,
	0xb0,0x4e,0x54,0x4c,0x44,0x52,0x20,0x20,0x20,0x20,0x20,0x20,0x0d,0x0a,0x44,0x61,
	0x74,0x65,0x6e,0x74,0x72,0x84,0x67,0x65,0x72,0x20,0x65,0x6e,0x74,0x66,0x65,0x72,
	0x6e,0x65,0x6e,0xff,0x0d,0x0a,0x4d,0x65,0x64,0x69,0x65,0x6e,0x66,0x65,0x68,0x6c,
	0x65,0x72,0xff,0x0d,0x0a,0x4e,0x65,0x75,0x73,0x74,0x61,0x72,0x74,0x3a,0x20,0x54,
	0x61,0x73,0x74,0x65,0x20,0x64,0x72,0x81,0x63,0x6b,0x65,0x6e,0x0d,0x0a,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xac,0xc4,0xd3,0x55,0xaa };

memcpy(buff, fat_debug_bpb, sdc_get_block_size());
}


// ************************************************************************************************
/// \brief		create a FAT
/// \note       functions to create a volume for a 64MB memory card (just for test cases)
///
// ************************************************************************************************
void fat_debug_create_fat( unsigned char *buff )
{
memset(buff, 0x00, sdc_get_block_size());
buff[0] = 0xF8;
buff[1] = 0xFF;
buff[2] = 0xFF;
buff[3] = 0xFF;
}

// ************************************************************************************************
/// \brief		create a DIR
/// \note       functions to create a volume for a 64MB memory card (just for test cases)
///
// ************************************************************************************************
void fat_debug_create_dir( unsigned char * buff )
{
unsigned char fat_debug_dir[32] = {
	0x53,0x44,0x43,0x41,0x52,0x44,0x20,0x20,0x20,0x20,0x20,0x08,0x00,0x00,0x00,0x00,
	0x00,0x00,0x00,0x00,0x00,0x00,0xeb,0xb4,0x73,0x32,0x00,0x00,0x00,0x00,0x00,0x00};

memset(buff, 0x00, sdc_get_block_size());
memcpy(buff, fat_debug_dir, sizeof(fat_debug_dir));
}

// ************************************************************************************************
/// \brief		format a SD-Card with 64MByte
/// \note       functions to create a volume for a 64MB memory card (just for test cases)
///
// ************************************************************************************************
void fat_debug_format_sdc(void)
{
unsigned char buff[512];

fat_debug_create_mbr( buff );
sdc_write_data( sdc_get_addr_block(0), buff, sdc_get_block_size());
fat_debug_create_bpb( buff );
sdc_write_data( sdc_get_addr_block(39), buff, sdc_get_block_size());
fat_debug_create_fat( buff );
sdc_write_data( sdc_get_addr_block(41), buff, sdc_get_block_size());
sdc_write_data( sdc_get_addr_block(280), buff, sdc_get_block_size());
fat_debug_create_dir( buff );
sdc_write_data( sdc_get_addr_block(519), buff, sdc_get_block_size());
}


// ************************************************************************************************
/// \brief		displays the structure of the FAT format
///
// ************************************************************************************************
void fat_display_format(void)
{
unsigned char state = 0;

//printf("---------------- Data structure ----------------\n\r");
if(FAT.type == 4)
    {
   	printf("FAT: identified file system supports FAT32.\n\r");
   	state = 1;
    }
else if(FAT.type == 2)
    {
  	printf("FAT: identified file system supports FAT16.\n\r");
   	state = 1;
    }
else
	printf("FAT: Unknown file system!\n\r");
if( state )
    {
    printf(" - FAT entry point @ sector %lu\n\r", FAT.sector_table );
    printf(" - DIR entry point @ sector %lu\n\r", FAT.sector_root_dir );
    printf(" - DATA entry point @ sector %lu\n\r", FAT.sector_data );
    printf(" - Number of sectors per FAT: %lu\n\r", FAT.sector_num );
    printf(" - Bytes per sector: %u\n\r", FAT.sector_byte);
    printf(" - Sectors per cluster: %u\n\r", FAT.sector_cluster );
    }
}


// ************************************************************************************************
/// \brief          displays the file system access error code.
///
// ************************************************************************************************
void fat_disp_error_code(unsigned char opcode)
{
printf("FAT ERROR CODE: ");
switch( opcode )
	{
	case 0: putsf("0\r"); break;
	case FAT_MEMORY_SRAM_ERROR:	putsf("can't initialize SRAM memory!\r"); break;
	case FAT_BUFFER_SIZE_ERROR:	putsf("buffer size too small!\r"); break;
	case FAT_VOLUME_ERROR: putsf("no volume available or specified!\r"); break;
	case FAT_UNKNOWN_FILE_SYSTEM: putsf("missing or unknown file system!\r"); break;
	case FAT_FORMAT_DAMAGED: putsf("proccess abort, format damaged!\r"); break;
	case FAT_HARDWARE_ERROR: putsf("hardware error sdc or mmc!\r"); break;
	case FAT_DIR_ENTRY_EXIST: putsf("directory entry already exist!\r"); break;
	case FAT_MAX_ROOT_DIR_ACHIEVED: putsf("maximum root directory achieved!\r"); break;
	case FAT_NO_SPACE_AVAILABLE: putsf("all clusters in use (no memory space)!\r");	break;
	case FAT_DIR_ENTRY_NOT_FOUND: putsf("directory entry not found!\r"); break;
	case FAT_ERROR_DOS83_FORMAT: putsf("invalid DOS 8.3 formated directory entry!\r"); break;
	case FAT_ERROR_FILE_ACCESS: putsf("can't access file location!\r");	break;
	case FAT_ERROR_FOLDER_ACCESS: putsf("can't access directory location!\r"); break;
	default:
	printf("unknown error message [opcode: 0x%x]!\n\r", opcode);
	}
}


// ************************************************************************************************
/// \brief      displays the command list.
//
// ************************************************************************************************
void fat_debug_cmd_list(void)
{
putsf("\"fat-xxx\" - fat debug commands:\r");
putsf("\tfat-cmd-list            fat-init-buff             fat-flush-buff        fat-disp-temp\r");
putsf("\tfat-disp-node           fat-disp-temp             fat-main-status       fat-open-folder <name>\r");
putsf("\tfat-create-fole <name>  fat-delete-folder <name>  fat-back-root         fat-create-file <name>\r");
putsf("\tfat-open-file <name>    fat-close-file            fat-read-file         fat-write-file\r");
putsf("\tfat-lsize-file          fat-psize-file            fat-update-stamp      fat-error-code\r");
putsf("\tfat-disp-format         fat-disp-drive            fat-disp-dir          fat-format\r");
}


// ************************************************************************************************
/// \brief	    command handler for debug commands
/// @param[in]  command	- pointer to received string
/// @param[in]  mode    - type of debug command, see T_DEBUG_HANDLER_MODE in debug.h
// ************************************************************************************************
void fat_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
unsigned char buff[200], *p_buff, count, ext[] = "TXT";
static unsigned char sign = 0x41;
unsigned int len;

if (mode == DEBUG_HANDLER_MODE_INFO)
    {
    printf("FAT_DEBUG");
	if (fat_debug_flag & FAT_DEBUG_BIT)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
	}
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
    fat_debug_cmd_list();
    // add output for 'help' command here
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
	{
	if (strncmpf(command, "fatprocess", 10)==0)
	    {
    	fat_debug_flag ^= FAT_PROCESS_DEBUG_BIT;
    	if (fat_debug_flag & FAT_PROCESS_DEBUG_BIT)
    		putsf("FAT_PROCESS_DEBUG ON\r");
    	else
    		putsf("FAT_PROCESS_DEBUG_OFF\r");
	    }
	else if (strncmpf(command, "fat", 3)==0)
	    {
    	fat_debug_flag ^= FAT_DEBUG_BIT;
    	if (fat_debug_flag & FAT_DEBUG_BIT)
    		putsf("FAT_DEBUG ON\r");
    	else
    		putsf("FAT_DEBUG_OFF\r");
	    }
	}
else if(strncmpf(command, "-init-buff", 10)==0)
	{
	p_buff = (unsigned char *)malloc(200);
	if(p_buff)
	    fat_init_buffer(p_buff, 200, 1);
	else
	    putsf("DEBUG: can't initialize memory in the heap!\r");
	}
else if(strncmpf(command, "-flush-buff", 11)==0)
	fat_flush_buffer();
else if(strncmpf(command, "-disp-node", 10)==0)
	{
	if(HEAP.node.buff)
	    {
        printf("FAT PROCESS: node buffer contains a free cluster chain [size: %u bytes].\n\r", HEAP.node.size);
        printf(" - p_write @ offset 0x%x and p_read @ offset 0x%x:\n\r", HEAP.node.p_write, HEAP.node.p_read);
        debug_display_mem_hex(HEAP.node.buff, HEAP.node.size, 16);
        }
    else
        fat_disp_error_code(fat_get_error_code());
    }
else if(strncmpf(command, "-disp-temp", 10)==0)
	{
	if(HEAP.temp.buff)
	    {
        printf("FAT PROCESS: temp buffer contains data @ addr 0x%lx [size: %u bytes].\n\r", HEAP.addr_table, HEAP.temp.size);
        printf(" - p_write @ offset 0x%x and p_read @ offset 0x%x:\n\r", HEAP.temp.p_write, HEAP.temp.p_read);
        debug_display_mem_hex(HEAP.temp.buff, HEAP.temp.size, 16);
        }
    else
        fat_disp_error_code(fat_get_error_code());
    }
else if(strncmpf(command, "-main-status", 12)==0)
	{
	if(HEAP.node.buff && FAT.sector_table)
	    printf("FAT: main process running [process code: 0x%x] ...\n\r", HEAP.switch_process);
	else
	    putsf("FAT: main process suspended!\r");
	}
else if(strncmpf(command, "-open-folder ", 13)==0)
	{
	len = strlen(command);
	command = debug_search_parameter(command);
	for(count = (len-16); count < len; count ++)
		command[count] = 0;
	if(command[0] != 0)
		{
		fat_open_folder(command);
		}
	else
	    putsf("FAT: error missing name.\r");
	}
else if(strncmpf(command, "-create-folder ", 14)==0)
	{
	len = strlen(command);
	command = debug_search_parameter(command);
	for(count = (len-18); count < len; count ++)
		command[count] = 0;
	if(command[0] != 0)
		{
		fat_create_folder(command);
		}
	else
	    putsf("FAT: error missing name.\r");
	}
else if(strncmpf(command, "-delete-folder ", 14)==0)
	{
	len = strlen(command);
	command = debug_search_parameter(command);
	for(count = (len-18); count < len; count ++)
		command[count] = 0;
	if(command[0] != 0)
		{
		//fat_delete_folder(command);
		putsf("FAT: not implemented yet.\r");
		}
	else
	    putsf("FAT: error missing name.\r");
	}
else if(strncmpf(command, "-back-root", 10)==0)
    fat_back_root_dir();
else if(strncmpf(command, "-create-file ", 12)==0)
	{
	len = strlen(command);
	command = debug_search_parameter(command);
	for(count = (len-16); count < len; count ++)
		command[count] = 0;
	if(command[0] != 0)
		{
		fat_create_file( command, ext);
		}
	else
	    putsf("FAT: error missing name.\r");
	}
else if(strncmpf(command, "-open-file ", 10)==0)
	{
	len = strlen(command);
	command = debug_search_parameter(command);
	for(count = (len-14); count < len; count ++)
		command[count] = 0;
	if(command[0] != 0)
		{
		fat_open_file( command, ext);
		}
	else
	    putsf("FAT: error missing name.\r");
	}
else if(strncmpf(command, "-close-file", 11)==0)
	{
	if(!fat_close_file())
        fat_disp_error_code(fat_get_error_code());
	}
else if(strncmpf(command, "-read-file", 10)==0)
	{
	if(!fat_read_file( buff, 200))
	    fat_disp_error_code(fat_get_error_code());
	}
else if(strncmpf(command, "-write-file", 11)==0)
	{
	memset(buff, sign, sizeof(buff));
	if(!fat_write_file( buff, 200))
	    fat_disp_error_code(fat_get_error_code());
	if(++sign > 0x5A)
		sign = 0x41;
	}
else if(strncmpf(command, "-lsize-file", 11)==0)
    printf("FAT: logical file size: %lu bytes.\n\r", fat_get_lsize_file());
else if(strncmpf(command, "-psize-file", 11)==0)
    printf("FAT: physical file size: %lu bytes.\n\r", fat_get_psize_file());
else if(strncmpf(command, "-update-stamp", 13)==0)
	fat_update_time_date(fat_calc_dir_time(15, 57, 40), fat_calc_dir_date(27, 9, 2005));
else if(strncmpf(command, "-error-code", 11)==0)
    fat_disp_error_code(fat_get_error_code());
else if(strncmpf(command, "-disp-format", 12)==0)
    {
    if(FAT.sector_table)
        fat_display_format();
    else
        fat_disp_error_code(fat_get_error_code());
    }
else if(strncmpf(command, "-disp-drive", 11)==0)
    fat_display_drive();
else if(strncmpf(command, "-disp-dir", 11)==0)
    {
    if(!fat_display_dir_entries())
        fat_disp_error_code(fat_get_error_code());
    }
else if(strncmpf(command, "-format", 7)==0)
	fat_debug_format_sdc();
}

#endif