// ************************************************************************************************
///
/// \file 			fat.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Nico M�ding, Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \addtogroup File_Systems
/// @{
/// \defgroup FAT
/// \addtogroup FAT
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define FAT_ENABLE
#define FAT_DEBUG
#define SDCARD_ENABLE
//@}
#endif

#ifndef _FAT_INCLUDED_
#define _FAT_INCLUDED_ 


///	\def FAT_ENABLE
///		This macro enables the whole FAT module. It must be defined in project.h
///
/// \def FAT_DEBUG
/// 	This define enables all debug output and functions in fat.c and fat_debug.c
///
/// \def SDCARD_ENABLE
/// 	At the moment, the FAT module works only with SD-Cards. This macro activates this 
///		one hardware interface.


// ************************************************************************************************
/// @name Macro Definition
/// \brief 	Master Boot Record (MBR) partition table:
/// \note 	The 1st partition of the table is used to identify the file system, 
///			all other defined partition entries are not considered yet.  
//@{ 
#define FAT_ADDR_FISRT_PART			0x01BE		///< 1st partition entry (16 bytes long)
#define FAT_ADDR_SECOND_PART		0x01CE		///< 2nd partition entry (16 bytes long)
#define FAT_ADDR_THIRD_PART		 	0x01DE		///< 3rd partition entry (16 bytes long)
#define FAT_ADDR_FOURTH_PART	 	0x01EE		///< 4th partitiion entry (16 bytes long)
//@} 	 
 

// ************************************************************************************************
/// @name Macro Definition
/// \brief 	Partition entry offsets:
/// \note 	The partition entry covers also fields like 'HEAD' or 'CYLINDER/SECTOR' which are
///			used by harddisk drivers and useless in this case.     
//@{
#define FAT_OFFSET_CURRENT_STATE		0x00		///< state of partition (1 byte).
#define FAT_OFFSET_TYP_PART				0x04		
///< type of partition (1 byte): 0x04 = FAT16 < 32MB / 0x06 = FAT16 > 32MB / 0x0B = FAT32.
#define FAT_OFFSET_NBR_MBR_SECTOR		0x08		
///<  number of sectors between the MBR and the 1st sector in the volume (4 bytes).
#define FAT_OFFSET_NBR_PART_SECTOR		0x0C		///< number of sectors in the volume (4 bytes).
//@}
 

// ************************************************************************************************
/// @name Macro Definition
/// \brief 	BIOS Parameter Block (BPB) offsets:
/// \note 	The BPB is a part of the 'boot sector' and located in the first sector of the volume.
///			The offsets below defines those fields which are relevant to calculate the fat specific
///			data structure. The values in brackets describes the length of each field.  
//@{
#define FAT_OFFSET_BYTES_PER_SECTOR	  	0x0B		///< bytes per sector (2 bytes).
#define FAT_OFFSET_SECTORS_PER_CLUSTER	0x0D		///< sectors per cluster (1 byte).
#define FAT_OFFSET_RESERVED_SECTORS		0x0E		///< reserved sectors (2 bytes).
#define FAT_OFFSET_NUMBER_OF_FATS		0x10		///< number of file allocation tables (1 byte).
#define FAT_OFFSET_MAX_DIR_ENTRIES		0x11		///< maximum root directory entries (2 bytes).
#define FAT_OFFSET_SECTORS_PER_FAT16	0x16		///< sectors per FAT16 (2 bytes).
#define FAT_OFFSET_NUMBER_OF_SECTORS	0x20		///< number of all sectors (4 bytes).
#define FAT_OFFSET_SECTORS_PER_FAT32	0x24		///< sectors per FAT32 (4 bytes).
//@} 
 

// ************************************************************************************************
/// @name Macro Definition
/// \brief	Directory entry offsets:
/// \note 	
///			- Short directory entries (DOS 8.3 fomat) are always 32 bytes long. <br> 
///			- Time/date stamps of the last file access or file creation are not supported yet.
//@{
#define FAT_OFFSET_NAME				0x00		///< directory name (8 bytes).
#define FAT_OFFSET_EXTENSION		0x08		///< file extension (3 bytes).
#define FAT_OFFSET_ATTRIBUTE		0x0B		///< attribute (1 byte). -> see definition below 
#define FAT_OFFSET_CLST_MAP_FAT32	0x14		///< cluster map, FAT32 high word (2 bytes).
#define FAT_OFFSET_TIME             0x16		///< time stamp of last write (2 bytes).
#define FAT_OFFSET_DATE				0x18		///< date stamp of last write (2 bytes).
#define FAT_OFFSET_CLUSTER_MAP		0x1A		///< cluster map to identify the first cluster (2 bytes).
#define FAT_OFFSET_FILE_SIZE		0x1C		///< file size (4 bytes).
//@}


// ************************************************************************************************
/// @name Macro Definition
/// Directory specific attributes:
//@{
#define FAT_ATTR_READ_ONLY_BIT		0x01		///< read only, which means any write operation fails. 
#define FAT_ATTR_HIDDEN_BIT			0x02		///< hidden file, not shown in normal directory listings.
#define FAT_ATTR_SYSTEM_BIT			0x04		///< indicates an operating system file entry.
#define FAT_ATTR_VOLUME_BIT			0x08		///< name or lable (ID) of the volume.		
#define FAT_ATTR_SUBDIR_BIT			0x10   		///< subdirectory entry, link to folder.
#define FAT_ATTR_ARCHIVE_BIT		0x20    	///< archive
//@}


// ************************************************************************************************
/// @name Marco Definition 
/// Application specific error codes:
//@{
#define FAT_MEMORY_SRAM_ERROR       1   	///< SRAM memory buffer can't be initialized.
#define FAT_HARDWARE_ERROR			2		///< error read/write operation to/from the volume.
#define FAT_VOLUME_ERROR			3		///< no volume available or specified.
#define FAT_UNKNOWN_FILE_SYSTEM		4		///< file system not supported or unknown.
#define FAT_FORMAT_DAMAGED			5		///< file system access aborted, format damaged. 
#define FAT_MAX_ROOT_DIR_ACHIEVED	6		///< maximum root directory achieved.
#define FAT_NO_SPACE_AVAILABLE		7		///< all clusters in use, no space available.
#define FAT_ERROR_DOS83_FORMAT		8		///< invalid DOS 8.3 formated directory entry.
#define FAT_BUFFER_SIZE_ERROR       9       ///< given buffer size is too small.

#define FAT_DIR_ENTRY_NOT_FOUND		10		///< directory entry not found.
#define FAT_DIR_ENTRY_EXIST			11		///< directory entry already exists. 

#define FAT_ERROR_FILE_ACCESS       12      ///< can't access file location.
#define FAT_ERROR_FOLDER_ACCESS     13      ///< can't access directory location.
#define FAT_ERROR_END_OF_FILE       14      ///< found EOF mark, end of file.
//@}
           

// ************************************************************************************************
/// @name Type Definition 
//@{  

// ************************************************************************************************
/// struct ADDR_FAT
/// \brief  typedef address structure to handle file access.
// ************************************************************************************************
typedef struct {
	unsigned long sector;				///< physical sector number.
	unsigned int  offset;				///< offset within the sector.
	} ADDR_FAT;							///< typdef struct address

// ************************************************************************************************
/// struct BUFFER
/// \brief	typedef buffer structure for temporary data storage.
// ************************************************************************************************
typedef struct {
	unsigned char* buff;				///< pointer to array.
	unsigned int   size;				///< buffer size.
	unsigned int   p_write;             ///< write pointer. 
	unsigned int   p_read;              ///< read pointer.
	} BUFFER;                          	///< typdef struct buffer
 
//@}	
 
 
// prototypes
#pragma used+ 
void          fat_init(void);
unsigned char fat_init_buffer(unsigned char *buff, unsigned int buff_size, unsigned char SRAM_type);
void          fat_flush_buffer(void);

unsigned char fat_main_process(void);
unsigned char fat_read_BPB(void);

unsigned char fat_create_file(unsigned char *str_name, unsigned char *str_ext);
unsigned char fat_open_file(unsigned char *str_name, unsigned char *str_ext);
unsigned char fat_close_file(void);
unsigned char fat_get_attr(void);
unsigned char fat_set_attr(unsigned char attr);  

unsigned char fat_create_folder(unsigned char *str_name);
unsigned char fat_open_folder(unsigned char *str_name);
unsigned char fat_back_root_dir(void);

unsigned int  fat_read_file(unsigned char *buff, unsigned int len);
unsigned int  fat_write_file(unsigned char *buff, unsigned int len);

unsigned char fat_update_time_date(unsigned int time, unsigned int date);
unsigned int  fat_calc_dir_date( unsigned char day, unsigned char month, unsigned int year );
unsigned int  fat_calc_dir_time( unsigned char hour, unsigned char min, unsigned char sec ); 

unsigned char fat_get_error_code(void);
unsigned long fat_get_psize_file(void);
unsigned long fat_get_lsize_file(void);

#ifdef FAT_DEBUG
void 		  fat_disp_error_code(unsigned char opcode);
unsigned char fat_display_dir_entries(void); 
void 		  fat_display_format(void);
void 		  fat_display_drive(void);
#endif      // #ifdef FAT_DEBUG
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library fat.c
#endif

#endif	// #ifndef _FAT_INCLUDED_

/// @}
/// @}