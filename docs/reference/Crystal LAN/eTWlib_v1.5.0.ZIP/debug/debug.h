// ************************************************************************************************
///
/// \file 			debug.h
/// \brief			header file of debug.c
///
/// \date	 		$LastChangedDate: 2007-03-06 13:04:46 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 598 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup Debug_Framework
/// \addtogroup Debug_Framework
/// @{
/// \defgroup Debug
/// \addtogroup Debug
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define DEBUG
#define DEBUG_CMD_BUFFERSIZE		50
#define DEBUG_PROJECT_NAME			"eTW_AIO_SDcard"
#define DEBUG_PROJECT_VERSION		"1.0"
#define DEBUG_MCU_CLOCK_STRING		"16.000MHz"
#define DEBUG_MCU_TYP_STRING		"ATmega128(L)"
#define DEBUG_MAX_HANDLER			15
//@}
#endif


///	\def DEBUG
///		This macro enables the whole debug interface. Is the main macro for the debug module 
///		together with DEBUG_UPLINK_xx. It also activates the debug_io.c module.
///
/// \def DEBUG_CMD_BUFFERSIZE
///		Specifies the size of the debug_cmd_buffer array. Limits the length of an command from PC.
///		By default, this buffer has a size of 30 Byte. You can define DEBUG_CMD_BUFFERSIZE
///		in project.h to an different value. The default size is overwritten.
///
/// \def DEBUG_PROJECT_NAME
///		Specifies an string with the name of the project. For example "My test project".
///		It is used in the debug_info() function in debug.c 
///
/// \def DEBUG_PROJECT_VERSION
///		Specifies an string with the version of the project. For example "0.1". It is used
///		in the debug_info() function in debug.c 
///
/// \def DEBUG_MCU_CLOCK_STRING
///		Specifies an string with the MCU clock value. For example "16 MHz". It is used
///		in the debug_info() function in debug.c 
///
/// \def DEBUG_MCU_TYP_STRING
///		Specifies an string with the MCU type name. For example "ATmega8". It is used
///		in the debug_info() function in debug.c 
///
/// \def DEBUG_MAX_HANDLER
///		Modules can register their debug handler functions with debug_register_handler(). By
///		default the number of functions is limited due to SRAM consumption. DEBUG_MAX_HANDLER
///		can be redefined in project.h to an other value

#ifndef _DEBUG_INCLUDED_
#define _DEBUG_INCLUDED_

#include "project.h"		// Project configuration

#ifndef DEBUG_PROJECT_NAME
#define DEBUG_PROJECT_NAME			"-xxxxx-"
#endif
#ifndef DEBUG_PROJECT_VERSION
#define DEBUG_PROJECT_VERSION		"x.xx"
#endif

#ifdef DEBUG

#ifndef DEBUG_MCU_TYP_STRING
	#if defined(_CHIP_ATMEGA128_)||defined(_CHIP_ATMEGA128L_)
	#define DEBUG_MCU_TYP_STRING		"ATmega128(L)"
	#elif defined(_CHIP_ATMEGA64_)||defined(_CHIP_ATMEGA64L_)
	#define DEBUG_MCU_TYP_STRING		"ATmega64(L)"
	#elif defined(_CHIP_ATMEGA32_)||defined(_CHIP_ATMEGA32L_)
	#define DEBUG_MCU_TYP_STRING		"ATmega32(L)"
	#elif defined(_CHIP_ATMEGA16_)||defined(_CHIP_ATMEGA16L_)
	#define DEBUG_MCU_TYP_STRING		"ATmega16(L)"
	#elif defined(_CHIP_ATMEGA8535_)||defined(_CHIP_ATMEGA8535L_)
	#define DEBUG_MCU_TYP_STRING	 	"ATmega8535(L)"
	#elif defined(_CHIP_ATMEGA8_)||defined(_CHIP_ATMEGA8L_)
	#define DEBUG_MCU_TYP_STRING		"ATmega8(L)"
	#else
	#define DEBUG_MCU_TYP_STRING		"ATmegaXXX"
	#endif
#endif	// #ifndef DEBUG_MCU_TYP_STRING

#if(_MCU_CLOCK_FREQUENCY_==16000000)
	#define	DEBUG_MCU_CLOCK_STRING		"16.000MHz"
#elif(_MCU_CLOCK_FREQUENCY_==14745600)
	#define	DEBUG_MCU_CLOCK_STRING		"14.7456MHz"
#elif(_MCU_CLOCK_FREQUENCY_==8000000)
	#define	DEBUG_MCU_CLOCK_STRING		"8.0000MHz"
#elif(_MCU_CLOCK_FREQUENCY_==7372800)
	#define	DEBUG_MCU_CLOCK_STRING		"7.3728MHz"
#elif(_MCU_CLOCK_FREQUENCY_==3686400)
	#define	DEBUG_MCU_CLOCK_STRING		"3.6864MHz"
#elif(_MCU_CLOCK_FREQUENCY_==1843200)
	#define	DEBUG_MCU_CLOCK_STRING		"1.8432MHz"
#else
	#define	DEBUG_MCU_CLOCK_STRING		"x.xxxMHz"
#endif


#ifndef DEBUG_CMD_BUFFERSIZE
#define DEBUG_CMD_BUFFERSIZE			30  	// size of uart-command-buffer
#endif


// ************************************************************************************************
/// \enum   T_DEBUG_HANDLER_MODE
/// \brief  type of handler call
// ************************************************************************************************
typedef enum {
    DEBUG_HANDLER_MODE_CMD,
    DEBUG_HANDLER_MODE_SWITCH,
    DEBUG_HANDLER_MODE_INFO,
    DEBUG_HANDLER_MODE_HELP
} T_DEBUG_HANDLER_MODE;

// ************************************************************************************************
/// \struct T_DEBUG_HANDLER_STRUCT
/// \brief  
// ************************************************************************************************
typedef struct {
    void (*fp_handler)(unsigned char*, T_DEBUG_HANDLER_MODE mode);
    unsigned char flash* id_string;
	}T_DEBUG_HANDLER_STRUCT;

#ifndef DEBUG_MAX_HANDLER
#define DEBUG_MAX_HANDLER               10
#endif


// prototypes
#pragma used+
void			debug_init(void);
unsigned char*	debug_get_command(void);
unsigned char 	debug_set_command(flash unsigned char *new_command);
void 			debug_do_cmd(unsigned char *p_command);
void 			debug_display_8bit_pattern(unsigned char binary);
void 			debug_display_mem_ascii(unsigned char *p_ascii, unsigned int size, unsigned char output_width);
void			debug_display_mem_hex(unsigned char *p_data, unsigned int size, unsigned char output_width);
void 			debug_display_mem_hex_eeprom(eeprom unsigned char *p_data, unsigned int size, unsigned char output_width);
void 			debug_display_buffer(unsigned char *p_data, unsigned int size, unsigned int highlight_pos);
unsigned char 	debug_string2ip(unsigned char *command, unsigned char *new_ip, unsigned int *new_port);
unsigned char 	debug_string2mac(unsigned char *command, unsigned char *new_mac);
unsigned char 	debug_atoi_hex_str(unsigned char* src, unsigned char* dest, unsigned char* length);
unsigned char*	debug_search_parameter(unsigned char *command);
signed int 		debug_get_int_parameter(unsigned char *command);
signed long 	debug_get_long_parameter(unsigned char *command);
void			debug_print_ip(flash unsigned char *string_data, unsigned char *ip_data);
void			debug_print_ip_ee(flash unsigned char *string_data, eeprom unsigned char *ip_data);
void			debug_print_mac(flash unsigned char *string_data, unsigned char *mac_data);
void			debug_info(flash unsigned char *info_string);
void 			debug_main(void);
void            debug_process_handler(unsigned char *command);
void			debug_register_handler(T_DEBUG_HANDLER_STRUCT* p_struct);
#pragma used-

#ifdef DEBUG_LIBRARY_ENABLE
#pragma library debug.c
#endif

#endif	// #ifdef DEBUG
#endif	// #ifndef _DEBUG_INCLUDED_

/// @}
/// @}