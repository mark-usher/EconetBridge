// ************************************************************************************************
///
/// \file 			debug.c
/// \brief			Common debug interface
///
/// \todo			All debug messages with timestamps
/// \todo			Reduce number of debug macros. In the application, one function 
///					call should be enough.
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef _DOXYGEN_PARSER_
#define DEBUG
#endif

#ifdef DEBUG

#include <io.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "debug.h"
#include "debug_io.h"
#include "etwlib_version.h"
#include "util.h"


#pragma regalloc-
unsigned char	debug_cmd_buffer[DEBUG_CMD_BUFFERSIZE]={0};	///< command buffer
unsigned char	debug_cmd_wr_index = 0;			///< index of next write position in command buffer
unsigned char	debug_last_key = 0;				///< last character from PC

T_DEBUG_HANDLER_STRUCT debug_struct[DEBUG_MAX_HANDLER]={0};
unsigned char   debug_next_free_handler=0;
#pragma regalloc+


// ************************************************************************************************
/// \brief		Inits the debug interface
///
// ************************************************************************************************
void debug_init(void)
{
debug_io_init();
}

// ************************************************************************************************
/// \brief		Reads a new UART debug-command
///
/// \note		Needs DEBUG_DEFINE_PUTCHAR to be defined!
/// @retval		0	- no new command
/// @retval		!=0 - pointer to the start of a new command
// ************************************************************************************************
unsigned char* debug_get_command(void)
{
signed int act_key;

act_key = debug_check_rx();
if (act_key != -1)						// character received?
	{
//	printf("D:0x%02x\r\n", (unsigned char)act_key);
	if (act_key == 0x0D)				// Enter-Key
		{
		if (debug_cmd_wr_index != 0)						// if new command was received
			debug_cmd_buffer[debug_cmd_wr_index] = 0;		// add \0 to received command
		debug_cmd_wr_index = 0;
		printf("??:%s\r\n", debug_cmd_buffer);
		debug_last_key = (unsigned char)act_key;
		return debug_cmd_buffer;
		}
	else if (act_key == '\b')			// Backspace-Key - Delete last sign
		{
		if (debug_cmd_wr_index > 0)
			{
			debug_cmd_wr_index--;
			printf(" \b");				// delete last sign on terminal
			}
		debug_cmd_buffer[debug_cmd_wr_index] = 0;
		}
	else if (act_key == 0x1b)			// ESC-Key - replace the last command
		{
		if (debug_last_key==0x0d)		// if command executed??
			{
			debug_cmd_wr_index = strlen(debug_cmd_buffer);
			printf("??:%s", debug_cmd_buffer);
			}
		}
	else
		{
		debug_cmd_buffer[debug_cmd_wr_index] = (unsigned char)act_key;		// command op code
		debug_cmd_wr_index++;
		if (debug_cmd_wr_index >= DEBUG_CMD_BUFFERSIZE)
			debug_cmd_wr_index = 0;
		}
	debug_last_key = act_key;
	}
return 0;
}
     

// ************************************************************************************************
/// \brief		Writes a new command to the commmand buffer
///
///	\note		New command can called with the ESC-Key after debug_set_command() is called
/// @param[in]  new_commmand - flash pointer to new command
/// @retval		0 - ERROR, string too long 
/// @retval		1 - OK
// ************************************************************************************************
unsigned char debug_set_command(flash unsigned char *new_command)
{
if (strlenf(new_command) < sizeof(debug_cmd_buffer))
	{
	debug_last_key = 0x0d;	// simulate command execute
	strcpyf(debug_cmd_buffer, new_command);
	return 1;
	}
return 0;
}


// ************************************************************************************************
/// \brief	    Outputs Binary pattern of 8-bit character
///
/// @param[in]  binary - 8-bit binary
// ************************************************************************************************
void debug_display_8bit_pattern(unsigned char binary)
{
unsigned char bitmask = 0x80;

while (bitmask)
	{
	if (bitmask & binary)
		putchar('1');
	else
		putchar('0');
	bitmask >>= 1;
	}   	
}


#define DEBUG_DISPLAY_WIDTH_DEFAULT			24			///< Parameter used in debug_display_mem_xx()
// ************************************************************************************************
/// \brief		Outputs an part of SRAM to the debug interface as ASCII signs
///
/// \note		Needs DEBUG_DEFINE_PUTCHAR to be defined!
/// @param[in]	p_data	- SRAM-pointer to ASCII signs
/// @param[in]	size	- size of string
/// @param[in]  output_width - >0 new line after this count of binary data
///                           0 new line after 24 Byte of binary data - 29 output characters +CR+LF
// ************************************************************************************************
void debug_display_mem_ascii(unsigned char *p_data, unsigned int size, unsigned char output_width)
{
unsigned char act_column=0;
unsigned char line_count=0;
unsigned int  byte_pos=1;

while (size)
	{
	#asm("wdr");	// Reset Watchdog
	if (act_column == 0)
		printf("%3u) ", byte_pos);
	if (isprint(*p_data))
		putchar(*p_data);
	else
		putchar('.');
	p_data++;
	size--;
	act_column++;
	byte_pos++;
	if (output_width != 0)
		{
		if (output_width <= DEBUG_DISPLAY_WIDTH_DEFAULT)
			{
			if (act_column==output_width)
				putsf("\r");
			}
		else
			{
			if (act_column == output_width)
				putsf("\r");
			else if ((act_column % DEBUG_DISPLAY_WIDTH_DEFAULT)==0)
				printf("\r\n     ");
			}
		if (act_column == output_width)
			{
			act_column=0;
			line_count++;
			}
		}
	else
		{
		if (act_column == DEBUG_DISPLAY_WIDTH_DEFAULT)
			{
			act_column = 0;
			putsf("\r");
			}
		}
	}
if (act_column != DEBUG_DISPLAY_WIDTH_DEFAULT)
	putsf("\r");
}


// ************************************************************************************************
/// \brief		Outputs an part of SRAM to the debug interface as hex values
///
/// \note		Needs DEBUG_DEFINE_PUTCHAR to be defined!
/// @param[in]  p_data 		- SRAM-pointer to data
/// @param[in]  size 		- size of data
/// @param[in]  output_width - >0 new line after this count of binary data
///                           0 new line after 24 Byte of binary data - 72 output characters +CR+LF
// ************************************************************************************************
void debug_display_mem_hex(unsigned char* p_data, unsigned int size, unsigned char output_width)
{
unsigned char act_column=0;
unsigned char line_count=0;
unsigned int  byte_pos=1;

while (size)
	{
	#asm("wdr");	// Reset Watchdog
	if (act_column == 0)
		printf("%3u) ", byte_pos);
	printf("%02x ", *p_data);
	p_data++;
	size--;
	act_column++;
	byte_pos++;
	if (output_width != 0)
		{
		if (output_width <= DEBUG_DISPLAY_WIDTH_DEFAULT)
			{
			if (act_column==output_width)
				putsf("\r");
			}
		else
			{
			if (act_column == output_width)
				putsf("\r");
			else if ((act_column % DEBUG_DISPLAY_WIDTH_DEFAULT)==0)
				printf("\r\n     ");
			}
		if (act_column == output_width)
			{
			act_column=0;
			line_count++;
			}
		}
	else
		{
		if (act_column == DEBUG_DISPLAY_WIDTH_DEFAULT)
			{
			act_column = 0;
			putsf("\r");
			}
		}
	}
if (act_column != DEBUG_DISPLAY_WIDTH_DEFAULT)
	putsf("\r");
}


// ************************************************************************************************
/// \brief		Outputs an part of EEPROM to the debug interface as hex values
///
/// \note		Needs DEBUG_DEFINE_PUTCHAR to be defined!
/// @param[in]  p_data 		- EEPROM-pointer to data
/// @param[in]  size 		- size of data
/// @param[in]  output_width - >0 length to write CR and LF
///                           0  new line after 24Byte date - 72signs +CR+LF
// ************************************************************************************************
void debug_display_mem_hex_eeprom(eeprom unsigned char *p_data, unsigned int size, unsigned char output_width)
{
unsigned char act_column=0;
unsigned char line_count=0;
unsigned int  byte_pos=1;

while (size)
	{
	#asm("wdr");	// Reset Watchdog
	if (output_width!=0 && act_column==0)
		printf("%3u) ", byte_pos);
	printf("%02x ", *p_data);
	p_data++;
	size--;
	act_column++;
	byte_pos++;
	if (output_width != 0)
		{
		if (output_width <= DEBUG_DISPLAY_WIDTH_DEFAULT)
			{
			if (act_column == output_width)
				putsf("\r");
			}
		else
			{
			if (act_column==output_width)
				putsf("\r");
			else if ((act_column % DEBUG_DISPLAY_WIDTH_DEFAULT)==0)
				printf("\r\n     ");
			}
		if (act_column == output_width)
			{
			act_column=0;
			line_count++;
			}
		}
	else
		{
		if (act_column == DEBUG_DISPLAY_WIDTH_DEFAULT)
			{
			act_column = 0;
			putsf("\r");
			}
		}
	}
if (act_column != DEBUG_DISPLAY_WIDTH_DEFAULT)
	putsf("\r");
}


#define DEBUG_DISPLAY_BUFFER_WIDTH		20
// ************************************************************************************************
/// \brief		Outputs a number of bytes as hexadecimal numbers
///
/// \note		Needs DEBUG_DEFINE_PUTCHAR to be defined!
/// @param[in]	p_data		  - SRAM-pointer to data
/// @param[in]	size		  - number of bytes. Will be reduced to DEBUG_DISPLAY_BUFFER_WIDTH
/// @param[in]	highlight_pos - byte position, that will be marked with an '>' sign
// ************************************************************************************************
void debug_display_buf_xbyte_hex(unsigned char *p_data, unsigned int size, signed char highlight_pos)
{
unsigned char byte_pos=0;

if (size > DEBUG_DISPLAY_BUFFER_WIDTH)
	size = DEBUG_DISPLAY_BUFFER_WIDTH;

while (byte_pos < size)
	{
	if (byte_pos == highlight_pos)
		putchar('>');
	else
		putchar(' ');
	printf("%02x", *p_data);
	byte_pos++;
	p_data++;
	}
while (byte_pos < DEBUG_DISPLAY_BUFFER_WIDTH)
	{
	printf("   ");
	byte_pos++;
	}
}


// ************************************************************************************************
/// \brief		Outputs a number of bytes as ASCII signs
///
/// \note		Needs DEBUG_DEFINE_PUTCHAR to be defined!
/// @param[in]	p_data	- SRAM-pointer to data
/// @param[in]	size	- number of bytes. Will be reduced to DEBUG_DISPLAY_BUFFER_WIDTH
// ************************************************************************************************
void debug_display_buf_xbyte_ascii(unsigned char *p_data, unsigned int size)
{
if (size > DEBUG_DISPLAY_BUFFER_WIDTH)
	size = DEBUG_DISPLAY_BUFFER_WIDTH;

while (size)
	{
	if (isprint(*p_data))
		putchar(*p_data);
	else
		putchar('.');
	size--;
	p_data++;
	}
}


// ************************************************************************************************
/// \brief		Outputs an buffer. Hex and ASCII side by side.
///
/// \note		Needs DEBUG_DEFINE_PUTCHAR to be defined!
/// @param[in]	p_data		  - SRAM-pointer to buffer
/// @param[in]	size		  - buffer size
/// @param[in]	highlight_pos - byte position, that will be marked with an '>' sign
// ************************************************************************************************
void debug_display_buffer(unsigned char *p_data, unsigned int size, unsigned int highlight_pos)
{
unsigned char byte_pos=0;

while (size)
	{
	#asm("wdr");	// Reset Watchdog
	printf("%3u)", byte_pos);
	if (byte_pos<=highlight_pos && byte_pos+DEBUG_DISPLAY_BUFFER_WIDTH>highlight_pos)
		debug_display_buf_xbyte_hex(p_data, size, highlight_pos-byte_pos);
	else
		debug_display_buf_xbyte_hex(p_data, size, -1);
	#asm("wdr");	// Reset Watchdog
	putchar(' ');
	debug_display_buf_xbyte_ascii(p_data, size);
	if (size > DEBUG_DISPLAY_BUFFER_WIDTH)
		{
		size -= DEBUG_DISPLAY_BUFFER_WIDTH;
		p_data += DEBUG_DISPLAY_BUFFER_WIDTH;
		byte_pos += DEBUG_DISPLAY_BUFFER_WIDTH;
		}
	else
		size = 0;
	printf("\r\n");
	}
}


// ************************************************************************************************
/// \brief		Prints a IP located in SRAM via debug interface
///
/// \note		Needs DEBUG_DEFINE_PUTCHAR to be defined!
/// @param[in]  string_data - !=0  - flash-pointer to additional string data
///							  0    - print IP without CRLF
/// @param[in]  ip_data 	- pointer to IP inside of SRAM memory 
// ************************************************************************************************
void debug_print_ip(flash unsigned char *string_data, unsigned char *ip_data)
{
if (string_data!=0x0)
	printf("%p: %u.%u.%u.%u\r\n", string_data, ip_data[0], ip_data[1], ip_data[2], ip_data[3]); 
else
	printf("%u.%u.%u.%u ", ip_data[0], ip_data[1], ip_data[2], ip_data[3]); 
}


// ************************************************************************************************
/// \brief		Prints a IP located in EEPROM via debug interface
///
/// \note		Needs DEBUG_DEFINE_PUTCHAR to be defined!
/// @param[in]  string_data - !=0  - flash-pointer to additional string data
///							  0    - print IP without CRLF
/// @param[in]  ip_data 	- pointer to IP inside of EEPROM memory 
// ************************************************************************************************
void debug_print_ip_ee(flash unsigned char *string_data, eeprom unsigned char *ip_data)
{
if (string_data!=0x0)
	printf("%p: %u.%u.%u.%u\r\n", string_data, ip_data[0], ip_data[1], ip_data[2], ip_data[3]); 
else
	printf("%u.%u.%u.%u ", ip_data[0], ip_data[1], ip_data[2], ip_data[3]); 
}


// ************************************************************************************************
/// \brief		Prints a Ethernet MAC address located in SRAM via debug interface
///
/// \note		Needs DEBUG_DEFINE_PUTCHAR to be defined!
/// @param[in]  string_data - !=0  - flash-pointer to additional string data
///							  0    - print MAC without CRLF
/// @param[in]  ip_data 	- pointer to MAC inside of SRAM memory
// ************************************************************************************************
void debug_print_mac(flash unsigned char *string_data, unsigned char *mac_data)
{
if (string_data!=0x0)
	printf("%p: ", string_data); 
printf("%02x:%02x:%02x:%02x:%02x:%02x ", mac_data[0], mac_data[1], mac_data[2], mac_data[3], mac_data[4], mac_data[5]); 
if (string_data!=0x0)
	putsf("\r"); 
}


// ************************************************************************************************
/// \brief		Extracts an IP address and port number from <command> string
///
/// @param[in]  command  - pointer to command
/// @param[out] new_ip   - pointer to new ip
/// @param[out] new_port - pointer to new port number. If new_port==0, then the port is not parsed.
// ************************************************************************************************
unsigned char debug_string2ip(unsigned char *command, unsigned char *new_ip, unsigned int *new_port)
{
unsigned char	Lva=0, Lvb, Lvc;
unsigned char	new_data[10];

// delete the first part of command
while ((command[Lva]!=' ')&&(command[Lva]!=0x0))
	Lva++;
// delete the space-signs between command and parameter
while ((command[Lva]==' ')&&(command[Lva]!=0x0))
	Lva++;
if (command[Lva]!=0x0)
	{
	Lvb=0; Lvc=0;
	for (Lva=Lva;Lva<strlen(debug_cmd_buffer);Lva++)
		{
		if (Lvc>3) return 0;	  		// to long IP-address
		if (command[Lva]==' ')		// found a new command
			break;
		if (command[Lva]=='.')
	  		{
			new_data[Lvb]=0x0;		// set end-sign
			new_ip[Lvc]=atoi(new_data);
			Lvb=0;
			Lvc++;
			}
		else
			{
			new_data[Lvb]=command[Lva];
			Lvb++;
			}
		}
	if (Lvc<3)return 0;					// wrong count of IP-address-parts
	new_data[Lvb]=0x0;					// set end-sign
	new_ip[Lvc]=atoi(new_data);
	if (new_port!=0x0)
		{
		// delete the last part of ip-parameter
		while ((command[Lva]!=' ')&&(command[Lva]!=0x0))
			Lva++;
		// delete the space-signs between ip and port-parameter
		while ((command[Lva]==' ')&&(command[Lva]!=0x0))
			Lva++;
		*new_port=0;
		if (command[Lva]!=0x0)
			*new_port=atoi(&command[Lva]);
		}
	return 1;
	}
return 0;
}


// ************************************************************************************************
/// \brief		Convert a ethernet MAC address from <command> string 
///
/// @param[in]  command  - pointer to string
/// @param[out] new_mac  - pointer to new mac
/// @retval     0 - error
/// @retval     1 - ok
// ************************************************************************************************
unsigned char debug_string2mac(unsigned char *command, unsigned char *new_mac)
{
unsigned char	Lva=0, Lvb, Lvc;
unsigned char	new_data[10];

// delete the first part of command
while ((command[Lva]!=' ')&&(command[Lva]!=0x0))
	Lva++;
// delete the space-signs between command and parameter
while ((command[Lva]==' ')&&(command[Lva]!=0x0))
	Lva++;
if (command[Lva]!=0x0)
	{
	Lvb=0; Lvc=0;
	for (Lva=Lva;Lva<strlen(debug_cmd_buffer);Lva++)
		{
		if (Lvc>5) return 0;	  		// too long IP-address
		if (command[Lva]==' ')		// found a new command
			break;
		if ((command[Lva]==':')||(command[Lva]=='-'))
	  		{
			if (util_atoi_hex(new_data[1])==0xff)
				new_mac[Lvc] = util_atoi_hex(new_data[0]);
			else
				{
				new_mac[Lvc] = util_atoi_hex(new_data[0]);
				new_mac[Lvc] <<= 4;
				new_mac[Lvc] |= util_atoi_hex(new_data[1]);
				}
			Lvb=0;
			Lvc++;
			}
		else
			{
			new_data[Lvb]=command[Lva];
			Lvb++;
			}
		}
	if (Lvc<5)return 0;					// wrong count of MAC-address-parts
	if (util_atoi_hex(new_data[1])==0xff)
		new_mac[Lvc] = util_atoi_hex(new_data[0]);
	else
		{
		new_mac[Lvc] = util_atoi_hex(new_data[0]);
		new_mac[Lvc] <<= 4;
		new_mac[Lvc] |= util_atoi_hex(new_data[1]);
		}
	return 1;
	}
return 0;
}


// ************************************************************************************************
/// \brief		Convert string with ASCII-hex characters (like "FE01") to binary array
///
/// @param[in]  src    - 0-terminated string of ASCII-signs '0'..'9','a'..'f','A'..'F'
/// @param[out] dest   - pointer for storing converted binary 0x00..0xFF
/// @param[in]  length - maximum number of bins to convert (size of 'dest'-array in byte)
/// @retval  	0     - ok
/// @retval  	0xFC  - ASCII string ends with half nibble
/// @retval  	0xFE  - string to long (>length)
/// @retval  	0xFF  - illegal character
/// @retval  	length - count of converted bins in dest
// ************************************************************************************************
unsigned char debug_atoi_hex_str(unsigned char* src, unsigned char* dest, unsigned char* length)
{
unsigned char 	result;
unsigned char 	index=0;

while (*src != 0x00)
	{
	result = util_atoi_hex(*src);
	if (result == 0xFF)
		return 0xFF;
	*dest = result<<4;
	src++;
	if (*src == 0x00)
		return 0xFC;
	result = util_atoi_hex(*src);
	if (result == 0xFF)
		return 0xFF;
	*dest |= result;
	src++;
	dest++;
    index++;
	if (index > *length)
		return 0xFE;
	}
*length	= index;
return 0x00;
}


// ************************************************************************************************
/// \brief		Parses the command string and delivers a pointer to next parameter
///
/// \note		commands must be divided with ' ' and the command pointer must point to first sign
///				of the string
/// @param[in]  command  - pointer to 0-terminated string
/// @return 	pointer to next parameter
// ************************************************************************************************
unsigned char* debug_search_parameter(unsigned char* command)
{
// delete the first part of command
while ((*command!=' ') && (*command!=0x00))
	command++;
// delete the space-signs between command and parameter
while ((*command==' ') && (*command!=0x00))
	command++;
if (*command != 0x00)
	return command;
return 0x00;
}


// ************************************************************************************************
/// \brief		Extracts integer parameter from command string
///
///				Uses debug_search_parameter() to find first parameter and converts it to binary
/// @param[in]  command  - pointer to string, like "test-send 154"
/// @retval   	-1   - no parameter found
/// @retval   	>=0  - converted int value 0..32767
// ************************************************************************************************
signed int debug_get_int_parameter(unsigned char *command)
{
command = debug_search_parameter(command);
if (command != 0x00)
	return atoi(command);
return -1;
}


// ************************************************************************************************
/// \brief		Extracts long integer paramter from command string
///
///				Uses debug_search_parameter() to find first parameter and converts it to binary
/// @param[in]  command  - pointer to string, like "test-send 154"
/// @retval   	-1   - no parameter found
/// @retval   	>=0  - converted long integer value 0..4294967295
// ************************************************************************************************
signed long debug_get_long_parameter(unsigned char *command)
{
command = debug_search_parameter(command);
if (command != 0x00)
	return atol(command);
return -1;
}


#ifdef WATCHDOG_ENABLE
flash unsigned int watchdog_time[8]={16, 32, 65, 130, 260, 520, 1000, 2100};	///< used in debug_info()
#endif
// ************************************************************************************************
/// \brief		Displays all infos around AVR
///
/// \note		Needs DEBUG_DEFINE_PUTCHAR to be defined!
/// @param[in]	info_string - flash pointer to additional informations to display 
// ************************************************************************************************
void debug_general_info(flash unsigned char *info_string)
{
if ((info_string)&&(info_string[0]!=0))
	printf("%p\r\n", info_string);
putsf("Project: "DEBUG_PROJECT_NAME" "DEBUG_PROJECT_VERSION" ("__DATE__"/"__TIME__")\r");
putsf("eTWlib-Version: "ETWLIB_VERSION_STRING"\r");
printf("CodeVisionAVR-Version:%u\r\n", __CODEVISIONAVR__);
putsf(DEBUG_MCU_TYP_STRING":"DEBUG_MCU_CLOCK_STRING"\r");
printf("AVR-RESET: ");
if (board_reset_status & 0x10)
	printf("JTAG, ");
if (board_reset_status & 0x08)
	printf("Watchdog, ");
if (board_reset_status & 0x04)
	printf("Brown-out, ");
if (board_reset_status & 0x02)
	printf("External, ");
if (board_reset_status & 0x01)
	printf("Power-On, ");
if (board_reset_status==0x00)
	printf("no Reset");
putsf("\r");
#ifdef WATCHDOG_ENABLE
printf("AVR-Watchdog: %ums\r\n", watchdog_time[WDTCR & 0x07]);
#endif
}


// ************************************************************************************************
/// \brief		Displays all infos around AVR
///
/// \note		Needs DEBUG_DEFINE_PUTCHAR to be defined!
/// @param[in]	info_string - flash pointer to additional informations to display 
// ************************************************************************************************
void debug_info(flash unsigned char *info_string)
{
debug_general_info(info_string);

debug_set_command("info");
debug_process_handler(debug_cmd_buffer);
debug_set_command("");
}


// ************************************************************************************************
/// \brief		Internal debug command handler
///
// ************************************************************************************************
void debug_display_handler_info(void)
{
unsigned char i;

printf("%1u debug handlers registered (%1u max)\r\n", debug_next_free_handler, DEBUG_MAX_HANDLER);
for (i=0; i<debug_next_free_handler; i++)
    {
    printf("Handler %1u:\r\n", i);
    printf("  function address: 0x%04X\r\n", debug_struct[i].fp_handler);
    printf("  id-string: %p\r\n", debug_struct[i].id_string);
    }
}


// ************************************************************************************************
/// \brief		Internal debug command handler
///
// ************************************************************************************************
void debug_do_cmd(unsigned char *p_command)
{
if (strncmpf(p_command, "reset", 5)==0)
	{
	// Watchdog Timer initialization
	#asm("cli");	// Global disable interrupts
	#if defined _CHIP_ATMEGA2561V_
	WDTCSR = 0x18;
	WDTCSR = 0x08;
	#else 
	WDTCR = 0x18;	// Watchdog Change Enable (WDTCR.WDCE=1)
	WDTCR = 0x08;	// Watchdog enable (WDTCR.WDE=1) and 16k Zyklus-16ms
	#endif
	#asm("sei");	// Global enable interrupts
	for(;;);
	}
else if (strncmpf(p_command, "info", 4)==0)    // show the user general info screen
    debug_general_info(0x00);
else if (strncmpf(p_command, "debug-info", 10)==0)    // show the user general info screen
    debug_display_handler_info();
}


// ************************************************************************************************
/// \brief		Main function to handle debug commands
///
/// \note       Called from main() the often the better
// ************************************************************************************************
void debug_main(void)
{
unsigned char*  p_command;

p_command = debug_get_command();
if (p_command)
	{
	debug_do_cmd(p_command);     // general command handler
    debug_process_handler(p_command);
	}
}


// ************************************************************************************************
/// \brief		Call registered debug handler functions
///
/// @param[in]	p_command - pointer to 0-terminated string with new debug command
/// \note       Called from debug_main(), or from extern (to be compatible with old framework)
// ************************************************************************************************
void debug_process_handler(unsigned char *p_command)
{
unsigned char        i;
unsigned char        id_string_len;
T_DEBUG_HANDLER_MODE mode = DEBUG_HANDLER_MODE_CMD;

if (strncmpf(p_command, "debug", 5)==0)     // user wants to enable/disable debug output
    mode = DEBUG_HANDLER_MODE_SWITCH;
if (strncmpf(p_command, "info", 4)==0)      // show the user general info screen
    mode = DEBUG_HANDLER_MODE_INFO;
if (strncmpf(p_command, "help", 4)==0)      // show possible commands to user
    mode = DEBUG_HANDLER_MODE_HELP;

for (i=0; i<debug_next_free_handler; i++)
    {
    if (mode == DEBUG_HANDLER_MODE_CMD)
        {
        id_string_len = strlenf(debug_struct[i].id_string);
        if (strncmpf(p_command, debug_struct[i].id_string, id_string_len)==0)
            debug_struct[i].fp_handler(&p_command[id_string_len],   // cut 'id_string' from cmd
                                       DEBUG_HANDLER_MODE_CMD);  
        }
    else if (mode == DEBUG_HANDLER_MODE_SWITCH)
        debug_struct[i].fp_handler(debug_search_parameter(p_command), mode);
    else
        debug_struct[i].fp_handler(p_command, mode);
    }
}


// ************************************************************************************************
/// \brief		Registers a new debug command handler (=call back function) 
///
///             After reset all software modules should registers their command handler functions.
///             If an debug command is received, the registered command handlers are called 
///             in debug_main()
/// @param[in]  p_struct - see T_DEBUG_HANDLER_STRUCT in debug.h
// ************************************************************************************************
void debug_register_handler(T_DEBUG_HANDLER_STRUCT* p_struct)
{
unsigned char i;

if (p_struct->fp_handler == 0)
    return;         // invalid function pointer

for (i=0; i<debug_next_free_handler; i++)
	{
	if (debug_struct[debug_next_free_handler].fp_handler == p_struct->fp_handler)
    	return;		// handler function already registered
	}

if (debug_next_free_handler < DEBUG_MAX_HANDLER)
    {
    memcpy(&debug_struct[debug_next_free_handler], p_struct, sizeof(T_DEBUG_HANDLER_STRUCT));
    debug_next_free_handler++;
    }
else
    putsf("DEBUG_MAX_HANDLER too small!\r");
}

#endif  // #ifdef DEBUG