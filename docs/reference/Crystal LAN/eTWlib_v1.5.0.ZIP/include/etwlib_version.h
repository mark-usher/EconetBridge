// ************************************************************************************************
///
/// \file 			etwlib_version_template.h
/// \brief			eTWlib version information
///
///					Defines version macros. Use SubWCRev.exe to create etwlib_version.h. 
///					See etwlib_version_create.bat
///
/// \date	 		$LastChangedDate: 2007-08-16 16:08:13 +0200 (Do, 16 Aug 2007) $
/// \version 		$Rev: 678 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

// indicates major changes in API
#ifndef ETWLIB_VERSION_MAJOR
#define ETWLIB_VERSION_MAJOR	1
#endif

// indicates minor changes in API
#ifndef ETWLIB_VERSION_MINOR
#define ETWLIB_VERSION_MINOR	5
#endif

// indicates only bugfixes. No change in API
#ifndef ETWLIB_VERSION_PATCH
#define ETWLIB_VERSION_PATCH	0
#endif

// Highest Subversion Revision number in working copy. See etwlib_version_create.bat
#ifndef ETWLIB_VERSION_REVISION
#define ETWLIB_VERSION_REVISION	677
#endif

// See etwlib_version_create.bat
#ifndef ETWLIB_VERSION_STRING
#define ETWLIB_VERSION_STRING	"1.5.0.677"
#endif
