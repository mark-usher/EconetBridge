// ************************************************************************************************
///
/// \file 			stdint.h
/// \brief			Types with fixed length
///
///					The <stdint.h> header shall declare sets of integer types having specified 
///					widths, and shall define corresponding sets of macros. It shall also define
///					macros that specify limits of integer types corresponding to types defined in 
///					other standard headers.
///					See http://www.opengroup.org/onlinepubs/000095399/basedefs/stdint.h.html
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _STDINT_INCLUDED_
#define _STDINT_INCLUDED_

// Integer types having certain exact widths
typedef signed char         int8_t
typedef signed int          int16_t
typedef signed long         int32_t
typedef unsigned char       uint8_t
typedef unsigned int        uint16_t
typedef unsigned long       uint32_t

// Integer types having at least certain specified widths
typedef signed char         int_least8_t;
typedef signed int          int_least16_t;
typedef signed long         int_least32_t;
typedef unsigned char       uint_least8_t;
typedef unsigned int        uint_least16_t;
typedef unsigned long       uint_least32_t;

// Fastest integer types having at least certain specified widths
typedef signed char         int_fast8_t;
typedef signed int          int_fast16_t;
typedef signed long         int_fast32_t;
typedef unsigned char       uint_fast8_t;
typedef unsigned int        uint_fast16_t;
typedef unsigned long       uint_fast32_t;

// Integer types wide enough to hold pointers to objects
// These types are optional for non-XSI-conformant systems
#if defined(_MODEL_TINY_) || defined(_MODEL_SMALL_) 
typedef signed int          intptr_t
typedef unsigned int        uintptr_t
#else
typedef signed long         intptr_t
typedef unsigned long       uintptr_t
#endif

// Integer types having greatest width
typedef signed long         intmax_t
typedef unsigned long       uintmax_t

// Limits of exact-width integer types
// Minimum values of exact-width signed integer types:   Exactly -2^(N-1)
// Maximum values of exact-width signed integer types:   Exactly 2^(N-1) -1
// Maximum values of exact-width unsigned integer types: Exactly 2^N -1
#define INT8_MIN            -128
#define INT8_MAX            127
#define UINT8_MAX           255
#define INT16_MIN           -32768
#define INT16_MAX           32767
#define UINT16_MAX          65535
#define INT32_MIN           -2147483648L
#define INT32_MAX           2147483647L
#define UINT32_MAX          4294967295L

// Limits of minimum-width integer types
#define INT_LEAST8_MIN      -128
#define INT_LEAST8_MAX      127
#define UINT_LEAST8_MAX     255
#define INT_LEAST16_MIN     -32768
#define INT_LEAST16_MAX     32767
#define UINT_LEAST16_MAX    65535
#define INT_LEAST32_MIN     -2147483648L
#define INT_LEAST32_MAX     2147483647L
#define UINT_LEAST32_MAX    4294967295L

// Limits of fastest minimum-width integer types
#define INT_FAST8_MIN       -128
#define INT_FAST8_MAX       127
#define UINT_FAST8_MAX      255
#define INT_FAST16_MIN      -32768
#define INT_FAST16_MAX      32767
#define UINT_FAST16_MAX     65535
#define INT_FAST32_MIN      -2147483648L
#define INT_FAST32_MAX      2147483647L
#define UINT_FAST32_MAX     4294967295L

// Limits of integer types capable of holding object pointers
#if defined(_MODEL_TINY_) || defined(_MODEL_SMALL_) 
#define INTPTR_MIN          -32768
#define INTPTR_MAX          32767
#define UINTPTR_MAX         65535
#else
#define INTPTR_MIN          -2147483648L
#define INTPTR_MAX          2147483647L
#define UINTPTR_MAX         4294967295L
#endif

// Limits of greatest-width integer types
#define INTMAX_MIN          -2147483648L
#define INTMAX_MAX          2147483647L
#define UINTMAX_MAX         4294967295L

// Limits of Other Integer Types
// depends on definitions in signal.h, stddef.h, wchar.h

// Macros for Integer Constant Expressions
// ToDo: Macros for minimum-width integer constant expressions
// ToDo: Macros for greatest-width integer constant expressions

#endif	// #ifndef _STDINT_INCLUDED_