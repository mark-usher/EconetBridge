// ************************************************************************************************
///
/// \file 			md5_test.c
/// \brief			HMAC-MD5 Test functions
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef	MD5_TEST_ENABLE

#include <stdio.h>
#include <string.h>
#include "board.h"
#include "debug.h"
#include "md5.h"

#pragma regalloc-
#pragma regalloc+

// Length of test block, number of test blocks.
#define TEST_BLOCK_LEN 1500
unsigned char md5_block[TEST_BLOCK_LEN];

unsigned char *md5_testarray[7] =
{
"",
"a",
"abc",
"message digest",
"abcdefghijklmnopqrstuvwxyz",
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
"12345678901234567890123456789012345678901234567890123456789012345678901234567890"
};

unsigned char *md5_resultarray[7] =
{
"d4 1d 8c d9 8f 00 b2 04 e9 80 09 98 ec f8 42 7e",
"0c c1 75 b9 c0 f1 b6 a8 31 c3 99 e2 69 77 26 61",
"90 01 50 98 3c d2 4f b0 d6 96 3f 7d 28 e1 7f 72",
"f9 6b 69 7d 7c b7 93 8d 52 5a 2f 31 aa f1 61 d0",
"c3 fc d3 d7 61 92 e4 00 7d fb 49 6c ca 67 e1 3b",
"d1 74 ab 98 d2 77 d9 f5 a5 61 1c 2c 9f 41 9d 9f",
"57 ed f4 a2 2b e3 c9 55 ac 49 da 2e 21 07 b6 7a"
};


//*********************************************************************************
// Description	: Measures the time to digest block_count*block_len byte blocks
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void md5_test_time_trial(unsigned int block_len, unsigned int block_count)
{
MD5_CTX context;
unsigned char digest[MD5_HASH_SIZE];
unsigned int i;
unsigned int counter_10ms_end;

if(block_len>TEST_BLOCK_LEN)
	block_len=TEST_BLOCK_LEN;
// Initialize block
for (i = 0; i < block_len; i++)
	md5_block[i] = (unsigned char)(i & 0xff);
// Start timer 
#asm("cli");	 	// Global disable interrupts
counter_10ms_16bit=0;
#asm("sei");	 	// Global enable interrupts
// Digest blocks
LED2_ON;		// PortD.5 LED2
for(i = 0; i < block_count; i++)
	{
	#ifdef MD5_ENABLE
	md5_init(&context);
	md5_update(&context, md5_block, block_len);
	md5_final(&context, digest);
	#endif // #ifdef MD5_ENABLE
	}
LED2_OFF;		// PortD.5 LED2
// Stop timer
#asm("cli");	 	// Global disable interrupts
counter_10ms_end=counter_10ms_16bit;
#asm("sei");	 	// Global enable interrupts
counter_10ms_end*=10;
printf("%4u = %u.%u ms per block (%u ms)\r\n", block_len, counter_10ms_end/block_count, counter_10ms_end%block_count, counter_10ms_end);
//debug_display_mem_hex(digest, sizeof(digest), 0);
}


//*********************************************************************************
// Description	: Digests a reference suite of strings and prints the results
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void md5_test_suite(void)
{
MD5_CTX context;
unsigned char digest[16];
unsigned char Lva;

for(Lva=0;Lva<7;Lva++)
	{
	#ifdef MD5_ENABLE
	md5_init(&context);
	md5_update(&context, md5_testarray[Lva], strlen(md5_testarray[Lva]));
	md5_final(&context, digest);
	#endif // #ifdef MD5_ENABLE
	printf("MD5 (\"%s\") = \r\n", md5_testarray[Lva]);
	printf("ok :%s\r\n", md5_resultarray[Lva]);
	printf("cal:");
	debug_display_mem_hex(digest, sizeof(digest), 0);
	}
md5_test_time_trial(8, 200);
md5_test_time_trial(28, 200);
md5_test_time_trial(50, 200);
md5_test_time_trial(64, 100);
md5_test_time_trial(128, 100);
md5_test_time_trial(256, 10);
md5_test_time_trial(512, 10);
md5_test_time_trial(1024, 10);
md5_test_time_trial(1500, 10);
}

//********************************************************************************
// Description	: md5 test command handler
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void md5_test_cmd(unsigned char *command)
{
int	data;

if(strncmpf(command, "md5", 3)==0)
	{
	data=debug_get_int_parameter(command);
	if(data==-1)
		md5_test_suite();
	else
		{
		if((data>=0)&&(data<64))
			md5_test_time_trial(data, 200);
		else if((data>=64)&&(data<256))
			md5_test_time_trial(data, 100);
		else
			md5_test_time_trial(data, 10);
		}
	}
}

#endif	// #ifdef	MD5_TEST_ENABLE



