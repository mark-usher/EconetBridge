// ************************************************************************************************
///
/// \file 			des.h
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Copyright (C) 2001-2003
///					This document is part of embedded IPsec
///					Niklaus Schild and Christian Scheurer, HTI Biel/Bienne
///					This file contains code from the OpenSSL Project<BR>
///					portions Copyright (c) 1998-2003 OpenSSL (www.openssl.org)
///					Udo Jakobza - FTZ Leipzig; 04107 Leipzig; W�chterstr. 13
///					jakobza@e-technik.htwk-leipzig.de
///
/// \par License    
///					Redistribution and use in source and binary forms, with or without 
///					modification, are permitted provided that the following conditions are met:
///
///					1. Redistributions of source code must retain the above copyright notice,
///					   this list of conditions and the following disclaimer.
///					2. Redistributions in binary form must reproduce the above copyright notice,
///					    this list of conditions and the following disclaimer in the documentation
///					   and/or other materials provided with the distribution.
///					3. The name of the author may not be used to endorse or promote products
///					   derived from this software without specific prior written permission.
///
///					THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
///					WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
///					MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
///					EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
///					EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
///					OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
///					INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
///					CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
///					IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
///					OF SUCH DAMAGE.
///
// ************************************************************************************************

#ifndef _DES_INCLUDED_
#define _DES_INCLUDED_

// --------------------------------------------------------------------------------
// DES Macros
// -------------------------------------------------------------------------------- 
typedef struct des_ks
    {
	unsigned char key[16,8];
    }DES_KEY_SCHEDULE;

#define DES_KEY_SIZE		8
#define DES_SCHEDULE_SIZE	(sizeof(DES_KEY_SCHEDULE))

#define DES_DECRYPT			0
#define DES_ENCRYPT			1

#pragma used+
void des_encrypt_version1(unsigned long *data, DES_KEY_SCHEDULE *ks, unsigned char encrypt);
void des_encrypt_version2(unsigned long *data, DES_KEY_SCHEDULE *ks, unsigned char encrypt);
void des_3des_encrypt_decrypt(unsigned long *data, DES_KEY_SCHEDULE *ks1, DES_KEY_SCHEDULE *ks2, DES_KEY_SCHEDULE *ks3, unsigned char encrypt_mode);
void des_3des_cbc_encrypt(unsigned char *input, unsigned char *output,
			  unsigned int length,
			  DES_KEY_SCHEDULE *ks1, DES_KEY_SCHEDULE *ks2,
			  DES_KEY_SCHEDULE *ks3, unsigned char *ivec, unsigned char encrypt_mode);
void des_3des_cbc_encrypt_new_iv(unsigned char *input, unsigned char *output,
		      unsigned int length, DES_KEY_SCHEDULE *schedule, unsigned char *ivec,
		      unsigned char encrypt_mode);
void des_set_odd_parity(unsigned char *key);
unsigned char des_check_key_parity(unsigned char *key);
unsigned char des_is_weak_key(unsigned char *key);
unsigned char des_set_key(unsigned char *key, DES_KEY_SCHEDULE *schedule, unsigned char des_shadow_check_key);
unsigned char des_set_key_checked(unsigned char *key,DES_KEY_SCHEDULE *schedule);
void des_set_key_unchecked(unsigned char *key,DES_KEY_SCHEDULE *schedule);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library des.c
#endif

#endif	// #ifndef _DES_INCLUDED_

