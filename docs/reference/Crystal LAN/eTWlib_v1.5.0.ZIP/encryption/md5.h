// ************************************************************************************************
///
/// \file 			md5.h
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Copyright (C) 2001-2003
///					Udo Jakobza - FTZ Leipzig; 04107 Leipzig; W�chterstr. 13
///					jakobza@e-technik.htwk-leipzig.de
///					Copyright (C) 1991-92, RSA Data Security, Inc. Created 1991. All
///					rights reserved.
///
/// \par License    
///					Copyright (C) 1991-92, RSA Data Security, Inc. Created 1991. All
///					rights reserved.
///					License to copy and use this software is granted provided that it
///					is identified as the "RSA Data Security, Inc. MD5 Message-Digest
///					Algorithm" in all material mentioning or referencing this software
///					or this function.
///					License is also granted to make and use derivative works provided
///					that such works are identified as "derived from the RSA Data
///					Security, Inc. MD5 Message-Digest Algorithm" in all material
///					mentioning or referencing the derived work.
///					RSA Data Security, Inc. makes no representations concerning either
///					the merchantability of this software or the suitability of this
///					software for any particular purpose. It is provided "as is"
///					without express or implied warranty of any kind.
///					These notices must be retained in any copies of any part of this
///					documentation and/or software.
///
// ************************************************************************************************

#ifndef _MD5_INCLUDED_
#define _MD5_INCLUDED_

#define MD5_HASH_SIZE	16
#define MD5_BLOCK_SIZE	64

// --------------------------------------------------------------------------------
// MD5 context
// -------------------------------------------------------------------------------- 
typedef struct
{
unsigned long state[4];		// state (ABCD)
unsigned long count[2];		// number of bits, modulo 2^64 (lsb first)
unsigned char buffer[64];	// input buffer
}MD5_CTX;

#pragma used+
void md5_init(MD5_CTX *context);
void md5_update(MD5_CTX *context, unsigned char *input, unsigned int inputLen);
void md5_final(MD5_CTX *context, unsigned char *digest);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library md5.c
#endif

#endif	// #ifndef _MD5_INCLUDED_