// ************************************************************************************************
///
/// \file 			sha1_test.c
/// \brief			SHA1 Test functions
///
///					This is the header file for code which implements the Secure
///					Hashing Algorithm 1 as defined in FIPS PUB 180-1 published
///					April 17, 1995.
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration


/// \todo
/// Update this module to the new debug handler framework

#ifdef SHA1_TEST_ENABLE

#include <stdio.h>
#include <string.h>
#include "board.h"
#include "debug.h"
#include "sha1.h"

#pragma regalloc-
#pragma regalloc+

// Length of test block, number of test blocks.
#define TEST_BLOCK_LEN 1500

unsigned char sha1_block[TEST_BLOCK_LEN];

unsigned char *sha1_testarray[4] =
{
"abc",
"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq",
"a",
"0123456701234567012345670123456701234567012345670123456701234567"
};

unsigned long sha1_repeatcount[4] = {1, 1, 1000, 10};
unsigned char *sha1_resultarray[4] =
{
"a9 99 3e 36 47 06 81 6a ba 3e 25 71 78 50 c2 6c 9c d0 d8 9d",
"84 98 3e 44 1c 3b d2 6e ba ae 4a a1 f9 51 29 e5 e5 46 70 f1",
"34 aa 97 3c d4 c4 dA a4 f6 1e eb 2b db ad 27 31 65 34 01 6f",
"de a3 56 a2 cd dd 90 c7 a7 ec ed c5 eb b5 63 93 4f 46 04 52"
};


//*********************************************************************************
// Description	: Measures the time to digest block_count*b�ock_len byte blocks
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void sha1_test_time_trial(unsigned int block_len, unsigned int block_count)
{
SHA1_CTX context;
unsigned char digest[SHA1_HASH_SIZE];
unsigned int i;
unsigned int counter_10ms_end;

if(block_len>TEST_BLOCK_LEN)
	block_len=TEST_BLOCK_LEN;
// Initialize block
for (i = 0; i < block_len; i++)
	sha1_block[i] = (unsigned char)(i & 0xff);
// Start timer 
#asm("cli");	 	// Global disable interrupts
counter_10ms_16bit=0;
#asm("sei");	 	// Global enable interrupts
// Digest blocks
LED2_ON;		// PortD.5 LED2
for(i = 0; i < block_count; i++)
	{
	#ifdef SHA1_ENABLE
	sha1_init(&context);
	sha1_update(&context, sha1_block, block_len);
	sha1_final(&context, digest);
	#endif // #ifdef SHA1_ENABLE
	}
LED2_OFF;		// PortD.5 LED2
// Stop timer
#asm("cli");	 	// Global disable interrupts
counter_10ms_end=counter_10ms_16bit;
#asm("sei");	 	// Global enable interrupts
counter_10ms_end*=10;
printf("%4u = %u.%u ms per block (%u ms)\r\n", block_len, counter_10ms_end/block_count, counter_10ms_end%block_count, counter_10ms_end);
debug_display_mem_hex(digest, sizeof(digest), 0);
}


//*********************************************************************************
// Description	: This file will exercise the SHA-1 code performing the three
//                tests documented in FIPS PUB 180-1 plus one which calls
//                SHA1Input with an exact multiple of 512 bits, plus a few
//                error test checks.
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void  sha1_test_suite(void)
{
SHA1_CTX context;
unsigned char j, err;
unsigned long i;
unsigned int sign_count;
unsigned char digest[SHA1_HASH_SIZE];

for(j = 0; j < 4; j++)
	{
	printf( "SHA1 \"%s\" = \r\n", sha1_testarray[j]);
	#ifdef SHA1_ENABLE
	err = sha1_init(&context);
	#endif // #ifdef SHA1_ENABLE
	if(err)
		{
		printf("SHA1Reset Error %u.\r\n", err);
		break; // out of for j loop
		}
	sign_count=0;
	for(i = 0; i < sha1_repeatcount[j]; i++)
		{
		#ifdef SHA1_ENABLE
		sign_count++;
		err = sha1_update(&context, sha1_testarray[j], strlen(sha1_testarray[j]));
		#endif // #ifdef SHA1_ENABLE
		if(err)
			{
			printf("SHA1Input Error %u.\r\n", err);
			break; // out of for i loop
			}
		if(sign_count==1000)
			{
			sign_count=0;
			printf("+");
			}
		}
	#ifdef SHA1_ENABLE
	err = sha1_final(&context, digest);
	#endif // #ifdef SHA1_ENABLE
	printf("ok :%s\r\n", sha1_resultarray[j]);
	if(err)
		printf("SHA1Result Error %u, could not compute message digest.\n", err);
	else
		{
		printf("cal:");
		debug_display_mem_hex(digest, sizeof(digest), 0);
		}
	}
// Test some error returns
#ifdef SHA1_ENABLE
err = sha1_update(&context, &sha1_testarray[1], 1);
#endif // #ifdef SHA1_ENABLE
printf ("Error %u. Should be %u.\r\n", err, SHA_STATE_ERROR);
#ifdef SHA1_ENABLE
err = sha1_init(0);
#endif // #ifdef SHA1_ENABLE
printf ("Error %u. Should be %u.\r\n", err, SHA_NULL);
sha1_test_time_trial(8, 50);
sha1_test_time_trial(28, 50);
sha1_test_time_trial(50, 50);
sha1_test_time_trial(64, 25);
sha1_test_time_trial(128, 25);
sha1_test_time_trial(256, 5);
sha1_test_time_trial(512, 5);
sha1_test_time_trial(1024, 5);
sha1_test_time_trial(1500, 5);
}


//********************************************************************************
// Description	: SHA1 Test command handler
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void sha1_test_cmd(unsigned char *command)
{
int	data;

if(strncmpf(command, "sha1", 4)==0)
	{
	data=debug_get_int_parameter(command);
	if(data==-1)
		sha1_test_suite();
	else
		{
		if((data>=0)&&(data<64))
			sha1_test_time_trial(data, 50);
		else if((data>=64)&&(data<256))
			sha1_test_time_trial(data, 25);
		else
			sha1_test_time_trial(data, 5);
		}
	}
}

#endif	// #ifdef	SHA1_TEST_ENABLE

