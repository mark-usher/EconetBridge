// ************************************************************************************************
///
/// \file 			aes.c
/// \brief			Advanced Encryption Standard
///
/// \todo			Check for license conditions
///
/// \date	 		$LastChangedDate: 2007-03-09 15:13:05 +0100 (Fr, 09 Mrz 2007) $
/// \version 		$Rev: 616 $
///	\author  		Daniel Matthes<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"					// Project configuration	

#ifdef _DOXYGEN_PARSER_
#define AES_ENABLE
#define DEBUG
#define AES_DEBUG
#endif

#ifdef AES_ENABLE 

#include <string.h>
#include "aes.h"
#include "aeskeys.h"

#if defined DEBUG && defined AES_DEBUG
#include "debug.h"
#include <stdio.h>
#endif
 
#define BPOLY 0x1b 					///< Lower 8 bits of (x^8+x^4+x^3+x+1), ie. (x^4+x^3+x+1).

#if AES_KEY_COUNT == 1
	#define KEYBITS 		128 	///< Use AES128 (alternative: AES196 or AES256).
#elif AES_KEY_COUNT == 2
	#define KEYBITS 		192 	///< Use AES196 (alternative: AES128 or AES256).
#elif AES_KEY_COUNT == 3
	#define KEYBITS 		256 	///< Use AES256 (alternative: AES128 or AES196).
#else
	#error "Use 1, 2 or 3 keys!"
#endif

#if KEYBITS == 128
	#define ROUNDS 			10 		///< Number of rounds (10, 12 or 14).
	#define KEYLENGTH 		16 		///< Key length in number of bytes (16, 24 or 32).
#elif KEYBITS == 192
	#define ROUNDS 			12 		///< Number of rounds (10, 12 or 14).
	#define KEYLENGTH 		24		///< Key length in number of bytes (16, 24 or 32).
#elif KEYBITS == 256
	#define ROUNDS 			14 		///< Number of rounds (10, 12 or 14).
	#define KEYLENGTH 		32 		///< Key length in number of bytes (16, 24 or 32).
#else
	#error "Key must be 128, 192 or 256 bits!"
#endif

#define EXPANDED_KEY_SIZE 	(AES_BLOCK_SIZE * (ROUNDS+1)) 		///< 176, 208 or 240 bytes.

unsigned char block1[ 256 ]; 		///< Workspace 1.
unsigned char block2[ 256 ]; 		///< Workspace 2.
unsigned char *expo_lookup_table;	///< Final location of exponentiation lookup table.
unsigned char *log_lookup_table; 	///< Final location of logarithm lookup table.
unsigned char *s_box; 				///< Final location of substitution box.
unsigned char *s_box_inv; 			///< Final location of inverse substitution box.
unsigned char *expanded_key; 		///< Final location of expanded key.

//	local prototypes
void 	aes_calc_lookup_table(unsigned char *expo_lookup_table, unsigned char *log_lookup_table);
void 	aes_calc_sbox(unsigned char *s_box);
void 	aes_calc_sbox_inv(unsigned char *s_box, unsigned char *s_box_inv);
void 	aes_key_expansion(unsigned char *expanded_key);

// ************************************************************************************************
/// \brief  	function init aes
/// @param[in]	tempbuf - temporary buffer for aes intialization 
// ************************************************************************************************
void aes_init(unsigned char * tempbuf)
{
expo_lookup_table = block1;
log_lookup_table = block2;
aes_calc_lookup_table(expo_lookup_table, log_lookup_table);

s_box = tempbuf;
aes_calc_sbox(s_box);

expanded_key = block1;
aes_key_expansion(expanded_key);
	
s_box_inv = block2; 					// Must be block2.
aes_calc_sbox_inv(s_box, s_box_inv);
}


// ************************************************************************************************
/// \brief  	function calculates the lookup tables
/// @param[in]	expo_lookup_table - pointer to exponentiation lookup table 
///	@param[in]  log_lookup_table - pointer to logarithm lookup table
// ************************************************************************************************
void aes_calc_lookup_table(unsigned char *expo_lookup_table, unsigned char *log_lookup_table)
{
unsigned char i = 0;
unsigned char t = 1; 

do 
	{
	// Use 0x03 as root for exponentiation and logarithms.
	expo_lookup_table[i] = t;
   	log_lookup_table[t] = i;
   	i++;

	// Multiply t by 3 in GF(2^8).
   	t ^= (t << 1) ^ (t & 0x80 ? BPOLY : 0);
   	} 
while( t != 1 ); 								// Cyclic properties ensure that i < 255.
   
expo_lookup_table[255] = expo_lookup_table[0]; 	// 255 = '-0', 254 = -1, etc.
}


// ************************************************************************************************
/// \brief  	function calculates the substitution box
/// @param[in]	s_box - pointer to the substitution box 
// ************************************************************************************************
void aes_calc_sbox(unsigned char *s_box)
{
unsigned char i, rot;
unsigned char temp;
unsigned char result;
        
// Fill all entries of s_box[].
i = 0;
do 
	{
    // Inverse in GF(2^8).
    if(i > 0) 
    	temp = expo_lookup_table[ 255 - log_lookup_table[i] ];
	else 
		temp = 0;
	// Affine transformation in GF(2).
	result = temp ^ 0x63; 	// Start with adding a vector in GF(2).
	for( rot = 0; rot < 4; rot++ ) 
		{
    	// Rotate left.
		temp = (temp<<1) | (temp>>7);

		// Add rotated byte in GF(2).
		result ^= temp;
		}
			  
		// Put result in table.
        s_box[i] = result;
		} 
while( ++i != 0 );
}	


// ************************************************************************************************
/// \brief  	function calculates the  invert substitution box
/// @param[in]	s_box - pointer to the substitution box 
/// @param[in]	s_box_inv - pointer to the invert substitution box 
// ************************************************************************************************
void aes_calc_sbox_inv(unsigned char *s_box, unsigned char *s_box_inv)
{
unsigned char i = 0;
unsigned char j = 0;

// this loop creates s_box_inv via s_box
// the index of a s_box element, gets the new content of the s_box_in element,
// whose index is equal to the s_box elements content. 
do
	{
	i = s_box[j];
	s_box_inv[i] = j;
	} while(++j != 0);
}


// ************************************************************************************************
/// \brief  	function realize a cycle left
/// @param[in]	row - pointer to data rows
// ************************************************************************************************
void aes_cycle_left(unsigned char *row)
{
// Cycle 4 bytes in an array left once.
unsigned char temp; 
temp = row[0];
row[0] = row[1];
row[1] = row[2];
row[2] = row[3];
row[3] = temp;
}


// ************************************************************************************************
/// \brief  	function: a vector of bytes is multiplied by a fixed matrix
/// @param[in]	column - pointer to a data column 
// ************************************************************************************************
void aes_inv_mix_column(unsigned char *column)
{
unsigned char r0, r1, r2, r3;

r0 = column[1] ^ column[2] ^ column[3];
r1 = column[0] ^ column[2] ^ column[3];
r2 = column[0] ^ column[1] ^ column[3];
r3 = column[0] ^ column[1] ^ column[2];

column[0] = (column[0] << 1) ^ (column[0] & 0x80 ? BPOLY : 0);
column[1] = (column[1] << 1) ^ (column[1] & 0x80 ? BPOLY : 0);
column[2] = (column[2] << 1) ^ (column[2] & 0x80 ? BPOLY : 0);
column[3] = (column[3] << 1) ^ (column[3] & 0x80 ? BPOLY : 0);

r0 ^= column[0] ^ column[1];
r1 ^= column[1] ^ column[2];
r2 ^= column[2] ^ column[3];
r3 ^= column[0] ^ column[3];

column[0] = (column[0] << 1) ^ (column[0] & 0x80 ? BPOLY : 0);
column[1] = (column[1] << 1) ^ (column[1] & 0x80 ? BPOLY : 0);
column[2] = (column[2] << 1) ^ (column[2] & 0x80 ? BPOLY : 0);
column[3] = (column[3] << 1) ^ (column[3] & 0x80 ? BPOLY : 0);

r0 ^= column[0] ^ column[2];
r1 ^= column[1] ^ column[3];
r2 ^= column[0] ^ column[2];
r3 ^= column[1] ^ column[3];

column[0] = (column[0] << 1) ^ (column[0] & 0x80 ? BPOLY : 0);
column[1] = (column[1] << 1) ^ (column[1] & 0x80 ? BPOLY : 0);
column[2] = (column[2] << 1) ^ (column[2] & 0x80 ? BPOLY : 0);
column[3] = (column[3] << 1) ^ (column[3] & 0x80 ? BPOLY : 0);

column[0] ^= column[1] ^ column[2] ^ column[3];
r0 ^= column[0];
r1 ^= column[0];
r2 ^= column[0];
r3 ^= column[0];

column[0] = r0;
column[1] = r1;
column[2] = r2;
column[3] = r3;
}


// ************************************************************************************************
/// \brief  	function substitute bytes with the assistance of the substitution box
/// @param[in]	bytes - pointer to data bytes
/// @param[in]	count - number of bytes
// ************************************************************************************************
void aes_sub_bytes(unsigned char *bytes, unsigned char count)
{
	do 
	{
	*bytes = s_box[*bytes]; 	// Substitute every byte in state.
	bytes++;
	} while(--count);
}


// ************************************************************************************************
/// \brief  	function substitute and xor bytes
/// @param[in]	bytes - pointer to data bytes
/// @param[in]	key - pointer to the decryption key
/// @param[in]	count - number of bytes
// ************************************************************************************************
void aes_inv_sub_bytes_and_xor(unsigned char *bytes, unsigned char *key, unsigned char count)
{
do 
	{
	*bytes = block2[ *bytes ] ^ *key; 		// Use block2 directly. Increases speed.
	bytes++;
	key++;
	} 
while(--count);
}


// ************************************************************************************************
/// \brief  	functions execute the shift rows operation
/// @param[in]	state - pointer to datablock
// ************************************************************************************************
void aes_inv_shift_rows(unsigned char *state)
{
unsigned char temp;

// Note: State is arranged column by column.

/*state

  ---- ---- ---- ----
 |  0 |  4 |  8 | 12 |
  ---- ---- ---- ----
 |  1 |  5 |  9 | 13 |
  ---- ---- ---- ----
 |  2 |  6 | 10 | 14 |
  ---- ---- ---- ----  
 |  3 |  7 | 11 | 15 |
  ---- ---- ---- ----

*/

// Cycle second row right one time.
temp = state[ 13 ];
state[ 13 ] = state[ 9 ];
state[ 9 ] = state[ 5 ];
state[ 5 ] = state[ 1 ];
state[ 1 ] = temp;

// Cycle third row right two times.
temp = state[ 2 ];
state[ 2 ] = state[ 10 ];
state[ 10 ] = temp;
temp = state[ 6 ];
state[ 6 ] = state[ 14 ];
state[ 14 ] = temp;

// Cycle fourth row right three times, ie. left once.
temp = state[ 3 ];
state[ 3 ] = state[ 7 ];
state[ 7 ] = state[ 11 ];
state[ 11 ] = state[ 15 ];
state[ 15 ] = temp;
}


// ************************************************************************************************
/// \brief  	function inits matrix multiplcation
/// @param[in]	state - pointer to a datablock
// ************************************************************************************************
void aes_inv_mix_columns(unsigned char *state)
{
aes_inv_mix_column( state + 0*4 );
aes_inv_mix_column( state + 1*4 );
aes_inv_mix_column( state + 2*4 );
aes_inv_mix_column( state + 3*4 );
}


// ************************************************************************************************
/// \brief  	function connected two bytes xor 
/// @param[in]	bytes1 - pointer to the first byte
/// @param[in]	bytes2 - pointer to the second bytes
/// @param[in]	count - count of xor operations
// ************************************************************************************************
void aes_xor_bytes(unsigned char *bytes1, unsigned char *bytes2, unsigned char count)
{
do 
	{
	*bytes1 ^= *bytes2; 		// Add in GF(2), ie. XOR.
	bytes1++;
	bytes2++;
	} 
while( --count );
}


// ************************************************************************************************
/// \brief  	function expanded the key
/// @param[in]	expanded_key - pointer to expanded key 
// ************************************************************************************************
void aes_key_expansion(unsigned char *expanded_key)
{
unsigned char temp[4];
unsigned char i;
unsigned char round_const[4] = { 0x01, 0x00, 0x00, 0x00 }; 	// Round constant.
unsigned char flash *key = aes_key;

// Copy key to start of expanded key.
i = KEYLENGTH;
do 
	{
	*expanded_key = *key;
	expanded_key++;
	key++;
	} 
while( --i );

// Prepare last 4 bytes of key in temp.
expanded_key -= 4;
temp[0] = *(expanded_key++);
temp[1] = *(expanded_key++);
temp[2] = *(expanded_key++);
temp[3] = *(expanded_key++);

// Expand key.
i = KEYLENGTH;
while( i < AES_BLOCK_SIZE*(ROUNDS+1) ) 
	{
	// Are we at the start of a multiple of the key size?
	if( (i % KEYLENGTH) == 0 ) 
		{
		aes_cycle_left(temp); 						// Cycle left once.
		aes_sub_bytes(temp, 4); 					// Substitute each byte.
		aes_xor_bytes(temp, round_const, 4); 		// Add constant in GF(2).
		*round_const = (*round_const << 1) ^ (*round_const & 0x80 ? BPOLY : 0);
		}

	// Keysize larger than 24 bytes, ie. larger that 192 bits?
	#if KEYLENGTH > 24
	// Are we right past a block size?
	else if( (i % KEYLENGTH) == AES_BLOCK_SIZE ) 
		{
		aes_sub_bytes(temp, 4); // Substitute each byte.
		}
	#endif

	// Add bytes in GF(2) one KEYLENGTH away.
	aes_xor_bytes(temp, expanded_key - KEYLENGTH, 4);
    
    // Copy result to current 4 bytes.
	*(expanded_key++) = temp[0];
	*(expanded_key++) = temp[1];
	*(expanded_key++) = temp[2];
	*(expanded_key++) = temp[3];

	i += 4; 							// Next 4 bytes.
	}	
}


// ************************************************************************************************
/// \brief  	function handels decryption
/// @param[in]	block - pointer to rx buffer
/// @param[in]	expanded_key - pointer to expanded key
// ************************************************************************************************
void aes_inv_cipher(unsigned char *block, unsigned char *expanded_key)
{
unsigned char round = ROUNDS-1;

expanded_key += AES_BLOCK_SIZE * ROUNDS;
aes_xor_bytes(block, expanded_key, 16);
expanded_key -= AES_BLOCK_SIZE;

do 
	{
	aes_inv_shift_rows(block);
	aes_inv_sub_bytes_and_xor(block, expanded_key, 16);
	expanded_key -= AES_BLOCK_SIZE;
	aes_inv_mix_columns(block);
	} 
while(--round);

aes_inv_shift_rows(block);
aes_inv_sub_bytes_and_xor(block, expanded_key, 16);
}


// ************************************************************************************************
/// \brief  	function decrypt 16 byte block
/// @param[in]	buffer - pointer to an array, which contains encrypted data
/// @param[in]  chainBlock - pointer to an array, which contains the chaining chipher block
// ************************************************************************************************
void aes_decrypt(unsigned char *buffer)
{
unsigned char temp[ AES_BLOCK_SIZE ];
static unsigned char chainBlock[AES_BLOCK_SIZE] = 			// Buffer for Cipher Block Unchaining
		{                      							   	// including initial vector
		(unsigned char)(AES_INITIALVECTOR_3 >> 24),
		(unsigned char)(AES_INITIALVECTOR_3 >> 16),
		(unsigned char)(AES_INITIALVECTOR_3 >> 8),
		(unsigned char)(AES_INITIALVECTOR_3 >> 0),
		(unsigned char)(AES_INITIALVECTOR_2 >> 24),
		(unsigned char)(AES_INITIALVECTOR_2 >> 16),
		(unsigned char)(AES_INITIALVECTOR_2 >> 8),
		(unsigned char)(AES_INITIALVECTOR_2 >> 0),
		(unsigned char)(AES_INITIALVECTOR_1 >> 24),
		(unsigned char)(AES_INITIALVECTOR_1 >> 16),
		(unsigned char)(AES_INITIALVECTOR_1 >> 8),
		(unsigned char)(AES_INITIALVECTOR_1 >> 0),
		(unsigned char)(AES_INITIALVECTOR_0 >> 24),
		(unsigned char)(AES_INITIALVECTOR_0 >> 16),
		(unsigned char)(AES_INITIALVECTOR_0 >> 8),
		(unsigned char)(AES_INITIALVECTOR_0 >> 0)
		};
		
memcpy(temp, buffer, AES_BLOCK_SIZE);
aes_inv_cipher(buffer, expanded_key);
aes_xor_bytes(buffer, chainBlock, AES_BLOCK_SIZE);
memcpy(chainBlock, temp, AES_BLOCK_SIZE);
}

#if defined DEBUG && defined AES_DEBUG
// ************************************************************************************************
/// \brief  	calculates time of aes encryption
/// 
/// \note		only in \ref AES_DEBUG modus available<br/>
///				configured for ATmega128 with 16 MHz clock
// ************************************************************************************************
void aes_decrypt_time(void)
{   
	unsigned char randomdata[16] =
	{
	0x00,0x11,0x22,0x33,
	0x44,0x55,0x66,0x77,
	0x88,0x99,0xAA,0xBB,
	0xCC,0xDD,0xEE,0xFF
	};
		
	unsigned long int calc_time;
	unsigned char timsk_temp;
	unsigned char tccr1b_temp;
	unsigned int count;
	unsigned char temp_buf[256];
	
	timsk_temp = TIMSK;
	tccr1b_temp = TCCR1B;
	TIMSK = 0x00;				//timer-interupt disabled 
	TCCR1B = 0x03;				//Prescaler 64 --> 1 Tick = 4�s
	
	TCNT1 = 0;
	aes_init(temp_buf);
	calc_time = 4*(unsigned long)TCNT1;
	
	printf("\naes-init time: %u us\n\r",calc_time);
	putsf("decrypt times:\r");
		
	TCNT1 = 0;
	aes_decrypt(randomdata); 
	calc_time = 4*(unsigned long)TCNT1;
	
	printf("16 Byte-Block: %u us\n\r",calc_time);
	
	TCNT1 = 0;
	for(count=0;count<16;count++)
		aes_decrypt(randomdata); 
	calc_time = (4*(unsigned long)TCNT1)/1000;
	
	printf("256 Byte-Block: %u ms\n\n\r",calc_time);
	
	TIMSK = timsk_temp;
	TCCR1B = tccr1b_temp;
}
#endif		// #if defined DEBUG && defined AES_DEBUG
#endif	// #ifdef AES_ENABLE