// ************************************************************************************************
///
/// \file 			hmac_md5_test.c
/// \brief			HMAC-MD5 Test functions
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef	HMAC_MD5_TEST_ENABLE

#include <stdio.h>
#include <string.h>
#include <delay.h>
#include "board.h"
#include "debug.h"
#include "md5.h"
#include "hmac_md5.h"
#include "hmac_md5_test.h"

#pragma regalloc-
#pragma regalloc+

// Length of test block, number of test blocks.
#define TEST_BLOCK_LEN 1500
unsigned char hmac_md5_block[TEST_BLOCK_LEN];
       
/*
test_case = 1
key = 0x0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b
key_len = 16
data = "Hi There"
data_len = 8
digest = 0x9294727a3638bb1c13f48ef8158bfc9d

test_case = 2
key = "Jefe"
key_len = 4
data = "what do ya want for nothing?"
data_len = 28
digest = 0x750c783e6ab0b503eaa86e310a5db738

test_case = 3
key = 0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
key_len 16
data = 0xdd repeated 50 times
data_len = 50
digest = 0x56be34521d144c88dbb8c733f0e8b3f6

test_case = 4
key = 0x0102030405060708090a0b0c0d0e0f10111213141516171819
key_len 25
data = 0xcd repeated 50 times
data_len = 50
digest = 0x697eaf0aca3a3aea3a75164746ffaa79

test_case = 5
key = 0x0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c
key_len = 16
data = "Test With Truncation"
data_len = 20
digest = 0x56461ef2342edc00f9bab995690efd4c
digest-96 0x56461ef2342edc00f9bab995

test_case = 6
key = 0xaa repeated 80 times
key_len = 80
data = "Test Using Larger Than Block-Size Key - Hash Key First"
data_len = 54
digest = 0x6b1ab7fe4bd7bf8f0b62e6ce61b9d0cd

test_case = 7
key = 0xaa repeated 80 times
key_len = 80
data = "Test Using Larger Than Block-Size Key and Larger
Than One Block-Size Data"
data_len = 73
digest = 0x6f630fad67cda0ee1fb1f562db3aa53e
*/

unsigned char hmac_mda5_test_key1[16]={0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b, 0x0b};
unsigned char hmac_mda5_test_data1[9]={"Hi There"};
unsigned char hmac_mda5_test_key2[5]={"Jefe"};
unsigned char hmac_mda5_test_data2[29]={"what do ya want for nothing?"};
unsigned char hmac_mda5_test_key3[25]={0xa,0xa,0xa,0xa,0xa,0xa,0xa,0xa,0xa,0xa,
                        0xa,0xa,0xa,0xa,0xa,0xa,0xa,0xa,0xa,0xa,
                        0xa,0xa,0xa,0xa,0xa};
unsigned char hmac_mda5_test_data3[50]={0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,
                         0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,
                         0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,
                         0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,
                         0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd};
unsigned char hmac_mda5_test_key4[25]={0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,
                        0x0b,0x0c,0x0d,0x0e,0x0f,0x10,0x11,0x12,0x13,0x14,
                        0x15,0x16,0x17,0x18,0x19};
unsigned char hmac_mda5_test_data4[50]={0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,
                         0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,
                         0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,
                         0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,
                         0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd};
unsigned char hmac_mda5_test_key5[16]={0xc,0xc,0xc,0xc,0xc,0xc,0xc,0xc,0xc,0xc,
                        0xc,0xc,0xc,0xc,0xc,0xc};
unsigned char hmac_mda5_test_data5[21]={"Test With Truncation"};
unsigned char hmac_mda5_test_key6[80]={0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa};
unsigned char hmac_mda5_test_data6[55]={"Test Using Larger Than Block-Size Key - Hash Key First"};
unsigned char hmac_mda5_test_data7[74]={"Test Using Larger Than Block-Size Key and Larger Than One Block-Size Data"};

unsigned char hmac_mda5_test_key8[16]={0x12,0x34,0x56,0x78,0x9a,0xbc,0xde,0xf0,
                                   0x24,0x68,0xac,0xe0,0x13,0x57,0x9b,0xdf};
unsigned char hmac_mda5_test_data8[108]={
0x45, 0x00, 0x00, 0x6c, 0x00, 0x33, 0x00, 0x00,
0x00, 0x33, 0x00, 0x00, 0xc0, 0xa8, 0x00, 0x01,
0xc0, 0xa8, 0x00, 0x02, 0x01, 0x04, 0x00, 0x00, 
0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x03, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x60, 0xc8, 
0x1a, 0x0b, 0x00, 0x01, 0xc3, 0x0e, 0x07, 0x40,
0xc2, 0xd9, 0x05, 0x00, 0x08, 0x09, 0x0a, 0x0b,
0x0c, 0x0d, 0x0e, 0x0f, 0x10, 0x11, 0x12, 0x13, 
0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b,
0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 
0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 
0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31, 0x32, 0x33,
0x34, 0x35, 0x36, 0x37};

typedef struct
{
unsigned char *key;
unsigned char key_len;
unsigned char *data;
unsigned char data_len;
}HMAC_MD5_TEST;


HMAC_MD5_TEST hmac_md5_test[8]={
{hmac_mda5_test_key1, sizeof(hmac_mda5_test_key1), hmac_mda5_test_data1, sizeof(hmac_mda5_test_data1)-1},
{hmac_mda5_test_key2, sizeof(hmac_mda5_test_key2)-1, hmac_mda5_test_data2, sizeof(hmac_mda5_test_data2)-1},
{hmac_mda5_test_key3, sizeof(hmac_mda5_test_key3), hmac_mda5_test_data3, sizeof(hmac_mda5_test_data3)},
{hmac_mda5_test_key4, sizeof(hmac_mda5_test_key4), hmac_mda5_test_data4, sizeof(hmac_mda5_test_data4)},
{hmac_mda5_test_key5, sizeof(hmac_mda5_test_key5), hmac_mda5_test_data5, sizeof(hmac_mda5_test_data5)-1},
{hmac_mda5_test_key6, sizeof(hmac_mda5_test_key6), hmac_mda5_test_data6, sizeof(hmac_mda5_test_data6)-1},
{hmac_mda5_test_key6, sizeof(hmac_mda5_test_key6), hmac_mda5_test_data7, sizeof(hmac_mda5_test_data7)-1},
{hmac_mda5_test_key8, sizeof(hmac_mda5_test_key8), hmac_mda5_test_data8, sizeof(hmac_mda5_test_data8)}
};


unsigned char *hmac_md5_testresult[8] =
{
"92 94 72 7a 36 38 bb 1c 13 f4 8e f8 15 8b fc 9d",
"75 0c 78 3e 6a b0 b5 03 ea a8 6e 31 0a 5d b7 38",
"56 be 34 52 1d 14 4c 88 db b8 c7 33 f0 e8 b3 f6",
"69 7e af 0a ca 3a 3a ea 3a 75 16 47 46 ff aa 79",
"56 46 1e f2 34 2e dc 00 f9 ba b9 95 69 0e fd 4c",
"6b 1a b7 fe 4b d7 bf 8f 0b 62 e6 ce 61 b9 d0 cd",
"6f 63 0f ad 67 cd a0 ee 1f b1 f5 62 db 3a a5 3e",
//"7d 38 56 4f fc 64 58 8c 3d ad 2d 11 00 00 00 00"
"1e ca f2 cb 62 8d 16 c5 0f c6 e6 6c a0 d5 4c f8" 
};

//*********************************************************************************
// Description	: Measures the time to digest block_count*block_len byte blocks
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void hmac_md5_test_time_trial(unsigned int block_len, unsigned int block_count)
{
unsigned char digest[MD5_HASH_SIZE];
unsigned int i;
unsigned int counter_10ms_end;

if(block_len>TEST_BLOCK_LEN)
	block_len=TEST_BLOCK_LEN;
// Initialize block
for (i = 0; i < block_len; i++)
	hmac_md5_block[i] = (unsigned char)(i & 0xff);
// Start timer 
#asm("cli");	 	// Global disable interrupts
counter_10ms_16bit=0;
#asm("sei");	 	// Global enable interrupts
// Digest blocks
LED2_ON;
for(i = 0; i < block_count; i++)
	{
	#ifdef HMAC_MD5_ENABLE
	hmac_md5(hmac_md5_block, block_len, hmac_md5_test[6].key, hmac_md5_test[6].key_len, digest);
	#endif // #ifdef HMAC_MD5_ENABLE
	}
LED2_OFF;
// Stop timer
#asm("cli");	 	// Global disable interrupts
counter_10ms_end=counter_10ms_16bit;
#asm("sei");	 	// Global enable interrupts
counter_10ms_end*=10;
printf("%4u = %u.%u ms per block (%u ms)\r\n", block_len, counter_10ms_end/block_count, counter_10ms_end%block_count, counter_10ms_end);
//debug_display_mem_hex(digest, sizeof(digest), 0);
}

//*********************************************************************************
// Description	: This file will exercise the SHA-1 code performing the three
//                tests documented in FIPS PUB 180-1 plus one which calls
//                SHA1Input with an exact multiple of 512 bits, plus a few
//                error test checks.
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void hmac_md5_test_suite(void)
{
unsigned char j;
unsigned char digest[MD5_HASH_SIZE];

for(j = 0; j < 8; j++)
	{
	printf("HMAC-MD5:%u data_len:%u key_len:%u\r\n", j+1, hmac_md5_test[j].data_len, hmac_md5_test[j].key_len);
//	debug_display_mem_hex(hmac_md5_test[j].data, hmac_md5_test[j].data_len, 0);
	#ifdef HMAC_MD5_ENABLE
	hmac_md5(hmac_md5_test[j].data, hmac_md5_test[j].data_len, hmac_md5_test[j].key, hmac_md5_test[j].key_len, digest);
	#endif // #ifdef HMAC_MD5_ENABLE
	printf("ok :%s\r\n", hmac_md5_testresult[j]);
	printf("cal:");
	debug_display_mem_hex(digest, sizeof(digest), 0);
	}
hmac_md5_test_time_trial(8, 50);
hmac_md5_test_time_trial(28, 50);
hmac_md5_test_time_trial(50, 50);
hmac_md5_test_time_trial(64, 25);
hmac_md5_test_time_trial(128, 25);
hmac_md5_test_time_trial(256, 5);
hmac_md5_test_time_trial(512, 5);
hmac_md5_test_time_trial(1024, 5);
hmac_md5_test_time_trial(1500, 5);
}


//********************************************************************************
// Description	: hmac-md5 command handler
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void hmac_md5_test_cmd(unsigned char *command)
{
int	data;

if(strncmpf(command, "hmac-md5", 6)==0)
	{
	data=debug_get_int_parameter(command);
	if(data==-1)
		hmac_md5_test_suite();
	else
		{
		if((data>=0)&&(data<64))
			hmac_md5_test_time_trial(data, 50);
		else if((data>=64)&&(data<256))
			hmac_md5_test_time_trial(data, 25);
		else
			hmac_md5_test_time_trial(data, 5);
		}
	}
}

#endif	// #ifdef	HMAC_MD5_TEST_ENABLE

