// ************************************************************************************************
///
/// \file 			aes.h
/// \brief			header file of aes.c
///
/// \date	 		$LastChangedDate: 2007-03-09 15:13:05 +0100 (Fr, 09 Mrz 2007) $
/// \version 		$Rev: 616 $
///	\author  		Daniel Matthes<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

/// \defgroup Encryption_Checksum
/// @{
/// \defgroup AES
/// @{

#ifdef _DOXYGEN_PARSER_
// ************************************************************************************************
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
//@{
#define AES_ENABLE
#define AES_KEY_COUNT 				3
#define AES_BLOCK_SIZE				16				
#define AES_INITIALVECTOR_3 		0x3BE133A0
#define AES_INITIALVECTOR_2 		0xA07A48FA
#define AES_INITIALVECTOR_1 		0x03426392
#define AES_INITIALVECTOR_0 		0xC3A4914C
#define AES_DEBUG
//@}
///	\def AES_ENABLE
///		Enables AES functions
///		
///	\def AES_KEY_COUNT
///		predefine KEY_SIZE
///		Use 128 (1), 192 (2) or 256 Bit	(3)
///		
///	\def AES_BLOCK_SIZE
///		Block size in number of bytes.
///		
///	\def AES_INITIALVECTOR_3
///		Part 3 of initial vector
///		
///	\def AES_INITIALVECTOR_2
///		Part 2 of initial vector
///		
///	\def AES_INITIALVECTOR_1
///		Part 1 of initial vector
///		
///	\def AES_INITIALVECTOR_0
///		Part 0 of initial vector
///
///	\def AES_DEBUG
///		Enables AES debug function
// ************************************************************************************************
#endif
 
#ifndef _AES_INCLUDED_
#define _AES_INCLUDED_

#pragma used+
void    aes_init(unsigned char *tempbuf);
void    aes_decrypt(unsigned char *buffer);
#ifdef AES_DEBUG
void	aes_decrypt_time(void);
#endif
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library aes.c
#endif

/// @}
/// @}
#endif
