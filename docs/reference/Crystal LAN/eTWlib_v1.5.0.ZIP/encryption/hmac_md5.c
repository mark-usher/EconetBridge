// ************************************************************************************************
///
/// \file 			hmac_md5.c
/// \brief			HMAC-MD5
///
///					This file contains the C reference code which implements HMAC-
///					MD5 using an existing MD5 library (see RFC 1321). 
///					see RFC 2104
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef HMAC_MD5_ENABLE

#include <string.h>
#include "md5.h"

//*********************************************************************************
// Description	: Calculate a "Hash Message Authentication Codes" HMAC with MD5
// Input	   	: *data: pointer to data to digest
//                data_len: length of data
//                *key: pointer to authentication key
//                key_len: length of authentication key
// Output     	: digest: caller digest to be filled in
// Indication	: none
//*********************************************************************************
void hmac_md5(unsigned char* data, unsigned int data_len, unsigned char* key, unsigned int key_len, 
                                 unsigned char *digest)
{
MD5_CTX context;
unsigned char o_ipad[MD5_BLOCK_SIZE]; // outer/inner padding -  key XORd with ipad
unsigned char tk[MD5_HASH_SIZE];
unsigned int i;

// if key is longer than 64 bytes reset it to key=MD5(key)
if(key_len > MD5_BLOCK_SIZE)
	{
	#ifdef MD5_ENABLE
	md5_init(&context);
	md5_update(&context, key, key_len);
	md5_final(&context, tk);
	#endif
	key = tk;
	key_len = MD5_HASH_SIZE;
	}
// the HMAC_MD5 transform looks like:
// MD5(K XOR opad, MD5(K XOR ipad, data))
// where K is an n byte key
// ipad is the byte 0x36 repeated 64 times
// opad is the byte 0x5c repeated 64 times
// and data is the data being protected
// perform inner MD5
memset(o_ipad, 0, sizeof(o_ipad));
memcpy(o_ipad, key, key_len);
for (i=0; i<MD5_BLOCK_SIZE; i++)
	o_ipad[i] ^= 0x36;				// XOR key with ipad and opad values 
#ifdef MD5_ENABLE
md5_init(&context);					// init context for 1st pass
md5_update(&context, o_ipad, MD5_BLOCK_SIZE);	// start with inner pad 
md5_update(&context, data, data_len);// then text of datagram
md5_final(&context, digest);		// finish up 1st pass
#endif
// perform outer MD5
memset(o_ipad, 0, sizeof(o_ipad));
memcpy(o_ipad, key, key_len);
for (i=0; i<MD5_BLOCK_SIZE; i++)
	o_ipad[i] ^= 0x5c;				// XOR key with ipad and opad values 
#ifdef MD5_ENABLE
md5_init(&context);					// init context for 2nd pass
md5_update(&context, o_ipad, MD5_BLOCK_SIZE);	// start with outer pad
md5_update(&context, digest, MD5_HASH_SIZE);	// then results of 1st hash
md5_final(&context, digest);		// finish up 2nd pass
#endif
}

#endif	// #ifdef HMAC_MD5_ENABLE


