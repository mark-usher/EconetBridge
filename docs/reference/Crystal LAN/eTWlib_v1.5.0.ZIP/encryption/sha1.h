// ************************************************************************************************
///
/// \file 			sha1.h
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _SHA1_INCLUDED_
#define _SHA1_INCLUDED_

enum
{
SHA_SUCCESS = 0,
SHA_NULL,			// Null pointer parameter
SHA_INPUT_TOO_LONG,	// input data too long
SHA_STATE_ERROR		// called Input after Result
};


#define SHA1_HASH_SIZE		20
#define SHA1_BLOCK_SIZE		64

// --------------------------------------------------------------------------------
// This structure will hold context information for the SHA-1
// hashing operation
// -------------------------------------------------------------------------------- 
typedef struct
{
unsigned long digest_32bit[SHA1_HASH_SIZE/4];	// Message Digest
unsigned long message_length;	  				// Message length in bits (only 32bit count)
unsigned char message_block_index; 				// Index into message block array
unsigned char message_block[SHA1_BLOCK_SIZE];	// 512-bit message blocks
unsigned char message_computed;   				// Is the message digest computed?
unsigned char message_corrupted;  				// Is the message digest corrupted?
}SHA1_CTX;


#pragma used+
// Function Prototypes
unsigned char sha1_init(SHA1_CTX *context);
unsigned char sha1_update(SHA1_CTX *context, unsigned char *message_array, unsigned int length);
unsigned char sha1_final(SHA1_CTX *context, unsigned char *digest);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library sha1.c
#endif

#endif	// #ifndef _SHA1_INCLUDED_
