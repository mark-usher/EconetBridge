// ************************************************************************************************
///
/// \file 			crc.h
/// \brief			header file of crc.c
///
/// \date	 		$LastChangedDate: 2007-03-09 15:13:05 +0100 (Fr, 09 Mrz 2007) $
/// \version 		$Rev: 616 $
///	\author  		Carsten K�gler, Nico M�ding, Daniel Matthes<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup Encryption_Checksum
/// @{
/// \defgroup CRC
/// @{

#ifdef _DOXYGEN_PARSER_
// ************************************************************************************************
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
//@{
#define CRC8_ENABLE
#define CRC8_LOOKUP_RAM
#define CRC8_LOOKUP_FLASH
#define CRC8_POLYNOM				0x11
#define CRC16_ENABLE
#define CRC16_ASSEMBLER
#define CRC16_LOOKUP_RAM
#define CRC16_LOOKUP_FLASH
#define CRC16_POLYNOM				0x8005
#define CRC32_LOOKUP_RAM
#define CRC32_ENABLE
#define CRC32_LOOKUP_FLASH
#define CRC32_POLYNOM				0x11111111
#define CRC16_DEBUG
//@}
///	\def CRC8_ENABLE
///		Enables CRC-8 functions
///		
///	\def CRC8_LOOKUP_RAM
///		CRC-8 functions work with an lookup table in RAM. This will be initialized with crc8_table_make().
///		
///	\def CRC8_LOOKUP_FLASH
///		CRC-8 functions work with an lookup table in FLASH.
///		
///	\def CRC8_POLYNOM
///		Defines an 8 Bit value for calculating CRC value or lookup table.
///		
///	\def CRC16_ENABLE
///		Enables CRC-16 functions
///		
///	\def CRC16_LOOKUP_RAM
///		CRC-16 functions work with an lookup table in RAM. This will be initialized with crc8_table_make().
///		
///	\def CRC16_LOOKUP_FLASH
///		CRC-16 functions work with an lookup table in FLASH.
///		
///	\def CRC16_ASSEMBLER
///		Define this to calculate CRC values with an assembler function
///		
///	\def CRC16_POLYNOM
///		Defines an 16 Bit value for calculating CRC value or lookup table.
///		
///	\def CRC32_LOOKUP_RAM
///		CRC-32 functions work with an lookup table in RAM. This will be initialized with crc8_table_make().
///		
///	\def CRC32_ENABLE
///		Enables CRC-32 functions
///		
///	\def CRC32_LOOKUP_FLASH
///		CRC-32 functions work with an lookup table in FLASH.
///		
///	\def CRC32_POLYNOM
///		Defines an 32 Bit value for calculating CRC value or lookup table.
///
/// \def CRC16_DEBUG
///		Enables CRC16 debug function
// ************************************************************************************************
#endif

#ifndef _CRC_INCLUDED_
#define _CRC_INCLUDED_

// Prototypes
#pragma used+ 
void			crc8_table_make(void);
void			crc16_table_make(void);
void			crc32_table_make(void);
unsigned char	crc8_calculate(unsigned char crc, unsigned char *buf, unsigned int len);
unsigned int 	crc16_calculate(unsigned int crc, unsigned char *buf, unsigned int len);
unsigned int 	crc16_asm_calculate(unsigned int crc, unsigned char ch);
#ifdef CRC16_DEBUG
void 			crc16_calc_time(void);
#endif
unsigned long	crc32_calculate(unsigned long crc, unsigned char *buf, unsigned int len);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library crc.c
#endif

#endif	// #ifndef _CRC_H_INCLUDED_

/// @}
/// @}
