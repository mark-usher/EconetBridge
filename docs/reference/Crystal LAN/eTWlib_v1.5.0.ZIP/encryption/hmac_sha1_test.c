// ************************************************************************************************
///
/// \file 			hmac_sha1_test.c
/// \brief			HMAC-SHA1 Test functions
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef	HMAC_SHA1_TEST_ENABLE

#include <stdio.h>
#include <string.h>
#include "board.h"
#include "debug.h"
#include "sha1.h"
#include "hmac_sha1.h"

#pragma regalloc-
#pragma regalloc+

// Length of test block, number of test blocks.
#define TEST_BLOCK_LEN 1500
unsigned char hmac_sha1_block[TEST_BLOCK_LEN];
       
/*
test_case = 1
key = 0x0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b
key_len = 20
data = "Hi There"
data_len = 8
digest = 0xb617318655057264e28bc0b6fb378c8ef146be00

test_case = 2
key = "Jefe"
key_len = 4
data = "what do ya want for nothing?"
data_len = 28
digest = 0xeffcdf6ae5eb2fa2d27416d5f184df9c259a7c79

test_case = 3
key = 0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
key_len = 20
data = 0xdd repeated 50 times
data_len = 50
digest = 0x125d7342b9ac11cd91a39af48aa17b4f63f175d3

test_case = 4
key = 0x0102030405060708090a0b0c0d0e0f10111213141516171819
key_len = 25
data = 0xcd repeated 50 times
data_len = 50
digest = 0x4c9007f4026250c6bc8414f9bf50c86c2d7235da

test_case = 5
key = 0x0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c0c
key_len = 20
data = "Test With Truncation"
data_len = 20
digest = 0x4c1a03424b55e07fe7f27be1d58bb9324a9a5a04
digest-96 = 0x4c1a03424b55e07fe7f27be1

test_case = 6
key = 0xaa repeated 80 times
key_len = 80
data = "Test Using Larger Than Block-Size Key - Hash Key
First"
data_len = 54
digest = 0xaa4ae5e15272d00e95705637ce8a3b55ed402112

test_case = 7
key = 0xaa repeated 80 times
key_len = 80
data = "Test Using Larger Than Block-Size Key and Larger
Than One Block-Size Data"
data_len = 73
digest = 0xe8e99d0f45237d786d6bbaa7965c7808bbff1a91
*/

unsigned char hmac_sha1_test_key1[20]={0x0b,0x0b,0x0b,0x0b,0x0b,0x0b,0x0b,0x0b,0x0b,0x0b, 
                        0x0b,0x0b,0x0b,0x0b,0x0b,0x0b,0x0b,0x0b,0x0b,0x0b};
unsigned char hmac_sha1_test_data1[9]={"Hi There"};
unsigned char hmac_sha1_test_key2[5]={"Jefe"};
unsigned char hmac_sha1_test_data2[29]={"what do ya want for nothing?"};
unsigned char hmac_sha1_test_key3[20]={0xa,0xa,0xa,0xa,0xa,0xa,0xa,0xa,0xa,0xa,
                        0xa,0xa,0xa,0xa,0xa,0xa,0xa,0xa,0xa,0xa};
unsigned char hmac_sha1_test_data3[50]={0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,
                         0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,
                         0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,
                         0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,
                         0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd,0xdd};
unsigned char hmac_sha1_test_key4[25]={0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,
                        0x0b,0x0c,0x0d,0x0e,0x0f,0x10,0x11,0x12,0x13,0x14,
                        0x15,0x16,0x17,0x18,0x19};
unsigned char hmac_sha1_test_data4[50]={0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,
                         0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,
                         0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,
                         0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,
                         0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd,0xcd};
unsigned char hmac_sha1_test_key5[20]={0xc,0xc,0xc,0xc,0xc,0xc,0xc,0xc,0xc,0xc,
                        0xc,0xc,0xc,0xc,0xc,0xc,0xc,0xc,0xc,0xc};
unsigned char hmac_sha1_test_data5[21]={"Test With Truncation"};
unsigned char hmac_sha1_test_key6[80]={0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,
                        0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa,0xaa};
unsigned char hmac_sha1_test_data6[55]={"Test Using Larger Than Block-Size Key - Hash Key First"};
unsigned char hmac_sha1_test_data7[74]={"Test Using Larger Than Block-Size Key and Larger Than One Block-Size Data"};


typedef struct
{
unsigned char *key;
unsigned char key_len;
unsigned char *data;
unsigned char data_len;
}HMAC_SHA1_TEST;


HMAC_SHA1_TEST hmac_sha1_test[7]={
{hmac_sha1_test_key1, sizeof(hmac_sha1_test_key1), hmac_sha1_test_data1, sizeof(hmac_sha1_test_data1)-1},
{hmac_sha1_test_key2, sizeof(hmac_sha1_test_key2)-1, hmac_sha1_test_data2, sizeof(hmac_sha1_test_data2)-1},
{hmac_sha1_test_key3, sizeof(hmac_sha1_test_key3), hmac_sha1_test_data3, sizeof(hmac_sha1_test_data3)},
{hmac_sha1_test_key4, sizeof(hmac_sha1_test_key4), hmac_sha1_test_data4, sizeof(hmac_sha1_test_data4)},
{hmac_sha1_test_key5, sizeof(hmac_sha1_test_key5), hmac_sha1_test_data5, sizeof(hmac_sha1_test_data5)-1},
{hmac_sha1_test_key6, sizeof(hmac_sha1_test_key6), hmac_sha1_test_data6, sizeof(hmac_sha1_test_data6)-1},
{hmac_sha1_test_key6, sizeof(hmac_sha1_test_key6), hmac_sha1_test_data7, sizeof(hmac_sha1_test_data7)-1}
};

unsigned char *hmac_sha1_testresult[7] =
{
"b6 17 31 86 55 05 72 64 e2 8b c0 b6 fb 37 8c 8e f1 46 be 00",
"ef fc df 6a e5 eb 2f a2 d2 74 16 d5 f1 84 df 9c 25 9a 7c 79",
"12 5d 73 42 b9 ac 11 cd 91 a3 9a f4 8a a1 7b 4f 63 f1 75 d3",
"4c 90 07 f4 02 62 50 c6 bc 84 14 f9 bf 50 c8 6c 2d 72 35 da",
"4c 1a 03 42 4b 55 e0 7f e7 f2 7b e1 d5 8b b9 32 4a 9a 5a 04",
"aa 4a e5 e1 52 72 d0 0e 95 70 56 37 ce 8a 3b 55 ed 40 21 12",
"e8 e9 9d 0f 45 23 7d 78 6d 6b ba a7 96 5c 78 08 bb ff 1a 91"
};


//*********************************************************************************
// Description	: Measures the time to digest block_count*block_len byte blocks
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void hmac_sha1_time_trial(unsigned int block_len, unsigned int block_count)
{
unsigned char digest[SHA1_HASH_SIZE];
unsigned int i;
unsigned int counter_10ms_end;

if(block_len>TEST_BLOCK_LEN)
	block_len=TEST_BLOCK_LEN;
// Initialize block
for (i = 0; i < block_len; i++)
	hmac_sha1_block[i] = (unsigned char)(i & 0xff);
// Start timer 
#asm("cli");	 	// Global disable interrupts
counter_10ms_16bit=0;
#asm("sei");	 	// Global enable interrupts
// Digest blocks
LED2_ON;		// PortD.5 LED2
for(i = 0; i < block_count; i++)
	{
	#ifdef HMAC_SHA1_ENABLE
	hmac_sha1(hmac_sha1_block, block_len, hmac_sha1_test[6].key, hmac_sha1_test[6].key_len, digest);
	#endif
	}
LED2_OFF;		// PortD.5 LED2
// Stop timer
#asm("cli");	 	// Global disable interrupts
counter_10ms_end=counter_10ms_16bit;
#asm("sei");	 	// Global enable interrupts
counter_10ms_end*=10;
printf("%4u = %u.%u ms per block (%u ms)\r\n", block_len, counter_10ms_end/block_count, counter_10ms_end%block_count, counter_10ms_end);
//debug_display_mem_hex(digest, sizeof(digest), 0);
}


//*********************************************************************************
// Description	: This file will exercise the SHA-1 code performing the three
//                tests documented in FIPS PUB 180-1 plus one which calls
//                SHA1Input with an exact multiple of 512 bits, plus a few
//                error test checks.
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void hmac_sha1_test_suite(void)
{
unsigned char j;
unsigned char digest[SHA1_HASH_SIZE];

for(j = 0; j < 7; j++)
	{
	printf("HMAC-SHA1:%u data_len:%u key_len:%u\r\n", j+1, hmac_sha1_test[j].data_len, hmac_sha1_test[j].key_len);
//	debug_display_mem_hex(hmac_sha1_test[j].data, hmac_sha1_test[j].data_len, 0);
	#ifdef HMAC_SHA1_ENABLE
	hmac_sha1(hmac_sha1_test[j].data, hmac_sha1_test[j].data_len, hmac_sha1_test[j].key, hmac_sha1_test[j].key_len, digest);
	#endif
	printf("ok :%s\r\n", hmac_sha1_testresult[j]);
	printf("cal:");
	debug_display_mem_hex(digest, sizeof(digest), 0);
	}
hmac_sha1_time_trial(8, 25);
hmac_sha1_time_trial(28, 25);
hmac_sha1_time_trial(50, 25);
hmac_sha1_time_trial(64, 10);
hmac_sha1_time_trial(128, 10);
hmac_sha1_time_trial(256, 3);
hmac_sha1_time_trial(512, 3);
hmac_sha1_time_trial(1024, 3);
hmac_sha1_time_trial(1500, 3);
}


//********************************************************************************
// Description	: HMAC-SHA1 command handler
// Input   		: none
// Output  		: none
// Indication	: none
//*********************************************************************************
void hmac_sha1_test_cmd(unsigned char *command)
{
int	data;

if(strncmpf(command, "hmac-sha1", 6)==0)
	{
	data=debug_get_int_parameter(command);
	if(data==-1)
		hmac_sha1_test_suite();
	else
		{
		if((data>=0)&&(data<64))
			hmac_sha1_time_trial(data, 25);
		else if((data>=64)&&(data<256))
			hmac_sha1_time_trial(data, 20);
		else
			hmac_sha1_time_trial(data, 3);
		}
	}
}

#endif	// #ifdef	HMAC_SHA1_TEST_ENABLE