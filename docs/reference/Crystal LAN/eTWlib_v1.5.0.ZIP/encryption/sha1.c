// ************************************************************************************************
///
/// \file 			sha1.c
/// \brief			Secure Hashing Algorithm 1
///
///					This file implements the Secure Hashing Algorithm 1 as
///					defined in FIPS PUB 180-1 published April 17, 1995.
///					see RFC 3174
///
///					The SHA-1, produces a 160-bit message digest for a given
///					data stream. It should take about 2**n steps to find a
///					message with the same digest as a given message and
///					2**(n/2) to find any two messages with the same digest,
///					when n is the digest size in bits. Therefore, this
///					algorithm can serve as a means of providing a
///					"fingerprint" for a message.
///
///					Caveats:
///					SHA-1 is designed to work with messages less than 2^32 bits
///					long. Although SHA-1 allows a message digest to be generated
///					for messages of any number of bits less than 2^32, this
///					implementation only works with messages with a length that is
///					a multiple of the size of an 8-bit character.
///
/// \date	 		$LastChangedDate: 2007-01-07 14:31:37 +0100 (So, 07 Jan 2007) $
/// \version 		$Rev: 447 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef SHA1_ENABLE

#include <string.h>
#include "sha1.h"

// Define the SHA1 circular left shift macro
#define SHA1_CIRCULAR_SHIFT(bits,word) (((word) << (bits)) | ((word) >> (32-(bits))))

// Local Function Prototyptes
void sha1_pad_message(SHA1_CTX *context);
void sha1_process_message_block(SHA1_CTX *context);

//*********************************************************************************
// Description	: This function will initialize the SHA1_CTX in preparation
//                for computing a new SHA1 message digest. 
// Input	   	: *context: pointer to SHA1 context to init
// Output     	: context: init SHA1 context
// Indication	: none
//*********************************************************************************
unsigned char sha1_init(SHA1_CTX *context)
{
if(context==0)
	return SHA_NULL;
memset(context, 0, sizeof(SHA1_CTX));
context->digest_32bit[0] = 0x67452301;
context->digest_32bit[1] = 0xEFCDAB89;
context->digest_32bit[2] = 0x98BADCFE;
context->digest_32bit[3] = 0x10325476;
context->digest_32bit[4] = 0xC3D2E1F0;
return SHA_SUCCESS;
}


//*********************************************************************************
// Description	: This function accepts an array of octets as the next portion
//                of the message
// Input	   	: *context: SHA1 context to update
//                *message_array: pointer to new data
//                length: length of message data
// Output     	: context: new SHA1 context
//                Return, see "SHA_XXXXXX"
// Indication	: none
//*********************************************************************************
unsigned char sha1_update(SHA1_CTX *context, unsigned char *message_array, unsigned int length)
{
if(length==0)
	return SHA_SUCCESS;
if((context==0)||(message_array==0))
	return SHA_NULL;
if(context->message_computed)
	{
	context->message_corrupted = SHA_STATE_ERROR;
	return SHA_STATE_ERROR;
	}
if(context->message_corrupted)
	return context->message_corrupted;
while(length--)
	{
	context->message_block[context->message_block_index++]=*message_array;
	context->message_length += 8;
	if(context->message_block_index == SHA1_BLOCK_SIZE)
		sha1_process_message_block(context);
	message_array++;
	}
return SHA_SUCCESS;
}

//*********************************************************************************
// Description	: This function will return the 160-bit message digest into the
//                Message_Digest array provided by the caller.
// Input	   	: *context: SHA1 context to update
//                *digest: pointer to new digest
// Output     	: context: new SHA1 context
//                digest: new SHA1 digest
//                Return, see "SHA_XXXXXX"
// Indication	: The first octet of hash is stored in the 0th element,
//                the last octet of hash in the 19th element.
//*********************************************************************************
unsigned char sha1_final(SHA1_CTX *context, unsigned char *digest)
{
unsigned char i;
unsigned char *data;

if((context==0)||(digest==0))
	return SHA_NULL;
if(context->message_corrupted)
	return context->message_corrupted;
if(context->message_computed==0)
	{
	sha1_pad_message(context);
	memset(context->message_block, 0, sizeof(context->message_block));	// message may be sensitive, clear it out
	context->message_length = 0; 				// and clear length
	context->message_computed = 1;
	}
data=(unsigned char*)context->digest_32bit;
for(i = 0; i < (SHA1_HASH_SIZE/4); i++)
	{
	digest[0]=data[3];
	digest[1]=data[2];
	digest[2]=data[1];
	digest[3]=data[0];
	data+=4;
	digest+=4;
	}
return SHA_SUCCESS;
}


//#pragma optsize-
//*********************************************************************************
// Description	: This function will process the next 512 bits of the message
//                stored in the message_block array.
// Input	   	: *context: SHA1 context to update
// Output     	: context: new SHA1 context
// Indication	: none
//*********************************************************************************
void sha1_process_message_block(SHA1_CTX *context)
{
// Constants defined in SHA-1
unsigned long K[4] = { 
0x5A827999,
0x6ED9EBA1,
0x8F1BBCDC,
0xCA62C1D6
};
unsigned char t; 		// Loop counter
unsigned long temp; 	// Temporary word value
unsigned long W[80];	// Word sequence
unsigned long A, B, C, D, E; // Word buffers
// Initialize the first 16 words in the array W
for(t = 0; t < 16; t++)
	{
	W[t] = (unsigned long)context->message_block[(unsigned int)t * 4] << 24;
	W[t]|= (unsigned long)context->message_block[(unsigned int)t * 4 + 1] << 16;
	W[t]|= (unsigned int)context->message_block[(unsigned int)t * 4 + 2] << 8;
	W[t]|= context->message_block[(unsigned int)t * 4 + 3];
	}
for(t = 16; t < 80; t++)
	W[t] = SHA1_CIRCULAR_SHIFT(1, W[t-3] ^ W[t-8] ^ W[t-14] ^ W[t-16]);
A = context->digest_32bit[0];
B = context->digest_32bit[1];
C = context->digest_32bit[2];
D = context->digest_32bit[3];
E = context->digest_32bit[4];
for(t = 0; t < 20; t++)
	{
	temp = SHA1_CIRCULAR_SHIFT(5,A) +((B & C) | ((~B) & D)) + E + W[t] + K[0];
	E = D;
	D = C;
	C = SHA1_CIRCULAR_SHIFT(30,B);
	B = A;
	A = temp;
	}
for(t = 20; t < 40; t++)
	{
	temp = SHA1_CIRCULAR_SHIFT(5,A) + (B ^ C ^ D) + E + W[t] + K[1];
	E = D;
	D = C;
	C = SHA1_CIRCULAR_SHIFT(30,B);
	B = A;
	A = temp;
	}
for(t = 40; t < 60; t++)
	{
	temp = SHA1_CIRCULAR_SHIFT(5,A) +((B & C) | (B & D) | (C & D)) + E + W[t] + K[2];
	E = D;
	D = C;
	C = SHA1_CIRCULAR_SHIFT(30,B);
	B = A;
	A = temp;
	}
for(t = 60; t < 80; t++)
	{
	temp = SHA1_CIRCULAR_SHIFT(5,A) + (B ^ C ^ D) + E + W[t] + K[3];
	E = D;
	D = C;
	C = SHA1_CIRCULAR_SHIFT(30,B);
	B = A;
	A = temp;
	}
context->digest_32bit[0]+= A;
context->digest_32bit[1]+= B;
context->digest_32bit[2]+= C;
context->digest_32bit[3]+= D;
context->digest_32bit[4]+= E;
context->message_block_index = 0;
}
//#pragma optsize+


//*********************************************************************************
// Description	: According to the standard, the message must be padded to an even
//                512 bits. The first padding bit must be a �1�. The last 64
//                bits represent the length of the original message. All bits in
//                between should be 0. This function will pad the message
//                according to those rules by filling the Message_Block array
//                accordingly. It will also call the ProcessMessageBlock function
//                provided appropriately. When it returns, it can be assumed that
//                the message digest has been computed.
// Input	   	: *context: SHA1 context to update
// Output     	: context: new SHA1 context
// Indication	: none
//*********************************************************************************
void sha1_pad_message(SHA1_CTX *context)
{
unsigned char *data;
// Check to see if the current message block is too small to hold
// the initial padding bits and length. If so, we will pad the
// block, process it, and then continue padding into a second block.
if(context->message_block_index > 55)
	{
	context->message_block[context->message_block_index++] = 0x80;
	while(context->message_block_index < 64)
		context->message_block[context->message_block_index++] = 0;	// length is NULL
	sha1_process_message_block(context);
	while(context->message_block_index < 56)
		context->message_block[context->message_block_index++] = 0;	// set all data to NULL
	}
else
	{
	context->message_block[context->message_block_index++] = 0x80;
	while(context->message_block_index < 56)
		context->message_block[context->message_block_index++] = 0;
	}
// Store the message length as the last 8 octets
memset(&context->message_block[56], 0, 4);
data=(unsigned char*)&context->message_length;
context->message_block[60] = data[3];
context->message_block[61] = data[2];
context->message_block[62] = data[1];
context->message_block[63] = data[0];
sha1_process_message_block(context);
}

#endif // #ifdef SHA1_ENABLE
