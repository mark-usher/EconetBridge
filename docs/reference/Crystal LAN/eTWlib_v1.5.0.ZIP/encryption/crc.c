// ************************************************************************************************
///
/// \file 			crc.c
/// \brief			Functions for CRC checksum
///                 
///					<b>Typical polynomials:</b><br/><br/>
/// 				<table>
///					<tr><td>CRC-CCITT (CRC-8)</td><td>x^8+x^7+x^3+x^2+1</td>
///                 <td>-> poly = 0x8D</td>
///					<td>(use: 1-Wire bus)</td></tr>	
///					<tr><td>CRC-CCITT (CRC-16)</td><td>x^16+x^12+x^5+x^1</td>
///                 <td>-> poly = 0x1021</td>
///					<td>(use: XMODEM, X.25, Bluetooth, PPP...)</td></tr>  
///					<tr><td>IBM-CRC-16</td><td>x16 + x15 + x2 + 1</td>
///                 <td>-> poly = 0x8005</td>
///					<td>(use: USB...)</td></tr>
///					<tr><td>CRC-32-IEEE 802.3 (CRC-32)</td><td>x^32+x^26+x^23+x^22+x^16+x^12+x^11+x^10+x^8+x^7+x^5+x^4+x^2+x+1</td>
///                 <td>-> poly = 0xEDB88320</td>
///					<td>(use: V.42)</td></tr>
///					</table><br/>
///					more on http://en.wikipedia.org/wiki/Cyclic_redundancy_check 
///
/// \todo			Add CRC8_ASSEMBLER functionality
/// \todo			Add CRC32_ASSEMBLER functionality
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		Carsten K�gler, Nico M�ding, Daniel Matthes<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"
#include "crc.h"

#ifdef _DOXYGEN_PARSER_
#define DEBUG
#endif

#if defined DEBUG && defined CRC16_DEBUG
#include "debug.h"
#include "spm.h"
#include <stdio.h>
#endif

#ifdef CRC8_ENABLE
	#ifdef CRC8_LOOKUP_RAM
	unsigned char	crc8_table[256];			///< RAM space for crc8 lookup table
	#endif	// #ifdef CRC8_LOOKUP_RAM
	
	#ifdef CRC8_LOOKUP_FLASH
	flash unsigned char crc8_table[256] = {
		0  , 49 , 98 , 83 , 196, 245, 166, 151, 185, 136, 219, 234, 125, 76 , 31 , 46 , 67 , 114, 33 , 16,
		135, 182, 229, 212, 250, 203, 152, 169, 62 , 15 , 92 , 109, 134, 183, 228, 213, 66 , 115, 32 , 17,	
		63 , 14 , 93 , 108, 251, 202, 153, 168, 197, 244, 167, 150, 1  , 48 , 99 , 82 , 124, 77 , 30 , 47,
		184, 137, 218, 235, 61 , 12 , 95 , 110, 249, 200, 155, 170, 132, 181, 230, 215, 64 , 113, 34 , 19,
		126, 79 , 28 , 45 , 186, 139, 216, 233, 199, 246, 165, 148, 3  , 50 , 97 , 80 , 187, 138, 217, 232,
		127, 78 , 29 , 44 , 2  , 51 , 96 , 81,  198, 247, 164, 149, 248, 201, 154, 171, 60 , 13,  94 , 111,	
		65 , 112, 35 , 18 , 133, 180, 231, 214, 122, 75 , 24 , 41 , 190, 143, 220, 237, 195, 242, 161, 144,
		7  , 54 , 101, 84 , 57 , 8  , 91 , 106, 253, 204, 159, 174, 128, 177, 226, 211, 68 , 117, 38 , 23,
		252, 205, 158, 175, 56 , 9  , 90 , 107, 69 , 116, 39 , 22 , 129, 176, 227, 210, 191, 142, 221, 236,
		123, 74 , 25 , 40 , 6  , 55 , 100, 85 , 194, 243, 160, 145, 71 , 118, 37 , 20 , 131, 178, 225, 208,
		254, 207, 156, 173, 58 , 11 , 88 , 105, 4  , 53 , 102, 87 , 192, 241, 162, 147, 189, 140, 223, 238,
		121, 72 , 27 , 42 , 193, 240, 163, 146, 5  , 52 , 103, 86 , 120, 73 , 26 , 43 , 188, 141, 222, 239,
		130, 179, 224, 209, 70 , 119, 36 , 21 , 59 , 10 , 89 , 104, 255, 206, 157, 172};
		///< Flash lookup table for polynom: x^8+x^5+x^4 + 1 -> poly = 0x31
	#endif	// 	#ifdef CRC8_LOOKUP_FLASH
		
	
	#ifdef CRC8_LOOKUP_RAM
	// ************************************************************************************************
	/// \brief		calculates the 8bit crc-table
	///	\note		Generate a table for a byte-wise 8-bit CRC calculation on the polynomial:
	/// 			x^8+x^5+x^4+1.
	// ************************************************************************************************
	void crc8_table_make(void)
	{
	unsigned char	c;
	unsigned int	n;
	unsigned char	k;
	unsigned char	poly;  						// polynomial exclusive-or pattern
	
	poly = CRC8_POLYNOM;
	
	for (n=0; n<256; n++)						// crc8-look-up-table generation
		{
		c = n;
		for (k=0; k<8; k++)
			c = (c&0x80) ? poly ^ (c << 1) : c << 1;   
			crc8_table[n] = c;
		}
	}	
	#endif	// #ifdef CRC8_LOOKUP_RAM	
	
	#pragma optsize-
	// ************************************************************************************************
	/// \brief		calculates the CRC-8 Checksum
	///	@param[in]	crc		-	8 bit crc value
	/// @param[in]	*buf 	- 	pointer to array
	/// @param[in]	len		-	array length	
	/// @retval		crc		-	8 bit crc value		
	// ************************************************************************************************
	unsigned char crc8_calculate(unsigned char crc, unsigned char *buf, unsigned int len)
	{
	if (buf == 0x00)
		return 0;
	
	#ifdef CRC8_LOOKUP_RAM
	if (crc8_table[1] == 0)
		crc8_table_make();
	#endif	// #ifdef CRC8_LOOKUP_RAM
	
	do											// Checksum calculation
		{
		crc = crc8_table[(crc ^ (*buf++))];
		}
	while(--len);
	
	return crc;
	}
	#pragma optsize+
	
	#ifdef CRC8_ASSEMBLER
		#error "CRC8_ASSEMBLER not available yet!"
	#endif
#endif	// #ifdef CRC8_ENABLE


#ifdef CRC16_ENABLE
	#ifdef CRC16_LOOKUP_RAM
	unsigned int	crc16_table[256];			///< RAM space for crc16 lookup table
	#endif	// #ifdef CRC16_LOOKUP_RAM
	
	#ifdef CRC16_LOOKUP_FLASH
	flash unsigned int crc16_table[256] = {
		0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50A5, 0x60C6, 0x70E7,
		0x8108, 0x9129, 0xA14A, 0xB16B, 0xC18C, 0xD1AD, 0xE1CE, 0xF1EF,
		0x1231, 0x0210, 0x3273, 0x2252, 0x52B5, 0x4294, 0x72F7, 0x62D6,
		0x9339, 0x8318, 0xB37B, 0xA35A, 0xD3BD, 0xC39C, 0xF3FF, 0xE3DE,
		0x2462, 0x3443, 0x0420, 0x1401, 0x64E6, 0x74C7, 0x44A4, 0x5485,
		0xA56A, 0xB54B, 0x8528, 0x9509, 0xE5EE, 0xF5CF, 0xC5AC, 0xD58D,
		0x3653, 0x2672, 0x1611, 0x0630, 0x76D7, 0x66F6, 0x5695, 0x46B4,
		0xB75B, 0xA77A, 0x9719, 0x8738, 0xF7DF, 0xE7FE, 0xD79D, 0xC7BC,
		0x48C4, 0x58E5, 0x6886, 0x78A7, 0x0840, 0x1861, 0x2802, 0x3823,
		0xC9CC, 0xD9ED, 0xE98E, 0xF9AF, 0x8948, 0x9969, 0xA90A, 0xB92B,
		0x5AF5, 0x4AD4, 0x7AB7, 0x6A96, 0x1A71, 0x0A50, 0x3A33, 0x2A12,
		0xDBFD, 0xCBDC, 0xFBBF, 0xEB9E, 0x9B79, 0x8B58, 0xBB3B, 0xAB1A,
		0x6CA6, 0x7C87, 0x4CE4, 0x5CC5, 0x2C22, 0x3C03, 0x0C60, 0x1C41,
		0xEDAE, 0xFD8F, 0xCDEC, 0xDDCD, 0xAD2A, 0xBD0B, 0x8D68, 0x9D49,
		0x7E97, 0x6EB6, 0x5ED5, 0x4EF4, 0x3E13, 0x2E32, 0x1E51, 0x0E70,
		0xFF9F, 0xEFBE, 0xDFDD, 0xCFFC, 0xBF1B, 0xAF3A, 0x9F59, 0x8F78,
		0x9188, 0x81A9, 0xB1CA, 0xA1EB, 0xD10C, 0xC12D, 0xF14E, 0xE16F,
		0x1080, 0x00A1, 0x30C2, 0x20E3, 0x5004, 0x4025, 0x7046, 0x6067,
		0x83B9, 0x9398, 0xA3FB, 0xB3DA, 0xC33D, 0xD31C, 0xE37F, 0xF35E,
		0x02B1, 0x1290, 0x22F3, 0x32D2, 0x4235, 0x5214, 0x6277, 0x7256,
		0xB5EA, 0xA5CB, 0x95A8, 0x8589, 0xF56E, 0xE54F, 0xD52C, 0xC50D,
		0x34E2, 0x24C3, 0x14A0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
		0xA7DB, 0xB7FA, 0x8799, 0x97B8, 0xE75F, 0xF77E, 0xC71D, 0xD73C,
		0x26D3, 0x36F2, 0x0691, 0x16B0, 0x6657, 0x7676, 0x4615, 0x5634,
		0xD94C, 0xC96D, 0xF90E, 0xE92F, 0x99C8, 0x89E9, 0xB98A, 0xA9AB, 
		0x5844, 0x4865, 0x7806, 0x6827, 0x18C0, 0x08E1, 0x3882, 0x28A3,
		0xCB7D, 0xDB5C, 0xEB3F, 0xFB1E, 0x8BF9, 0x9BD8, 0xABBB, 0xBB9A,
		0x4A75, 0x5A54, 0x6A37, 0x7A16, 0x0AF1, 0x1AD0, 0x2AB3, 0x3A92,
		0xFD2E, 0xED0F, 0xDD6C, 0xCD4D, 0xBDAA, 0xAD8B, 0x9DE8, 0x8DC9,
		0x7C26, 0x6C07, 0x5C64, 0x4C45, 0x3CA2, 0x2C83, 0x1CE0, 0x0CC1,
		0xEF1F, 0xFF3E, 0xCF5D, 0xDF7C, 0xAF9B, 0xBFBA, 0x8FD9, 0x9FF8,
		0x6E17, 0x7E36, 0x4E55, 0x5E74, 0x2E93, 0x3EB2, 0x0ED1, 0x1EF0};
		///< Flash lookup table for polynom: x^16+x^12+x^5+x^0 -> poly = 0x1021
	#endif	// #ifdef CRC16_LOOKUP_FLASH
	
	#ifdef CRC16_LOOKUP_RAM
	// ************************************************************************************************
	/// \brief		calculates the 16bit crc-table
	///	\note		Generate a table for a byte-wise 16-bit CRC calculation on the polynomial:
	/// 			x^16+x^12+x^5+x^0.
	// ************************************************************************************************	
	void crc16_table_make(void)
	{
	unsigned int	c;
	unsigned int	n;
	unsigned char	k;
	unsigned int	poly;   // polynomial exclusive-or pattern
	
	poly = CRC16_POLYNOM;		
	for (n=0; n<256; n++)
		{
		c = n << 8;
		for(k=0; k<8; k++)
			c = c & (0x8000) ? poly ^ (c << 1) : (c << 1);
	
		crc16_table[n] = c;
		}
	}
	#endif	// #ifdef CRC16_LOOKUP_RAM
	
	
	#if defined(CRC16_LOOKUP_FLASH) || defined(CRC16_LOOKUP_RAM)
	// ************************************************************************************************
	/// \brief		calculates the CRC-16 Checksum  (in blocks)
	///	@param[in]	crc		-	16 bit crc value
	/// @param[in]	*buf 	- 	pointer to array
	/// @param[in]	len		-	array length	
	/// @retval		crc		-	16 bit crc value
	// ************************************************************************************************
	#pragma optsize-
	unsigned int crc16_calculate(unsigned int crc, unsigned char *buf, unsigned int len)
	{
	if (buf == 0x00)
		return 0;
		
	#ifdef CRC16_LOOKUP_RAM
	if (crc16_table[1] == 0)
		crc16_table_make();
	#endif 
	
	do
	    {
	    crc =  crc16_table[((crc >> 8) ^ (*buf++)) & 0xFF] ^ (crc << 8);
		}    
	while(--len);
	
	return crc;
	}
	#pragma optsize+
	#endif 	// #if defined(CRC16_LOOKUP_FLASH) || defined(CRC16_LOOKUP_RAM)
	
	#ifdef CRC16_ASSEMBLER
	
	// ************************************************************************************************
	//  definitions and equations 	
	// ************************************************************************************************
	// Codevision Help:
	// The registers R0, R1, R22, R23, R24, R25, R26, R27, R30 and R31 can be freely used 
	// in assembly routines.
	
	#ifndef _DOXYGEN_PARSER_
	#asm
	    .def    polyhigh = r25  
	    .def    polylow = r24
	    .def    crchigh = r1
	    .def    crclow  = r0
	    .def    char = r23
	    .def    loop = r22
	    
	    .equ    CRC_POLYNOM = 0x8005
	#endasm
	#endif	//ifndef _DOXYGEN_PARSER_
	
	// ************************************************************************************************
	/// \brief  	calculates the CRC-16 Checksum (byte by byte)
	///
	/// @param[in]  crc - previous calculated checksum
	/// @param[in]  ch - actual char (byte)
	/// @retval		CRC16-Checksum - new calculated checksum
	// ************************************************************************************************
	#pragma warn- 
	unsigned int crc16_asm_calculate(unsigned int crc, unsigned char ch)
	{   
	#asm
	CRC:        	wdr
					ldd crchigh, y+2
	            	ldd crclow, y+1
	            	ld char, y
	    
	            	ldi loop, 0x08
	            	ldi polyhigh, HIGH(CRC_POLYNOM) 
	            	ldi polylow, LOW(CRC_POLYNOM)
	    
	CRC_LOOP:   	;rotate left. If MSB is 1 -> divide with Generator-polynom
	            
	        		lsl char
	            	rol crclow
	            	rol crchigh
	            	brcc CRC_SKIPEOR      
	        
	            	eor crclow, polylow
		            eor crchigh, polyhigh
	        
	CRC_SKIPEOR:
					dec loop
	            	brne CRC_LOOP
	            	
	            	mov r30, crclow
	            	mov r31, crchigh
	#endasm 
	}
	#pragma warn+
	#endif	// #ifdef CRC16_ASSEMBLER
	
	#ifdef DEBUG
	#ifdef CRC16_DEBUG
	// ************************************************************************************************
	/// \brief  	calculates time of crc16 check of the whole application section
	/// 
	/// \note		only in \ref CRC16_DEBUG modus available<br/>
	///				configured for ATmega128 with 16 MHz clock
	// ************************************************************************************************
	void crc16_calc_time(void)
		{
		unsigned int crc = 0;
		unsigned long n = 122880/256;
		unsigned long calc_time;
		unsigned char timsk_temp;
		unsigned char tccr1b_temp;
		unsigned char flash_temp[256];
		unsigned long flash_address = 0x0;
		
		timsk_temp = TIMSK;
		tccr1b_temp = TCCR1B;
		TIMSK = 0x00;				//timer-interupt disabled 
		TCCR1B = 0x05;				//Prescaler 1024 --> 1 Tick = 64�s
		TCNT1 = 0;
   		   		   		   		
		do
			{
			SPM_READFLASH(flash_temp, flash_address, 256);
			flash_address += 256;
			crc = crc16_calculate(crc, flash_temp, 256);
			}
		while (--n);
	
		calc_time = (64*(unsigned long)TCNT1)/1000;
	    
		printf("\ncalculated time: %u ms\n\r",calc_time);
		printf("calculated CRC 0x%x \n\r",crc);
	
		if(crc != 0x0)
 			putsf("calculated CRC invalid\r");
   		else
   			putsf("calculated CRC valid\n\r");
   	
	    TIMSK = timsk_temp;
		TCCR1B = tccr1b_temp;
		}
	#endif		// #ifdef CRC_DEBUG
	#endif		// #ifdef DEBUG
	
#endif  // #else CRC16_ENABLE


#ifdef CRC32_ENABLE
	#ifdef CRC32_LOOKUP_RAM
	unsigned long	crc32_table[256];           ///< RAM space for crc32 look up table
	#endif	// #ifdef CRC32_LOOKUP_RAM
	
	#ifdef CRC32_LOOKUP_FLASH
	flash unsigned long crc32_table[256] = {
		0x00000000L, 0x77073096L, 0xee0e612cL, 0x990951baL, 0x076dc419L, 0x706af48fL, 0xe963a535L, 0x9e6495a3L, 
		0x0edb8832L, 0x79dcb8a4L, 0xe0d5e91eL, 0x97d2d988L, 0x09b64c2bL, 0x7eb17cbdL, 0xe7b82d07L, 0x90bf1d91L, 
		0x1db71064L, 0x6ab020f2L, 0xf3b97148L, 0x84be41deL, 0x1adad47dL, 0x6ddde4ebL, 0xf4d4b551L, 0x83d385c7L,
		0x136c9856L, 0x646ba8c0L, 0xfd62f97aL, 0x8a65c9ecL, 0x14015c4fL, 0x63066cd9L, 0xfa0f3d63L, 0x8d080df5L, 
		0x3b6e20c8L, 0x4c69105eL, 0xd56041e4L, 0xa2677172L, 0x3c03e4d1L, 0x4b04d447L, 0xd20d85fdL, 0xa50ab56bL,
		0x35b5a8faL, 0x42b2986cL, 0xdbbbc9d6L, 0xacbcf940L, 0x32d86ce3L, 0x45df5c75L, 0xdcd60dcfL, 0xabd13d59L,
		0x26d930acL, 0x51de003aL, 0xc8d75180L, 0xbfd06116L, 0x21b4f4b5L, 0x56b3c423L, 0xcfba9599L, 0xb8bda50fL, 
		0x2802b89eL, 0x5f058808L, 0xc60cd9b2L, 0xb10be924L, 0x2f6f7c87L, 0x58684c11L, 0xc1611dabL, 0xb6662d3dL,
		0x76dc4190L, 0x01db7106L, 0x98d220bcL, 0xefd5102aL, 0x71b18589L, 0x06b6b51fL, 0x9fbfe4a5L, 0xe8b8d433L,
		0x7807c9a2L, 0x0f00f934L, 0x9609a88eL, 0xe10e9818L, 0x7f6a0dbbL, 0x086d3d2dL, 0x91646c97L, 0xe6635c01L,
		0x6b6b51f4L, 0x1c6c6162L, 0x856530d8L, 0xf262004eL, 0x6c0695edL, 0x1b01a57bL, 0x8208f4c1L, 0xf50fc457L,
		0x65b0d9c6L, 0x12b7e950L, 0x8bbeb8eaL, 0xfcb9887cL, 0x62dd1ddfL, 0x15da2d49L, 0x8cd37cf3L, 0xfbd44c65L,
		0x4db26158L, 0x3ab551ceL, 0xa3bc0074L, 0xd4bb30e2L, 0x4adfa541L, 0x3dd895d7L, 0xa4d1c46dL, 0xd3d6f4fbL,
		0x4369e96aL, 0x346ed9fcL, 0xad678846L, 0xda60b8d0L, 0x44042d73L, 0x33031de5L, 0xaa0a4c5fL, 0xdd0d7cc9L,
		0x5005713cL, 0x270241aaL, 0xbe0b1010L, 0xc90c2086L, 0x5768b525L, 0x206f85b3L, 0xb966d409L, 0xce61e49fL,
		0x5edef90eL, 0x29d9c998L, 0xb0d09822L, 0xc7d7a8b4L, 0x59b33d17L, 0x2eb40d81L, 0xb7bd5c3bL, 0xc0ba6cadL,
		0xedb88320L, 0x9abfb3b6L, 0x03b6e20cL, 0x74b1d29aL, 0xead54739L, 0x9dd277afL, 0x04db2615L, 0x73dc1683L, 
		0xe3630b12L, 0x94643b84L, 0x0d6d6a3eL, 0x7a6a5aa8L, 0xe40ecf0bL, 0x9309ff9dL, 0x0a00ae27L, 0x7d079eb1L,
		0xf00f9344L, 0x8708a3d2L, 0x1e01f268L, 0x6906c2feL, 0xf762575dL, 0x806567cbL, 0x196c3671L, 0x6e6b06e7L,
		0xfed41b76L, 0x89d32be0L, 0x10da7a5aL, 0x67dd4accL, 0xf9b9df6fL, 0x8ebeeff9L, 0x17b7be43L, 0x60b08ed5L,
		0xd6d6a3e8L, 0xa1d1937eL, 0x38d8c2c4L, 0x4fdff252L, 0xd1bb67f1L, 0xa6bc5767L, 0x3fb506ddL, 0x48b2364bL,
		0xd80d2bdaL, 0xaf0a1b4cL, 0x36034af6L, 0x41047a60L, 0xdf60efc3L, 0xa867df55L, 0x316e8eefL, 0x4669be79L,
		0xcb61b38cL, 0xbc66831aL, 0x256fd2a0L, 0x5268e236L, 0xcc0c7795L, 0xbb0b4703L, 0x220216b9L, 0x5505262fL,
		0xc5ba3bbeL, 0xb2bd0b28L, 0x2bb45a92L, 0x5cb36a04L, 0xc2d7ffa7L, 0xb5d0cf31L, 0x2cd99e8bL, 0x5bdeae1dL,
		0x9b64c2b0L, 0xec63f226L, 0x756aa39cL, 0x026d930aL, 0x9c0906a9L, 0xeb0e363fL, 0x72076785L, 0x05005713L,
		0x95bf4a82L, 0xe2b87a14L, 0x7bb12baeL, 0x0cb61b38L, 0x92d28e9bL, 0xe5d5be0dL, 0x7cdcefb7L, 0x0bdbdf21L,
		0x86d3d2d4L, 0xf1d4e242L, 0x68ddb3f8L, 0x1fda836eL, 0x81be16cdL, 0xf6b9265bL, 0x6fb077e1L, 0x18b74777L,
		0x88085ae6L, 0xff0f6a70L, 0x66063bcaL, 0x11010b5cL, 0x8f659effL, 0xf862ae69L, 0x616bffd3L, 0x166ccf45L,
		0xa00ae278L, 0xd70dd2eeL, 0x4e048354L, 0x3903b3c2L, 0xa7672661L, 0xd06016f7L, 0x4969474dL, 0x3e6e77dbL,
		0xaed16a4aL, 0xd9d65adcL, 0x40df0b66L, 0x37d83bf0L, 0xa9bcae53L, 0xdebb9ec5L, 0x47b2cf7fL, 0x30b5ffe9L,
		0xbdbdf21cL, 0xcabac28aL, 0x53b39330L, 0x24b4a3a6L, 0xbad03605L, 0xcdd70693L, 0x54de5729L, 0x23d967bfL,
		0xb3667a2eL, 0xc4614ab8L, 0x5d681b02L, 0x2a6f2b94L, 0xb40bbe37L, 0xc30c8ea1L, 0x5a05df1bL, 0x2d02ef8dL};
		///< Flash lookup table for polynom: x^32+x^26+x^23+x^22+x^16+x^12+x^11+x^10+x^8+x^7+x^5+x^4+x^2+x+1   -> poly = 0xEDB88320
	#endif	// #ifdef CRC32_LOOKUP_FLASH
	
	 
	#ifdef CRC32_LOOKUP_RAM
	// ************************************************************************************************
	/// \brief		calculates the 32bit crc-table
	///	\note		Generate a table for a byte-wise 32-bit CRC calculation on the polynomial:
	/// 			x^32+x^26+x^23+x^22+x^16+x^12+x^11+x^10+x^8+x^7+x^5+x^4+x^2+x+1.
	// ************************************************************************************************	
	void crc32_table_make(void)
	{
	unsigned long	c;
	unsigned int	n;
	unsigned char	k;
	unsigned long	poly;						   		// polynomial exclusive-or pattern
	
	poly = CRC32_POLYNOM;								// 0xedb88320 see Ethernet-FCS
	for (n=0; n<256; n++)
		{
		c = n;
		for(k=0; k<8; k++)
			c = c & 1 ? poly ^ (c >> 1) : c >> 1;
		crc32_table[n] = c;
		}
	}
	#endif	// #ifdef CRC32_LOOKUP_RAM
	
	#if defined(CRC32_LOOKUP_RAM) || defined(CRC32_LOOKUP_FLASH)
	// ************************************************************************************************
	/// \brief		calculates the CRC-32 Checksum
	///	@param[in]	crc		-	32 bit crc value
	/// @param[in]	*buf 	- 	pointer to array
	/// @param[in]	len		-	array length	
	/// @retval		crc		-	32 bit crc value
	// ************************************************************************************************
	unsigned long crc32_calculate(unsigned long crc, unsigned char *buf, unsigned int len)
	{
	if(buf==0x00)
		return 0;
		
	#ifdef CRC32_LOOKUP_RAM
	if(crc32_table[1]==0)
		crc32_table_make();
	#endif
	
	crc = crc ^ 0xffffffff;
	while(len)
		{
		crc = crc32_table[(crc ^ (*buf++)) & 0xff] ^ (crc >> 8);
		len--;
		}
	
	crc = crc ^ 0xffffffff;
	return crc;
	}
	#pragma optsize+
	#endif	// #if defined(CRC32_LOOKUP_RAM) || defined(CRC32_LOOKUP_FLASH)
	
	#ifdef CRC32_ASSEMBLER
	#error "CRC32_ASSEMBLER not available yet!"
	#endif
	
#endif	// #ifdef CRC32_ENABLE