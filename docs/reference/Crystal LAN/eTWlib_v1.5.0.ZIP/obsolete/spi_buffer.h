// ************************************************************************************************
///
/// 			\file spi_buffer.h
///
///  SPI buffer
///
/// \par Created 	10.04.2001
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#ifndef _SPI_BUFFER_INCLUDED_
#define _SPI_BUFFER_INCLUDED_

//#define	SPI_READ_BUFFERSIZE		128
//#define	SPI_WRITE_BUFFERSIZE		128

#pragma used+
/*  --------------------------------------------------------------------------------
 *	SPI Buffer structure
 *  -------------------------------------------------------------------------------- */
typedef struct{
	U8				*rbuffer;			// read data buffer
	U8			   	rtop;				// read top pointer
	U8				rbottom;			// read bottom pointer
	U8				rgap;				// read gap
	U8				*wbuffer;			// write data buffer
	U8			   	wtop;				// write top pointer
	U8				wbottom;	  		// write bottom pointer
	U8				wgap;				// write gap
} SPI_BUFFER;

void	spi_buffer_enable(U8 mode);
U8	spi_buffer_isdata(void);
U8	spi_buffer_data_free(void);
char	spi_buffer_read(void);
void	spi_buffer_write(char data);
U8 	spi_buffer_write_data(U8 *data, U8 size);
U8 	spi_buffer_read_data(U8 *data, U8 size);
void	spi_buffer_puts(char *string);
void	spi_buffer_putsf(char flash *string);
void	spi_buffer_clear(void);
void 	spi_buffer_test(U8 pos);

#pragma used-

#endif		// end of spi_buffer.h
