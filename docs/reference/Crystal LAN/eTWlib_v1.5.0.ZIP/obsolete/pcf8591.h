// ************************************************************************************************
///
/// 			\file pcf8591.h
///
///  Functions for PCF8591
///
/// \par Created 	12.05.2003
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************


#ifndef _PCF8591_INCLUDED_
#define _PCF8591_INCLUDED_

//---------------------------------------------------------------------------
//	PCF8591 addess macros
//---------------------------------------------------------------------------
#define	PCF8591_ADDRESS		0b10010010	// Address-byte of PCF8591
#define	PCF8591_READ		0x01		// Read-bit
#define	PCF8591_WRITE		0x00		// Write-bit

//---------------------------------------------------------------------------
//	PCF8591 control macros
//---------------------------------------------------------------------------
#define	PCF8591_DA_ENABLE	0x40		// enable analogue output
#define	PCF8591_AD_00		0x00		// 4 single ended ad channels
#define	PCF8591_AD_01		0x10		// 3 differential ad channels
#define	PCF8591_AD_10		0x20		// 2 single ended 1 differential ad channels
#define	PCF8591_AD_11		0x30		// 2 full differential ad channels
#define	PCF8591_AUTO_INC	0x04		// auto increment mode
#define	PCF8591_AD_CH0		0x00		// A/D channel 0
#define	PCF8591_AD_CH1		0x01		// A/D channel 1
#define	PCF8591_AD_CH2		0x02		// A/D channel 2
#define	PCF8591_AD_CH3		0x03		// A/D channel 3

#pragma used+

unsigned char 	pcf8591_init(unsigned char control);
unsigned char 	pcf8591_write_da(unsigned char da_value);
unsigned char 	pcf8591_read_ad(unsigned char *ad_value);

#pragma used-

#endif		// #ifndef _PCF8591_INCLUDED_

