// ************************************************************************************************
///
/// 			\file dcf77.h
///
///  control-functions to read DCF77-Data
///
/// \par Created 	01.11.2002
/// \date	 		$LastChangedDate: 2007-01-15 12:56:42 +0100 (Mo, 15 Jan 2007) $
/// \version 		$Rev: 490 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#ifndef _ELV_DCF77_INCLUDED_
#define _ELV_DCF77_INCLUDED_

//#define	ELV_DCF77_DEBUG

#define DCF77_1MS		(_MCU_CLOCK_FREQUENCY_/256)DIV 1000

#if(_MCU_CLOCK_FREQUENCY_==4000000)
// values calculate with 4.00 Mhz (Internal RC Ozci)
// 16bit-Timer1 with Prescale=4 --> XTAL/256	--> 64�sec per clock
#define	DCF77_MIN_L		1093	//  1093 * 64�s = 70,00ms
#define	DCF77_MAX_L		2031	//  2031 * 64�s = 130,00ms
#define	DCF77_MIN_H		2656  	//  2656 * 64�s = 170,00ms
#define	DCF77_MAX_H		3593	//  3593 * 64�s = 230,00ms

#define	DCF77_MAX_SIG	4000	//  4000 * 64�s = 256,00ms

#define	DCF77_MIN_1SEC	14843	// 14843 * 64�s = 950,00ms
#define	DCF77_MAX_1SEC	16406	// 16406 * 64�s = 1050,00ms

#define	DCF77_MIN_2SEC	30468	// 30468 * 64�s = 1950,00ms
#define	DCF77_MAX_2SEC	32031	// 32031 * 64�s = 2050,00ms
#endif

#if(_MCU_CLOCK_FREQUENCY_==3686400)
// values calculate with 3.6864 Mhz (Internal RC Ozci)
// 16bit-Timer1 with Prescale=4 --> XTAL/256	--> 69,4�sec per clock
#define	DCF77_MIN_L		1009	//  1009 * 69,4�s = 70,00ms
#define	DCF77_MAX_L		1873	//  1873 * 69,4�s = 130,00ms
#define	DCF77_MIN_H		2450  	//  2450 * 69,4�s = 170,00ms
#define	DCF77_MAX_H		3314	//  3314 * 69,4�s = 230,00ms

#define	DCF77_MAX_SIG	3689	//  3689 * 69,4�s = 256,00ms

#define	DCF77_MIN_1SEC	13689	// 13689 * 69,4�s = 950,00ms
#define	DCF77_MAX_1SEC	15130	// 15130 * 69,4�s = 1050,00ms

#define	DCF77_MIN_2SEC	28098	// 28098 * 69,4�s = 1950,00ms
#define	DCF77_MAX_2SEC	29539	// 29539 * 69,4�s = 2050,00ms
#endif

#define	DCF77_ON		PORTD|=0x20  		// PortD.5 DCF77
#define	DCF77_OFF		PORTD&=~0x20  		// PortD.5 DCF77
#define	DCF77_PORT		PORTD.5==1 		// DCF77 ON?
#define	DCF77_DATA		PINE.6	   		// PINE.6

#define DCF77_TIMEOUT	7*60*100	 	// power off at latest after 5min

#define	SUMMER_TIME		0xaa			// flag for summer time (0xaa==summer time; 0x55==winter time)
#define	WINTER_TIME		0x55			// flag for summer time (0xaa==summer time; 0x55==winter time)
#define	UNKNOWN_TIME	0x00			// flag for unknown time

typedef struct 
	{
	unsigned char	second;			// 0..59 second
	unsigned char	minute;			// 0..59 minutes
	unsigned char	hour;			// 0..23 hours
	unsigned char	day;			// 1..31 days
	unsigned char	weekday;		// 1..7 weekdays
	unsigned char	month;			// 1..12 month
	unsigned char	year;			// 0..255 years
	unsigned char	ok;				// ok flag of dcf77 time
	unsigned char	newdcf77;		// flag to handle overflow of seconds (1==new dcf77 time; 0==no new one)
	unsigned char	run;			// flag to display the activity of DCF77 (1==running; 0==stops)
	unsigned char	mesz;			// flag for summer time (0xaa==summer time; 0x55==winter time)
	}DCF77_DATE;

#pragma used+
extern DCF77_DATE  		dcf77_date;
extern unsigned char 	dcf77_counter_bit;
extern const unsigned char weekday_string[8,3];

unsigned char	elv_dcf77_do_cmd(unsigned char *command);
void elv_dcf77_read(void);
unsigned char elv_dcf77_calculate(void);
void elv_dcf77_step_time(void);
void elv_dcf77_power_on(void);
void elv_dcf77_power_off(void);
#pragma used-

#endif


