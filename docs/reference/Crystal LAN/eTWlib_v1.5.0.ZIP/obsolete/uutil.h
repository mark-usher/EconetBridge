// ************************************************************************************************
///
/// \file 			uutil.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Carsten K�gler, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _UUTIL_INCLUDED_
#define _UUTIL_INCLUDED_


#include "project.h"
#include "debug.h"

//#define	UUTIL_IRQ
//#define	UUTIL_DOUBLE_SPEED
//#define	UUTIL_DEBUG
//#define	UUTIL_UART0
//#define	UUTIL_UART1

#ifdef UUTIL_DEBUG
	#ifndef UUTIL_STATUS
	#define UUTIL_STATUS
	#endif
#endif

#if defined(UUTIL_UART0) && defined(UUTIL_UART1)
	#define UUTIL_UART_DEVICE_COUNT	2
	typedef enum{
		UUTIL_UART_DEVICE_0,
		UUTIL_UART_DEVICE_1
	} UUTIL_UART_DEVICE;
#else
	#define UUTIL_UART_DEVICE_COUNT	1
		#if defined(UUTIL_UART0)
		typedef enum{
			UUTIL_UART_DEVICE_0
		} UUTIL_UART_DEVICE;
	#elif defined(UUTIL_UART1)
		typedef enum{
			UUTIL_UART_DEVICE_1
		} UUTIL_UART_DEVICE;
	#else
		#error "UUTIL no uart specified!"
	#endif   // #if defined(UUTIL_UART0)
#endif   // #if defined(UUTIL_UART0) && defined(UUTIL_UART1) 

#ifndef UUTIL_READ_BUFFER_SIZE
#define	UUTIL_READ_BUFFER_SIZE		64
#endif

#ifndef UUTIL_WRITE_BUFFER_SIZE
#define	UUTIL_WRITE_BUFFER_SIZE		64
#endif

#ifdef UUTIL_DOUBLE_SPEED
#define UUTIL_DIVIDER	8
#else
#define UUTIL_DIVIDER	16
#endif

#if ((_MCU_CLOCK_FREQUENCY_==3686400)||(_MCU_CLOCK_FREQUENCY_==7372800))
#define	UUTIL_BAUD_DIV_230400	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/230400-1
#define	UUTIL_BAUD_DIV_115200	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/115200-1
#define	UUTIL_BAUD_DIV_76800	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/76800-1
#define	UUTIL_BAUD_DIV_57600	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/57600-1
#define	UUTIL_BAUD_DIV_38400	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/38400-1
#define	UUTIL_BAUD_DIV_28800	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/28800-1
#define	UUTIL_BAUD_DIV_19200	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/19200-1
#define	UUTIL_BAUD_DIV_14400	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/14400-1
#define	UUTIL_BAUD_DIV_9600		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/9600-1
#endif


#if (_MCU_CLOCK_FREQUENCY_==2000000)
#define	UUTIL_BAUD_DIV_9600		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/9600-1
#define	UUTIL_BAUD_DIV_4800		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/4800-1
#define	UUTIL_BAUD_DIV_2400		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/2400-1
#endif

#if (_MCU_CLOCK_FREQUENCY_==4000000)
#define	UUTIL_BAUD_DIV_19200	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/19200-1
#define	UUTIL_BAUD_DIV_9600		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/9600-1
#define	UUTIL_BAUD_DIV_4800		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/4800-1
#define	UUTIL_BAUD_DIV_2400		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/2400-1
#endif

#if (_MCU_CLOCK_FREQUENCY_==8000000)
#define	UUTIL_BAUD_DIV_57600	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/57600-1
#define	UUTIL_BAUD_DIV_38400	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/38400-1
#define	UUTIL_BAUD_DIV_19200	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/19200-1
#define	UUTIL_BAUD_DIV_14400	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/14400-1
#define	UUTIL_BAUD_DIV_9600		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/9600-1
#define	UUTIL_BAUD_DIV_4800		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/4800-1
#define	UUTIL_BAUD_DIV_2400		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/2400-1
#endif


#if (_MCU_CLOCK_FREQUENCY_==12000000)
#define	UUTIL_BAUD_DIV_115200	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/115200-1
#define	UUTIL_BAUD_DIV_57600	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/57600-1
#define	UUTIL_BAUD_DIV_38400	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/38400-1
#define	UUTIL_BAUD_DIV_19200	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/19200-1
#define	UUTIL_BAUD_DIV_14400	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/14400-1
#define	UUTIL_BAUD_DIV_9600		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/9600-1
#endif


#if (_MCU_CLOCK_FREQUENCY_==16000000)
#define	UUTIL_BAUD_DIV_115200	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/115200-1
#ifdef UUTIL_DOUBLE_SPEED
#define	UUTIL_BAUD_DIV_57600	0x22
#else
#define	UUTIL_BAUD_DIV_57600	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/57600-1
#endif
#define	UUTIL_BAUD_DIV_38400	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/38400-1
#define	UUTIL_BAUD_DIV_19200	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/19200-1
#define	UUTIL_BAUD_DIV_14400	_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/14400-1
#define	UUTIL_BAUD_DIV_9600		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/9600-1
#define	UUTIL_BAUD_DIV_4800		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/4800-1
#define	UUTIL_BAUD_DIV_2400		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/2400-1
#define	UUTIL_BAUD_DIV_1200		_MCU_CLOCK_FREQUENCY_/UUTIL_DIVIDER/1200-1
#endif

#if(UUTIL_READ_BUFFER_SIZE <= 255)
	#define T_UUTIL_RD_VAR_SIZE	unsigned char
#else
	#define T_UUTIL_RD_VAR_SIZE	unsigned int
#endif
#if(UUTIL_WRITE_BUFFER_SIZE <= 255)
	#define T_UUTIL_WR_VAR_SIZE	unsigned char
#else
	#define T_UUTIL_WR_VAR_SIZE	unsigned int
#endif


//  --------------------------------------------------------------------------------
//	UART Status structure
//  --------------------------------------------------------------------------------             
#ifdef UUTIL_STATUS
typedef struct{
	unsigned int			rcount;				// counter of receive-data
	unsigned int			wcount;				// counter of transmit-data
	unsigned int			rlost;				// counter of lost receive-data
	unsigned int			wlost;				// counter of lost transmit-data
	unsigned char			r_frame_error;		// counter of Receive Frame Error
	unsigned char			r_data_over_run;	// counter of Receive Data OverRun
	unsigned char			r_parity_error;		// counter of Receive Parity Error
} UUTIL_STATUS_STRUCTURE;
#endif

//  --------------------------------------------------------------------------------
//	UART Buffer structure
//  --------------------------------------------------------------------------------
typedef struct{
	unsigned char*			rbuffer;			// read data buffer
	T_UUTIL_RD_VAR_SIZE	    rtop;				// read top pointer
	T_UUTIL_RD_VAR_SIZE	    rbottom;			// read bottom pointer
	T_UUTIL_RD_VAR_SIZE	    rgap;				// read gap
	unsigned char*			wbuffer;			// write data buffer
	T_UUTIL_WR_VAR_SIZE  	wtop;				// write top pointer
	T_UUTIL_WR_VAR_SIZE	    wbottom;	  		// write bottom pointer
	T_UUTIL_WR_VAR_SIZE 	wgap;				// write gap	
#ifdef UUTIL_STATUS
    UUTIL_STATUS_STRUCTURE  status;
#endif
} UUTIL_BUFFER;      

#pragma used+
void		            uutil_init();
void		            uutil_enable(unsigned int baudrate, UUTIL_UART_DEVICE uart_device);
void				    uutil_disable(UUTIL_UART_DEVICE uart_device);
void			        uutil_baudrate(unsigned int baudrate, UUTIL_UART_DEVICE uart_device);
T_UUTIL_RD_VAR_SIZE     uutil_get_rx_count(UUTIL_UART_DEVICE uart_device);
T_UUTIL_WR_VAR_SIZE	    uutil_get_tx_gap(UUTIL_UART_DEVICE uart_device);
char			        uutil_getchar(UUTIL_UART_DEVICE uart_device);
void			        uutil_putchar(unsigned char data, UUTIL_UART_DEVICE uart_device);
void			        uutil_write_data(unsigned char *data, T_UUTIL_WR_VAR_SIZE size, UUTIL_UART_DEVICE uart_device);
void 				    uutil_read_data(unsigned char *data, T_UUTIL_RD_VAR_SIZE size, UUTIL_UART_DEVICE uart_device);
void			        uutil_puts(unsigned char *string, UUTIL_UART_DEVICE uart_device);
void			        uutil_putsf(unsigned char flash *string, UUTIL_UART_DEVICE uart_device);
void			        uutil_putse(unsigned char eeprom *string, UUTIL_UART_DEVICE uart_device);
void			        uutil_putbin(unsigned char bin, unsigned char width, UUTIL_UART_DEVICE uart_device);
void			        uutil_clear_buffer(UUTIL_UART_DEVICE uart_device);
void 				    uutil_clear_rx_buffer(UUTIL_UART_DEVICE uart_device);
void 				    uutil_clear_tx_buffer(UUTIL_UART_DEVICE uart_device);
#ifndef UUTIL_IRQ
void			        uutil_receive_poll(UUTIL_UART_DEVICE uart_device);
void			        uutil_transmit_poll(UUTIL_UART_DEVICE uart_device);
#endif
#ifdef UUTIL_DEBUG
void                    uutil_debug_do_cmd(unsigned char *command);
#endif
#ifdef UUTIL_PARSE_CHAR
unsigned char	        uutil_frames_received(UUTIL_UART_DEVICE uart_device);
#endif                              
#ifdef UUTIL_STATUS
void 				    uutil_get_status(UUTIL_STATUS_STRUCTURE *p_struct, UUTIL_UART_DEVICE uart_device);
void 			        uutil_reset_status(UUTIL_UART_DEVICE uart_device);
#endif
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library uutil.c
#endif

#endif	// #ifndef _UUTIL_INCLUDED_