// ************************************************************************************************
///
///			\file pcf8583_hw.c
///
///  Functions for the Philips PCF8583 I2C bus Real Time Clock
///
/// \par Created 	24.01.2002
/// \date	 		$LastChangedDate: 2007-01-09 14:51:12 +0100 (Di, 09 Jan 2007) $
/// \version 		$Rev: 454 $
/// \author  		Udo Jakobza
/// \par Copyright	(C) 1998-2003 Pavel Haiduc, HP InfoTech S.R.L.

///					modified by
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#include "project.h"

#include <bcd.h>
#include "i2c_hw.h"

#pragma regalloc-
unsigned char __rtc_status;
bit __rtc_alarm;
#pragma regalloc+

//********************************************************************************
// Description	: reads a value from RTC
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
unsigned char rtc_read(unsigned char chip, unsigned char address)
{
unsigned char a;

a=(chip<<1)|0xa0;
i2c_start_hw();
i2c_write_hw(a);
i2c_write_hw(address);
i2c_start_hw();
i2c_write_hw(a|1);
a=i2c_read_hw(0);
i2c_stop_hw();
return a;
}

//********************************************************************************
// Description	: writes a value to RTC
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_write(unsigned char chip, unsigned char address,unsigned char data)
{
i2c_start_hw();
i2c_write_hw((chip<<1)|0xa0);
i2c_write_hw(address);
i2c_write_hw(data);
i2c_stop_hw();
}


//********************************************************************************
// Description	: reads the status from RTC
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
unsigned char rtc_get_status(unsigned char chip)
{
__rtc_status=rtc_read(chip,0);
__rtc_alarm=(__rtc_status & 0x02);
return __rtc_status;
}

//********************************************************************************
// Description	: init of RTC
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_init(unsigned char chip,unsigned char dated_alarm)
{
unsigned char d;

__rtc_status=0;
__rtc_alarm=0;
rtc_write(chip,0,0);
rtc_write(chip,4,rtc_read(chip,4)&0x3f);	// set 24h mode
d=0x90;
if(dated_alarm)
	d=0xb0;
rtc_write(chip,8,d);						// write  
}

//********************************************************************************
// Description	: stops the RTC
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_stop(unsigned char chip)
{
rtc_get_status(chip);
__rtc_status|=0x80;
rtc_write(chip,0,__rtc_status);
}

//********************************************************************************
// Description	: starts the RTC
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_start(unsigned char chip)
{
rtc_get_status(chip);
__rtc_status&=0x7f;
rtc_write(chip,0,__rtc_status);
}

//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_hold_off(unsigned char chip)
{
rtc_get_status(chip);
__rtc_status&=0xbf;
rtc_write(chip,0,__rtc_status);
}

//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_hold_on(unsigned char chip)
{
rtc_get_status(chip);
__rtc_status|=0x40;
rtc_write(chip,0,__rtc_status);
}


//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_alarm_off(unsigned char chip)
{
rtc_get_status(chip);
__rtc_status&=0xfb;
rtc_write(chip,0,__rtc_status);
}


//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_alarm_on(unsigned char chip)
{
rtc_get_status(chip);
__rtc_status|=4;
rtc_write(chip,0,__rtc_status);
}

//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
unsigned char rtc_read_bcd(unsigned char chip,unsigned char addr)
{
return bcd2bin(rtc_read(chip,addr));
}

//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_write_bcd(unsigned char chip,unsigned char addr,unsigned char data)
{
rtc_write(chip,addr,bin2bcd(data));
}

//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_write_word(unsigned char chip,unsigned char addr,unsigned data)
{
rtc_write(chip,addr,(unsigned char) data&0xff);
rtc_write(chip,++addr,(unsigned char)(data>>8));
}

//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_write_date(unsigned char chip,unsigned char addr,unsigned char date, unsigned year)
{
rtc_write(chip,addr,bin2bcd(date)|(((unsigned char) year&3)<<6));
}

//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_get_time(unsigned char chip,unsigned char *hour,unsigned char *min, unsigned char *sec,unsigned char *hsec)
{
rtc_hold_on(chip);
*hsec=rtc_read_bcd(chip,1);
*sec=rtc_read_bcd(chip,2);
*min=rtc_read_bcd(chip,3);
*hour=rtc_read_bcd(chip,4);
rtc_hold_off(chip);
}

//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_set_time(unsigned char chip,unsigned char hour,unsigned char min,unsigned char sec,unsigned char hsec)
{
rtc_stop(chip);
rtc_write_bcd(chip,1,hsec);
rtc_write_bcd(chip,2,sec);
rtc_write_bcd(chip,3,min);
rtc_write_bcd(chip,4,hour);
rtc_start(chip);
}


//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_get_date(unsigned char chip,unsigned char *date,unsigned char *month, unsigned *year)
{
unsigned char dy;
unsigned y1;
rtc_hold_on(chip);
dy=rtc_read(chip,5);
*month=bcd2bin(rtc_read(chip,6)&0x1f);
rtc_hold_off(chip);
*date=bcd2bin(dy&0x3f);
dy>>=6;
y1=rtc_read(chip,0x10)|((unsigned) rtc_read(chip,0x11)<<8);
if (((unsigned char) y1&3)!=dy) rtc_write_word(chip,0x10,++y1);
*year=y1;
}


//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_set_date(unsigned char chip,unsigned char date,unsigned char month, unsigned year)
{
rtc_write_word(chip,0x10,year);
rtc_stop(chip);
rtc_write_date(chip,5,date,year);
rtc_write_bcd(chip,6,month);
rtc_start(chip);
}

//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_get_alarm_time(unsigned char chip,unsigned char *hour, unsigned char *min,unsigned char *sec,unsigned char *hsec)
{
*hsec=rtc_read_bcd(chip,9);
*sec=rtc_read_bcd(chip,0xa);
*min=rtc_read_bcd(chip,0xb);
*hour=rtc_read_bcd(chip,0xc);
}

//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_set_alarm_time(unsigned char chip,unsigned char hour, unsigned char min,unsigned char sec,unsigned char hsec)
{
rtc_write_bcd(chip,9,hsec);
rtc_write_bcd(chip,0xa,sec);
rtc_write_bcd(chip,0xb,min);
rtc_write_bcd(chip,0xc,hour);
}


//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_get_alarm_date(unsigned char chip,unsigned char *date, unsigned char *month)
{
*date=bcd2bin(rtc_read(chip,0xd)&0x3f);
*month=bcd2bin(rtc_read(chip,0xe)&0x1f);
}

//********************************************************************************
// Description	: 
// Input	   	: none
// Output      	: none
// Indication	: none
//********************************************************************************
void rtc_set_alarm_date(unsigned char chip,unsigned char date, unsigned char month)
{
rtc_write_date(chip,0xd,date,0);
rtc_write_bcd(chip,0xe,month);
}

