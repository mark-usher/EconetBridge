// ************************************************************************************************
///
/// 			\file stk500.c
///
/// This file contains functions for processing stk500 bootloader.
///
/// \par Created 	07.07.2005
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Carsten K�gler, Daniel Matthes
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#include "project.h"

#include <io.h>      
#include <string.h>

#include "bootloader.h"
#include "spm.h"

#ifdef BL_UART_ENABLE
	#include "bl_uart.h"
#endif

#ifdef BL_STK500_PROTOCOL
	#include "stk500.h"
#endif

// ************************************************************************************************
//	STK500 PROTOCOL BOOTLOADER
// ************************************************************************************************
#ifdef BL_STK500_PROTOCOL

#define STK500_MAX_COMMAND_SIZE		275

#pragma regalloc-
unsigned int 			stk500_command_size;
unsigned char 			stk500_seq_number;
unsigned char 			stk_write_cmd_checksum;
unsigned char			tempbuffer[256];
unsigned char			sign = 0;
unsigned char			signature[3] = {0x1E,0x97,0x02};
#pragma regalloc+

// ************************************************************************************************
//	ProgramFlash-ISP-Command-Structure
// ************************************************************************************************
typedef struct
	{
	unsigned char	cmd;			// Command
	unsigned int	num_bytes;
	unsigned char	mode;
	unsigned char	delay;
	unsigned char	cmd_byte[3];
	unsigned char	poll_1;
	unsigned char	poll_2;
	unsigned char	data[256];
	} STK500_PROG_MEMORY_STRUCT;

// ************************************************************************************************
//	ReadFlash-ISP-Command-Structure
// ************************************************************************************************
typedef struct
	{
	unsigned char	cmd;			// Command
	unsigned int	num_bytes;
	unsigned char	cmd_byte;
	} STK500_READ_MEMORY_STRUCT;

// ************************************************************************************************
//	SPI-Multi-ISP-Command-Structure
// ************************************************************************************************
typedef struct
	{
	unsigned char	cmd;			// Command
	unsigned char	num_tx;
	unsigned char	num_rx;
	unsigned char	rx_start_add;
	unsigned int	tx_data[128];
	} STK500_SPI_MULTI_STRUCT;

// ************************************************************************************************
//	ProgammFuseBits & ProgammLockBits-ISP-Command-Structure
// ************************************************************************************************
typedef struct
	{
	unsigned char	cmd;			// Command
	unsigned int	cmd_byte[2];
	} STK500_PROG_BITS_STRUCT;

// ************************************************************************************************
//	ReadFuseBits & ReadLockBits-ISP-Command-Structure
// ************************************************************************************************
typedef struct
	{
	unsigned char	cmd;			// Command
	unsigned char	ret_address;
	unsigned int	cmd_byte[2];
	} STK500_READ_BITS_STRUCT;

union
	{
	unsigned char 				stk500_command_buffer[STK500_MAX_COMMAND_SIZE];
	STK500_PROG_MEMORY_STRUCT 	prog_mem_struct;
	STK500_READ_MEMORY_STRUCT	read_mem_struct;
	STK500_SPI_MULTI_STRUCT		spi_multi_struct;	
	STK500_PROG_BITS_STRUCT		prog_bits_struct;
	STK500_READ_BITS_STRUCT		read_bits_struct;
	} sharedbufs;
	
	#define STK500_COMMAND_BUFFER   sharedbufs.stk500_command_buffer
	#define	PROG_NUM_BYTES			sharedbufs.prog_mem_struct.num_bytes	
	#define PROG_DATA           	sharedbufs.prog_mem_struct.data
	#define PROG_MODE				sharedbufs.prog_mem_struct.mode
	#define READ_NUM_BYTES      	sharedbufs.read_mem_struct.num_bytes
	#define TX_DATA		        	sharedbufs.spi_multi_struct.tx_data
	#define PROG_CMD_BYTES    		sharedbufs.prog_bits_struct.cmd_byte
	#define READ_CMD_BYTES      	sharedbufs.read_bits_struct.cmd_byte
                                    
// ************************************************************************************************
/// \brief  	function transmit response-bytes and calculate response-checksum
/// @param[in]	data - one byte of response
// ************************************************************************************************

void stk500_write_command_byte(unsigned char data)
{
loader_uart_putchar(data);
stk_write_cmd_checksum ^= data;
}


// ************************************************************************************************
/// \brief  	function initialize response and send the first response-bytes
/// @param[in]	size - size of responce
// ************************************************************************************************
void stk500_write_command_start(unsigned int size)
{
stk_write_cmd_checksum = 0x0;
stk500_write_command_byte(MESSAGE_START);
stk500_write_command_byte(stk500_seq_number);
stk500_write_command_byte(size>>8);
stk500_write_command_byte(size);
stk500_write_command_byte(TOKEN);
}


// ************************************************************************************************
/// \brief  	function transmit standart answer
///
// ************************************************************************************************
void stk500_send_standard_answer(void)
{
stk500_write_command_start(2);
stk500_write_command_byte(STK500_COMMAND_BUFFER[0]);
stk500_write_command_byte(STATUS_CMD_OK);
loader_uart_putchar(stk_write_cmd_checksum);
}


// ************************************************************************************************
/// \brief  	function transmit device sign
/// 
// ************************************************************************************************
void stk500_send_sign_on_answer(void)
{
stk500_write_command_start(11);
stk500_write_command_byte(STK500_COMMAND_BUFFER[0]);
stk500_write_command_byte(STATUS_CMD_OK);
stk500_write_command_byte(8);
stk500_write_command_byte(0x41);    						// AVRISP_2
stk500_write_command_byte(0x56);
stk500_write_command_byte(0x52);
stk500_write_command_byte(0x49);
stk500_write_command_byte(0x53);
stk500_write_command_byte(0x50);
stk500_write_command_byte(0x5F);
stk500_write_command_byte(0x32);
loader_uart_putchar(stk_write_cmd_checksum);
}


// ************************************************************************************************
/// \brief  	function transmit signature
/// 
// ************************************************************************************************
void stk500_send_signature_answer(void)
{
stk500_write_command_start(4);
stk500_write_command_byte(STK500_COMMAND_BUFFER[0]);
stk500_write_command_byte(STATUS_CMD_OK);
stk500_write_command_byte(signature[sign++]);
stk500_write_command_byte(STATUS_CMD_OK);
loader_uart_putchar(stk_write_cmd_checksum);
}


// ************************************************************************************************
/// \brief  	function transmit param
/// 
// ************************************************************************************************
void stk500_send_getparam_answer(void)
{
stk500_write_command_start(3);
stk500_write_command_byte(STK500_COMMAND_BUFFER[0]);
stk500_write_command_byte(STATUS_CMD_OK);
stk500_write_command_byte(tempbuffer[0]);
loader_uart_putchar(stk_write_cmd_checksum);
}


// ************************************************************************************************
/// \brief  	function transmit EEPROM or FLASH read answer
/// 
// ************************************************************************************************
void stk500_send_read_answer(void)
{
unsigned char i = 0;

stk500_write_command_start(READ_NUM_BYTES+3);
stk500_write_command_byte(STK500_COMMAND_BUFFER[0]);
stk500_write_command_byte(STATUS_CMD_OK);
do 
	{
   	stk500_write_command_byte(tempbuffer[i++]);
   	}
while(--READ_NUM_BYTES);
stk500_write_command_byte(STATUS_CMD_OK);
loader_uart_putchar(stk_write_cmd_checksum);
}


// ************************************************************************************************
/// \brief  	function transmit programm fuse- or lockbits answer
///
// ************************************************************************************************
void stk500_send_progbits_answer(void)
{
stk500_write_command_start(3);
stk500_write_command_byte(STK500_COMMAND_BUFFER[0]);
stk500_write_command_byte(STATUS_CMD_OK);
stk500_write_command_byte(STATUS_CMD_OK);
loader_uart_putchar(stk_write_cmd_checksum); 
}


// ************************************************************************************************
/// \brief  	function transmit read lock- or fusebits
/// 
// ************************************************************************************************
void stk500_send_readbits_answer(void)
{
stk500_write_command_start(4);
stk500_write_command_byte(STK500_COMMAND_BUFFER[0]);
stk500_write_command_byte(STATUS_CMD_OK);
stk500_write_command_byte(tempbuffer[0]);
stk500_write_command_byte(STATUS_CMD_OK);
loader_uart_putchar(stk_write_cmd_checksum);
}


// ************************************************************************************************
/// \brief  	function execute the stk500-message-format
/// @retval		receiving status
// ************************************************************************************************
STK500_READ_CMD_RESULT bootloader_stk500_read_command(void)
{
static STK500_READ_CMD_STATE	uart_state=ST_EXP_START;
static unsigned char			data_length_exp;
static unsigned char			checksum_tmp;
unsigned char					new_data;

while(LOADER_UART_RXC_BIT)
{
new_data = loader_uart_getchar();
	
switch (uart_state)
	{
	case ST_EXP_START:
		if (new_data==MESSAGE_START)
			{
			checksum_tmp=MESSAGE_START;
			uart_state=ST_EXP_SEQ;
			}
	break;
		
	case ST_EXP_SEQ:
		checksum_tmp^=new_data;
		stk500_seq_number = new_data;
		uart_state = ST_EXP_SIZE_MSB;
	break;
			
	case ST_EXP_SIZE_MSB:
		checksum_tmp^=new_data;
		data_length_exp = (unsigned int)new_data<<8;
		uart_state = ST_EXP_SIZE_LSB;
	break;
			
	case ST_EXP_SIZE_LSB:
		checksum_tmp^=new_data;
		data_length_exp |= (unsigned int)new_data;
		if (data_length_exp==0x00)
			{
			uart_state = ST_EXP_START;
			return STK_ERROR;
			}
		else
			uart_state = ST_EXP_TOKEN;
	break;
			
	case ST_EXP_TOKEN:
		checksum_tmp^=new_data;
		if (new_data!=TOKEN)
			{
			uart_state = ST_EXP_START;
			return STK_ERROR;
			}
		else
			{
			stk500_command_size = 0;
			uart_state = ST_EXP_DATA;
			}
	break;
			
	case ST_EXP_DATA:
		checksum_tmp^=new_data;
		STK500_COMMAND_BUFFER[stk500_command_size] = new_data;
		stk500_command_size++;
		if (stk500_command_size==data_length_exp)
			uart_state = ST_EXP_CHECKSUM;
	break;
		
	case ST_EXP_CHECKSUM:
		uart_state = ST_EXP_START;		// error -> wrong checksum
		if (checksum_tmp != new_data)
			return STK_ERROR;
		else
			return STK_NEW_CMD;
	break;
			
	default:
	}
}
return STK_WAIT;
}

// ************************************************************************************************
/// \brief  	function execute the STK500-protocol from ATMEL
///
// ************************************************************************************************
void bootloader_stk500_protocol(void)
{
STK500_READ_CMD_RESULT 		read_result = STK_WAIT;
unsigned int 				size;
static unsigned int			offset = 0;
static unsigned long 		address;
	
read_result = bootloader_stk500_read_command();

if (read_result!=STK_WAIT)
    {
    if (read_result==STK_NEW_CMD)
        {
        switch (STK500_COMMAND_BUFFER[0])
      		{
      		case CMD_SIGN_ON:
      			{
      			stk500_send_sign_on_answer();			// send answer	
				break;
				}
      		
      		case CMD_READ_SIGNATURE_ISP:
      		    {
      			if(sign==3) 
      				sign=0;
      		      					     		
      			stk500_send_signature_answer();			// send answer
      			break;
				}
      		
      		case CMD_SET_PARAMETER:
      		    {    
				stk500_send_standard_answer();			// send answer
				break;
				}
      	       
       		case CMD_GET_PARAMETER:
      	       	{	
      	    	switch(STK500_COMMAND_BUFFER[1])		// parameter number
					{
					case 0x90:          	//PARAM_HW_VER
						tempbuffer[0] = 0x01;
						break;
				
					case 0x91: 	
						tempbuffer[0] = 0x02;		//PARAM_SW_MAJOR
						break;
				
					case 0x92:
				    	tempbuffer[0] = 0x00;		//PARAM_SW_MINOR
						break;
					
					default:				//PARAM_CONTROLLER_INIT, PARAM_TOPCARD_DETECT
						tempbuffer[0] = 0x00;
					}
								        						
				stk500_send_getparam_answer();					// send answer
				break;
	    		}					
      		
       		case CMD_ENTER_PROGMODE_ISP:
      		    {      			      					     		        
      			stk500_send_standard_answer();					// send answer
				break;
				}      			
      		
      		case CMD_LEAVE_PROGMODE_ISP:
      			{
      			stk500_send_standard_answer();					// send answer
				// Start the Watchdog Timer 
				#asm("wdr");
				WDTCR = 0x18;
				WDTCR = 0x0F;									// WDE and WDP 2..0 set
                while(1);
				break;
				}
      		
      		case CMD_CHIP_ERASE_ISP:
      		    {  		      		        
      	    	stk500_send_standard_answer();					// send answer
				break;
				}

			case CMD_LOAD_ADDRESS:
      			{
      			address |= STK500_COMMAND_BUFFER[2];
	   			address <<= 8;
	   			address |= STK500_COMMAND_BUFFER[3];
		   		address <<= 8;
		   		address |= STK500_COMMAND_BUFFER[4];
	   			       		      			
      			stk500_send_standard_answer();					// send answer
				break;
				}
      		
      		case CMD_PROGRAM_FLASH_ISP:
				{
				unsigned int *pagebuffer_pointer_int = (unsigned int *)tempbuffer;
				unsigned long temp2;
								
				PROG_NUM_BYTES = BL_SWAPB(PROG_NUM_BYTES);
			    			
				if (PROG_MODE&0x01)		//page mode
					{
					//load page
					
					for(size=0; size<PROG_NUM_BYTES;size++)
						{
						tempbuffer[((unsigned char)(address << 1))+size] = PROG_DATA[size];
						}
					offset++;
										
					SPM_ERASEPAGE((address << 1));
					
					temp2 = 0;
					size = BL_PAGE_SIZE/2;
										
					do
						{
						#asm("wdr");
						
						SPM_WRITEWORD(temp2, *pagebuffer_pointer_int++);
						temp2 += 2;
						}
					while (--size);
					
					SPM_PROGRAMPAGE((address << 1));
					}
				
				if (offset==2)
					{ 
					for(size=0;size<BL_PAGE_SIZE;size++)
						tempbuffer[size] = 0xff;
					}
							
				address += BL_PAGE_SIZE/4;
					
				stk500_send_standard_answer();					// send answer	
				break;
				}
			
			case CMD_PROGRAM_EEPROM_ISP:
				{
				PROG_NUM_BYTES = BL_SWAPB(PROG_NUM_BYTES);
								
				for(size=0;size<PROG_NUM_BYTES;size++)
        			{
        			spm_eewritebyte((unsigned int)address++, PROG_DATA[size]);
        			}
        		
        		stk500_send_standard_answer();					// send answer
				break;
				}
      		
      		case CMD_READ_FLASH_ISP:
      			{
				READ_NUM_BYTES = BL_SWAPB(READ_NUM_BYTES);
      			     			     			
      			SPM_READFLASH(tempbuffer, (address << 1), READ_NUM_BYTES);
				
				address += BL_PAGE_SIZE/2;
      	      	  
				stk500_send_read_answer();						// send answer
				break;
		        }
		        
			case CMD_READ_EEPROM_ISP:
			 	{
				READ_NUM_BYTES = BL_SWAPB(READ_NUM_BYTES);
                
                	        
	        	for (size=0;size<READ_NUM_BYTES;size++)
        			{
        			spm_eeread(&tempbuffer[size], (unsigned int)address++);
        			}
         	          	                              
				stk500_send_read_answer();						// send answer
				break;
				}
				
			case CMD_PROGRAM_FUSE_ISP:
 				{     		
      			stk500_send_progbits_answer(); 					// send answer 
      			break;
      			}
      			     			
      		case CMD_READ_FUSE_ISP:
      			{
      		    switch(READ_CMD_BYTES[0])
      				{
      				// read fuse or lock bits (Code Vision)
      				case 0x0050:
      					{
      			        tempbuffer[0] = spm_readfuselockbits(0x0000);		//LOW-FUSE
      			        break;
      			        }
      			  	case 0x0850:
      			    	{
      			    	tempbuffer[0] = spm_readfuselockbits(0x0002);		//EXT-FUSE
      			    	break;
      			    	}
      			   	case 0x0858:
      			    	{
      			    	tempbuffer[0] = spm_readfuselockbits(0x0003);		//HIGH-FUSE
      			    	break;
      			    	}
      			    default:
      				}
      		          		    
      			stk500_send_readbits_answer();	   	    		// send answer
      			break;
      			}	
      			
      		case CMD_PROGRAM_LOCK_ISP:
      			{
      		   	if(PROG_CMD_BYTES[0]==0xe0ac)					//BOOT-LOCK
      		   		{
      		   		spm_writelockbits(((unsigned char)(PROG_CMD_BYTES[1] >> 8)));
      		   		}	
      			
      			stk500_send_progbits_answer();          		// send answer
      			break;
      			}
      		     	
      		case CMD_READ_LOCK_ISP:
      		    {
      		    if (READ_CMD_BYTES[0]==0x0058)
      			   	tempbuffer[0]=spm_readfuselockbits(0x0001);		//BOOT-LOCK
      			      		
      			stk500_send_readbits_answer();					// send answer	
      			break;
      			}
      	         	      		    		
      		case CMD_SPI_MULTI:
      		    {
				switch(TX_DATA[0])
      				{
      				// read fuse or lock bits (Code Vision)
      				case 0x0050:
      					{
      			        tempbuffer[0] = spm_readfuselockbits(0x0000);		//LOW-FUSE
      			        break;
      			        }
      			  	case 0x0850:
      			    	{
      			    	tempbuffer[0] = spm_readfuselockbits(0x0002);		//EXT-FUSE
      			    	break;
      			    	}
      			   	case 0x0058:
      			    	{
      			    	tempbuffer[0] = spm_readfuselockbits(0x0001);		//BOOT-LOCK
      			    	break;
      			    	}
      			  case 0x0858:
      			    	{
      			    	tempbuffer[0] = spm_readfuselockbits(0x0003);		//HIGH-FUSE
      			    	break;
      			    	}
      			    // write lock bits (Code Vision)
      			    case 0xe0ac:                     			 			//BOOT-LOCK
      			    	{
						spm_writelockbits(((unsigned char)(TX_DATA[1] >> 8)));
      					break;
      					}
      				default:
      				}
      			     		
      			stk500_send_readbits_answer();          // send answer
	    		break;
	    		}
	                		
     		default:
      		}
      	}
	}
}


#endif			// #ifdef BL_STK500_PROTOCOL

