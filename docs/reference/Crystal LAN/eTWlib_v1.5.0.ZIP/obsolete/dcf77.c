// ************************************************************************************************
///
/// 			\file dcf77.c
///
///  control-functions to read DCF77-Data
///
/// \par Created 	01.11.2002
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#include <stdio.h>
#include "bcd.h"
#include "elv_main.h"
#include "dcf77.h"

#pragma regalloc-
DCF77_DATE		dcf77_date;
unsigned char 	dcf77_counter_bit=0;
unsigned long 	dcf77_timeout;
#pragma regalloc+

const unsigned char weekday_string[8,3]={{"XX"},{"MO"},{"DI"},{"MI"},{"DO"},{"FR"},{"SA"},{"SO"}};
unsigned char dcf_buffer[38];

void elv_dcf77_sync_sec(void);


// **********************************************************************************
// Description	: displays the DCF77-info
// Input	   	: none
// Output      	: none
// Indication	: none
// **********************************************************************************
void elv_debug_dcf77(void)
{
unsigned char mesz_buffer='X';
unsigned char mode_buffer=' ';

rs232_driver_on();
if(dcf77_date.run==1)  		// flag to display the activity of DCF77
	mode_buffer=0xb7;
else if(dcf77_date.ok==1)
	mode_buffer=0xae;       // Spezialzeichen
if(dcf77_date.mesz==SUMMER_TIME)	// flag for summer time (0xaa==summer time; 0x55==winter time)
	mesz_buffer='S';
else if(dcf77_date.mesz==WINTER_TIME)
	mesz_buffer='W';
printf("%c %c-%02u:%02u:%02u", mode_buffer, mesz_buffer, dcf77_date.hour, dcf77_date.minute, dcf77_date.second);
if(dcf77_date.run==1)
	printf("(%u)\n\r", dcf77_counter_bit);
else
	printf("\n\r");
printf("%p-%u.%u.%u\n\r", &weekday_string[dcf77_date.weekday,0], dcf77_date.day, dcf77_date.month, (unsigned int)(dcf77_date.year+2000));

printf("dcf77_date.ok:%u\n\r", dcf77_date.ok);				// ok flag of dcf77 time
printf("dcf77_date.newdcf77:%u\n\r", dcf77_date.newdcf77);	// flag to handle overflow of seconds (1==new dcf77 time; 0==no new one)
printf("dcf77_date.run:%u\n\r", dcf77_date.run);			// flag to display the activity of DCF77 (1==running; 0==stops)
printf("dcf77_date.mesz:%u\n\r", dcf77_date.mesz);			// flag for summer time (0xaa==summer time; 0x55==winter time)

printf("dcf77 power ");
if(DCF77_PORT)
	putsf("ON\n\r");
else
	putsf("OFF\n\r");
}



// **********************************************************************************
// Description   : debug-frontend for DCF77-functions
// Input         : *command: pointer to command 
// Output     	 : 0: doesn't serve the command
// 		     	   1: serves the command
// Indication	 : none
// **********************************************************************************
unsigned char	elv_dcf77_do_cmd(unsigned char *command)
{
if(strncmpf(command, "dcf77-info", 7)==0)
	{
	elv_debug_dcf77();
	return 1;
	}
if(strncmpf(command, "dcf77-reset", 7)==0)
	{
	elv_dcf77_power_on();
	putsf("Restart DCF77\r");
	return 1;
	}
return 0;
}

//********************************************************************************
// Description	: DCF77 read function
// Input	   	: none
// Output     	: none
// Indication	: none
//********************************************************************************
void elv_dcf77_read(void)
{
static unsigned char start_bit=1;
static unsigned char start_frame=1;
static unsigned char start_data=1;
static unsigned char counter_data=0;
static unsigned char z1_bit=0xff;
static unsigned char z2_bit=0xff;

if(dcf77_date.ok)
	{
	dcf77_date.run=0;          // flag to display the activity of DCF77
	return;
	}
if(dcf77_timeout<counter_10ms_32bit)
	{
	#ifdef ELV_DCF77_DEBUG
	rs232_driver_on();
	putsf("DCF77 timeout\r");
	#endif
	elv_dcf77_power_off();
	dcf77_date.ok=1;			// stop of DCF77 function
	return;
	}
if(DCF77_DATA==1)  		// PINE.6
	{
	#ifdef ELV_DCF77_DEBUG
	rs232_driver_on();
	#endif
	if(TIFR & 0x04)	 		// Timer2 Overflow-Flag
		dcf77_date.run=0;   // flag to display the activity of DCF77
	if(start_bit==1) return;
	if((TCNT1>DCF77_MIN_L)&&(TCNT1<DCF77_MAX_L))	// find 100ms signal
		{
		#ifdef ELV_DCF77_DEBUG
		printf("%2u L: %ums\n\r", dcf77_counter_bit, (TCNT1*8)/125);
		#endif
		if(start_frame==0)
			{
			if(start_data==0)
				{
				dcf_buffer[counter_data]=0;	
				counter_data++;
				if(counter_data>sizeof(dcf_buffer))
					counter_data=0;
				}
			if(dcf77_counter_bit==17)	// find Z1 bit
				z1_bit=0;
			if(dcf77_counter_bit==18)	// find Z2 bit
				z2_bit=0;
			if(dcf77_counter_bit==58)	// find last valid data-bit (P3)
				{
				#ifdef ELV_DCF77_DEBUG
				putsf("DCF-Frame-End\r");
				#endif
				if(start_data==0)
					{
					elv_dcf77_sync_sec();
					elv_dcf77_calculate();
					}
				start_data=1;
				start_frame=1;
				}
			dcf77_counter_bit++;
			}
		start_bit=1;
		}
	else if((TCNT1>DCF77_MIN_H)&&(TCNT1<DCF77_MAX_H))	// find 200ms signal
		{
		#ifdef ELV_DCF77_DEBUG
		printf("%2u H: %ums\n\r", dcf77_counter_bit, (TCNT1*8)/125);
		#endif
		if(start_frame==0)
			{
			if(start_data==0)
				{
				dcf_buffer[counter_data]=1;	
				counter_data++;
				if(counter_data>sizeof(dcf_buffer))
					counter_data=0;
				}
			if(dcf77_counter_bit==17)	// find Z1 bit
				z1_bit=1;
			if(dcf77_counter_bit==18)	// find Z2 bit
				z2_bit=1;
			if(dcf77_counter_bit==20)	// find Startbit
				{
				if((z1_bit==0)&&(z2_bit==1))	
					dcf77_date.mesz=WINTER_TIME;	// flag for summer time (0xaa==summer time; 0x55==winter time)
				else if((z1_bit==1)&&(z2_bit==0))	
					dcf77_date.mesz=SUMMER_TIME;	// flag for summer time (0xaa==summer time; 0x55==winter time)
				else
					dcf77_date.mesz=UNKNOWN_TIME;			
				#ifdef ELV_DCF77_DEBUG
				putsf("DCF-Frame-Start\r");
				#endif
				start_data=0;
				counter_data=0;
				}
			if(dcf77_counter_bit==58)	// find last valid data-bit (P3)
				{
				#ifdef ELV_DCF77_DEBUG
				putsf("DCF-Frame-End\r");
				#endif
				if(start_data==0)
					{
					elv_dcf77_sync_sec();
					elv_dcf77_calculate();
					}
				start_data=1;
				start_frame=1;
				}
			dcf77_counter_bit++;
			}
		start_bit=1;
		}
	else if(TCNT1>DCF77_MAX_SIG)
		{
		dcf77_date.run=0;   // flag to display the activity of DCF77
		start_bit=1;
		}
	}
else	// Low-Level activ
	{
	if(start_bit==0) return;
	if(TIFR & 0x04)		// Timer2 Overflow-Flag
		{
		TCNT1=0;   		// start counter
		TIFR|=0x04;		// reset Timer1 Overflow-Flag
		start_bit=0;
		start_frame=1;
		start_data=1;
		dcf77_counter_bit=0;
		counter_data=0;
		dcf77_date.run=0;   // flag to display the activity of DCF77
		#ifdef ELV_DCF77_DEBUG
		putsf("DCF-Overflow\r");
		#endif
		}
	else if((TCNT1>DCF77_MIN_1SEC)&&(TCNT1<DCF77_MAX_1SEC))
		{
		dcf77_date.run=1;   // flag to display the activity of DCF77
		TCNT1=0;   			// start counter
		start_bit=0;
		#ifdef ELV_DCF77_DEBUG
		putsf("DCF-bit\r");
		#endif
		}
	else if((TCNT1>DCF77_MIN_2SEC)&&(TCNT1<DCF77_MAX_2SEC))	// find 59. second label
		{
		TCNT1=0;   		// start counter
		start_bit=0;
		start_frame=0;
		dcf77_counter_bit=0;
		start_data=1;
		counter_data=0;
		#ifdef ELV_DCF77_DEBUG
		putsf("DCF-Sync\r");
		#endif
		}
	}
}


//********************************************************************************
// Description	: synchronisation of 32k-Timer with DCF77-clock
// Input	   	: none
// Output     	: none
// Indication	: none
//********************************************************************************
void elv_dcf77_sync_sec(void)
{
#asm("cli");
count_100=0;
dcf77_date.second=58;
#asm("sei");
}


//********************************************************************************
// Description	: calculates the data from serial data
// Input	   	: none
// Output     	: none
// Indication	: none
//********************************************************************************
unsigned char elv_dcf77_calculate(void)
{
unsigned char Lva;
unsigned char shift=0;
unsigned char data_count=0;
unsigned char parity=0;
unsigned char data[6]={0,0,0,0,0,0};		// minute, hour, day, weekday, month, year

for(Lva=0;Lva<=37;Lva++)
	{
	if(Lva==7)	// find parity P1
		{
		if((parity % 2)!=dcf_buffer[Lva])
			{
			#ifdef ELV_DCF77_DEBUG
			printf("P1-Error:%02x %02x %02x %02x %02x %02x\n\r", data[0], data[1], data[2], data[3], data[4], data[5]);
			#endif
			return 0;
			}
		parity=0;
		Lva++;
		data_count++;
		shift=0;
		}
	if(Lva==14)	// find parity P2
		{
		if((parity % 2)!=dcf_buffer[Lva])
			{
			#ifdef ELV_DCF77_DEBUG
			printf("P2-Error:%02x %02x %02x %02x %02x %02x\n\r", data[0], data[1], data[2], data[3], data[4], data[5]);
			#endif
			return 0;
			}
		parity=0;
		Lva++;
		data_count++;
		shift=0;
		}
	if(Lva==21)	// find first bit of weekday
		{
		data_count++;
		shift=0;
		}
	if(Lva==24)	// find first bit of month
		{
		data_count++;
		shift=0;
		}
	if(Lva==29)	// find first bit of year
		{
		data_count++;
		shift=0;
		}
	if(Lva==37)	// find parity P3
		{
		if((parity % 2)!=dcf_buffer[Lva])
			{
			#ifdef ELV_DCF77_DEBUG
			printf("P3-Error:%02x %02x %02x %02x %02x %02x\n\r", data[0], data[1], data[2], data[3], data[4], data[5]);
			#endif
			return 0;
			}
		if(data[4]==0x0)	// month has to >0
			{
			#ifdef ELV_DCF77_DEBUG
			printf("month==0\n\r");
			#endif
			return 0;
			}
		for(Lva=0;Lva<6;Lva++)
			data[Lva]=bcd2bin(data[Lva]);
		memcpy((unsigned char*)&dcf77_date.minute, data, 6);
		dcf77_date.ok=1;
		dcf77_date.newdcf77=1;	// set new DCF77 value flag to prevent second overflow
		#ifdef ELV_DCF77_DEBUG
		printf("OK: %02u:%02u:%02u %p-%u.%u.%u\n\r", dcf77_date.hour, dcf77_date.minute, dcf77_date.second, 
					&weekday_string[dcf77_date.weekday,0], dcf77_date.day, dcf77_date.month, (unsigned int)(dcf77_date.year+2000));
		#endif
		return 1;
		}
	if(dcf_buffer[Lva]==1)
		parity++;
	data[data_count]|=(dcf_buffer[Lva]<<shift);
	shift++;
	}
#ifdef ELV_DCF77_DEBUG
printf("Error:%02x %02x %02x %02x %02x %02x\n\r", data[0], data[1], data[2], data[3], data[4], data[5]);
#endif
return 0;
}


//********************************************************************************
// Description	: steps the time+date with ONE second
// Input	   	: none
// Output     	: none
// Indication	: none
//********************************************************************************
void elv_dcf77_step_time(void)
{
dcf77_date.second++;
if(dcf77_date.second==60)
	{
	dcf77_date.second=0;
	if(dcf77_date.newdcf77==1)	// new DCF77 value
		{
		dcf77_date.newdcf77=0;	// reset new DCF77 value flag
		elv_dcf77_power_off();
		return;
		}
	dcf77_date.minute++;
	if(dcf77_date.minute==60)
		{
		dcf77_date.minute=0;
		dcf77_date.hour++;
		if(dcf77_date.ok==0)		// every hour restart to read the DCF77-data
			elv_dcf77_power_on();	// switch on to change to sommer time
		if(dcf77_date.hour==24)
			{
			dcf77_date.hour=0;
			dcf77_date.day++;
			dcf77_date.weekday++;
			if(dcf77_date.weekday==8)
				dcf77_date.weekday=1;
			if(dcf77_date.day==255)
				dcf77_date.month=0;		// after 255 days with no DCF77-signal
			elv_dcf77_power_on();	// switch on every midnight
			}
		}
	if((dcf77_date.mesz==WINTER_TIME)&&(dcf77_date.hour==1)&&(dcf77_date.minute==59))	// winter time
		{
		elv_dcf77_power_on();	// switch on to change to sommer time
		}
	else if((dcf77_date.mesz==SUMMER_TIME)&&(dcf77_date.hour==2)&&(dcf77_date.minute==59))	// summer time
		{
		elv_dcf77_power_on();	// switch on to change to winter time
		}
	}
}


//********************************************************************************
// Description	: power on of DCF77 Modul
// Input	   	: none
// Output     	: none
// Indication	: none
//********************************************************************************
void elv_dcf77_power_on(void)
{
elv_data_stop();
dcf77_timeout=counter_10ms_32bit;
dcf77_timeout+=DCF77_TIMEOUT;
power_mode|=POWER_DCF77;		// Flag to handle the global power-modes
dcf77_date.ok=0;				// restart of DCF77 function
DCF77_ON;		  				// PortD.5 DCF77
}

//********************************************************************************
// Description	: power on of DCF77 Modul
// Input	   	: none
// Output     	: none
// Indication	: none
//********************************************************************************
void elv_dcf77_power_off(void)
{
elv_data_restart();
DCF77_OFF;		  				// PortD.5 DCF77
power_mode&=~POWER_DCF77;		// Flag to handle the global power-modes
}
