// ************************************************************************************************
///
/// 			\file max5250.c
///
///  Functions for MAX5250
///
/// \par Created 	24.01.2002
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#include "avr_spi.h"
#include "spi_103.h"

#define		LOAD_ALL_DAC	0x80    // A1=1; A0=0; C1=0; C0=0

#pragma used+
#pragma regalloc-

#pragma regalloc+
#pragma used-

/*********************************************************************************
; Description	: initaliation of MAX5250-DAC
; Input	  	 	: none
; Output  	 	: none
; Indication	: none
;*********************************************************************************/
void 	max5250_init(U8 config)
{
// SPCR_SPIE	SPI Interrupt Enable
// SPCR_SPE		SPI Enable
// SPCR_DORD	SPI Data Order 1=LSB; 0=MSB
// SPCR_MSTR	SPI Master/Slave Select
// SPCR_CPOL	SPI Clock Polarity 1=SCK=HIGH; 0=SCK=LOW
// SPCR_CPHA	SPI Clock Phase
// SPCR_128		SPI Clock 1/128 Main-Clock
// SPCR_64		SPI Clock 1/64 Main-Clock
// SPCR_16		SPI Clock 1/16 Main-Clock
// SPCR_4		SPI Clock 1/4 Main-Clock
spi_103_init(config);
max5250_reset();
}

#if funcused max5250_reset
/*********************************************************************************
; Description	: reset the DAC
; Input	   		: none
; Output  	 	: none
; Indication	: none
;*********************************************************************************/
void 	max5250_reset(void)
{
CS_SPI1_LOW;		// PortB.4 /CS_SPI1
spi_write_poll(LOAD_ALL_DAC);
spi_write_poll(0);
CS_SPI1_HIGH;		// PortB.4 /CS_SPI1
}
#endif 


#if funcused max5250_write || funcused max5250_write_m_ampere
/*********************************************************************************
; Description	: write a value to I2C-Channel 0
; Input	  	 	: none
; Output   		: none
; Indication	: none
;*********************************************************************************/
void 	max5250_write(U16 value, U8 channel)
{
U8	data;

value&=0x3ff;		// set to 10bit;
value<<=2;			// expand to 12bit
data=(U8)(value>>8);
data|=channel;
CS_SPI1_LOW;		// PortB.4 /CS_SPI1
spi_write_poll(data);
spi_write_poll((U8)(value & 0xff));
CS_SPI1_HIGH;		// PortB.4 /CS_SPI1
}
#endif



#if funcused max5250_write_m_ampere
/*********************************************************************************
; Description	: set a new milli ampere value
; Input	  	 	: none
; Output 	  	: none
; Indication	: none
;*********************************************************************************/
void 	max5250_write_m_ampere(U8 ampere, U8 channel)
{
U16	value;

value=ampere;
value*=5;
max5250_write(value, channel);
}
#endif 



