// ************************************************************************************************
///
/// 			\file key_4.h
///
///  ATmega103
///
/// \par Created 	21.02.2001
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#ifndef _KEY_4_INCLUDED_
#define _KEY_4_INCLUDED_

#define	KEY1	   			0x01
#define	KEY2	 			0x02
#define	KEY3		 		0x04
#define	KEY4     			0x08
#define	KEY1_RELEASE  		0xf1
#define	KEY2_RELEASE 		0xf4
#define	KEY3_RELEASE 		0xf2
#define	KEY4_RELEASE		0xf8

#define	KEY_UP   			KEY1
#define	KEY_DOWN		 	KEY3
#define	KEY_LEFT 			KEY2
#define	KEY_RIGHT     		KEY4
#define	KEY_UP_RELEASE  	KEY1_RELEASE
#define	KEY_DOWN_RELEASE 	KEY3_RELEASE
#define	KEY_LEFT_RELEASE 	KEY2_RELEASE
#define	KEY_RIGHT_RELEASE	KEY4_RELEASE

#define	KEY_ESC   			KEY1
#define	KEY_D			 	KEY2
#define	KEY_U	 			KEY3
#define	KEY_ENTER    		KEY4
#define	KEY_ESC_RELEASE  	KEY1_RELEASE
#define	KEY_D_RELEASE	 	KEY2_RELEASE
#define	KEY_U_RELEASE	 	KEY3_RELEASE
#define	KEY_ENTER_RELEASE	KEY4_RELEASE

#define	KEY_OPTO2_ENTER     KEY1
#define	KEY_OPTO2_R	       	KEY2
#define	KEY_OPTO2_L	       	KEY3
#define	KEY_OPTO2_ESC       KEY4
#define	KEY_OPTO2_ENTER_REL	KEY1_RELEASE
#define	KEY_OPTO2_R_REL	 	KEY2_RELEASE
#define	KEY_OPTO2_L_REL	 	KEY3_RELEASE
#define	KEY_OPTO2_ESC_REL  	KEY4_RELEASE

#define KEY_CONT				TRUE
#define KEY_PRESSED_COUNTER		5		// count of Timer0 ticks for first key-pressing
#define KEY_CONT_COUNTER		30		// count of Timer0 ticks for continous key-pressing
#define KEY_RELEASED_COUNTER	5		// count of Timer0 ticks for key-realeasing

#pragma used+

void 			key_4_init(void);
unsigned char	key_4_inkey(void);

#pragma used-

#endif

// #pragma library key_4.lib

