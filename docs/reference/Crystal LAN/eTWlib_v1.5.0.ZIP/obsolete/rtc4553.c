// ************************************************************************************************
///
/// 			\file rtc4553.c
///
/// Routines for Interfacing an RTC-4553 from Epson via SPI
///
/// \par Created 	xx.xx.200x
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
/// \author  		Carsten K�gler
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#include "project.h"

#ifdef RTC4553_ENABLE

#include "board.h"	 		// see file "project.h" inside of your project path
#include "rtc4553.h"

#include <mega128.h>
#include <delay.h>
#include <stdio.h>
#include <spi.h>


// SPI Initialisierung - SCK=HIGH und steigende Flanke (MODE 3); LSB first
#define RTC4553_SPI_MODE   SPCR_SPE|SPCR_MSTR|SPCR_64|SPCR_CPOL|SPCR_CPHA|SPCR_DORD


// *********************************************************************************
/// \brief		Initialisierung des RTC-Bausteins
/// 
// *********************************************************************************
void rtc4553_init(void)
{
delay_ms(2);             // RTC wakeup delay

RTC4553_RW_READ;
RTC4553_RW_ACTIV;

RTC4553_SS_HIGH;
RTC4553_SS_ACTIV;
}


// *********************************************************************************
/// \brief		Zur�cksetzen aller Counter
/// 
// *********************************************************************************
void rtc4553_reset_rtc(void)
{
unsigned char tmp;

hardware_get_spi_sema();

hardware_spi_init(RTC4553_SPI_MODE);
RTC4553_RW_WRITE;				// clear bit - Write to rtc
RTC4553_SS_LOW;

tmp = spi(0x8F);                      
RTC4553_SS_HIGH;				// chip select high
delay_us(10);
RTC4553_SS_LOW;					// chip select low
SPI_SCK_PORT = 0;				// SCK LOW
delay_us(10);
RTC4553_SS_HIGH;				// chip select high
   
hardware_release_spi_sema();
}


// *********************************************************************************
/// \brief	   				 vollstaendiges Clock Setup 
/// @param[in] new_sys_time  pointer auf Zeitstruktur
// *********************************************************************************
void rtc4553_set_rtc(t_time* new_sys_time)
{
unsigned char 	tmp;
unsigned int 	i;

rtc4553_reset_rtc();

hardware_get_spi_sema();

hardware_spi_init(RTC4553_SPI_MODE);
RTC4553_RW_WRITE;
RTC4553_SS_LOW;

tmp = spi(0x1D);            // select 24-hour-format    
if (new_sys_time->second)
	for(i=1; i<=new_sys_time->second; i++)
		tmp = spi(0x00);     	// increase second counter
if (new_sys_time->minute)
	for(i=1; i<=new_sys_time->minute; i++)
		tmp = spi(0x02);     	// increase minute counter
if (new_sys_time->hour)
	for(i=1; i<=new_sys_time->hour; i++)
		tmp = spi(0x04);     	// increase hour counter
if (new_sys_time->day)
	for(i=1; i<new_sys_time->day; i++)
		tmp = spi(0x07);   	// increase day counter
if (new_sys_time->month)
	for(i=1; i<new_sys_time->month; i++)
		tmp = spi(0x09);     	// increase month counter
new_sys_time->year -= 2000;
if (new_sys_time->year)
	for(i=1; i<=new_sys_time->year; i++)
		tmp = spi(0x0B);     	// increase year counter
RTC4553_SS_HIGH;

hardware_release_spi_sema();
} 


// *********************************************************************************
/// \brief	   	Gibt an, ob das Busy flag in der RTC gesetzt ist.
///				Es darf nicht von der RTC gelesen werden, wenn in K�rze (3,9ms)
///				Ein Carry (Sekunde vorbei) ansteht.
///	@return		0- not busy / !=0 rtc busy
// *********************************************************************************
unsigned char rtc4553_busy(void)
{
return rtc4553_read_ram(0x0e, RTC4553_MODE0) & 0x08;
}


// *********************************************************************************
/// \brief	   				  Auslesen aller Counter
/// @param[out] new_sys_time  pointer auf Zeitstruktur
///	@return		0- success-no error / !=0 error
// *********************************************************************************
unsigned char rtc4553_read_rtc(t_time* new_sys_time)
{
unsigned char tmp;
unsigned char counter_10ms;
unsigned char timeout_10ms_delay;

timeout_10ms_delay = 2;
counter_10ms = (unsigned char)counter_10ms_16bit;
while (rtc4553_busy())	// while device busy ...
	{
    if (counter_10ms != (unsigned char)counter_10ms_16bit)
    	timeout_10ms_delay--;
    if (timeout_10ms_delay==0)
    	return 1;	// device busy timeout
	}

hardware_get_spi_sema();
hardware_spi_init(RTC4553_SPI_MODE);
RTC4553_RW_READ;
RTC4553_SS_LOW;

tmp = spi(0x0);    
tmp = spi(0x1);    // data from prevoious read access, 1-second digit
tmp >>= 4;
new_sys_time->second = tmp;
tmp = spi(0x2);    // data from prevoious read access, 10-second digit
tmp >>= 4;
new_sys_time->second += tmp*10;                              
tmp = spi(0x3);    // read 1-minute digit
tmp >>= 4;
new_sys_time->minute = tmp;
tmp = spi(0x4);    // read 10-minute digit
tmp >>= 4;
new_sys_time->minute += tmp*10;                              
tmp = spi(0x5);    // read 1-hour digit
tmp >>= 4;
new_sys_time->hour = tmp;
tmp = spi(0x6);    // read 10-hour digit
tmp >>= 4;               
tmp &= ~0x08;      // clear PM/AM Bit
new_sys_time->hour += tmp*10;                                
tmp = spi(0x7);    // read day-of-the-week digit
tmp >>= 4;
tmp = spi(0x8);    // read 1-day digit
tmp >>= 4;
new_sys_time->day = tmp;
tmp = spi(0x9);    // read 10-day digit
tmp >>= 4;
new_sys_time->day += tmp*10;                                 
tmp = spi(0xA);    // read 1-month digit
tmp >>= 4;
new_sys_time->month = tmp;
tmp = spi(0xB);    // read 10-month digit
tmp >>= 4;
new_sys_time->month += tmp*10;                               
tmp = spi(0xC);    // read 1-year digit
tmp >>= 4;
new_sys_time->year = tmp;
tmp = spi(0xC);    // read 10-year digit
tmp >>= 4;
new_sys_time->year += (unsigned int)tmp*10;
new_sys_time->year += 2000;

RTC4553_SS_HIGH;
hardware_release_spi_sema();

return 0;
}

 
// *********************************************************************************
/// \brief	   				 Auslesen der beiden Sekunden Counter
/// @param[out] new_sys_time  pointer auf Zeitstruktur
// *********************************************************************************
void rtc4553_read_sec(t_time* new_sys_time)
{
unsigned char tmp;      

hardware_get_spi_sema();
hardware_spi_init(RTC4553_SPI_MODE);
RTC4553_RW_READ;
RTC4553_SS_LOW;

tmp = spi(0x0);    
tmp = spi(0x1);    	// data from prevoious read access, 1-second digit
tmp >>= 4;
new_sys_time->second = tmp;
tmp = spi(0x1);    	// data from prevoious read access, 10-second digit
tmp >>= 4;
new_sys_time->second += tmp*10;

RTC4553_SS_HIGH;
hardware_release_spi_sema();
}


// *********************************************************************************
/// \brief		Auslesen Control Register 2
/// @return	1 - Battery changed / 0 - Battery not changed
// *********************************************************************************
unsigned char rtc4553_battery_change(void)
{
unsigned char tmp;

hardware_get_spi_sema();
hardware_spi_init(RTC4553_SPI_MODE);
RTC4553_RW_READ;
RTC4553_SS_LOW;

tmp = spi(0xE);
tmp = spi(0xE);    // data from prevoious read access

RTC4553_SS_HIGH;
hardware_release_spi_sema();

tmp >>= 4;
if ((tmp & RTC4553_PONC_BIT) == RTC4553_PONC_BIT)
	return 1;
else       
	return 0;
}


// *********************************************************************************
/// \brief				Auslesen des RTC-RAM
/// @param[in] adr		Addresse
/// @param[in] mode	Mode 1/2
/// @return			Inhalt des 4-Bit-User-RAM-Register
// *********************************************************************************
unsigned char rtc4553_read_ram(unsigned char adr, unsigned char mode)
{
unsigned char tmp;

hardware_get_spi_sema();
hardware_spi_init(RTC4553_SPI_MODE);
RTC4553_RW_WRITE;
RTC4553_SS_LOW;

spi(mode);         // set mode     
RTC4553_RW_READ;
adr &= 0xF;
tmp = spi(adr);
tmp = spi(adr);    // data from prevoious read access

RTC4553_RW_WRITE;
spi(RTC4553_MODE0);    // set mode 0   

RTC4553_SS_HIGH;
hardware_release_spi_sema();

tmp &= 0xF0;
tmp >>= 4;
return tmp;
}


// *********************************************************************************
/// \brief				Schreiben des RTC-RAM
/// @param[in] adr		Addresse
/// @param[in] mode	Mode 1/2
/// @param[in] data	pointer to data
// *********************************************************************************
void rtc4553_write_ram(unsigned char adr, unsigned char mode, unsigned char* data)
{
unsigned char tmp;                       

hardware_get_spi_sema();
hardware_spi_init(RTC4553_SPI_MODE);
RTC4553_RW_WRITE;
RTC4553_SS_LOW;

spi(mode);         		// set mode    
tmp = *data;             
tmp <<= 4;
tmp |= (adr & 0xF);
spi(tmp);          		// write adress and data
spi(RTC4553_MODE0); 	// set mode 0          

RTC4553_SS_HIGH;
hardware_release_spi_sema();
}


// *********************************************************************************
/// \brief		RAM testweise beschreiben und auslesen
/// @return 	1 - OK / 0 - Fehler
// *********************************************************************************
unsigned char rtc4553_check_device(void)
{
unsigned char tmp, success=1, adr=0;
  
tmp = 0xA;
rtc4553_write_ram(adr, RTC4553_MODE1, &tmp);
if (rtc4553_read_ram(adr, RTC4553_MODE1)!=tmp)
	success=0;
rtc4553_write_ram(++adr, RTC4553_MODE1, &tmp);
if (rtc4553_read_ram(adr, RTC4553_MODE1)!=tmp)
	success=0;
rtc4553_write_ram(++adr, RTC4553_MODE1, &tmp);
if (rtc4553_read_ram(adr, RTC4553_MODE1)!=tmp)
	success=0;
tmp = 0x5;
rtc4553_write_ram(adr, RTC4553_MODE1, &tmp);
if (rtc4553_read_ram(adr, RTC4553_MODE1)!=tmp)
	success=0;
rtc4553_write_ram(++adr, RTC4553_MODE1, &tmp);
if (rtc4553_read_ram(adr, RTC4553_MODE1)!=tmp)
	success=0;
rtc4553_write_ram(++adr, RTC4553_MODE1, &tmp);
if (rtc4553_read_ram(adr, RTC4553_MODE1)!=tmp)
	success=0;

return success;
}


#ifdef RTC4553_DEBUG
// *********************************************************************************
/// \brief				 function extracts date info from string in format 01.01.2002
/// @param[in]  date_str pointer to string e.g. "01.01.2002"
/// @param[out] p_time	 pointer to time/date struct
/// @return				 errorcode 0=success
// *********************************************************************************
unsigned char rtc4553_debug_parse_date(unsigned char *date_str, t_time* p_time)
{
unsigned char*	p_point1;
unsigned char*	p_point2;
unsigned char 	temp_str[5];
signed int	 	result;

// find first point
p_point1 = strchr(date_str, '.');
if (p_point1-date_str !=2)
	return 1;

// find second point
p_point2 = strchr(p_point1+1, '.');
if (p_point2-(p_point1+1) !=2)
	return 1;

// convert day
memset(temp_str, 0x00, 5);
memcpy(temp_str, date_str, 2);
result = atoi(temp_str);
if (result == -1)
	return 1;
else
	if (result > 31)
		return 1;
	else
		p_time->day = result;

// convert month
memset(temp_str, 0x00, 5);
memcpy(temp_str, p_point1+1, 2);
result = atoi(temp_str);
if (result == -1)
	return 1;
else
	if (result > 12)
		return 1;
	else
		p_time->month = result;

// convert year
memset(temp_str, 0x00, 5);
memcpy(temp_str, p_point2+1, 4);
result = atoi(temp_str);
if (result == -1)
	return 1;
else
	if (result<2000 || result>2099)
		return 1;
	else
		p_time->year = result;

return 0;
}


// *********************************************************************************
/// \brief				 function extracts time info from string in format 01:01:01
/// @param[in]  time_str pointer to string e.g. "01:01:01"
/// @param[out] p_time	 pointer to time/date struct
/// @return				 errorcode 0=success
// *********************************************************************************
unsigned char rtc4553_debug_parse_time(unsigned char *time_str, t_time* p_time)
{
unsigned char*	p_point1;
unsigned char*	p_point2;
unsigned char 	temp_str[5];
signed int	 	result;

// find first point
p_point1 = strchr(time_str, ':');
if (p_point1-time_str !=2)
	return 1;

// find second point
p_point2 = strchr(p_point1+1, ':');
if (p_point2-(p_point1+1) !=2)
	return 1;

// convert hour
memset(temp_str, 0x00, 5);
memcpy(temp_str, time_str, 2);
result = atoi(temp_str);
if (result == -1)
	return 1;
else
	if (result > 23)
		return 1;
	else
		p_time->hour = result;

// convert minute
memset(temp_str, 0x00, 5);
memcpy(temp_str, p_point1+1, 2);
result = atoi(temp_str);
if (result == -1)
	return 1;
else
	if (result > 59)
		return 1;
	else
		p_time->minute = result;

// convert second
memset(temp_str, 0x00, 5);
memcpy(temp_str, p_point2+1, 2);
result = atoi(temp_str);
if (result == -1)
	return 1;
else
	if (result > 59)
		return 1;
	else
		p_time->second = result;

return 0;
}


// *********************************************************************************
/// \brief				main function for RTC4553 debug commands
/// @param[in] command	pointer to received debug command
// *********************************************************************************
void rtc4553_debug_do_cmd(unsigned char *command)
{
signed char	Lva;
t_time		time_struct;

if(strncmpf(command, "rtc-init", 8)==0)
	{
	rtc4553_init();
	putsf("RTC4553 initialized!\r");
	return;
	}
if(strncmpf(command, "rtc-reset", 9)==0)
	{
	rtc4553_reset_rtc();
	putsf("RTC4553 reset!\r");
	return;
	}
if(strncmpf(command, "rtc-read", 8)==0)
	{
	rtc4553_read_rtc(&time_struct);
	printf("RTC4553 date: %02u.%02u.%04u\r\n", time_struct.day, time_struct.month, time_struct.year);
	printf("RTC4553 time: %02u:%02u:%02u\r\n", time_struct.hour, time_struct.minute, time_struct.second);
	return;
	}
if(strncmpf(command, "rtc-info", 9)==0)
	{
	if(RTC4553_SS_PIN)
		putsf("RTC4553_SS:H\r");
	else
		putsf("RTC4553_SS:L\r");
	if(RTC4553_RW_PIN)
		putsf("RTC4553_RW:READ\r");
	else
		putsf("RTC4553_RW:WRITE\r");
	Lva = rtc4553_check_device();
	if (Lva==0)
		putsf("RTC4553 check: failed.\r");
	else
		putsf("RTC4553 check: success.\r");
	Lva = rtc4553_battery_change();
	if (Lva==0)
		putsf("RTC4553 battery ok\r");
	else
		putsf("RTC4553 battery empty\r");
	}
if(strncmpf(command, "rtc-set-date", 9)==0)
	{
	command = debug_search_parameter(command);
	rtc4553_read_rtc(&time_struct);
	Lva = rtc4553_debug_parse_date(command, &time_struct);
	if (Lva !=0)
		putsf("RTC4553 wrong date format.\r");
	else
		{
		printf("RTC4553 date: %02u.%02u.%04u\r\n", time_struct.day, time_struct.month, time_struct.year);
		rtc4553_set_rtc(&time_struct);
		putsf("RTC4553 date set successfully.\r");
		}
	return;
	}
if(strncmpf(command, "rtc-set-time", 9)==0)
	{
	command = debug_search_parameter(command);
	rtc4553_read_rtc(&time_struct);
	Lva = rtc4553_debug_parse_time(command, &time_struct);
	if (Lva !=0)
		putsf("RTC4553 wrong time format\r");
	else
		{
		printf("RTC4553 time: %02u:%02u:%02u\r\n", time_struct.hour, time_struct.minute, time_struct.second);
		rtc4553_set_rtc(&time_struct);
		putsf("RTC4553 date set successfully.\r");
		}
	return;
	}
}
#endif	// #ifdef RTC4553_DEBUG
#endif	// #ifdef RTC4553_ENABLE