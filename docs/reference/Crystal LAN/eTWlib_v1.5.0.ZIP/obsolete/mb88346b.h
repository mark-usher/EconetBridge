// ************************************************************************************************
///
/// 			\file dac_mb88346b.h
///
/// control of digital analog converter device MB88346B <br>
/// application uses two devices connected in shift register order
///
/// \par Created 	27.09.2005
/// \date			$LastChangedDate: 2007-03-22 10:28:39 +0100 (Do, 22 Mrz 2007) $
/// \version 		$Rev: 649 $
/// \author  		Udo Jakobza, Thomas Kellner
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************
#ifndef _MB88346B_INCLUDED_
#define _MB88346B_INCLUDED_

#include "project.h"		// Project configuration

#define	DAC_MB88346B_ADDRESS_MAX    12

// --------------------------------------------------------------------------------
// macros for dac signal pins
// --------------------------------------------------------------------------------
#ifndef DAC_MB88346B_PORT
#define DAC_MB88346B_PORT           PORTB
#endif
#ifndef DAC_MB88346B_DDR
#define DAC_MB88346B_DDR            DDRB
#endif
#ifndef DAC_MB88346B_CLK_BIT
#define DAC_MB88346B_CLK_BIT        0x10
#endif
#ifndef DAC_MB88346B_DI_BIT
#define DAC_MB88346B_DI_BIT         0x20
#endif
#ifndef DAC_MB88346B_LOAD_BIT
#define DAC_MB88346B_LOAD_BIT       0x40
#endif
#define DAC_MB88346B_DIR	        DAC_MB88346B_DDR |= (DAC_MB88346B_DI_BIT|DAC_MB88346B_CLK_BIT|DAC_MB88346B_LOAD_BIT)

//#define TIMER0_PRE			0x01		// 1
//#define TIMER0_PRE			0x02		// 8 -> 0,5�s
//#define TIMER0_PRE			0x03		// 32 -> 2�s
//#define TIMER0_PRE			0x04		// 64 -> 4�s
//#define TIMER0_PRE			0x05		// 128 -> 4�s
#define TIMER0_PRE			0x06		// 256 -> 16�s
//#define TIMER0_PRE			0x07		// 1024 -> 64�s
#define TIMER0_OCIE			0x02
#define TIMER0_OC_FLAG		0x02
#define TIMER0_COMP			20

// currently only two devices are supported
#define DAC_MB88346B_DEVICE_MAX     2
typedef enum{
    DAC_DEVICE_1,
    DAC_DEVICE_2
//    DAC_DEVICE_3,
//    DAC_DEVICE_4
} DAC_MB88346B_DEVICE;

typedef enum{
    DAC_CONV_BUSY,
    DAC_CONV_READY
} DAC_MB88346B_CONV_STATUS;

typedef enum{
    DAC_DATA_SHIFT_1,
    DAC_DATA_SHIFT_2,
    DAC_LOAD_PULSE_START,
    DAC_LOAD_PULSE_END,
    DAC_DUMMY_SHIFT,
    DAC_CONV_END
} DAC_MB88346B_SIGNAL_STATUS;

#ifdef MB88346B_DEBUG
#define MB88346B_DEBUG_BIT      0x01   
extern eeprom unsigned char mb88346b_debug_flag;
#endif

// function prototypes
#pragma used+
void dac_mb88346b_init(void);
unsigned char dac_mb88346b_load(unsigned char value, unsigned char address, unsigned char device);  
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library dac_mb88346b.c
#endif

#endif  // #ifndef _MB88346B_INCLUDED_
