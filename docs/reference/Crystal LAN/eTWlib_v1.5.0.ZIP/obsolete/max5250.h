// ************************************************************************************************
///
/// 			\file max5250.h
///
///  Functions for MAX5250
///
/// \par Created 	24.01.2002
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#ifndef _MAX5250_INCLUDED_
#define _MAX5250_INCLUDED_

#define		LOAD_DAC_A	0x30    // A1=0; A0=0; C1=1; C0=1
#define		LOAD_DAC_B	0x70	// A1=0; A0=1; C1=1; C0=1
#define		LOAD_DAC_C	0xb0	// A1=1; A0=0; C1=1; C0=1
#define		LOAD_DAC_D	0xf0	// A1=1; A0=1; C1=1; C0=1

#pragma used+

void 	max5250_init(U8 config);
void 	max5250_write(U16 value, U8 channel);
void 	max5250_reset(void);
void 	max5250_write_m_ampere(U8 ampere, U8 channel);
void 	max5250_read_m_ampere(U8 ampere, U8 channel);

#pragma used-

#endif

// #pragma library max5250.lib

