// ************************************************************************************************
///
/// \file 			uutil.c
/// \brief			Obsolete UART module
///
///					Das UART-Util-Modul ist ein flexibel einsetzbares UART-Interface mit 
///					Bufferfunktion Es stellt controllerunabh�ngige Makros f�r Registerzugriffe 
///					bereit, und kann im Polling und im Interrrupt-Modus betrieben werden.
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Carsten K�gler, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef UUTIL_ENABLE

#include <io.h>
#include <stdio.h>
#include <string.h>
#include "uutil.h"
#include "debug.h"

#pragma regalloc-
unsigned char	uutil_rx_buffer[UUTIL_UART_DEVICE_COUNT][UUTIL_READ_BUFFER_SIZE];
unsigned char	uutil_tx_buffer[UUTIL_UART_DEVICE_COUNT][UUTIL_WRITE_BUFFER_SIZE];
UUTIL_BUFFER	uutil_buffer[UUTIL_UART_DEVICE_COUNT];
unsigned char	uutil_ok[UUTIL_UART_DEVICE_COUNT]={0};
#ifdef UUTIL_PARSE_CHAR
unsigned char	uutil_parse_counter[UUTIL_UART_DEVICE_COUNT]={0};
#endif
#pragma regalloc+

// ---------------------------------------------------------------------------
//	inline macros
// ---------------------------------------------------------------------------
#define UUTIL_UART_STATUS_RXC			0x80	// UART Receive complete
#define UUTIL_UART_STATUS_TXC			0x40	// UART Transmit complete
#define UUTIL_UART_STATUS_UDRE			0x20	// UART Data Register Empty

#define UUTIL_UART_STATUS_FE			0x10	// UART Framing Error
#define UUTIL_UART_STATUS_OR			0x08	// UART OverRun

#define UUTIL_UART_RECEIVE_FE			0x10	// Receive Frame Error
#define UUTIL_UART_RECEIVE_DOR			0x08	// Receive Data OverRun
#define UUTIL_UART_RECEIVE_UPE			0x04	// Receive Parity Error


#if defined(_CHIP_ATMEGA161_)||defined(_CHIP_ATMEGA161L_)
#define UUTIL_UART0_RX_INT_ON			UCSR0B|=0x80	// 1==enable Receive-Interrupt
#define UUTIL_UART0_RX_INT_OFF			UCSR0B&=~0x80	// 1==disable Receive-Interrupt
#define UUTIL_UART0_TX_INT_ON			UCSR0B|=0x40	// 1==enable Transmit-Interrupt
#define UUTIL_UART0_TX_INT_OFF			UCSR0B&=~0x40	// 0==disable Transmit-Interrupt
#define UUTIL_UART0_EMPTY_INT_ON		UCSR0B|=0x20	// 1==enable Empty-Interrupt
#define UUTIL_UART0_EMPTY_INT_OFF		UCSR0B&=~0x20	// 0==disable Empty-Interrupt
#define UUTIL_UART0_RX_ENABLE			UCSR0B|=0x10	// 1==enable Receive
#define UUTIL_UART0_RX_DISABLE			UCSR0B&=~0x10	// 0==disable Receive
#define UUTIL_UART0_TX_ENABLE			UCSR0B|=0x08	// 1==enable Transmit
#define UUTIL_UART0_TX_DISABLE			UCSR0B&=~0x08	// 1==disable Transmit
#define UUTIL_UART0_RXC_BIT			    UCSR0A&0x80	// UUTIL_UART Receive Complete
#define UUTIL_UART0_UDRE_BIT			UCSR0A&0x20	// UUTIL_UART Data Register Empty
#define UUTIL_UART0_CONTROL_CLEAR		UCSR0A=0x0;UCSR0B=0x0 						// clears all necessary control register
#define UUTIL_UART0_SET_BAUDRATE(x)	    (UBRR0=(x & 0xff),UBRRHI&=0xf0,UBRRHI|=(x>>8))// set new baudrate
#define UUTIL_UART0_GET_BAUDRATE		(unsigned int)UBRR0|((unsigned int)UBRRHI<<8)	// get baudrate
// UART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// UART Receiver: On
// UART Transmitter: On
#ifdef UUTIL_DOUBLE_SPEED
#define UUTIL_UART0_CONTROL_IRQ		    UCSR0A|=0x02;UCSR0B=0x98	// set doppel speed  and init UART with IRQ
#define UUTIL_UART0_CONTROL_POLL		UCSR0A|=0x02;UCSR0B=0x18	// set doppel speed  and init UART without IRQ
#else
#define UUTIL_UART0_CONTROL_IRQ		    UCSR0B=0x98	    // init UART with IRQ and without double speed
#define UUTIL_UART0_CONTROL_POLL		UCSR0B=0x18	    // init UART without IRQ and without double speed
#endif
#define UUTIL_UART0_DATA_READ			UDR0 	        // reads data from UART
#define UUTIL_UART0_DATA_WRITE(x)		UDR0=x 	        // writes data to UART
#define UUTIL_UART0_RXC_IRQ_NUMBER		UART0_RXC	    // UART RX Complete Handler
#define UUTIL_UART0_DRE_IRQ_NUMBER		UART0_DRE	    // UART Empthy Handler
#endif

#if defined(_CHIP_ATMEGA128_)||defined(_CHIP_ATMEGA128L_)
#ifdef UUTIL_UART0
#define UUTIL_UART0_RX_INT_ON 			UCSR0B|=0x80	// 1==enable Receive-Interrupt
#define UUTIL_UART0_RX_INT_OFF			UCSR0B&=~0x80	// 1==disable Receive-Interrupt
#define UUTIL_UART0_TX_INT_ON			UCSR0B|=0x40	// 1==enable Transmit-Interrupt
#define UUTIL_UART0_TX_INT_OFF			UCSR0B&=~0x40	// 0==disable Transmit-Interrupt
#define UUTIL_UART0_EMPTY_INT_ON		UCSR0B|=0x20	// 1==enable Empty-Interrupt
#define UUTIL_UART0_EMPTY_INT_OFF		UCSR0B&=~0x20	// 0==disable Empty-Interrupt
#define UUTIL_UART0_RX_ENABLE			UCSR0B|=0x10	// 1==enable Receive
#define UUTIL_UART0_RX_DISABLE			UCSR0B&=~0x10	// 0==disable Receive
#define UUTIL_UART0_TX_ENABLE			UCSR0B|=0x08	// 1==enable Transmit
#define UUTIL_UART0_TX_DISABLE			UCSR0B&=~0x08	// 1==disable Transmit
#define UUTIL_UART0_RXC_BIT			    UCSR0A&0x80		// UART Receive Complete
#define UUTIL_UART0_UDRE_BIT			UCSR0A&0x20		// UART Data Register Empty
#define UUTIL_UART0_CONTROL_CLEAR		(UCSR0A=0x0,UCSR0B=0x0) 						// clears all necessary control register
#define UUTIL_UART0_SET_BAUDRATE(x)	    (UBRR0L=(x & 0xff),UBRR0H=(x>>8))		// set new baudrate
#define UUTIL_UART0_GET_BAUDRATE		(unsigned int)UBRR0L|((unsigned int)UBRR0H<<8)	// get baudrate
// UART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// UART Receiver: On
// UART Transmitter: On
#ifdef UUTIL_DOUBLE_SPEED
#define UUTIL_UART0_CONTROL_IRQ		    (UCSR0A=0x02,UCSR0B=0x98)	// set doppel speed  and init UART with IRQ
#define UUTIL_UART0_CONTROL_POLL		(UCSR0A=0x02,UCSR0B=0x18)	// set doppel speed  and init UART without IRQ
#else	// #ifdef UUTIL_DOUBLE_SPEED
#define UUTIL_UART0_CONTROL_IRQ		    UCSR0B=0x98		// init UART with IRQ and without double speed
#define UUTIL_UART0_CONTROL_POLL		UCSR0B=0x18		// init UART without IRQ and without double speed
#endif	// #ifdef UUTIL_DOUBLE_SPEED
#define UUTIL_UART0_DATA_READ			UDR0 			// reads data from UART
#define UUTIL_UART0_DATA_WRITE(x)		UDR0=x 			// writes data to UART
#define UUTIL_UART0_RXC_IRQ_NUMBER		USART0_RXC		// UART RX Complete Handler
#define UUTIL_UART0_DRE_IRQ_NUMBER		USART0_DRE		// UART Empthy Handler
#define UUTIL_UART0_ERROR_BITS			UCSR0A			// UART Error Bits
#define UUTIL_UART0_PULLUP_ENABLE 		PORTE|=0x01 	// UART Pullup enable
#endif	// #ifdef UUTIL_UART0
#ifdef UUTIL_UART1
#define UUTIL_UART1_RX_INT_ON 			UCSR1B|=0x80	// 1==enable Receive-Interrupt
#define UUTIL_UART1_RX_INT_OFF			UCSR1B&=~0x80	// 1==disable Receive-Interrupt
#define UUTIL_UART1_TX_INT_ON			UCSR1B|=0x40	// 1==enable Transmit-Interrupt
#define UUTIL_UART1_TX_INT_OFF			UCSR1B&=~0x40	// 0==disable Transmit-Interrupt
#define UUTIL_UART1_EMPTY_INT_ON		UCSR1B|=0x20	// 1==enable Empty-Interrupt
#define UUTIL_UART1_EMPTY_INT_OFF		UCSR1B&=~0x20	// 0==disable Empty-Interrupt
#define UUTIL_UART1_RX_ENABLE			UCSR1B|=0x10	// 1==enable Receive
#define UUTIL_UART1_RX_DISABLE			UCSR1B&=~0x10	// 0==disable Receive
#define UUTIL_UART1_TX_ENABLE			UCSR1B|=0x08	// 1==enable Transmit
#define UUTIL_UART1_TX_DISABLE			UCSR1B&=~0x08	// 1==disable Transmit
#define UUTIL_UART1_RXC_BIT			    UCSR1A&0x80		// UART Receive Complete
#define UUTIL_UART1_UDRE_BIT			UCSR1A&0x20		// UART Data Register Empty
#define UUTIL_UART1_CONTROL_CLEAR		(UCSR1A=0x0, UCSR1B=0x0) 		// clears all necessary control register
#define UUTIL_UART1_SET_BAUDRATE(x)	    (UBRR1L=(x & 0xff), UBRR1H=(x>>8))		// set new baudrate
#define UUTIL_UART1_GET_BAUDRATE		(unsigned int)UBRR1L|((unsigned int)UBRR1H<<8)	// get baudrate
// UART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// UART Receiver: On
// UART Transmitter: On
#ifdef UUTIL_DOUBLE_SPEED
#define UUTIL_UART1_CONTROL_IRQ		    (UCSR1A=0x02, UCSR1B=0x98)	// set doppel speed  and init UART with IRQ
#define UUTIL_UART1_CONTROL_POLL		(UCSR1A=0x02, UCSR1B=0x18)	// set doppel speed  and init UART without IRQ
#else	// #ifdef UUTIL_DOUBLE_SPEED
#define UUTIL_UART1_CONTROL_IRQ		    UCSR1B=0x98		// init UART with IRQ and without double speed
#define UUTIL_UART1_CONTROL_POLL		UCSR1B=0x18		// init UART without IRQ and without double speed
#endif	// #ifdef UUTIL_DOUBLE_SPEED
#define UUTIL_UART1_DATA_READ			UDR1 			// reads data from UART
#define UUTIL_UART1_DATA_WRITE(x)		UDR1=x 			// writes data to UART
#define UUTIL_UART1_RXC_IRQ_NUMBER		USART1_RXC		// UART RX Complete Handler
#define UUTIL_UART1_DRE_IRQ_NUMBER		USART1_DRE		// UART Empthy Handler
#define UUTIL_UART1_ERROR_BITS			UCSR1A			// UART Error Bits
#endif	// #ifdef UUTIL_UART1
#endif	// #if defined(_CHIP_ATMEGA128_)||defined(_CHIP_ATMEGA128L_)

#if defined(_CHIP_AT90S8535_)||defined(_CHIP_AT90S8535L_)
#ifdef UUTIL_UART1
#error "UUTIL: UART1 is not available with this chip!"
#endif	// #ifdef UUTIL_UART1
#define UUTIL_UART0_RX_INT_ON			UCR|=0x80	    // 1==enable Receive-Interrupt
#define UUTIL_UART0_RX_INT_OFF			UCR&=~0x80	    // 1==disable Receive-Interrupt
#define UUTIL_UART0_TX_INT_ON			UCR|=0x40	    // 1==enable Transmit-Interrupt
#define UUTIL_UART0_TX_INT_OFF			UCR&=~0x40	    // 0==disable Transmit-Interrupt
#define UUTIL_UART0_EMPTY_INT_ON		UCR|=0x20	    // 1==enable Empty-Interrupt
#define UUTIL_UART0_EMPTY_INT_OFF		UCR&=~0x20	    // 0==disable Empty-Interrupt
#define UUTIL_UART0_RX_ENABLE			UCR|=0x10	    // 1==enable Receive
#define UUTIL_UART0_RX_DISABLE			UCR&=~0x10	    // 0==disable Receive
#define UUTIL_UART0_TX_ENABLE			UCR|=0x08	    // 1==enable Transmit
#define UUTIL_UART0_TX_DISABLE			UCR&=~0x08	    // 1==disable Transmit
#define UUTIL_UART0_RXC_BIT			    USR&0x80    // UART Receive Complete
#define UUTIL_UART0_UDRE_BIT			USR&0x20    // UART Data Register Empty
#define UUTIL_UART0_CONTROL_CLEAR		UCR=0x0     // clears all necessary control register
#define UUTIL_UART0_SET_BAUDRATE(x)	    UBRR=x	    // set new baudrate
#define UUTIL_UART0_GET_BAUDRATE		UBRR	    // get baudrate
// UART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// UART Receiver: On
// UART Transmitter: On
#define UUTIL_UART0_CONTROL_IRQ		    UCR=0x98    // init UART with IRQ
#define UUTIL_UART0_CONTROL_POLL		UCR=0x18    // init UART without IRQ
#define UUTIL_UART0_DATA_READ			UDR 	    // reads data from UART
#define UUTIL_UART0_DATA_WRITE(x)		UDR=x 	    // writes data to UART
#define UUTIL_UART0_RXC_IRQ_NUMBER		UART_RXC	// UART RX Complete Handler
#define UUTIL_UART0_DRE_IRQ_NUMBER		UART_DRE    // UART Empthy Handler
#endif	// #if defined(_CHIP_AT90S8535_)||defined(_CHIP_AT90S8535L_)

#if defined(_CHIP_ATMEGA8535_)||defined(_CHIP_ATMEGAS8535L_)||\
    defined(_CHIP_ATMEGA8_)||defined(_CHIP_ATMEGAS8L_)|| \
    defined(_CHIP_ATMEGA32_)||defined(_CHIP_ATMEGAS32L_)
#ifdef UUTIL_UART1
#error "UUTIL: UART1 is not available with this chip!"
#endif
#define UUTIL_UART0_RX_INT_ON 	 		UCSRB|=0x80	// 1==enable Receive-Interrupt
#define UUTIL_UART0_RX_INT_OFF	 		UCSRB&=~0x80	// 1==disable Receive-Interrupt
#define UUTIL_UART0_TX_INT_ON			UCSRB|=0x40	// 1==enable Transmit-Interrupt
#define UUTIL_UART0_TX_INT_OFF			UCSRB&=~0x40	// 0==disable Transmit-Interrupt
#define UUTIL_UART0_EMPTY_INT_ON		UCSRB|=0x20	// 1==enable Empty-Interrupt
#define UUTIL_UART0_EMPTY_INT_OFF		UCSRB&=~0x20	// 0==disable Empty-Interrupt
#define UUTIL_UART0_RX_ENABLE			UCSRB|=0x10	// 1==enable Receive
#define UUTIL_UART0_RX_DISABLE			UCSRB&=~0x10	// 0==disable Receive
#define UUTIL_UART0_TX_ENABLE			UCSRB|=0x08	// 1==enable Transmit
#define UUTIL_UART0_TX_DISABLE			UCSRB&=~0x08	// 1==disable Transmit
#define UUTIL_UART0_RXC_BIT			    UCSRA&0x80	// UART Receive Complete
#define UUTIL_UART0_UDRE_BIT			UCSRA&0x20	// UART Data Register Empty
#define UUTIL_UART0_CONTROL_CLEAR		UCSRA=0x0;UCSRB=0x0 					// clears all necessary control register
#define UUTIL_UART0_SET_BAUDRATE(x)	    (UBRRL=(x & 0xff), UBRRH=(x>>8))		// set new baudrate
#define UUTIL_UART0_GET_BAUDRATE		(unsigned int)UBRRL|((unsigned int)UBRRH<<8)	// get baudrate
// UART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// UART Receiver: On
// UART Transmitter: On
#ifdef UUTIL_DOUBLE_SPEED
#define UUTIL_UART0_CONTROL_IRQ		    UCSRA|=0x02;UCSRB=0x98	// set doppel speed  and init UART with IRQ
#define UUTIL_UART0_CONTROL_POLL		UCSRA|=0x02;UCSRB=0x18	// set doppel speed  and init UART without IRQ
#else
#define UUTIL_UART0_CONTROL_IRQ		    UCSRB=0x98	// init UART with IRQ and without double speed
#define UUTIL_UART0_CONTROL_POLL		UCSRB=0x18	// init UART without IRQ and without double speed
#endif
#define UUTIL_UART0_DATA_READ			UDR 	    // reads data from UART
#define UUTIL_UART0_DATA_WRITE(x)		UDR=x 	    // writes data to UART
#define UUTIL_UART0_RXC_IRQ_NUMBER		USART_RXC	// UART RX Complete Handler
#define UUTIL_UART0_DRE_IRQ_NUMBER		USART_DRE	// UART Empthy Handler
#define UUTIL_UART0_ERROR_BITS			UCSRA		// UART Error Bits
#endif

// local prototype
#pragma used+
void uutil_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);
#pragma used-
	
// *********************************************************************************
/// \brief		Initialize uutil module
/// @param[in]	baudrate    - baudrate macro of the kind UUTIL_BAUD_DIV_
/// @param[in]	uart_device - uart number 0/1
// *********************************************************************************
void uutil_init(void)
{
#ifdef UUTIL_DEBUG
T_DEBUG_HANDLER_STRUCT p_struct;
                      
p_struct.fp_handler = &uutil_debug_handler;
p_struct.id_string = "uutil";
debug_register_handler(&p_struct);
#endif
}
	
// *********************************************************************************
/// \brief                   enable the uart-interface with buffer
/// @param[in] baudrate      baudrate macro of the kind UUTIL_BAUD_DIV_
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_enable(unsigned int baudrate, UUTIL_UART_DEVICE uart_device)
{
#ifdef UUTIL_UART0
if(uart_device==UUTIL_UART_DEVICE_0)
	{
	UUTIL_UART0_CONTROL_CLEAR;
	UUTIL_UART0_SET_BAUDRATE(baudrate);
	#ifdef UUTIL_IRQ
	UUTIL_UART0_CONTROL_IRQ;	// init UART with IRQ
	#else
	UUTIL_UART0_CONTROL_POLL;	// init UART without IRQ
	#endif
	}
#endif
#ifdef UUTIL_UART1
if(uart_device==UUTIL_UART_DEVICE_1)
	{
	UUTIL_UART1_CONTROL_CLEAR;
	UUTIL_UART1_SET_BAUDRATE(baudrate);
	#ifdef UUTIL_IRQ
	UUTIL_UART1_CONTROL_IRQ;	// init UART with IRQ
	#else
	UUTIL_UART1_CONTROL_POLL;	// init UART without IRQ
	#endif
	}
#endif
uutil_clear_buffer(uart_device);
uutil_buffer[uart_device].rbuffer = &uutil_rx_buffer[uart_device][0];	// rbuffer
uutil_buffer[uart_device].wbuffer = &uutil_tx_buffer[uart_device][0];	// wbuffer
uutil_ok[uart_device] = 1;
#ifdef UUTIL_PARSE_CHAR
uutil_parse_counter[uart_device] = 0;
#endif
}


// *********************************************************************************
/// \brief                   disable the uart-interface with buffer
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_disable(UUTIL_UART_DEVICE uart_device)
{
#ifdef UUTIL_UART0
if (uart_device==UUTIL_UART_DEVICE_0)
	UUTIL_UART0_CONTROL_CLEAR;
#endif
#ifdef UUTIL_UART1
if (uart_device==UUTIL_UART_DEVICE_1)
	UUTIL_UART1_CONTROL_CLEAR;
#endif
uutil_ok[uart_device] = 0;
}


// *********************************************************************************
/// \brief                   set a new baudrate
/// @param[in] baudrate      baudrate macro of the kind UUTIL_BAUD_DIV_
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_baudrate(unsigned int baudrate, UUTIL_UART_DEVICE uart_device)
{
if(uutil_ok[uart_device])
	{
	#ifndef UUTIL_IRQ
	while(uutil_buffer[uart_device].wgap<UUTIL_WRITE_BUFFER_SIZE)		// wait until transmit empty
		uutil_transmit_poll(uart_device);
	#else
	while(uutil_buffer[uart_device].wgap<UUTIL_WRITE_BUFFER_SIZE);		// wait until transmit empty
	#endif
	uutil_disable(uart_device);
	#ifdef UUTIL_UART0
	if (uart_device==UUTIL_UART_DEVICE_0)
		{
		UUTIL_UART0_CONTROL_CLEAR;
		UUTIL_UART0_SET_BAUDRATE(baudrate);
		#ifdef UUTIL_IRQ
		UUTIL_UART0_CONTROL_IRQ;	// init UART with IRQ
		#else
		UUTIL_UART0_CONTROL_POLL;	// init UART without IRQ
		#endif
		}
	#endif
	#ifdef UUTIL_UART1
	if (uart_device==UUTIL_UART_DEVICE_1)
		{
		UUTIL_UART1_CONTROL_CLEAR;
		UUTIL_UART1_SET_BAUDRATE(baudrate);
		#ifdef UUTIL_IRQ
		UUTIL_UART1_CONTROL_IRQ;	// init UART with IRQ
		#else
		UUTIL_UART1_CONTROL_POLL;	// init UART without IRQ
		#endif
		}
	#endif
	}
else
	uutil_enable(baudrate, uart_device);
}


// *********************************************************************************
/// \brief                   test the buffer whether Data present
/// \param[in] uart_device   uart number 0/1
/// \return                  1..x: - data present, 0 - no data
// *********************************************************************************
T_UUTIL_RD_VAR_SIZE uutil_get_rx_count(UUTIL_UART_DEVICE uart_device)
{
T_UUTIL_RD_VAR_SIZE rgap;

#ifdef UUTIL_IRQ
#ifdef UUTIL_UART0
if(uart_device==UUTIL_UART_DEVICE_0)
	UUTIL_UART0_RX_INT_OFF;		// disable Receive-Interrupt
#endif
#ifdef UUTIL_UART1
if(uart_device==UUTIL_UART_DEVICE_1)
	UUTIL_UART1_RX_INT_OFF;		// disable Receive-Interrupt
#endif
#endif
rgap = UUTIL_READ_BUFFER_SIZE-uutil_buffer[uart_device].rgap;
#ifdef UUTIL_IRQ
#ifdef UUTIL_UART0
if(uart_device==UUTIL_UART_DEVICE_0)
	UUTIL_UART0_RX_INT_ON;		// enable Receive-Interrupt
#endif
#ifdef UUTIL_UART1
if(uart_device==UUTIL_UART_DEVICE_1)
	UUTIL_UART1_RX_INT_ON;		// enable Receive-Interrupt
#endif
#endif
return rgap;
}


// *********************************************************************************
/// \brief                   check the size of transmit-buffer
/// \param[in] uart_device   uart number 0/1
/// \return                  1..x - size of free buffer, 0 - buffer full
// *********************************************************************************
T_UUTIL_WR_VAR_SIZE uutil_get_tx_gap(UUTIL_UART_DEVICE uart_device)
{
T_UUTIL_RD_VAR_SIZE wgap;

#ifdef UUTIL_IRQ
#ifdef UUTIL_UART0
if (uart_device==UUTIL_UART_DEVICE_0)
	UUTIL_UART0_EMPTY_INT_OFF; 		// disable Empty-Interrupt
#endif
#ifdef UUTIL_UART1
if (uart_device==UUTIL_UART_DEVICE_1)
	UUTIL_UART1_EMPTY_INT_OFF; 		// disable Empty-Interrupt
#endif
#endif
wgap = uutil_buffer[uart_device].wgap;
#ifdef UUTIL_IRQ
#ifdef UUTIL_UART0
if (uart_device==UUTIL_UART_DEVICE_0)
	UUTIL_UART0_EMPTY_INT_ON;	 	// enable Empty-Interrupt
#endif
#ifdef UUTIL_UART1
if (uart_device==UUTIL_UART_DEVICE_1)
	UUTIL_UART1_EMPTY_INT_ON;	 	// enable Empty-Interrupt
#endif
#endif
return wgap;
}


#ifdef UUTIL_PARSE_CHAR
// *********************************************************************************
/// \brief                   check the parse counter
/// @param[in] uart_device   uart number 0/1
/// @return                  1..x: - special chars received, 0 - no special chars received
// *********************************************************************************
unsigned char uutil_frames_received(UUTIL_UART_DEVICE uart_device);
{
return uutil_parse_counter[uart_device];
}
#endif


// *********************************************************************************
/// \brief                   send a char to the uart
/// @param[in] data          "data" sign to send
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_putchar(unsigned char data, UUTIL_UART_DEVICE uart_device)
{                  
#ifdef UUTIL_STATUS
if(uutil_buffer[uart_device].wgap==0)
	uutil_buffer[uart_device].status.wlost++;		// counter of lost data
uutil_buffer[uart_device].status.wcount++;	   		// counter of transmit-data
#endif
while(uutil_buffer[uart_device].wgap==0)	// if buffer full? - wait
	{
	#ifndef UUTIL_IRQ
	uutil_transmit_poll(uart_device);
	#endif
	}
#ifdef UUTIL_IRQ
#ifdef UUTIL_UART0
if (uart_device==UUTIL_UART_DEVICE_0)
	UUTIL_UART0_EMPTY_INT_OFF; 		// disable Empty-Interrupt
#endif
#ifdef UUTIL_UART1
if (uart_device==UUTIL_UART_DEVICE_1)
	UUTIL_UART1_EMPTY_INT_OFF; 		// disable Empty-Interrupt
#endif
#endif
uutil_buffer[uart_device].wbuffer[uutil_buffer[uart_device].wtop]=data;
uutil_buffer[uart_device].wtop++;
if(uutil_buffer[uart_device].wtop==UUTIL_WRITE_BUFFER_SIZE)
	uutil_buffer[uart_device].wtop = 0;
uutil_buffer[uart_device].wgap--;
#ifdef UUTIL_IRQ
#ifdef UUTIL_UART0
if (uart_device==UUTIL_UART_DEVICE_0)
	UUTIL_UART0_EMPTY_INT_ON;	 	// enable Empty-Interrupt
#endif
#ifdef UUTIL_UART1
if (uart_device==UUTIL_UART_DEVICE_1)
	UUTIL_UART1_EMPTY_INT_ON;	 	// enable Empty-Interrupt
#endif
#endif
}


// *********************************************************************************
/// \brief                   read a char from uart
/// @param[in] uart_device   uart number 0/1
/// @return                  the character
// *********************************************************************************
unsigned char uutil_getchar(UUTIL_UART_DEVICE uart_device)
{
unsigned char Lva=0x0;

if (uutil_buffer[uart_device].rgap<UUTIL_READ_BUFFER_SIZE)
	{
	#ifdef UUTIL_STATUS
	uutil_buffer[uart_device].status.rcount++;		// counter of receive-data
	#endif
	#ifdef UUTIL_IRQ
	#ifdef UUTIL_UART0
	if (uart_device==UUTIL_UART_DEVICE_0)
		UUTIL_UART0_RX_INT_OFF;		// disable Receive-Interrupt
	#endif
	#ifdef UUTIL_UART1
	if (uart_device==UUTIL_UART_DEVICE_1)
		UUTIL_UART1_RX_INT_OFF;		// disable Receive-Interrupt
	#endif
	#endif
	Lva=uutil_buffer[uart_device].rbuffer[uutil_buffer[uart_device].rbottom];
	uutil_buffer[uart_device].rbottom++;
	if (uutil_buffer[uart_device].rbottom==UUTIL_READ_BUFFER_SIZE)
		uutil_buffer[uart_device].rbottom = 0;
	uutil_buffer[uart_device].rgap++;
	#ifdef UUTIL_PARSE_CHAR
	if (Lva==UUTIL_PARSE_CHAR)
		if (uutil_parse_counter[uart_device]>0)
			uutil_parse_counter[uart_device]--;
	#endif
	#ifdef UUTIL_IRQ
	#ifdef UUTIL_UART0
	if (uart_device==UUTIL_UART_DEVICE_0)
		UUTIL_UART0_RX_INT_ON;		// enable Receive-Interrupt
	#endif
	#ifdef UUTIL_UART1
    if (uart_device==UUTIL_UART_DEVICE_1)
		UUTIL_UART1_RX_INT_ON;		// enable Receive-Interrupt
	#endif
	#endif
	}
return Lva;
}


// *********************************************************************************
/// \brief                   write a buffer to the comport
/// @param[in] data          pointer to data
/// @param[in] size          size of data
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_write_data(unsigned char *data, T_UUTIL_WR_VAR_SIZE size, UUTIL_UART_DEVICE uart_device)
{
T_UUTIL_WR_VAR_SIZE Lva;

for(Lva=0;Lva<size;Lva++)
	{
	uutil_putchar(*data, uart_device);
	data++;
	}
}


// *********************************************************************************
/// \brief                   read from buffer
/// @param[in] size          size of data
/// @param[in] uart_device   uart number 0/1
/// @param[out] data         pointer to data
// *********************************************************************************
void uutil_read_data(unsigned char *data, T_UUTIL_RD_VAR_SIZE size, UUTIL_UART_DEVICE uart_device)
{
T_UUTIL_RD_VAR_SIZE Lva;

for(Lva=0;Lva<size;Lva++)
	{
	*data = uutil_getchar(uart_device);
	data++;
	}
}


// *********************************************************************************
/// \brief                   write a string to the to uart
/// @param[in] string        pointer to a string in SRAM
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_puts(unsigned char *string, UUTIL_UART_DEVICE uart_device)
{
#ifdef _MODEL_TINY_
#asm
    clr  r31
#endasm
#endif

#ifdef _MODEL_SMALL_
#asm
    ldd  r31,y+1
#endasm
#endif
while (*string != 0x0)
	{
	uutil_putchar(*string, uart_device);
	string++ ;
	}
}


// *********************************************************************************
/// \brief                   write a string located in FLASH to uart
/// @param[in] string        pointer to a string in FLASH
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_putsf(unsigned char flash *string, UUTIL_UART_DEVICE uart_device)
{
while (*string!= 0x0)
	{
	uutil_putchar(*string, uart_device);
	string++;
	}
}


// *********************************************************************************
/// \brief                   write a string located in EEPROM to uart
/// @param[in] string        pointer to a string in EEPROM
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_putse(unsigned char eeprom *string, UUTIL_UART_DEVICE uart_device)
{
while (*string!= 0x0)
	{
	uutil_putchar(*string, uart_device);
	string++;
	}
}


// *********************************************************************************
/// \brief                   write a char(8bit) as bin to the uart
/// @param[in] bin           integer
/// @param[in] width         length of bin-string
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_putbin(unsigned char bin, unsigned char width, UUTIL_UART_DEVICE uart_device)
{
unsigned char	c;
unsigned char	Lva;

if(width>8)
	width=8;
for (Lva = (width-1); Lva >= 0; Lva--)
	{
	c = (bin >> (Lva)) & 0x1;
	c = c + '0';
	uutil_putchar(c, uart_device);
	}
}


// *********************************************************************************
/// \brief               clears all buffer of uart-interface
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_clear_rx_buffer(UUTIL_UART_DEVICE uart_device)
{
uutil_buffer[uart_device].rtop = 0;
uutil_buffer[uart_device].rbottom = 0;
uutil_buffer[uart_device].rgap = UUTIL_READ_BUFFER_SIZE;
#ifdef UUTIL_PARSE_CHAR
uutil_parse_counter[uart_device] = 0;
#endif
}


// *********************************************************************************
/// \brief                   clears all buffer of uart-interface
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_clear_tx_buffer(UUTIL_UART_DEVICE uart_device)
{
uutil_buffer[uart_device].wtop = 0;
uutil_buffer[uart_device].wbottom = 0;
uutil_buffer[uart_device].wgap = UUTIL_WRITE_BUFFER_SIZE;
}


// *********************************************************************************
/// \brief                   clears all buffer of uart-interface
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_clear_buffer(UUTIL_UART_DEVICE uart_device)
{
uutil_clear_tx_buffer(uart_device);
uutil_clear_rx_buffer(uart_device);
}


#ifdef UUTIL_IRQ
#ifdef UUTIL_UART0
// *********************************************************************************
/// \brief               Interrupt-Handler UART0-Receive
// *********************************************************************************
interrupt [UUTIL_UART0_RXC_IRQ_NUMBER] void irq_uart0_receive(void)
{
unsigned char Lva;
#ifdef UUTIL_STATUS
unsigned char uart_error;

uart_error = UUTIL_UART0_ERROR_BITS;
#endif
Lva = UUTIL_UART0_DATA_READ;
#ifdef UUTIL_STATUS
if(uart_error & (UUTIL_UART_RECEIVE_FE | UUTIL_UART_RECEIVE_DOR | UUTIL_UART_RECEIVE_UPE))
	{
	if(uart_error & UUTIL_UART_RECEIVE_FE)
		uutil_buffer[UUTIL_UART_DEVICE_0].status.r_frame_error++;		// counter of Receive Frame Error
	if(uart_error & UUTIL_UART_RECEIVE_DOR)
		{
		uutil_buffer[UUTIL_UART_DEVICE_0].status.r_data_over_run++;		// counter of Receive Data OverRun
		uutil_buffer[UUTIL_UART_DEVICE_0].status.rlost++;		// counter of lost data
		}
	if(uart_error & UUTIL_UART_RECEIVE_UPE)
		uutil_buffer[UUTIL_UART_DEVICE_0].status.r_parity_error++;		// counter of Receive Parity Error
	}
#endif
if(uutil_buffer[UUTIL_UART_DEVICE_0].rgap>0)
	{
	uutil_buffer[UUTIL_UART_DEVICE_0].rgap--;
	uutil_buffer[UUTIL_UART_DEVICE_0].rbuffer[uutil_buffer[UUTIL_UART_DEVICE_0].rtop]=Lva;
	uutil_buffer[UUTIL_UART_DEVICE_0].rtop++;
	if(uutil_buffer[UUTIL_UART_DEVICE_0].rtop==UUTIL_READ_BUFFER_SIZE)
		uutil_buffer[UUTIL_UART_DEVICE_0].rtop = 0;
	#ifdef UUTIL_PARSE_CHAR
	if (Lva==UUTIL_PARSE_CHAR)
		if (uutil_parse_counter[UUTIL_UART_DEVICE_0]<255)
			uutil_parse_counter[UUTIL_UART_DEVICE_0]++;
	#endif
	}
#ifdef UUTIL_STATUS
else
	uutil_buffer[UUTIL_UART_DEVICE_0].status.rlost++;		// counter of lost data
#endif
}
#endif   // UUTIL_UART0

#ifdef UUTIL_UART1
// *********************************************************************************
/// \brief               Interrupt-Handler UART1-Receive
// *********************************************************************************
interrupt [UUTIL_UART1_RXC_IRQ_NUMBER] void irq_uart1_receive(void)
{
unsigned char Lva;
#ifdef UUTIL_STATUS
unsigned char uart_error;

uart_error = UUTIL_UART1_ERROR_BITS;
#endif
Lva = UUTIL_UART1_DATA_READ;
#ifdef UUTIL_STATUS
if(uart_error & (UUTIL_UART_RECEIVE_FE | UUTIL_UART_RECEIVE_DOR | UUTIL_UART_RECEIVE_UPE))
	{
	if(uart_error & UUTIL_UART_RECEIVE_FE)
		uutil_buffer[UUTIL_UART_DEVICE_1].status.r_frame_error++;		// counter of Receive Frame Error
	if(uart_error & UUTIL_UART_RECEIVE_DOR)
		{
		uutil_buffer[UUTIL_UART_DEVICE_1].status.r_data_over_run++;		// counter of Receive Data OverRun
		uutil_buffer[UUTIL_UART_DEVICE_1].status.rlost++;		// counter of lost data
		}
	if(uart_error & UUTIL_UART_RECEIVE_UPE)
		uutil_buffer[UUTIL_UART_DEVICE_1].status.r_parity_error++;		// counter of Receive Parity Error
	}
#endif
if(uutil_buffer[UUTIL_UART_DEVICE_1].rgap>0)
	{
	uutil_buffer[UUTIL_UART_DEVICE_1].rgap--;
	uutil_buffer[UUTIL_UART_DEVICE_1].rbuffer[uutil_buffer[UUTIL_UART_DEVICE_1].rtop] = Lva;
	uutil_buffer[UUTIL_UART_DEVICE_1].rtop++;
	if(uutil_buffer[UUTIL_UART_DEVICE_1].rtop==UUTIL_READ_BUFFER_SIZE)
		uutil_buffer[UUTIL_UART_DEVICE_1].rtop=0;
	#ifdef UUTIL_PARSE_CHAR
	if (Lva==UUTIL_PARSE_CHAR)
		if (uutil_parse_counter[UUTIL_UART_DEVICE_1]<255)
			uutil_parse_counter[UUTIL_UART_DEVICE_1]++;
	#endif
	}
#ifdef UUTIL_STATUS
else
	uutil_buffer[UUTIL_UART_DEVICE_1].status.rlost++;		// counter of lost data
#endif
}
#endif   // #ifdef UUTIL_UART1

#else
// *********************************************************************************
/// \brief                   read the new receive value (in polling mode)
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_receive_poll(UUTIL_UART_DEVICE uart_device)
{
unsigned char Lva, rx_flag=0;

#ifdef UUTIL_UART0
if (uart_device==UUTIL_UART_DEVICE_0)
	{
	if(UUTIL_UART0_RXC_BIT)			// RXC - UART Receive Complete
		{
		Lva=UUTIL_UART0_DATA_READ;	// reads data from UART
		rx_flag = 1;
		}
	}
#endif
#ifdef UUTIL_UART1
if (uart_device==UUTIL_UART_DEVICE_1)
	{
	if(UUTIL_UART1_RXC_BIT)			// RXC - UART Receive Complete
		{
		Lva=UUTIL_UART1_DATA_READ;	// reads data from UART
		rx_flag = 1;
		}
	}
#endif
if(rx_flag)	// RXC - UART Receive Complete
	{
	if(uutil_buffer[uart_device].rgap>0)
		{
		uutil_buffer[uart_device].rgap--;
		uutil_buffer[uart_device].rbuffer[uutil_buffer[uart_device].rtop]=Lva;
		uutil_buffer[uart_device].rtop++;
		if(uutil_buffer[uart_device].rtop==UUTIL_READ_BUFFER_SIZE)
			uutil_buffer[uart_device].rtop=0;
		#ifdef UUTIL_PARSE_CHAR
		if (Lva == UUTIL_PARSE_CHAR)
			if (uutil_parse_counter[uart_device]<255)
				uutil_parse_counter[uart_device]++;
		#endif
		}
	}
	#ifdef UUTIL_STATUS
	else
		uutil_buffer[uart_device].rlost++;		// counter of lost data
	#endif
}
#endif


#ifdef UUTIL_IRQ
#ifdef UUTIL_UART0
// *********************************************************************************
/// \brief               Interrupt-Handler UART0 Empty
// *********************************************************************************
interrupt [UUTIL_UART0_DRE_IRQ_NUMBER] void irq_uart0_empty(void)
{
if(uutil_buffer[UUTIL_UART_DEVICE_0].wgap<UUTIL_WRITE_BUFFER_SIZE)
	{
	uutil_buffer[UUTIL_UART_DEVICE_0].wgap++;
	UUTIL_UART0_DATA_WRITE(uutil_buffer[UUTIL_UART_DEVICE_0].wbuffer[uutil_buffer[UUTIL_UART_DEVICE_0].wbottom]);
	uutil_buffer[UUTIL_UART_DEVICE_0].wbottom++;
	if(uutil_buffer[UUTIL_UART_DEVICE_0].wbottom==UUTIL_WRITE_BUFFER_SIZE)
		{
		uutil_buffer[UUTIL_UART_DEVICE_0].wbottom=0;
		}
	}
else
	{
	UUTIL_UART0_EMPTY_INT_OFF;	 	// disable Empty-Interrupt
	}
}
#endif   // #ifdef UUTIL_UART0

#ifdef UUTIL_UART1
// *********************************************************************************
/// \brief               Interrupt-Handler UART1 Empty
// *********************************************************************************
interrupt [UUTIL_UART1_DRE_IRQ_NUMBER] void irq_uart1_empty(void)
{
if(uutil_buffer[UUTIL_UART_DEVICE_1].wgap<UUTIL_WRITE_BUFFER_SIZE)
	{
	uutil_buffer[UUTIL_UART_DEVICE_1].wgap++;
	UUTIL_UART1_DATA_WRITE(uutil_buffer[UUTIL_UART_DEVICE_1].wbuffer[uutil_buffer[UUTIL_UART_DEVICE_1].wbottom]);
	uutil_buffer[UUTIL_UART_DEVICE_1].wbottom++;
	if(uutil_buffer[UUTIL_UART_DEVICE_1].wbottom==UUTIL_WRITE_BUFFER_SIZE)
		{
		uutil_buffer[UUTIL_UART_DEVICE_1].wbottom=0;
		}
	}
else
	{
	UUTIL_UART1_EMPTY_INT_OFF;	 	// disable Empty-Interrupt
	}
}
#endif   // #ifdef UUTIL_UART1

#else
// *********************************************************************************
/// \brief                   write value (in polling mode)
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_transmit_poll(UUTIL_UART_DEVICE uart_device)
{
unsigned char dre_falg=0;

#ifdef UUTIL_UART0
if (uart_device==UUTIL_UART_DEVICE_0)
	{
	if(UUTIL_UART0_UDRE_BIT)	//UDRE: UART Data Register Empty
		dre_falg = 1;
	}
#endif
#ifdef UUTIL_UART1
if (uart_device==UUTIL_UART_DEVICE_1)
	{
	if(UUTIL_UART1_UDRE_BIT)  //UDRE: UART Data Register Empty
		dre_falg = 1;
	}
#endif
if(dre_falg)	//UDRE: UART Data Register Empty
	{
	if(uutil_buffer[uart_device].wgap<UUTIL_WRITE_BUFFER_SIZE)
		{
		uutil_buffer[uart_device].wgap++;
		#ifdef UUTIL_UART0
		if (uart_device==UUTIL_UART_DEVICE_0)
			UUTIL_UART0_DATA_WRITE(uutil_buffer[uart_device].wbuffer[uutil_buffer[uart_device].wbottom]);	// writes data to UART
		#endif
        #ifdef UUTIL_UART1
		if (uart_device==UUTIL_UART_DEVICE_1)
			UUTIL_UART1_DATA_WRITE(uutil_buffer[uart_device].wbuffer[uutil_buffer[uart_device].wbottom]);	// writes data to UART
        #endif
		uutil_buffer[uart_device].wbottom++;
		if(uutil_buffer[uart_device].wbottom==UUTIL_WRITE_BUFFER_SIZE)
			uutil_buffer[uart_device].wbottom=0;
		}
	}
}
#endif


#ifdef UUTIL_STATUS
// *********************************************************************************
/// \brief                   check if uart device available
/// @param[in] uart_device   uart number 0/1
/// @return                  1: uart available; 0: uart unavailable
// *********************************************************************************                      
unsigned char uutil_device_available(UUTIL_UART_DEVICE uart_device)
{
#ifdef UUTIL_UART0
if(uart_device==UUTIL_UART_DEVICE_0)
    return 1;
#endif
#ifdef UUTIL_UART1
if(uart_device==UUTIL_UART_DEVICE_1)
    return 1;
#endif      
return 0;
}

// *********************************************************************************
/// \brief                   get structure of uart status information
/// @param[in] uart_device   uart number 0/1
/// @param[out] p_struct     pointer to structure (allocated sram)
// *********************************************************************************
void uutil_get_status(UUTIL_STATUS_STRUCTURE *p_struct, UUTIL_UART_DEVICE uart_device)
{
if((p_struct!=0x0) && uutil_device_available(uart_device))
    {                                                     
    // disable of uart interrupts necessary
    memcpy(p_struct, &uutil_buffer[uart_device].status, sizeof(UUTIL_STATUS_STRUCTURE));
    uutil_buffer[uart_device].status.rcount = 0;
    uutil_buffer[uart_device].status.wcount = 0;
    uutil_buffer[uart_device].status.rlost = 0;
    uutil_buffer[uart_device].status.wlost = 0;
    uutil_buffer[uart_device].status.r_frame_error = 0;
    uutil_buffer[uart_device].status.r_data_over_run = 0;
    uutil_buffer[uart_device].status.r_parity_error = 0;
    }
}
#endif


#ifdef UUTIL_DEBUG
// *********************************************************************************
/// \brief                   write the info of uutil uart interface to debug uart
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_info(UUTIL_UART_DEVICE uart_device)
{
unsigned long baudrate;

printf("uart_buffer: (uart %u)\r\n", uart_device);
printf("receive : 0x%04x %u %u %u\r\n", uutil_buffer[uart_device].rbuffer, uutil_buffer[uart_device].rtop,
					uutil_buffer[uart_device].rbottom, uutil_buffer[uart_device].rgap);
printf("transmit: 0x%04x %u %u %u\r\n", uutil_buffer[uart_device].wbuffer, uutil_buffer[uart_device].wtop,
					uutil_buffer[uart_device].wbottom, uutil_buffer[uart_device].wgap);
printf("application count: r:%u t:%u\r\n", uutil_buffer[uart_device].status.rcount, uutil_buffer[uart_device].status.wcount);
uutil_buffer[uart_device].status.rcount=0;
uutil_buffer[uart_device].status.wcount=0;
if(uutil_buffer[uart_device].status.rlost)		// counter of lost data
	printf("receive-lost: %u\r\n", uutil_buffer[uart_device].status.rlost);
else
	putsf("NO receive-lost\r");
uutil_buffer[uart_device].status.rlost=0;
if(uutil_buffer[uart_device].status.wlost)		// counter of lost data
	printf("transmit-lost: %u\r\n", uutil_buffer[uart_device].status.wlost);
else
	putsf("NO transmit-lost\r");
uutil_buffer[uart_device].status.wlost=0;
printf("Frame-Error : %u\r\n", uutil_buffer[uart_device].status.r_frame_error);		// counter of Receive Frame Error
uutil_buffer[uart_device].status.r_frame_error=0;
printf("Data OverRun: %u\r\n", uutil_buffer[uart_device].status.r_data_over_run);	// counter of Receive Data OverRun
uutil_buffer[uart_device].status.r_data_over_run = 0;
printf("Parity Error: %u\r\n", uutil_buffer[uart_device].status.r_parity_error);	// counter of Receive Parity Error
uutil_buffer[uart_device].status.r_parity_error=0;
#ifdef UUTIL_UART0
if (uart_device==UUTIL_UART_DEVICE_0)
    baudrate = UUTIL_UART0_GET_BAUDRATE;
#endif
#ifdef UUTIL_UART1
if (uart_device==UUTIL_UART_DEVICE_1)
    baudrate = UUTIL_UART1_GET_BAUDRATE;
#endif
baudrate++;
#ifdef UUTIL_DOUBLE_SPEED
baudrate*=8;
#else
baudrate*=16;
#endif
baudrate = _MCU_CLOCK_FREQUENCY_/baudrate;
printf("baudrate : %luBaud\r\n", baudrate);
}


// *********************************************************************************
/// \brief                   write the uutil tx-buffer to debug uart
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_tx(UUTIL_UART_DEVICE uart_device)
{
printf("UUTIL UART%u Tx-Buffer Top:%u/Bot:%u/Gap:%u\r\n", uart_device, uutil_buffer[uart_device].wtop, uutil_buffer[uart_device].wbottom, uutil_buffer[uart_device].wgap);
debug_display_mem_hex(uutil_buffer[uart_device].wbuffer, uutil_buffer[uart_device].wtop, 0);
debug_display_mem_hex(&uutil_buffer[uart_device].wbuffer[uutil_buffer[uart_device].wtop], UUTIL_WRITE_BUFFER_SIZE-uutil_buffer[uart_device].wtop, 0);
}


// *********************************************************************************
/// \brief                   write the uutil rx-buffer to debug uart
/// @param[in] uart_device   uart number 0/1
// *********************************************************************************
void uutil_rx(UUTIL_UART_DEVICE uart_device)
{
printf("UUTIL UART%u Rx-Buffer Top:%u/Bot:%u/Gap:%u\r\n", uart_device, uutil_buffer[uart_device].rtop, uutil_buffer[uart_device].rbottom, uutil_buffer[uart_device].rgap);
debug_display_mem_hex(uutil_buffer[uart_device].rbuffer, uutil_buffer[uart_device].rtop, 0);
debug_display_mem_hex(&uutil_buffer[uart_device].rbuffer[uutil_buffer[uart_device].rtop], UUTIL_READ_BUFFER_SIZE-uutil_buffer[uart_device].rtop, 0);
}


// ************************************************************************************************
/// \brief		Command handler for incoming commands
///
/// @param[in] 	command	- pointer to received string
/// @param[in] 	mode	- see debug.h
// ************************************************************************************************
void uutil_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
UUTIL_STATUS_STRUCTURE uutil_status;
unsigned int uart_device;

if (mode == DEBUG_HANDLER_MODE_INFO)
    {
    // add output for 'info' command here
    }                   
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
    // add output for 'help' command here
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
    {
    // add output for 'debug' command here
    }
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-info", 5)==0)
	    {
		uart_device = debug_get_int_parameter(command);
	    if (uutil_device_available(uart_device))
	        uutil_info(uart_device);
	    else
	    	printf("Specify valid UART device.\r\n");
	    }
	else if (strncmpf(command, "-rx", 3)==0)
		{
		uart_device = debug_get_int_parameter(command);
	    if (uutil_device_available(uart_device))
	        uutil_rx(uart_device);
	    else
	    	printf("Specify valid UART device.\r\n");
		}
	else if (strncmpf(command, "-tx", 3)==0)
		{
		uart_device = debug_get_int_parameter(command);
	    if (uutil_device_available(uart_device))
	        uutil_tx(uart_device);
	    else
	    	printf("Specify valid UART device.\r\n");
		}
	else if (strncmpf(command, "-status", 7)==0)
		{
		uart_device = debug_get_int_parameter(command);
	    if (uutil_device_available(uart_device))
	        {
	        uutil_get_status(&uutil_status, uart_device);   
	        printf("UUTIL status structure (uart %u)\r\n", uart_device);
	        printf("rcount:  %u\r\n", uutil_status.rcount);
	        printf("wcount:  %u\r\n", uutil_status.wcount);
	        printf("rlost:   %u\r\n", uutil_status.rlost);
	        printf("wlost:   %u\r\n", uutil_status.wlost);
	        printf("frm_err: %u\r\n", uutil_status.r_frame_error);
	        printf("ovr_run: %u\r\n", uutil_status.r_data_over_run);
	        printf("pty_err: %u\r\n", uutil_status.r_parity_error); 
	        }
	    else
	    	printf("Specify valid UART device.\r\n");
		}
	}
}
#endif 	// #ifdef UUTIL_DEBUG
#endif	// ifdef UUTIL_ENABLE