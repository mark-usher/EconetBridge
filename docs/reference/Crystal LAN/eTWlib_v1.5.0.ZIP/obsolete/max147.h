// ************************************************************************************************
///
/// 			\file max147.h
///
///  max147
///
/// \par Created 	21.02.2001
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#ifndef _MAX147_INCLUDED_
#define _MAX147_INCLUDED_

#define	CH_S_0		0x00	// AD-Channel 0 Single Ended
				// Differential: CH0+ and CH1-
#define	CH_S_1		0x40	// AD-Channel 1 Single Ended
				// Differential: CH1+ and CH0-
#define	CH_S_2		0x10	// AD-Channel 2 Single Ended
				// Differential: CH2+ and CH3-
#define	CH_S_3		0x50	// AD-Channel 3 Single Ended
				// Differential: CH3+ and CH2-
#define	CH_S_4		0x20	// AD-Channel 4 Single Ended
				// Differential: CH4+ and CH5-
#define	CH_S_5		0x60	// AD-Channel 5 Single Ended
				// Differential: CH5+ and CH4-
#define	CH_S_6		0x30	// AD-Channel 6 Single Ended
				// Differential: CH6+ and CH7-
#define	CH_S_7		0x70	// AD-Channel 7 Single Ended
				// Differential: CH7+ and CH6-

#define	AD_UNI		0x08	// unipolar mode 0V to Vref
#define	AD_BIP		0x00	// bipolar mode -Vref/2 to +Vref/2

#define	AD_SGL		0x04	// single ended voltage refered to COM
#define	AD_DIF		0x00	// differential betwenn to channel

#define	AD_PD_SLEEP	0x00	// power down mode
#define	AD_PD_INT	0x02	// internal clock cirka 2MHz
#define	AD_PD_EXT	0x03	// external clock

#define	FULL_RANGE	4096	// full range voltage
#define	HALF_RANGE	2048	// half range voltage

#pragma used+

extern	const char ad_channel[8];

extern	U16	ad_act_data;
extern	U16	ad_sample_counter;

extern	U8	ad_act_channel;
extern	U8	ad_act_delay[8];
extern	U8	ad_command[8];

void 	max147_init(U8 cs);
void 	max147_set_com(U8 channel);
S16 	max147_get_voltage(U16 data);
void 	max147_measure(void);

#pragma used-


// #pragma library max147.lib
#endif
