// ************************************************************************************************
///
/// 			\file rtc4553.h
///
/// Definitions and prototyps for rtc453-Module
///
/// \par Created 	xx.xx.200x
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
/// \author  		Carsten K�gler
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#ifndef _RTC4553_H_INCLUDED_
#define _RTC4553_H_INCLUDED_


#if (HARDWARE_VERSION<10)
#define	RTC4553_SS_ACTIV	DDRF|=0x10
#define	RTC4553_SS_PASSIV	DDRF&=~0x10
#define	RTC4553_SS_LOW 		PORTF&=~0x10
#define	RTC4553_SS_HIGH  	PORTF|=0x10
#define	RTC4553_SS_PIN  	(PINF&0x10)

#define	RTC4553_RW_ACTIV	DDRF|=0x10
#define	RTC4553_RW_PASSIV	DDRF&=~0x10
#define	RTC4553_RW_LOW 		PORTF&=~0x10
#define	RTC4553_RW_HIGH  	PORTF|=0x10
#define	RTC4553_RW_PIN  	(PINF&0x10)
#define	RTC4553_RW_READ 	RTC4553_RW_HIGH
#define	RTC4553_RW_WRITE 	RTC4553_RW_LOW
#endif

#if (HARDWARE_VERSION>=10)
#define	RTC4553_SS_ACTIV	DDRF|=0x04
#define	RTC4553_SS_PASSIV	DDRF&=~0x04
#define	RTC4553_SS_LOW 		PORTF&=~0x04
#define	RTC4553_SS_HIGH  	PORTF|=0x04
#define	RTC4553_SS_PIN  	(PINF&0x04)

#define	RTC4553_RW_ACTIV	DDRF|=0x08
#define	RTC4553_RW_PASSIV	DDRF&=~0x08
#define	RTC4553_RW_LOW 		PORTF&=~0x08
#define	RTC4553_RW_HIGH  	PORTF|=0x08
#define	RTC4553_RW_PIN  	(PINF&0x08)
#define	RTC4553_RW_READ 	RTC4553_RW_HIGH
#define	RTC4553_RW_WRITE 	RTC4553_RW_LOW
#endif

#define RTC4553_PONC_BIT    0x04

// Mode Selection                  
#define RTC4553_MODE0       0x0F       // Time/calendar counters and control registers 1-3	
#define RTC4553_MODE1       0x2F       // User RAM area Ra0-Ra59 and control register 3	 
#define RTC4553_MODE2       0x3F       // User RAM area Ra60-Ra119 and control register 3	 

typedef struct {
	unsigned char second;
	unsigned char minute;
	unsigned char hour;
	unsigned char day;
	unsigned char month;
	unsigned int year;
	} t_time;
  
#pragma used+
void 			rtc4553_init(void);
void	 		rtc4553_reset_rtc(void);
void 			rtc4553_set_rtc(t_time* new_sys_time);
unsigned char 	rtc4553_busy(void);
unsigned char 	rtc4553_read_rtc(t_time* new_sys_time);
void 			rtc4553_read_sec(t_time* new_sys_time);
unsigned char 	rtc4553_battery_change(void);
unsigned char 	rtc4553_read_ram(unsigned char adr, unsigned char mode);
void 			rtc4553_write_ram(unsigned char adr, unsigned char mode, unsigned char* data);
unsigned char 	rtc4553_check_device(void);
unsigned char 	rtc4553_CheckDevice(void);
#ifdef RTC4553_DEBUG
void 			rtc4553_debug_do_cmd(unsigned char *command);
#endif
#pragma used-

//#pragma library rtc4553.lib

#endif	// #ifndef _RTC4553_H_INCLUDED_