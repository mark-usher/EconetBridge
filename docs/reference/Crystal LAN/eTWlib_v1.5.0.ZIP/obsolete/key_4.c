// ************************************************************************************************
///
/// 			\file key_4.c
///
///  ATmega103
///
/// \par Created 	21.02.2001
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#include "defs.h"
#include "key_4.h"

#pragma regalloc-
unsigned char keys;
#pragma regalloc+

//#define	XTAL	3686400L

#if (XTAL==2000000)
#define	TIMER0_PRE		4		// Prescale=4 --> XTAL/64
#endif
#if ((XTAL==3686400)||(XTAL==4000000))
#define	TIMER0_PRE		5		// Prescale=5 --> XTAL/128
#endif

#if ((XTAL==7372800)||(XTAL==6000000))
#define	TIMER0_PRE		6		// Prescale=6 --> XTAL/256
#endif


/*********************************************************************************
; Description	: initalitation of Key-functions
; Input	   	: none
; Output   	: none
; Indication	: none
;*********************************************************************************/
void key_4_init(void)
{
// Port D
DDRD &= ~0x0f;		// PortD.3..0 input (IO4 .. IO1)

TCNT0=0x0;
TCCR0=TIMER0_PRE;	// Prescale
TIMSK|=0x01;		// enable Timer/Counter0 Overflow Interrupt Enable
}

#pragma regalloc-
/*********************************************************************************
; Description	: TIMER 0 overflow 
; Input	  	 	: none
; Output  	 	: none
; Indication	: interrupt at every:
;				 8,2 ms with 2.0000MHz
;				 8,9 ms with 3.6864MHz
;				 8,2 ms with 4.0000MHz
;				10,9 ms with 6.0000MHz
;				 8,9 ms with 7.3728MHz
;*********************************************************************************/
interrupt [TIM0_OVF] void timer0_int(void)
{
static char key_pressed_counter=KEY_PRESSED_COUNTER;
static char key_released_counter=0;
static U8 last_key=0;
static U8 key_activ=FALSE;
U8 act_key;

act_key=(PIND & 0x0f);
if(act_key!=0x0f)
	{
	key_pressed_counter--;
	if(key_released_counter==0)
		key_released_counter=KEY_RELEASED_COUNTER;
	if(key_pressed_counter<=0)
		{
		if(key_activ==FALSE)
			{
			if((act_key & KEY1)==0)
				{
				last_key=keys=KEY1;
				}
			if((act_key & KEY2)==0)
				{
				last_key=keys=KEY2;
				}
			if((act_key & KEY3)==0)
				{
				last_key=keys=KEY3;
				}
			if((act_key & KEY4)==0)
				{
				last_key=keys=KEY4;
				}
			key_activ=TRUE;
			}
		else
			{
			if(KEY_CONT==TRUE)
				{
				key_activ=FALSE;	// reset the key 
				key_pressed_counter=KEY_CONT_COUNTER;
				}
			}
		}
	}
else
	{
	if(key_released_counter>0)
		{
		key_released_counter--;
		if(key_released_counter==0)
			{
			key_pressed_counter=KEY_PRESSED_COUNTER;
			key_activ=FALSE;	// reset the 
			if(last_key == KEY1)
				{
				keys=KEY1_RELEASE;
				}
			if(last_key == KEY2)
				{
				keys=KEY2_RELEASE;
				}
			if(last_key == KEY3)
				{
				keys=KEY3_RELEASE;
				}
			if(last_key == KEY4)
				{
				keys=KEY4_RELEASE;
				}
			}
		}
	}
}
#pragma regalloc+

/*********************************************************************************
; Description	: test if a key was pressed
; Input	   	: none
; Output   	: none
; Indication	: none
;*********************************************************************************/
unsigned char key_4_inkey(void)
{
unsigned char k;
if (k=keys) keys=0;
return k;
}

