// ************************************************************************************************
///
/// 			\file dac_mb88346b.c
///
/// control of digital analog converter device MB88346B <br>
/// application uses two devices connected in shift register order
///
/// \par Created 	27.09.2005
/// \date			$LastChangedDate: 2007-03-22 10:28:39 +0100 (Do, 22 Mrz 2007) $
/// \version 		$Rev: 649 $
/// \author  		Udo Jakobza, Thomas Kellner
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************
#include "project.h"		// Project configuration

#ifdef MB88346B_ENABLE
#include <io.h>
#include "mb88346b.h"
#include "debug.h"
                                              
// global variable dac_serial_data will be used as shift register in isr, order of content
// | bit 15-12 device no.| bit 11-4 dac data (lsb first) | bit 3-0 address (msb first) |
unsigned int  dac_mb88346b_serial_data;
unsigned char dac_mb88346b_conv_status=DAC_CONV_READY;
#ifdef MB88346B_DEBUG
eeprom unsigned char mb88346b_debug_flag=0;
                                                    
void mb88346b_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);
#endif

// *********************************************************************************
/// \brief  init timer0
// *********************************************************************************
void dac_mb88346b_timer_init(void)
{
// on rising edge of clock pulse, data is inputted to DI-pin of DAC
TCCR0 = 0;				    // stop timer
TCNT0 = 0;				    // reset timer
OCR0 += TIMER0_COMP;	    // init output compare register
TCCR0 = TIMER0_PRE;		    // set prescale and compare match output mode
TIFR |= TIMER0_OC_FLAG;     // clear Interrupt Flag "Timer/Counter0 Output Compare Match Flag"
}


// *********************************************************************************
/// \brief  init pins
// *********************************************************************************
void dac_mb88346b_init(void)
{
#ifdef MB88346B_DEBUG
T_DEBUG_HANDLER_STRUCT p_struct;
                       
p_struct.fp_handler = &mb88346b_debug_handler;
p_struct.id_string = "dac-";
debug_register_handler(&p_struct);
#endif
DAC_MB88346B_PORT &= ~DAC_MB88346B_DI_BIT;
DAC_MB88346B_PORT |= DAC_MB88346B_CLK_BIT;
DAC_MB88346B_PORT &= ~DAC_MB88346B_LOAD_BIT;
DAC_MB88346B_DIR;
dac_mb88346b_timer_init();
}


// *********************************************************************************
/// \brief              start conversation to load dac with value
/// \param[in] value    value for dac channel
/// \param[in] address  address of dac channel
/// \param[in] device   dac device 1 or 2
/// \return             1 - dac conversation ready; 0 - dac coversation busy
// *********************************************************************************
unsigned char dac_mb88346b_load(unsigned char value, unsigned char address, unsigned char device)
{
// function must not be called to often because global variable dac_mb88346b_serial_data is shared
// with and changed in interrupt routine
unsigned char i;

if(dac_mb88346b_conv_status==DAC_CONV_READY)
	{
    if((address==0) || (address>DAC_MB88346B_ADDRESS_MAX) || (device>=DAC_MB88346B_DEVICE_MAX))
    	return 0;
	#ifdef MB88346B_DEBUG
	if(mb88346b_debug_flag & MB88346B_DEBUG_BIT)
		printf("MB88346B dac load: device %u / address: %u / value: %u (0x%02x)\r\n", device, address, value, value);
	#endif
    dac_mb88346b_serial_data = 0;
    for(i=0;i<8;i++)
    	{
    	dac_mb88346b_serial_data <<= 1;
    	dac_mb88346b_serial_data |= value&0x01;
    	value >>= 1;
    	}
    dac_mb88346b_serial_data <<= 4;
    dac_mb88346b_serial_data |= address;
    if(device==DAC_DEVICE_2)
    	dac_mb88346b_serial_data |= 0x1000;	// set device 2 bit
	dac_mb88346b_conv_status = DAC_CONV_BUSY;
    OCR0 = TCNT0 + TIMER0_COMP;
    TIMSK |= TIMER0_OCIE;  	// enable "Timer/Counter0 Output Compare Match Interrupt Enable"
    return 1;
    }
else
    return 0;
}


// *********************************************************************************
/// \brief  timer0 compare isr includes statemachine for dac conversation,
///         creates clock and data signal and load pulse
// *********************************************************************************
interrupt [TIM0_COMP] void dac_mb88346b_timer_comp_isr(void)
{
static unsigned char    dac_signal_status=DAC_DATA_SHIFT_1;
static unsigned char    dac_clk_state=1, dac_clk_count=0;

switch(dac_signal_status)
    {
    case(DAC_DATA_SHIFT_1):
    case(DAC_DATA_SHIFT_2):
        if(dac_clk_state==1)
        	{
           	DAC_MB88346B_PORT &= ~DAC_MB88346B_CLK_BIT;
           	dac_clk_state = 0;
            if(dac_clk_count<12)		// shift out data
            	{
                if(dac_mb88346b_serial_data&0x01)
                   	DAC_MB88346B_PORT |= DAC_MB88346B_DI_BIT;
                else
                   	DAC_MB88346B_PORT &= ~DAC_MB88346B_DI_BIT;
            	dac_mb88346b_serial_data >>= 1;
            	}
        	}
        else
        	{
           	DAC_MB88346B_PORT |= DAC_MB88346B_CLK_BIT;    // rising edga of dac_clk will latch dac_di
           	dac_clk_state = 1;
        	dac_clk_count++;
           	}
        if((dac_clk_state==1) && ((dac_clk_count==12)||(dac_clk_count==24)))
        	{
        	if(dac_signal_status==DAC_DATA_SHIFT_1)
        		{
    			if((dac_mb88346b_serial_data & 0x01)==0x01)	// second device selected
    				dac_signal_status = DAC_DATA_SHIFT_2;
    			else
    				dac_signal_status = DAC_LOAD_PULSE_START;
        		}
        	else if(dac_signal_status==DAC_DATA_SHIFT_2)
        	    dac_signal_status = DAC_LOAD_PULSE_START;   // request load pulse 2nd device
            }
        break;
    case(DAC_LOAD_PULSE_START):
       	DAC_MB88346B_PORT |= DAC_MB88346B_LOAD_BIT;
       	dac_signal_status = DAC_LOAD_PULSE_END;
       	break;
    case(DAC_LOAD_PULSE_END):
       	DAC_MB88346B_PORT &= ~DAC_MB88346B_LOAD_BIT;
        if(dac_clk_count==24)       // 2nd device
            {
           	dac_clk_count = 0;
            dac_signal_status = DAC_CONV_END;
           	}
        else                        // 1st device
           	dac_signal_status = DAC_DUMMY_SHIFT;
       	break;
    case(DAC_DUMMY_SHIFT):
        if(dac_clk_state==1)
        	{
           	DAC_MB88346B_PORT &= ~DAC_MB88346B_CLK_BIT;
           	dac_clk_state = 0;
        	}
        else
        	{
           	DAC_MB88346B_PORT |= DAC_MB88346B_CLK_BIT;    // rising edga of dac_clk will latch dac_di
           	dac_clk_state = 1;
           	if(--dac_clk_count==0)
                dac_signal_status = DAC_CONV_END;
            }
        break;
    case(DAC_CONV_END):
       	DAC_MB88346B_PORT &= ~DAC_MB88346B_DI_BIT;
        dac_signal_status = DAC_DATA_SHIFT_1;
    	dac_mb88346b_conv_status = DAC_CONV_READY;
       	TIMSK &= ~TIMER0_OCIE;      // disable "Timer/Counter0 Output Compare Match Interrupt Enable"
       	break;
    default:
    }
OCR0 += TIMER0_COMP;
}


#ifdef MB88346B_DEBUG
// *********************************************************************************
/// \brief                  debug command handler
/// \param[in] command      pointer to command string
/// \param[in] mode         mode of debug command
// *********************************************************************************
void mb88346b_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
unsigned char param1, param2, param3;

if(mode==DEBUG_HANDLER_MODE_INFO)
    {
    printf("MB88346B_DEBUG");
	if(mb88346b_debug_flag & MB88346B_DEBUG_BIT)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
	}
else if(mode==DEBUG_HANDLER_MODE_HELP)
    {
    }
else if(mode==DEBUG_HANDLER_MODE_SWITCH)
	{
	if(strncmpf(command, "dac", strlenf("dac"))==0)
	    {
    	mb88346b_debug_flag ^= MB88346B_DEBUG_BIT;
    	printf("MB88346B_DEBUG");
    	if (mb88346b_debug_flag & MB88346B_DEBUG_BIT)
    		printf(" ON\r");
    	else
    		printf(" OFF\r");
	    }
	}
// if(mode==DEBUG_HANDLER_MODE_CMD) 
else if(strncmpf(command, "load", 4)==0)
    {
    param1 = debug_get_int_parameter(command);
    command = debug_search_parameter(command);
    param2 = debug_get_int_parameter(command);
    command = debug_search_parameter(command);
    param3 = debug_get_int_parameter(command);
    dac_mb88346b_load(param1, param2, param3);
    }
}
#endif  // #ifdef MB88346B_DEBUG
#endif  // #ifdef MB88346B_ENABLE
