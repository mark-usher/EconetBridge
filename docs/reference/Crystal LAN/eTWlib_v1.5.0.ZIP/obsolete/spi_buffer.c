// ************************************************************************************************
///
/// 			\file spi_buffer.c
///
///  SPI buffer
///
/// \par Created 	10.04.2001
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#include "defs.h"
#include "avr_spi.h"

#pragma regalloc-

U8		spi_receive_buffer[SPI_READ_BUFFERSIZE];
U8		spi_transmit_buffer[SPI_WRITE_BUFFERSIZE];

SPI_BUFFER	spi_buffer;		
#pragma regalloc+


/*********************************************************************************
; Description	: init the SPI-interface with buffer
; Input	   	: none
; Output   	: none
; Indication	: none
;*********************************************************************************/
void	spi_buffer_enable(U8 mode)
{
spi_buffer_clear();
spi_buffer.rbuffer=spi_receive_buffer;			// rbuffer
spi_buffer.wbuffer=spi_transmit_buffer;			// wbuffer
spi_init(mode);
}


/*********************************************************************************
; Description	: test the buffer whether Data present
; Input		: none
; Output	: 1..x - Data present
;		  0    - no Data present
; Indication	: none
;*********************************************************************************/
U8	spi_buffer_isdata(void)
{
return (SPI_READ_BUFFERSIZE-spi_buffer.rgap);
}


#if funcused spi_data_free
/*********************************************************************************
; Description	: check the size of transmit-buffer
; Input		: none
; Output	: 1..x - size of free buffer
;		  0    - buffer full
; Indication	: none
;*********************************************************************************/
U8	spi_buffer_data_free(void)
{
return spi_buffer.wgap;
}
#endif

/*********************************************************************************
; Description	: send a char to the uart
; Input		: "data" sign, that to send
; Output	: none
; Indication	: none
;*********************************************************************************/
void	spi_buffer_write(char data)
{
if(spi_buffer.wgap>0)
	{
	SPI_INTERRUPT=0;   	// disable SPI-Interrupt
	spi_buffer.wbuffer[spi_buffer.wtop]=data;
	spi_buffer.wtop++;
	if(spi_buffer.wtop==SPI_WRITE_BUFFERSIZE)
		{
		spi_buffer.wtop=0;
		}
	spi_buffer.wgap--;
	SPI_INTERRUPT=1;   	// enable SPI-Interrupt
	}
}

/*********************************************************************************
; Description	: read a char from uart
; Input	      	: none
; Output      	: the character
; Indication	: none
;*********************************************************************************/
char 	spi_buffer_read(void)
{
char Lva=0x0;

if(spi_buffer.rgap<SPI_READ_BUFFERSIZE)
	{
	SPI_INTERRUPT=0;   	// disable SPI-Interrupt
	Lva=spi_buffer.rbuffer[spi_buffer.rbottom];
	spi_buffer.rbottom++;
	if(spi_buffer.rbottom==SPI_READ_BUFFERSIZE)
		{
		spi_buffer.rbottom=0;
		}
	spi_buffer.rgap++;
	SPI_INTERRUPT=1;   	// enable SPI-Interrupt
	}
return Lva;
}


#if funcused spi_buffer_write_data
/*********************************************************************************
; Description	: write a buffer to the comport
; Input		: 1.)data   : pointer to data
;		: 2.)size   : size of data
; Output	: none
; Indication	: none
;*********************************************************************************/
U8 	spi_buffer_write_data(U8 *data, U8 size) 
{
U8		Lva;

for(Lva=0;Lva<size;Lva++)
	{ 
	spi_putchar(*data);
	data++;
	}
return Lva;
}
#endif

#if funcused spi_buffer_read_data
/*********************************************************************************
; Description	: read from buffer
; Input	    	: 1.)data   : pointer to data
;	    	: 2.)size   : size of data
; Output    	: none
; Indication	: none
;*********************************************************************************/
U8 	spi_buffer_read_data(U8 *data, U8 size) 
{
U8		Lva;

for(Lva=0;Lva<size;Lva++)
	{ 
	*data=spi_getchar();
	data++;
	}
return Lva;
}
#endif

#if funcused spi_buffer_puts
/*********************************************************************************
; Description	: write a string to the comport
; Input		: string: Pointer to a string
; Output	: none
; Indication	: none
;*********************************************************************************/
void	spi_buffer_puts(char *string)
{
#ifdef _MODEL_TINY_
#asm
    clr  r31
#endasm
#endif

#ifdef _MODEL_SMALL_
#asm
    ldd  r31,y+1
#endasm
#endif
while (*string != 0x0)
	{
	spi_buffer_putchar(*string);
	string++ ;
	}
}
#endif

#if funcused spi_buffer_putsf
/*********************************************************************************
; Description	: write a string located in FLASH to the comport
; Input		: string: Pointer to a string
; Output	: none
; Indication	: none
;*********************************************************************************/
void	spi_buffer_putsf(char flash *string)
{
while (*string!= 0x0)
	{
	spi_buffer_putchar(*string);
	string++ ;
	}
}
#endif

/*********************************************************************************
; Description	: clears all buffer of spi-interface
; Input		: none
; Output	: none
; Indication	: none
;*********************************************************************************/
void	spi_buffer_clear(void)
{
spi_buffer.rtop=0;
spi_buffer.rbottom=0;
spi_buffer.rgap=SPI_READ_BUFFERSIZE;
spi_buffer.wtop=0;
spi_buffer.wbottom=0;
spi_buffer.wgap=SPI_WRITE_BUFFERSIZE;
}

/*********************************************************************************
; Description	: SPI-Handler
; Input	   	: none
; Output   	: none
; Indication	: none
;*********************************************************************************/
interrupt [SPI_STC] void irq_spi(void)
{
U8	data;

data=SPDR;
if(spi_buffer.rgap>0)
	{
	spi_buffer.rgap--;
	spi_buffer.rbuffer[spi_buffer.rtop]=data;
	spi_buffer.rtop++;
	if(spi_buffer.rtop==SPI_READ_BUFFERSIZE)
		{
		spi_buffer.rtop=0;
		}
	}
if(spi_buffer.wgap<SPI_WRITE_BUFFERSIZE)
	{
	spi_buffer.wgap++;
	SPDR=spi_buffer.wbuffer[spi_buffer.wbottom];
	spi_buffer.wbottom++;
	if(spi_buffer.wbottom==SPI_WRITE_BUFFERSIZE)
		{
		spi_buffer.wbottom=0;
		}
	}
}



#if funcused spi_buffer_test
/*********************************************************************************
; Description	: spi test
; Input	   	: none
; Output   	: none
; Indication	: none
;*********************************************************************************/
void 	spi_buffer_test(U8 pos)
{
U8	k;
static	U8	x1_pos=0;

if((x1_pos>15)||(pos==0))
	{
	lcd_clear_line(1);
	x1_pos=0;
	if(pos==0)
		return;
	}
lcd_gotoxy(x1_pos,1);
k=spi_buffer_read();
lcd_putchar(k);
x1_pos++;
}
#endif
