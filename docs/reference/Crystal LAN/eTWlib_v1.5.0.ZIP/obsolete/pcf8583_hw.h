// ************************************************************************************************
///
///			\file pcf8583_hw.h
///
///  Functions for the Philips PCF8583 I2C bus Real Time Clock
///
/// \par Created 	24.01.2002
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright	(C) 1998-2003 Pavel Haiduc, HP InfoTech S.R.L.

///					modified by
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************


#ifndef _PCF8583_HW_INCLUDED_
#define _PCF8583_HW_INCLUDED_

#pragma used+

extern unsigned char __rtc_status;
extern bit __rtc_alarm;

unsigned char rtc_read(unsigned char chip,unsigned char address);
void rtc_write(unsigned char chip, unsigned char address,unsigned char data);
unsigned char rtc_get_status(unsigned char chip);
void rtc_init(unsigned char chip,unsigned char dated_alarm);
void rtc_alarm_off(unsigned char chip);
void rtc_alarm_on(unsigned char chip);
void rtc_get_time(unsigned char chip,unsigned char *hour,unsigned char *min, unsigned char *sec,unsigned char *hsec);
void rtc_set_time(unsigned char chip,unsigned char hour,unsigned char min, unsigned char sec,unsigned char hsec);
void rtc_get_date(unsigned char chip,unsigned char *date,unsigned char *month, unsigned *year);
void rtc_set_date(unsigned char chip,unsigned char date,unsigned char month, unsigned year);
void rtc_get_alarm_time(unsigned char chip,unsigned char *hour, unsigned char *min,unsigned char *sec,unsigned char *hsec);
void rtc_set_alarm_time(unsigned char chip,unsigned char hour, unsigned char min,unsigned char sec,unsigned char hsec);
void rtc_get_alarm_date(unsigned char chip,unsigned char *date, unsigned char *month);
void rtc_set_alarm_date(unsigned char chip,unsigned char date, unsigned char month);

#pragma used-
//#pragma library pcf8583_hw.lib

#endif	// #ifndef _PCF8583_HW_INCLUDED_

