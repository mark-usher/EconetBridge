// ************************************************************************************************
///
/// 			\file max147.c
///
///  max147
///
/// \par Created 	21.02.2001
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#include <io.h>
#include "defs.h"
#include "avr_spi.h"
#include "max147.h"
#include "timer.h"

#pragma used+

const char ad_channel[8]={CH_S_0, CH_S_1, CH_S_2, CH_S_3, CH_S_4, CH_S_5, CH_S_6, CH_S_7};

U8	ad_counter;
U16	ad_act_data;
U16	ad_sample_counter=0;

U8	ad_act_channel=0;
U8 	ad_act_delay[8]={1, 2, 2, 4, 4, 5, 5, 5};
U8	ad_command[8]={0x8f | CH_S_0, 0x8f | CH_S_1, 0x8f | CH_S_2, 0x8f | CH_S_3, 
		       0x8f | CH_S_4, 0x8f | CH_S_5, 0x8f | CH_S_6, 0x8f | CH_S_7};
#pragma used-

/*********************************************************************************
; Description	: initalitation of SPI-Interface
; Input	   		: none
; Output   		: none
; Indication	: none
;*********************************************************************************/
void max147_init(U8 channel)
{
// SPCR_SPIE	SPI Interrupt Enable
// SPCR_SPE		SPI Enable
// SPCR_DORD	SPI Data Order 1=LSB; 0=MSB
// SPCR_MSTR	SPI Master/Slave Select
// SPCR_CPOL	SPI Clock Polarity 1=SCK=HIGH; 0=SCK=LOW
// SPCR_CPHA	SPI Clock Phase
// SPCR_128		SPI Clock 1/128 Main-Clock
// SPCR_64		SPI Clock 1/64 Main-Clock
// SPCR_16		SPI Clock 1/16 Main-Clock
// SPCR_4		SPI Clock 1/4 Main-Clock
spi_103_init(SPCR_SPE | SPCR_MSTR | SPCR_16);
spi_103_set_cs(channel);
SPDR=ad_command[ad_act_channel];	// write command to MAX147
ad_counter=1;
ad_act_data=0;
}

/*********************************************************************************
; Description	: sets the new command
; Input	  	 	: none
; Output   		: none
; Indication	: none
;*********************************************************************************/
void max147_set_com(U8 channel)
{
ad_act_channel=channel;
ad_command[channel]=0x80 | AD_UNI | AD_DIF | ad_channel[channel] | AD_PD_EXT; 
}


/*********************************************************************************
; Description	: calculate the voltage with Vref and mode
; Input	    	: none
; Output    	: none
; Indication	: none
;*********************************************************************************/
S16 max147_get_voltage(U16 data)
{
S16	value;

value=data;
if((ad_command[ad_act_channel] & AD_UNI)==0)
	{
	if(value>2047)
		value-=FULL_RANGE;
	}
return value;
}


/*********************************************************************************
; Description	: measure-routine for MAX147
; Input	  	 	: none
; Output  	 	: none
; Indication	: none
;*********************************************************************************/
void max147_measure(void)
{
static	U8 ad_delay_counter=0;
static	U8 old_counter_10ms=0;

if(counter_10ms!=old_counter_10ms)
	{
	old_counter_10ms=counter_10ms;
	if(ad_delay_counter==0)
		{
		ad_delay_counter=ad_act_delay[ad_act_channel];
		spi_103_set_cs(SPI_CS_0);
		SPDR=ad_command[ad_act_channel];	// write command to MAX147
		ad_counter=1;
		}
	ad_delay_counter--;
	}
}


/*********************************************************************************
; Description	: SPI Interrupt
; Input	 	  	: none
; Output  	 	: none
; Indication	: none
;*********************************************************************************/
interrupt [SPI_STC] void max147_int(void)
{
static U16	ad_data_buffer;

ad_counter++;
if(ad_counter==2)
	{
	ad_data_buffer=SPDR;	// read a dummy-byte
	SPDR=0x00;     	 		// write dummy-data to MAX147
	}
if(ad_counter==3)
	{
	ad_data_buffer=SPDR;	// read the MSB-Byte from MAX147
	ad_data_buffer<<=5;		// move MSB-Byte
	SPDR=0x00;     	  		// write dummy-data to MAX147
	}
if(ad_counter>3)
	{
	spi_103_clear_cs();
	ad_sample_counter++;
	ad_data_buffer|=(SPDR>>3);	// read the LSB-Byte from MAX147
	ad_act_data=ad_data_buffer;
	}
}

