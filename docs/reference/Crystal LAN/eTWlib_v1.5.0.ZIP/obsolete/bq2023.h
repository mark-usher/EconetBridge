// ************************************************************************************************
///
/// 			\file 1wire_irq.c
///
///  TI (Benchmarq) BQ2023 1 Wire bus Battery Monitor functions
///
/// \par Created 	23.10.2002
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************


#ifndef _BQ2023_INCLUDED_
#define _BQ2023_INCLUDED_

#ifndef NULL
#define NULL 	0x0
#endif

#define	BQ2023_DEBUG

#define	BQ2023_IRQ		// controls the use of disable and enable of global IRQ

#define BQ2023_FAMILY_CODE 0xb2
// read-enable register of BQ2023
typedef enum {TEMPL=0x02, TEMPH, CLR, MODE_WOE, CTCL, CTCH, DTCL, DTCH, SCRL, SCRH, CCRL, CCRH, DCRL, DCRH} BQ2023_R_REG;
// write-enable register of BQ2023
typedef enum {CLR=0x04, MODE_WOE} BQ2023_W_REG;

#define LO(x) ((unsigned char)  ((x)&0x00ff))		//returns the lower end byte of an integer
#define HI(x) ((unsigned char) (((x)>>8)&0x00ff))	//returns the higher end byte of an integer   

// MODE/WOE-Register
#define		MODE_SLEN	0x40
#define		MODE_STC	0x20
#define		MODE_STD	0x10
#define		WOE_2135	0x02		// Wake-Up Output Enable bit with 21.35�V
#define		WOE_1830	0x04		// Wake-Up Output Enable bit with 18.30�V
#define		WOE_1525	0x06		// Wake-Up Output Enable bit with 15.25�V
#define		WOE_1220	0x08		// Wake-Up Output Enable bit with 12.20�V
#define		WOE_915		0x0a		// Wake-Up Output Enable bit with 9.15�V
#define		WOE_610		0x0c		// Wake-Up Output Enable bit with 6.10�V
#define		WOE_305		0x0e		// Wake-Up Output Enable bit with 3.05�V


// CLR Clear-Register
#define		CLR_POR		0x40		// Power on
#define		CLR_STAT	0x20		// sets the STAT-output
#define		CLR_CTC		0x10		// delete the CTCH and CTCL Register
#define		CLR_DTC		0x08		// delete the DTCH and DTCL Register
#define		CLR_SCR		0x04		// delete the SCRH and SCRL Register
#define		CLR_CCR		0x02		// delete the CCRH and CCRL Register
#define		CLR_DCR		0x01		// delete the DCRH and DCRL Register

#define		OVERFLOW_CHECK			3*6000	// every 180 second - 3min
#define		DISCHARGE_CHECK			60*6000	// every 3600 second - 60min
#define		MAX_DISCHARGE_VALUE		25

// RAM-address for overflow variables
#define		RAM_START			0xe0	//  starts the RAM address
#define		RAM_SIZE			32		//  size of RAM
#define		OVERFLOW_START		0xe0	//  overflow-counter start-address
#define		OVERFLOW_SIZE		6		//  size of overflow-counter
#define		DCR_OVERFLOW_8		0xe0	//  8Bit overflow-counter for Discharge Count Register
#define		CCR_OVERFLOW_8		0xe1	//  8Bit overflow-counter for Charge Count Register
#define		DTC_OVERFLOW_16		0xe2	// 16Bit overflow-counter for Discharge Time Counter
#define		CTC_OVERFLOW_16		0xe4	// 16Bit overflow-counter for Charge Time Counter

typedef struct 
	{
	unsigned char	dcr_overflow;		// 8Bit overflow-counter for Discharge Count Register
	unsigned char	ccr_overflow;		// 8Bit overflow-counter for Charge Count Register
	unsigned int	dtc_overflow;		// 8Bit overflow-counter for Discharge Time Register
	unsigned int	ctc_overflow;		// 8Bit overflow-counter for Charge Time Register
	unsigned char	ok;					// 8Bit overflow-counter for Charge Time Register
	}BQ2023_OVERFLOW;


#pragma used+

extern BQ2023_OVERFLOW	bq2023_overflow;
extern unsigned char	romcodes_1wire[1,9];
extern unsigned char 	*bq2023_romcode;

// **********************************************************************************
// Description   : debug-frontend for BQ2023-functions
// Input         : none
// Output     	 : 0: doesn't serve the command
// 		     	   1: serves the command
// Indication	 : none
// **********************************************************************************
unsigned char	bq2023_do_cmd(unsigned char *command);

// ********************************************************************************
// Description	: this function initializes the 1 Wire devices on the bus.
// Input	   	: none
// Output      	: 1.) return==0x00 - 1wire device not present
//				      return==0x01 - 1wire device found
// Indication	: none
// *********************************************************************************
unsigned char w1_init_irq(void);

// ********************************************************************************
// Description	: this function reads a byte from the 1 Wire bus.
// Input	   	: none
// Output      	: 1.) data of 1wire device
// Indication	: check with "w1_init" wether 1wire device is present
// *********************************************************************************
unsigned char w1_read_irq(void);

// ********************************************************************************
// Description	: this function writes the byte data to the 1 Wire bus.
// Input	   	: 1.) data - data to 1wire device
// Output      	: 1.) return==0x00 - 1wire write not ok
//				      return==0x01 - 1wire write ok
// Indication	: check with "w1_init" wether 1wire device is present
// *********************************************************************************
unsigned char w1_write_irq(unsigned char data);

// ********************************************************************************
// Description	: calculates with overflow-variables the discharge+time+temp
// Input	   	: 1.) *buffer - pointer to >16 Byte-Array
//          	  2.) *temp - int varibale with temp-value in 4*x*Kelvin
//          	  3.) *discharge - long variable with discharge-value in �Ah
//          	  4.) *time - long variable with time in second
// Output      	: 1.) return==0x00 - Error
//				      return!=0x00 - OK BQ2023 found
// Indication	: none
// *********************************************************************************
unsigned char bq2023_discharge(unsigned char *buffer, signed int *temp, 
								unsigned long *discharge, unsigned long *time);

// ********************************************************************************
// Description	: calculates with overflow-variables the discharge+time+temp
// Input	   	: 3.) *discharge - long variable with discharge-value in �Ah in last 24hour
//          	  4.) *time - char variable with time in hour
// Output      	: none
// Indication	: none
// *********************************************************************************
void bq2023_discharge24(unsigned long *discharge24, unsigned char *time);


// ********************************************************************************
// Description	: init the 1-wire-Interface and check BQ2023
// Input	   	: none
// Output      	: 1.) return==0x01 - OK BQ2023 found
//				      return==0x00 - Error
// Indication	: none
// *********************************************************************************
unsigned char bq2023_init(void);

// ********************************************************************************
// Description	: resets all register
// Input	   	: 1.) *romcode - pointer to 9Byte-Array with ROM-number
// Output      	: 1.) return==0x01 - OK BQ2023 found
//				      return==0x00 - Error
// Indication	: none
// *********************************************************************************
unsigned char bq2023_reset(unsigned char *romcode);

// **********************************************************************************
// Description	: checks the BQ2023 overflow cyclic
// Input	   	: none
// Output      	: none
// Indication	: none
// **********************************************************************************
void bq2023_overflow_execute(void);

// ********************************************************************************
// Description	: read a block of size bytes
// Input	   	: 1.) *romcode - pointer to 9Byte-Array with ROM-number
//                2.) *dest - pointer to Data-Array
//                3.) addr - addr of FLASH, SRAM and Register
//                4.) size - size to read from FLASH, SRAM and Register
// Output      	: 1.) return==0x01 - OK
//				      return==0x00 - error
// Indication	: none
// *********************************************************************************
unsigned char bq2023_read_data(unsigned char *romcode,
		unsigned char *dest, unsigned int addr, unsigned char size);

// ********************************************************************************
// Description	: read a block of registers until the end of registers
// Input	   	: 1.) *romcode - pointer to 9Byte-Array with ROM-number
//                2.) *dest - pointer to Data-Array
//                3.) start_addr - addr of Register
// Output      	: 1.) return==0x01 - OK
//				      return==0x00 - error
// Indication	: none
// *********************************************************************************
unsigned char bq2023_read_all_register(unsigned char *romcode,
		unsigned char *dest, unsigned int start_addr);

// ********************************************************************************
// Description	: read a block of size bytes, starting from application
// Input	   	: 1.) *romcode - pointer to 9Byte-Array with ROM-number
//                2.) dest - Data-Byte
//                3.) addr - addr of Register only
// Output      	: 1.) return==0x01 - OK
//				      return==0x00 - error
// Indication	: none
// *********************************************************************************
unsigned char bq2023_read_register(unsigned char *romcode,
		unsigned char dest, BQ2023_R_REG addr);


//#if funcused bq2023_write_register
// ********************************************************************************
// Description	: write a byte to register
// Input	   	: 1.) *romcode - pointer to 9Byte-Array with ROM-number
//                2.) source - Data-Byte
//                3.) addr - addr of Write-Enable-Register
// Output      	: 1.) return==0x01 - OK
//				      return==0x00 - error
// Indication	: none
// *********************************************************************************
unsigned char bq2023_write_register(unsigned char *romcode,
		unsigned char source, BQ2023_W_REG addr);

//#if funcused bq2023_write_flash
// ********************************************************************************
// Description	: write a block to flash of size bytes
// Input	   	: 1.) *romcode - pointer to 9Byte-Array with ROM-number
//                2.) *source - pointer to Data-Array
//                3.) addr - addr of flash
//                4.) size - size to write to flash
// Output      	: 1.) return==0x01 - OK
//				      return==0x00 - error
// Indication	: none
// *********************************************************************************
unsigned char bq2023_write_flash(unsigned char *romcode,
		unsigned char *source, unsigned char addr, unsigned char size);

// ********************************************************************************
// Description	: write a block to ram of size bytes
// Input	   	: 1.) *romcode - pointer to 9Byte-Array with ROM-number
//                2.) *source - pointer to Data-Array
//                3.) addr - addr of BQ2023-RAM
//                4.) size - size to write to RAM
// Output      	: 1.) return==0x01 - OK
//				      return==0x00 - error
// Indication	: none
// *********************************************************************************
unsigned char bq2023_write_ram(unsigned char *romcode,
		unsigned char *source, unsigned char addr, unsigned char size);


// ********************************************************************************
// Description	: calculates the CRC-value with start-value
// Input	   	: 1.) *p - pointer to Data-Array
//                2.) n - count of data
//                3.) start - start-value
// Output      	: 1.) return==CRC-value
// Indication	: none
// *********************************************************************************
unsigned char w1_dow_crc8_new(void *p, unsigned char n, unsigned char start);

// **********************************************************************************
// Description	: read and displays the sram and flash from BQ2023
// Input	   	: none
// Output      	: none
// Indication	: none
// **********************************************************************************
void bq2023_display_data(void);

// **********************************************************************************
// Description	: write a pattern to SRAM from BQ2023
// Input	   	: none
// Output      	: none
// Indication	: none
// **********************************************************************************
void bq2023_backup(void);

// **********************************************************************************
// Description	: read and displays the register from BQ2023
// Input	   	: none
// Output      	: none
// Indication	: none
// **********************************************************************************
unsigned char bq2023_display_register(void);

#pragma used-
//#pragma library bq2023.lib

#endif

