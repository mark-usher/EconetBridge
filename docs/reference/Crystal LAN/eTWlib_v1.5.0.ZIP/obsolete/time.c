// ************************************************************************************************
///
/// 			\file time.c
///
/// time-functions
///
/// \par Created 	05.08.2002
/// \date	 		$LastChangedDate: 2007-01-09 14:51:12 +0100 (Di, 09 Jan 2007) $
/// \version 		$Rev: 454 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************

#include "project.h"

#include <stdio.h>
#include <math.h>
#include "time.h"


// **********************************************************************************
// Description	: displays the actual time 
// Input	   	: 1.) act_time: new time with 10ms resolution or 1 second
// 				  2.) factor: TIME_1(second) or TIME_100(100ms)
// Output      	: none
// Indication	: none
// **********************************************************************************
void time_display(unsigned long act_time, TIME_FACTOR factor)
{
TIME_DATA time_data;

time_calculate(act_time, &time_data, factor);
printf("%ud %02u:%02u:%02u:%02u0\n\r",time_data.day, 
									 time_data.hour, 
									 time_data.minute,
									 time_data.second,
									 time_data.ms);
}


flash unsigned long divide_factor[8]={86400, 3600, 60, 1, 8640000, 360000, 6000, 100}; 
// **********************************************************************************
// Description	: displays the actual time 
// Input	   	: 1.) act_time: new time with 10ms resolution or 1 second
// 				  2.) *time_data: pointer to TIME_DATA-structure (see time.h)
// 				  3.) factor: TIME_1(second) or TIME_100(100ms)
// Output      	: *time_data: pointer to TIME_DATA-structure (see time.h)
// Indication	: none
// **********************************************************************************
void time_calculate(unsigned long act_time, TIME_DATA *time_data, TIME_FACTOR factor)
{
unsigned long d_rest;
unsigned long h_rest;
unsigned int min_rest;
unsigned int sec_rest;

d_rest=act_time%divide_factor[factor];
h_rest=d_rest%divide_factor[(unsigned char)(factor+1)]; 
min_rest=(unsigned int)(h_rest%divide_factor[(unsigned char)(factor+2)]);
sec_rest=min_rest%divide_factor[(unsigned char)(factor+3)];

time_data->day=(unsigned int)(act_time/divide_factor[factor]);							// max. 179.5 years
time_data->hour=(unsigned char)(d_rest/divide_factor[(unsigned char)(factor+1)]);		// 0..23 hours
time_data->minute=(unsigned char)(h_rest/divide_factor[(unsigned char)(factor+2)]);		// 0..59 minutes
time_data->second=(unsigned char)(min_rest/divide_factor[(unsigned char)(factor+3)]);	// 0..59 seconds
time_data->ms=sec_rest;																	// 0..999 milli seconds
}

