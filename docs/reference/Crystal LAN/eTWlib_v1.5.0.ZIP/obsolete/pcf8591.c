// ************************************************************************************************
///
/// 			\file pcf8591.c
///
///  Functions for PCF8591
///
/// \par Created 	12.05.2003
/// \date	 		$LastChangedDate: 2006-12-20 21:50:05 +0100 (Mi, 20 Dez 2006) $
/// \version 		$Rev: 415 $
///	\author  		Udo Jakobza
/// \par Copyright
///					FTZ Leipzig;  W�chterstra�e 13; 04107 Leipzig <br>
///			   		info@easytoweb.net
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// ************************************************************************************************


#include "pcf8591.h"
// the I2C bus is connected to PORTB
// the SDA signal is bit 2
// the SCL signal is bit 3
#asm
	.equ __i2c_port=0x18
	.equ __sda_bit=2
	.equ __scl_bit=3
#endasm
#include <i2c.h>

#pragma regalloc-
unsigned char 	pcf8591_control=0;
#pragma regalloc+

//********************************************************************************
// Description	: init the PCF8591
// Input	   	: none
// Output      	: none
// Indication	: none
//*********************************************************************************
unsigned char 	pcf8591_init(unsigned char control)
{
pcf8591_control=control;
i2c_init();
if(i2c_start())
	{
	i2c_write(PCF8591_ADDRESS | PCF8591_WRITE);
	i2c_write(control);
	i2c_stop();
	return 1;
	}
return 0;
}


//********************************************************************************
// Description	: write a D/A value
// Input	   	: none
// Output      	: none
// Indication	: none
//*********************************************************************************
unsigned char 	pcf8591_write_da(unsigned char da_value)
{
if(i2c_start())
	{
	i2c_write(PCF8591_ADDRESS | PCF8591_WRITE);
	i2c_write(pcf8591_control);
	i2c_write(da_value);
	i2c_stop();
	return 1;
	}
return 0;
}


//********************************************************************************
// Description	: reads all A/D values
// Input	   	: none
// Output      	: none
// Indication	: none
//*********************************************************************************
unsigned char 	pcf8591_read_ad(unsigned char *ad_value)
{
if(i2c_start())
	{
	i2c_write(PCF8591_ADDRESS | PCF8591_READ);
	if(ad_value)
		{
		*ad_value=i2c_read(1);	// with ACK
		ad_value++;
		*ad_value=i2c_read(1);	// with ACK
		ad_value++;
		*ad_value=i2c_read(1);	// with ACK
		ad_value++;
		*ad_value=i2c_read(0);	// without ACK
		}
    else
    	{
		i2c_read(1);	// read last A/D value with ACK
		i2c_read(1);	// with ACK
		i2c_read(1);	// with ACK
		i2c_read(1);	// with ACK
		i2c_read(0);	// without ACK
    	}
	i2c_stop();	
	return 1;
	}
return 0;
}

