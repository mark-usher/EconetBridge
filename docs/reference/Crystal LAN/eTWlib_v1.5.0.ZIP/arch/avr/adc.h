// ************************************************************************************************
///
/// \file 			adc.h
///
/// \date	 		$LastChangedDate: 2007-04-05 17:44:32 +0200 (Do, 05 Apr 2007) $
/// \version 		$Rev: 662 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup AVR_Driver
/// \addtogroup AVR_Driver
/// @{
/// \defgroup ADC
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define ADC_ENABLE
#define ADC_DEBUG
//@}
#endif

///	\def ADC_ENABLE
///		This macro enables the adc module.
///
///	\def ADC_DEBUG
///		Enables debug handler in the adc module.

#ifndef _ADC_INCLUDED_
#define _ADC_INCLUDED_


// --------------------------------------------------------------------------------
// AD-Converter definitions
// -------------------------------------------------------------------------------- 
// register ADCSRA
#define	ADCSR_ADEN	    	0x80	///< ADC Enable
#define	ADCSR_ADSC	    	0x40	///< ADC Start Conversion
#define	ADCSR_ADFR	    	0x20	///< ADC Free Running Select
#define	ADCSR_ADIF	    	0x10	///< ADC Interrupt Flag
#define	ADCSR_ADIE	    	0x08	///< ADC Interrupt Enable
#define	ADCSR_128	    	0x07	///< ADC Prescaler Selects Bits - _MCU_CLOCK_FREQUENCY_/128
#define	ADCSR_64	    	0x06	///< ADC Prescaler Selects Bits - _MCU_CLOCK_FREQUENCY_/64
#define	ADCSR_32	    	0x05	///< ADC Prescaler Selects Bits - _MCU_CLOCK_FREQUENCY_/32
#define	ADCSR_16	    	0x04	///< ADC Prescaler Selects Bits - _MCU_CLOCK_FREQUENCY_/16
#define	ADCSR_8		    	0x03	///< ADC Prescaler Selects Bits - _MCU_CLOCK_FREQUENCY_/8
#define	ADCSR_4		    	0x02	///< ADC Prescaler Selects Bits - _MCU_CLOCK_FREQUENCY_/4
#define	ADCSR_2		    	0x01	///< ADC Prescaler Selects Bits - _MCU_CLOCK_FREQUENCY_/2
// Note: By default, the successive approximation circuitry requires an input clock frequency 
// between 50 kHz and 200 kHz to get maximum resolution.

// register ADMUX
#define	ADMUX_REF_EXT		0x00	///< enable external REF
#define	ADMUX_REF_AVCC		0x40	///< enable external REF from AVCC
#define	ADMUX_REF_256		0xC0	///< enable internal REF (2.3V .. 2.7V)
#define	ADMUX_LEFT_ADJ		0x20	///< enable internal REF (2.3V .. 2.7V)


#pragma used+
void 		 adc_init(void);
void 		 adc_configure(unsigned char cfg, unsigned char ref);
unsigned int adc_read_poll(unsigned char channel);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library adc.c
#endif

#endif	// _ADC_INCLUDED_

/// @}
/// @}
