// ************************************************************************************************
///
/// \file 			avr_spi.c
/// \brief			Generic SPI-Functions for AVR
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <io.h>
#include "avr_spi.h"
#include "bitdefs.h"

#ifdef SPI_ENABLE

// --------------------------------------------------------------------------------
// SPI Pin macros
// -------------------------------------------------------------------------------- 
#ifdef _CHIP_ATMEGA128_
#define	SPI_MISO_CFG_OUT	SETBIT(DDRB, BIT3)
#define	SPI_MISO_CFG_IN		CLRBIT(DDRB, BIT3)
#define	SPI_MISO_HIGH		SETBIT(PORTB, BIT3)
#define	SPI_MISO_LOW		CLRBIT(PORTB, BIT3)
#define	SPI_MOSI_CFG_OUT	SETBIT(DDRB, BIT2)
#define	SPI_MOSI_CFG_IN		CLRBIT(DDRB, BIT2)
#define	SPI_MOSI_HIGH		SETBIT(PORTB, BIT2)
#define	SPI_MOSI_LOW		CLRBIT(PORTB, BIT2)
#define	SPI_SCK_CFG_OUT		SETBIT(DDRB, BIT1)
#define	SPI_SCK_CFG_IN		CLRBIT(DDRB, BIT1)
#define	SPI_SCK_HIGH		SETBIT(PORTB, BIT1)
#define	SPI_SCK_LOW			CLRBIT(PORTB, BIT1)
#define	SPI_SS_CFG_OUT		SETBIT(DDRB, BIT0)
#define	SPI_SS_CFG_IN		CLRBIT(DDRB, BIT0)
#define	SPI_SS_HIGH			SETBIT(PORTB, BIT0)
#define	SPI_SS_LOW			CLRBIT(PORTB, BIT0)
#endif

#ifdef _CHIP_ATMEGA8535_
#define	SPI_MISO_CFG_OUT	SETBIT(DDRB, BIT6)
#define	SPI_MISO_CFG_IN		CLRBIT(DDRB, BIT6)
#define	SPI_MISO_HIGH		SETBIT(PORTB, BIT6)
#define	SPI_MISO_LOW		CLRBIT(PORTB, BIT6)
#define	SPI_MOSI_CFG_OUT	SETBIT(DDRB, BIT5)
#define	SPI_MOSI_CFG_IN		CLRBIT(DDRB, BIT5)
#define	SPI_MOSI_HIGH		SETBIT(PORTB, BIT5)
#define	SPI_MOSI_LOW		CLRBIT(PORTB, BIT5)
#define	SPI_SCK_CFG_OUT		SETBIT(DDRB, BIT7)
#define	SPI_SCK_CFG_IN		CLRBIT(DDRB, BIT7)
#define	SPI_SCK_HIGH		SETBIT(PORTB, BIT7)
#define	SPI_SCK_LOW			CLRBIT(PORTB, BIT7)
#define	SPI_SS_CFG_OUT		SETBIT(DDRB, BIT4)
#define	SPI_SS_CFG_IN		CLRBIT(DDRB, BIT4)
#define	SPI_SS_HIGH			SETBIT(PORTB, BIT4)
#define	SPI_SS_LOW			CLRBIT(PORTB, BIT4)
#endif

#ifdef _CHIP_ATMEGA8_
#define	SPI_MISO_CFG_OUT	SETBIT(DDRB, BIT4)
#define	SPI_MISO_CFG_IN		CLRBIT(DDRB, BIT4)
#define	SPI_MISO_HIGH		SETBIT(PORTB, BIT4)
#define	SPI_MISO_LOW		CLRBIT(PORTB, BIT4)
#define	SPI_MOSI_CFG_OUT	SETBIT(DDRB, BIT3)
#define	SPI_MOSI_CFG_IN		CLRBIT(DDRB, BIT3)
#define	SPI_MOSI_HIGH		SETBIT(PORTB, BIT3)
#define	SPI_MOSI_LOW		CLRBIT(PORTB, BIT3)
#define	SPI_SCK_CFG_OUT		SETBIT(DDRB, BIT5)
#define	SPI_SCK_CFG_IN		CLRBIT(DDRB, BIT5)
#define	SPI_SCK_HIGH		SETBIT(PORTB, BIT5)
#define	SPI_SCK_LOW			CLRBIT(PORTB, BIT5)
#define	SPI_SS_CFG_OUT		SETBIT(DDRB, BIT2)
#define	SPI_SS_CFG_IN		CLRBIT(DDRB, BIT2)
#define	SPI_SS_HIGH			SETBIT(PORTB, BIT2)
#define	SPI_SS_LOW			CLRBIT(PORTB, BIT2)
#endif

#ifdef _CHIP_ATMEGA32_
#define	SPI_MISO_CFG_OUT	SETBIT(DDRB, BIT6)
#define	SPI_MISO_CFG_IN		CLRBIT(DDRB, BIT6)
#define	SPI_MISO_HIGH		SETBIT(PORTB, BIT6)
#define	SPI_MISO_LOW		CLRBIT(PORTB, BIT6)
#define	SPI_MOSI_CFG_OUT	SETBIT(DDRB, BIT5)
#define	SPI_MOSI_CFG_IN		CLRBIT(DDRB, BIT5)
#define	SPI_MOSI_HIGH		SETBIT(PORTB, BIT5)
#define	SPI_MOSI_LOW		CLRBIT(PORTB, BIT5)
#define	SPI_SCK_CFG_OUT		SETBIT(DDRB, BIT7)
#define	SPI_SCK_CFG_IN		CLRBIT(DDRB, BIT7)
#define	SPI_SCK_HIGH		SETBIT(PORTB, BIT7)
#define	SPI_SCK_LOW			CLRBIT(PORTB, BIT7)
#define	SPI_SS_CFG_OUT		SETBIT(DDRB, BIT4)
#define	SPI_SS_CFG_IN		CLRBIT(DDRB, BIT4)
#define	SPI_SS_HIGH			SETBIT(PORTB, BIT4)
#define	SPI_SS_LOW			CLRBIT(PORTB, BIT4)
#endif

#define SPSR_SPI2X			0x01
#define SPSR_WCOL			0x40
#define SPSR_SPIF			0x80

// ************************************************************************************************
/// \brief		Initialization of AVR-SPI
///
/// @param[in]	mode - see macros SPCR... in avr_spi
/// 					SPCR_SPIE	SPI Interrupt Enable
/// 					SPCR_SPE	SPI Enable
/// 					SPCR_DORD	SPI Data Order 1=LSB; 0=MSB first
/// 					SPCR_MSTR	SPI Master/Slave Select
/// 					SPCR_CPOL	SPI Clock Polarity 1=SCK=HIGH; 0=SCK=LOW
/// 					SPCR_CPHA	SPI Clock Phase
/// 					SPCR_128	SPI Clock 1/128 Main-Clock
/// 					SPCR_64		SPI Clock 1/64 Main-Clock
/// 					SPCR_32		SPI Clock 1/32 Main-Clock
/// 					SPCR_16		SPI Clock 1/16 Main-Clock
/// 					SPCR_8		SPI Clock 1/8 Main-Clock
/// 					SPCR_4		SPI Clock 1/4 Main-Clock
/// 					SPCR_2		SPI Clock 1/2 Main-Clock
// ************************************************************************************************
void spi_init(unsigned int mode)
{
if (mode & SPCR_MSTR)
	{ // *** MASTER-MODE ***
	// MISO input
	// MOSI output
	// SCK  output
	// /SS  output (Chip switches to slave mode, if /SS goes low in Master Mode!)
	SPI_MISO_CFG_IN;
	SPI_MOSI_CFG_OUT;
	SPI_SCK_CFG_OUT;
	SPI_SS_CFG_OUT;

	SPI_MOSI_HIGH;
	SPI_SCK_HIGH;
	SPI_SS_HIGH;
	}
else
	{ // *** SLAVE-MODE ***
	// MISO output
	// MOSI input
	// SCK  input
	// /SS  input
	SPI_MISO_CFG_OUT;
	SPI_MOSI_CFG_IN;
	SPI_SCK_CFG_IN;
	SPI_SS_CFG_IN;

	SPI_MISO_HIGH;
	}
#if defined(_CHIP_ATMEGA128_)||defined(_CHIP_ATMEGA128L_)||defined(_CHIP_ATMEGA32_)||defined(_CHIP_ATMEGA32L_)||defined(_CHIP_ATMEGA161_)||defined(_CHIP_ATMEGA161L_)
if (mode & 0x0100)	// found SPCR_32, SPCR_8 or SPCR_2
	SETBIT(SPSR, SPSR_SPI2X);		// enable double speed
else
	CLRBIT(SPSR, SPSR_SPI2X);		// disable double speed
#endif

// Clear the SPI interrupt flag
#asm
    in   r30,spsr
    in   r30,spdr
#endasm

SPCR = mode;
}


// ************************************************************************************************
/// \brief		Sends and receives 8 Bit of data via SPI
///
/// @param[in]	data - byte to send
/// @return		received data
// ************************************************************************************************
unsigned char spi_transfer(unsigned char data)
{
#if defined _CHIP_ATMEGA164_ || defined _CHIP_ATMEGA164V_ || \
defined _CHIP_ATMEGA324_ || defined _CHIP_ATMEGA324V_ || \
defined _CHIP_ATMEGA644_ || defined _CHIP_ATMEGA644V_
SPDR0 = data;
while ((SPSR0 & SPSR_SPIF)==0);
return SPDR0;
#else
SPDR = data;
while ((SPSR & SPSR_SPIF)==0);
return SPDR;
#endif
}

#endif	// #ifdef SPI_ENABLE