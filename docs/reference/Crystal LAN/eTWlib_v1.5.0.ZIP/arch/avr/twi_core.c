// ************************************************************************************************
///
/// \file 			twi_core.c
/// \brief			Common i2c functions
/// 
/// \date	 		$LastChangedDate: 2007-03-12 15:18:09 +0100 (Mo, 12 Mrz 2007) $
/// \version 		$Rev: 620 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration
#include "twi.h"

#if defined TWI_CVAVR_ENABLE || defined TWI_AVR_ENABLE 

// ************************************************************************************************
/// \brief		Writes some data to an I2C device
/// @param[in]  addr - 7-bit I2C address. Range 0..127
/// @param[in]  len  - length of data, not including I2C address byte 
/// @param[in]  buf  - pointer to I2C data
/// @return		error code, see \ref T_TWI_ERR
// ************************************************************************************************
T_TWI_ERR twi_write_msg(unsigned char addr, unsigned char len, unsigned char* buf)
{
unsigned char i;

if (twi_start() == 1)					// check if bus is free
	{
	if (twi_write_byte(addr<<1) == 0)	// address is transferred in data bits 1..7
		{
		twi_stop();
		return 2;
		}
	for (i=0; i<len; i++)
		{
		twi_write_byte(*buf);
		buf++;
		}
	twi_stop();
	return 0;
	}
else
	{
	twi_stop();
	return 1;
	}
}


// ************************************************************************************************
/// \brief		Reads some data from an I2C device
/// @param[in]  addr - 7-bit I2C address. Range 0..127
/// @param[in]  len  - length of data, not including I2C address byte
/// @param[out] buf  - pointer to I2C data
/// @return		error code, see \ref T_TWI_ERR
// ************************************************************************************************
T_TWI_ERR twi_read_msg(unsigned char addr, unsigned char len, unsigned char* buf)
{
unsigned char i;

if (twi_start() == 1)   						// check if bus is free
	{
	if (twi_write_byte(addr<<1 | 0x01) == 0)	// address + direction bit '1' -> read
		{
		twi_stop();
		return 2;
		}
	for (i=0; i<len; i++)
		{
		if (i == len-1)
			*buf = twi_read_byte(0);
		else
			*buf = twi_read_byte(1);
		buf++;
		}
	twi_stop();
	return 0;
	}
else 
	{
	twi_stop();
	return 1;
	}
}

#endif	// #if defined TWI_CVAVR_ENABLE || defined TWI_AVR_ENABLE 