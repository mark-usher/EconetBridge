// ************************************************************************************************
///
/// \file 			gpio.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup AVR_Driver
/// \addtogroup AVR_Driver
/// @{
/// \defgroup GPIO
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define GPIO_ENABLE
#define GPIO_DEBUG
//@}
#endif


#ifndef _GPIO_INCLUDED_
#define _GPIO_INCLUDED_

///	\def GPIO_ENABLE
///		This macro enables the whole gpio module. It must be defined in project.h
///
///	\def GPIO_DEBUG
///		Defines command handler function for the gpio module. With the command "gpio-info" the status
///		of all gpio can be checked.

#include "project.h"

#ifdef GPIO_ENABLE

#if defined(GPIO_DEBUG) && !defined(DEBUG)
#error "GPIO: Debug Interface not enabled!"
#endif

typedef enum {
    GPIO_PORTA,
    GPIO_PORTB,
    GPIO_PORTC,
    GPIO_PORTD,
    GPIO_PORTE,
    GPIO_PORTF,
    GPIO_PORTG
    } GPIO_PORT_ENUM;

typedef struct {
	GPIO_PORT_ENUM	port;
	unsigned char	bitmask;
    } GPIO_CFG_STRUCT;

typedef struct {
flash	GPIO_PORT_ENUM	port;
flash	unsigned char	bitmask;
    } GPIO_CFG_STRUCT_FLASH;

extern flash unsigned char gpio_pin_addr[];
extern flash unsigned char gpio_ddr_addr[];
extern flash unsigned char gpio_port_addr[];

#define gpio_set_pin_mask(port, bitmask)    *(unsigned char*)gpio_port_addr[port] |= bitmask
#define gpio_clear_pin_mask(port, bitmask)  *(unsigned char*)gpio_port_addr[port] &= ~bitmask
#define gpio_read_pin_mask(port, bitmask) 	(*(unsigned char*)gpio_pin_addr[port] & bitmask)
#define gpio_cfg_out_mask(port, bitmask) 	*(unsigned char*)gpio_ddr_addr[port] |= bitmask
#define gpio_cfg_in_mask(port, bitmask) 	*(unsigned char*)gpio_ddr_addr[port] &= ~bitmask

#pragma used+
void 	gpio_init(void);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library gpio.c
#endif

#endif	// #ifdef GPIO_ENABLE
#endif	// #ifndef _GPIO_INCLUDED__

/// @}
/// @}