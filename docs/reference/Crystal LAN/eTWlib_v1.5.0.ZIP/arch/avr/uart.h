// ************************************************************************************************
///
/// \file 			uart.h
///
/// \date	 		$LastChangedDate: 2007-03-22 10:52:53 +0100 (Do, 22 Mrz 2007) $
/// \version 		$Rev: 650 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup AVR_Driver
/// \addtogroup AVR_Driver
/// @{
/// \defgroup UART
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define UART_ENABLE
#define UART_DEBUG
#define UART_DEVICE0_ENABLE
#define UART_DEVICE1_ENABLE
#define UART_RX_BUFFER_SIZE			80
#define UART_TX_BUFFER_SIZE			80
#define UART_STATISTIC_ENABLE
#define UART_MODE_IRQ
#define UART_MODE_POLL
#define UART_PARSE_CHAR
#define UART_RS485_DEV0_ENABLE
#define UART_RS485_DEV1_ENABLE
#define UART_RS485_DEV0_ACTIVE		DDRA|=0x01
#define UART_RS485_DEV0_TX_ON		PORTA|=0x01
#define UART_RS485_DEV0_TX_OFF		PORTA&=~0x01
#define UART_RS485_DEV1_ACTIVE		DDRA|=0x02
#define UART_RS485_DEV1_TX_ON		PORTA|=0x02
#define UART_RS485_DEV1_TX_OFF		PORTA&=~0x02
//@}
#endif


///	\def UART_ENABLE
///		This macro enables the whole uart module. It must be defined in project.h
///
///	\def UART_DEBUG
///		Defines debug output and command handler function for the uart module. It registers
///		with the string 'uart' at the debug handler framework.
///
///	\def UART_DEVICE0_ENABLE
///		This macro makes the AVR internal UART0 usable in the uart module. When calling
///		uart_init(), UART0 is initialized and started with default settings. If
///		UART_MODE_IRQ is defined, an receive and transmit ISR is defined for UART0.
///
///	\def UART_DEVICE1_ENABLE
///		Same as UART_DEVICE0_ENABLE, but for AVR internal UART1
///
///	\def UART_RX_BUFFER_SIZE
///		Size of receive buffer in bytes. Maximum value is 65536. If this macro is not
///		defined in project.h, an default value is used. See uart.h
///
///	\def UART_TX_BUFFER_SIZE
///		Same as UART_RX_BUFFERSIZE, but for transmit buffer
///
///	\def UART_STATISTIC_ENABLE
///		Enables statistic functions. Received and transmitted bytes and errors are counted.
///
///	\def UART_MODE_IRQ
///		UART module uses interrupt mode. This macro is the default setting. If neither
///		UART_MODE_IRQ nor UART_MODE_POLL is defined, interrupt mode is used.
///		See also UART_MODE_POLL
///
///	\def UART_MODE_POLL
///		UART module uses polling mode. User program has to call uart_receive_poll() and
///		uart_transmit_poll() regular.
///
///	\def UART_PARSE_CHAR
///		The uart module constantly checks for an special character in the receive buffer.
///		This can be any 8-bit pattern. UART_PARSE_CHAR enables this function and is equal
///		to this character itself. Define like this: <br>
///		#define UART_PARSE_CHAR 	0xFE
///
///	\def UART_RS485_DEV0_ENABLE
///		Enables RS485 mode for AVR internal UART0
///
///	\def UART_RS485_DEV1_ENABLE
///		Enables RS485 mode for AVR internal UART1
///
///	\def UART_RS485_DEV0_ACTIVE
///		Defines an instruction to set the RS-485 pin of UART device 0 to output.
///		
///	\def UART_RS485_DEV0_TX_ON
///		Defines an instruction to enable the RS-485 driver of UART device 0
///		
///	\def UART_RS485_DEV0_TX_OFF
///		Defines an instruction to disable the RS-485 driver of UART device 0
///		
///	\def UART_RS485_DEV1_ACTIVE
///		Defines an instruction to set the RS-485 pin of UART device 1 to output.
///		
///	\def UART_RS485_DEV1_TX_ON
///		Defines an instruction to enable the RS-485 driver of UART device 1
///		
///	\def UART_RS485_DEV1_TX_OFF
///		Defines an instruction to disable the RS-485 driver of UART device 1


#ifndef _UART_INCLUDED_
#define _UART_INCLUDED_

#include "project.h"

#ifdef UART_ENABLE

// ---------------------------------------------------------------------------
// Check for correct macro configuration
// ---------------------------------------------------------------------------
#if !defined(UART_DEVICE0_ENABLE) && !defined(UART_DEVICE1_ENABLE)
#error "UART: You have to define UART_DEVICE0_ENABLE or UART_DEVICE1_ENABLE"
#endif

#if defined(UART_MODE_IRQ) && defined(UART_MODE_POLL)
#error "UART: Define UART_MODE_IRQ or UART_MODE_POLL"
#endif

#if !defined(UART_MODE_IRQ) && !defined(UART_MODE_POLL)
#define UART_MODE_IRQ			// interrupt mode is default
#endif


// ---------------------------------------------------------------------------
// Device-ID Enumeration type, used for most uart functions
// ---------------------------------------------------------------------------
typedef enum {
#if defined(UART_DEVICE0_ENABLE) && defined(UART_DEVICE1_ENABLE)
	UART_DEV0,
#endif
#if defined(UART_DEVICE0_ENABLE) && !defined(UART_DEVICE1_ENABLE)
	UART_DEV0
#endif
#ifdef UART_DEVICE1_ENABLE
	UART_DEV1
#endif
	} UART_DEV_ENUM;


// ---------------------------------------------------------------------------
// Enable Statistic functions always in debug mode
// ---------------------------------------------------------------------------
#ifdef UART_DEBUG
	#ifndef UART_STATISTIC_ENABLE
	#define UART_STATISTIC_ENABLE
	#endif
#endif


// ---------------------------------------------------------------------------
// UART Buffer size
// ---------------------------------------------------------------------------
#ifndef UART_RX_BUFFER_SIZE
#define	UART_RX_BUFFER_SIZE		64
#endif

#ifndef UART_TX_BUFFER_SIZE
#define	UART_TX_BUFFER_SIZE		64
#endif


// ---------------------------------------------------------------------------
// Defines variable type for buffer index. Minimizes program size, if only
// 8-Bit buffer is needed
// ---------------------------------------------------------------------------
#if (UART_RX_BUFFER_SIZE <= 255)
	#define UART_RX_VAR_TYPE	unsigned char
#else
	#define UART_RX_VAR_TYPE	unsigned int
#endif
#if (UART_TX_BUFFER_SIZE <= 255)
	#define UART_TX_VAR_TYPE	unsigned char
#else
	#define UART_TX_VAR_TYPE	unsigned int
#endif


// ---------------------------------------------------------------------------
// UART starts with default baudrate after uart_init()
// ---------------------------------------------------------------------------
#define	UART_DEFAULT_BAUDRATE	115200


// ---------------------------------------------------------------------------
// Parameter for uart_configure()
// ---------------------------------------------------------------------------
typedef enum{
	UART_CFG_SETDBLSPEED,
	UART_CFG_GETDBLSPEED,
	UART_CFG_SETDATABITS,
	UART_CFG_GETDATABITS,
	UART_CFG_SETPARITY,
	UART_CFG_GETPARITY,
	UART_CFG_SETSTOPBITS,
	UART_CFG_GETSTOPBITS
	} UART_CFG_CMD_ENUM;

typedef enum{          
    UART_CFG_DATABITS_5,
    UART_CFG_DATABITS_6,
    UART_CFG_DATABITS_7,
    UART_CFG_DATABITS_8,
    UART_CFG_DATABITS_9
    } UART_CFG_DATABITS;

typedef enum{          
    UART_CFG_PARITY_NONE,
    UART_CFG_PARITY_EVEN,
    UART_CFG_PARITY_ODD
    } UART_CFG_PARITY;

typedef enum{          
    UART_CFG_STOPBITS_1,
    UART_CFG_STOPBITS_2
    } UART_CFG_STOPBITS;

// ---------------------------------------------------------------------------
// UART Statistic structure
// ---------------------------------------------------------------------------
#ifdef UART_STATISTIC_ENABLE
typedef struct{
	unsigned int	rcount;				// counter of receive-data
	unsigned int	wcount;				// counter of transmit-data
	unsigned int	rlost;				// counter of lost receive-data
	unsigned int	wlost;				// counter of lost transmit-data
	unsigned char	r_frame_error;		// counter of Receive Frame Error
	unsigned char	r_data_over_run;	// counter of Receive Data OverRun
	unsigned char	r_parity_error;		// counter of Receive Parity Error
} UART_STAT_STRUCT;
#endif


#pragma used+
void 			 uart_init(void);
void 			 uart_clear_rx_buffer(UART_DEV_ENUM dev_id);
void 			 uart_clear_tx_buffer(UART_DEV_ENUM dev_id);
void 			 uart_clear_buffer(UART_DEV_ENUM dev_id);
void 			 uart_disable(UART_DEV_ENUM dev_id);
void 			 uart_enable(UART_DEV_ENUM dev_id);
void 			 uart_set_baudrate(UART_DEV_ENUM dev_id, unsigned long baudrate);
unsigned long 	 uart_get_baudrate(UART_DEV_ENUM dev_id);
unsigned char 	 uart_configure(UART_DEV_ENUM dev_id, UART_CFG_CMD_ENUM cmd, unsigned char param);
UART_RX_VAR_TYPE uart_get_rx_count(UART_DEV_ENUM dev_id);
UART_TX_VAR_TYPE uart_get_tx_gap(UART_DEV_ENUM dev_id);
unsigned char 	 uart_get_parse_counter(UART_DEV_ENUM dev_id);
void 			 uart_putchar(UART_DEV_ENUM dev_id, unsigned char data);
unsigned char 	 uart_getchar(UART_DEV_ENUM dev_id);
void 			 uart_puts(UART_DEV_ENUM dev_id, unsigned char* data);
void 			 uart_putsf(UART_DEV_ENUM dev_id, unsigned char flash *str);
void 			 uart_write_block(UART_DEV_ENUM dev_id, unsigned char* data, UART_TX_VAR_TYPE size);
void 			 uart_read_block(UART_DEV_ENUM dev_id, unsigned char* data, UART_RX_VAR_TYPE size);
#ifdef UART_MODE_POLL
void 			 uart_receive_poll(UART_DEV_ENUM dev_id);
void 			 uart_transmit_poll(UART_DEV_ENUM dev_id);
#endif
#ifdef UART_STATISTIC_ENABLE
void 			uart_get_statistic(UART_DEV_ENUM dev_id, UART_STAT_STRUCT *p_struct);
#endif
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library uart.c
#endif

#endif	// #ifdef UART_ENABLE
#endif	// #ifndef _UART_INCLUDED_

/// @}
/// @}
