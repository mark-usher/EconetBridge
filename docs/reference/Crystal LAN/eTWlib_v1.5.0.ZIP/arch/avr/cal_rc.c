// ************************************************************************************************
///
/// \file 			cal_rc.c
/// \brief			Calibrating the AVR internal RC Oscillator
///
///					This design note describes how to calibrate the internal RC Oscillator using 
///					an external 32.768 KHz crystal as input signal to an asynchronous Timer/Counter.
///					AVR devices with internal RC Oscillator and an OSCCAL Calibration Register 
///					can be calibrated very accurately by using an external signal with stable 
///					frequency. This calibration can be useful if running the device at a temerature
///					or supply voltage level different from what it is calibrated for by default
///					(5V @ 25�C or 3.3V @ 25�C).
///
///					Overview Note that external low-frequency crystals may require a stabilization
///					period of up to one second after Power-up. Please consult the crystal data 
///					sheet for exact data. The calibration is executed in a 5-cycle loop. In every 
///					loop a Counter is incremented, and the value of the 32 KHz Timer is read. 
///					After 4..10 ticks of the 32 KHz timer are completed, the frequency of the 
///					internal RC is compared with the Timer value. If the internal RC frequency is 
///					too low, a higher value is written to the OSCCAL Register. If the frequency
///					is too high, a lower value is written. The loop is repeated 255 times to 
///					guarantee that OSCCAL gets the correct value.
///
///					The relation between the repeat count value and the frequency can be obtained
///					from:
///					Loop cycles (5) x count value x RC period = external clk period x external
///					ticks (10) Calibrating the RC Oscillator to 1 MHz gives the following values:
///					5 x count value x 1 us(1 MHz) = 30.5 us (32.768 KHz) x 10
///					Which gives the count value of 61.
///					Below is a sample program in C language that carries out the calibration
///					described above. Make sure to include the bit definitions and intrinsic 
///					instructions for the specific device.
///							Example:  	
///								if (!cal_rc_calibrate_first())
///								OSCCAL = CAL_RC_OSCCAL_DEFAULT;			// use default OSCCAL-Value
///
/// \date	 		$LastChangedDate: 2007-01-31 15:35:41 +0100 (Mi, 31 Jan 2007) $
/// \version 		$Rev: 532 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef _DOXYGEN_PARSER_
#define CAL_RC_ENABLE
#endif

#ifdef CAL_RC_ENABLE

#if defined(_CHIP_ATMEGA128_)||defined(_CHIP_ATMEGA128L_)
#include <mega128.h>
#define CAL_RC_TIMER_TCNT			TCNT0
#define CAL_RX_TIMER_PRESCALE		TCCR0
#define CAL_RC_TIMER_DISABLE_IRQ	TIMSK &=~0x03
#endif
#if defined(_CHIP_ATMEGA32_)||defined(_CHIP_ATMEGA32L_)
#include <mega32.h>
#define CAL_RC_TIMER_TCNT			TCNT2
#define CAL_RX_TIMER_PRESCALE		TCCR2
#define CAL_RC_TIMER_DISABLE_IRQ 	TIMSK&=~0x80
#endif
#if defined(_CHIP_ATMEGA16_)||defined(_CHIP_ATMEGA16L_)
#include <mega16.h>
#define CAL_RC_TIMER_TCNT			TCNT2
#define CAL_RX_TIMER_PRESCALE		TCCR2
#define CAL_RC_TIMER_DISABLE_IRQ	TIMSK&=~0x80
#endif
#if defined(_CHIP_ATMEGA8_)||defined(_CHIP_ATMEGA8L_)
#include <mega8.h>
#define CAL_RC_TIMER_TCNT			TCNT2
#define CAL_RX_TIMER_PRESCALE 		TCCR2
#define CAL_RC_TIMER_DISABLE_IRQ	TIMSK&=~0x80
#endif

#include <delay.h>
#include "cal_rc.h"

//----------------------------------------------------------------------------------
// parameter to handle calibration function
//----------------------------------------------------------------------------------
#if (_MCU_CLOCK_FREQUENCY_==1000000)
#define NOMINAL_LOOP_COUNT		61		// =305�sec(5*1.0�s) - 5 clocks for every measure-loop
#define TCNTX_CLOCK				10		// Until 30.51�s(1/32768Hz) * 10 cycles = 305,175us
#endif
#if (_MCU_CLOCK_FREQUENCY_==1843200)
#define NOMINAL_LOOP_COUNT		112		// =303,856�sec(5*0.5426�s) - 5 clocks for every measure-loop
#define TCNTX_CLOCK				10		// Until 30.51�s(1/32768Hz) * 10 cycles = 305,175us
#endif
#if (_MCU_CLOCK_FREQUENCY_==2000000)
#define NOMINAL_LOOP_COUNT		122		// =305�sec(5*0.5�s) - 5 clocks for every measure-loop
#define TCNTX_CLOCK				10		// Until 30.51�s(1/32768Hz) * 10 cycles = 305,175us
#endif
#if (_MCU_CLOCK_FREQUENCY_==3686400)
#define NOMINAL_LOOP_COUNT		135		// =183�sec(5*0.2713�s) - 5 clocks for every measure-loop
#define TCNTX_CLOCK				6		// Until 30.51�s(1/32768Hz) * 6 cycles = 183,175us
#endif
#if (_MCU_CLOCK_FREQUENCY_==4000000)
#define NOMINAL_LOOP_COUNT		146		// =183�sec(5*0.25�s) - 5 clocks for every measure-loop
#define TCNTX_CLOCK				6		// Until 30.51�s(1/32768Hz) * 6 cycles = 183,175us
#endif
#if (_MCU_CLOCK_FREQUENCY_==8000000)
#define NOMINAL_LOOP_COUNT		195		// =121,9�sec(5*0.125�s) - 5 clocks for every measure-loop
#define TCNTX_CLOCK				4		// Until 30.51�s(1/32768Hz) * 4 cycles = 122,07us
#endif

#pragma regalloc-
#pragma regalloc+


// ************************************************************************************************
/// \brief		Check whether asynchronuous Timer is running
///
/// @retvalue	1 - ok
/// @retvalue	0 - timer not ready -> crystal not connected?
// ************************************************************************************************
unsigned char cal_rc_timer_check(void)
{
unsigned char tcntx;

ASSR |= 0x08;		  			// ASSR.ASx - enable Asynchronous Timer/Counterx
CAL_RX_TIMER_PRESCALE = 0x01;	// no Prescale. The timer works with 32.768kHz directly
tcntx = CAL_RC_TIMER_TCNT;
delay_ms(1);	  				// wait until test
if (CAL_RC_TIMER_TCNT != tcntx)
	return 1;
return 0;
}


// ************************************************************************************************
/// \brief		Check whether asynchronuous Timer is ready
///
/// @retvalue	1 - ok
/// @retvalue	0 - timer not ready -> crystal not connected?
// ************************************************************************************************
unsigned char cal_rc_timer_ready(void)
{
unsigned char ext_crystal_startup_try=200;	// max: 2 second

#ifdef CAL_RC_DEBUG
printf("CAL_RC: Start-OSCCAL:0x%x\r\n", OSCCAL);
#endif
while (1)
	{
	if (cal_rc_timer_check())
		break;
	ext_crystal_startup_try--;
	if (ext_crystal_startup_try==0)
		{
		ASSR &= ~0x08;			// ASSR.ASx - disable Asynchronous Timer/Counterx
		#ifdef CAL_RC_DEBUG
		putsf("CAL_RC: no 32.768kHz Quarz\r");
		#endif
		return 0;
		}
	delay_ms(9);				// 1 ms delay in cal_rc_timer_ready()
	}
delay_ms(10);					// delay to be sure that crystal is running stable

return 1;
}


// ************************************************************************************************
/// \brief		Calibrate the internal RC-oscillator of ATmega128, ATmega32 and so on
///
/// @retvalue	1 - ok
/// @retvalue	0 - timer not ready -> crystal not connected?
// ************************************************************************************************
void cal_rc_calibrate(void)
{
unsigned char sreg_temp;
unsigned char cycles=0xFF;	// max 255 calibration cycles
unsigned char count;
unsigned char osccal;

CAL_RC_TIMER_DISABLE_IRQ;		// disable Timer/CounterX Output Compare Interrupt Enable
ASSR |= 0x08;					// ASSR.ASx - set Asynchronous Timer/Counterx
CAL_RX_TIMER_PRESCALE = 0x01; 	// no Prescale. The timer works with 32.768kHz directly
osccal = OSCCAL;
do
	{
	count = 0;
	CAL_RC_TIMER_TCNT = 0x00;
	while (ASSR & 0x07);		// ASSR.TCR0UB wait while TCCR0-Register Update Busy
								// ASSR.OCR0UB wait while OCR0-Register Update Busy
								// ASSR.TCN0UB wait while TCNT0-Register Update Busy
	sreg_temp = SREG;			// saves actual status of SREG
	#asm("cli");
	do
		{
		count++; 		   		// Increment counter
		}
	while (CAL_RC_TIMER_TCNT < TCNTX_CLOCK);
	SREG = sreg_temp;			// restore SREG

	if (count > NOMINAL_LOOP_COUNT)
		{
		osccal--;               // If count is more than NOMINAL_LOOP_COUNT - decrease speed
		OSCCAL = osccal;
		}
	if (count < NOMINAL_LOOP_COUNT)
		{
		osccal++;               // If count is less than NOMINAL_LOOP_COUNT - increase speed
		OSCCAL = osccal;
		}
	} 
while (--cycles && count!=NOMINAL_LOOP_COUNT); 	// Calibrate for max. 255 cycles 

// The external 32.768 Hz Oscillator is not stopped after this calibration routine, to ensure 
// fast recalibration. The external oscillator could take 1 second to start again.
#ifdef CAL_RC_DEBUG
printf("CAL_RC: Cal-OSCCAL:0x%x\r\n", OSCCAL);
#endif
}


// ************************************************************************************************
/// \brief		Calibrate internal RC-Oscillator for the first time after reset.
///
/// @retval		1 - ok
/// @retval		0 - timer not ready
// ************************************************************************************************
unsigned char cal_rc_calibrate_first(void)
{
if (cal_rc_timer_ready())		// wait max. 2 seconds for oscillator to startup
	{
	cal_rc_calibrate();
	return 1;
	}
else
	return 0;
}


// ************************************************************************************************
/// \brief		Recalibrate internal RC-Oscillator.
///                       
/// @retvalue	1 - ok
/// @retvalue	0 - timer not ready -> crystal not connected?
// ************************************************************************************************
unsigned char cal_rc_recalibrate(void)
{
if (cal_rc_timer_check())		// wait max. 1 ms for oscillator to startup
	{
	cal_rc_calibrate();
	return 1;
	}
else
	return 0;
}
#endif	// #ifdef CAL_RC_ENABLE