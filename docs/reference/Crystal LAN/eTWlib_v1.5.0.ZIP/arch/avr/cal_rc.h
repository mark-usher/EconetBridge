// ************************************************************************************************
///
/// \file 			cal_rc.h
/// \brief			header file of cal_rc.c
///
/// \date	 		$LastChangedDate: 2007-03-12 18:20:34 +0100 (Mo, 12 Mrz 2007) $
/// \version 		$Rev: 624 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup AVR_Driver
/// \addtogroup AVR_Driver
/// @{
/// \defgroup CAL_RC
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define CAL_RC_ENABLE
#define CAL_RC_DEBUG
#define CAL_RC_OSCCAL_DEFAULT		0x9c
//@}
#endif

///	\def CAL_RC_ENABLE
///		This macro enables the whole cal-rc module. It must be defined in project.h
///
///	\def CAL_RC_DEBUG
///		Enables debug output in cal-rc module.
///
///	\def CAL_RC_OSCCAL_DEFAULT
///		If calibration fails, this default value is used.


#ifndef _CAL_RC_INCLUDED_
#define _CAL_RC_INCLUDED_

#include "project.h"

#ifndef CAL_RC_OSCCAL_DEFAULT
#define CAL_RC_OSCCAL_DEFAULT		0xcb
#endif

#pragma used+
unsigned char cal_rc_calibrate_first(void);
unsigned char cal_rc_recalibrate(void);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library cal_rc.c
#endif

#endif	// #ifndef _CAL_RC_INCLUDED_

/// @}
/// @}