// ************************************************************************************************
///
/// \file 			systimer.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br>
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup AVR_Driver
/// \addtogroup AVR_Driver
/// @{
/// \defgroup System_Timer
/// \addtogroup System_Timer
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define SYSTIMER_ENABLE
#define SYSTIMER_CYCLE_1MS
#define SYSTIMER_CYCLE_10MS
#define SYSTIMER_SOURCE_TIM0
#define SYSTIMER_SOURCE_TIM1
#define SYSTIMER_SOURCE_TIM2
#define SYSTIMER_SOURCE_TIM3
#define SYSTIMER_ISR_HOOK_MAX   2
//@}
#endif

///	\def SYSTIMER_ENABLE
///		This macro enables the System Timer module.
///
///	\def SYSTIMER_CYCLE_1MS
///		The system timer works with a granularity of 1ms.
///
///	\def SYSTIMER_CYCLE_10MS
///		The system timer works with a granularity of 10ms. This is the default value.
///
///	\def SYSTIMER_SOURCE_TIM0
///		Timer/Counter 0 is used for the systimer
///
///	\def SYSTIMER_SOURCE_TIM1
///		Timer/Counter 1 is used for the systimer
///
///	\def SYSTIMER_SOURCE_TIM2
///		Timer/Counter 2 is used for the systimer
///
///	\def SYSTIMER_SOURCE_TIM3
///		Timer/Counter 3 is used for the systimer
///
///	\def SYSTIMER_ISR_HOOK_MAX
///		With the function systimer_register_isr_hook() the user can register an function
///		that is called with every system timer interrupt. sys_callback and sys_delay use
///		this feature. If SYSTIMER_ISR_HOOK_MAX is not defined in project.h, the default
///		value of 2 is used.

#ifndef _SYSTIMER_INCLUDED_
#define _SYSTIMER_INCLUDED_

#if !defined(SYSTIMER_CYCLE_1MS) && !defined(SYSTIMER_CYCLE_10MS)
#define SYSTIMER_CYCLE_10MS
#endif

#ifdef SYSTIMER_CYCLE_10MS
#define SYS_MS2TICS(ms)		(ms/10)			///< converts Milliseconds in Systimer Tics
#define SYS_TICS2MS(tics)	(tics*10)		///< converts Systimer Tics in Milliseconds
#else
#define SYS_MS2TICS(ms)		ms
#define SYS_TICS2MS(tics)	tics
#endif

#pragma used+
extern unsigned int systimer_cnt;

void 		  systimer_init(void);
unsigned char systimer_register_isr_hook(void (*fp)(void));
void 		  systimer_tic(void);
unsigned long systimer_tac(void);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library systimer.c
#endif

#endif	// #ifndef _SYSTIMER_INCLUDED_

/// @}
/// @}