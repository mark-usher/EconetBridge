// ************************************************************************************************
///
/// \file 			debug_io.h
/// \brief			header file of debug_io.c
///
/// \date	 		$LastChangedDate: 2007-03-30 10:17:04 +0200 (Fr, 30 Mrz 2007) $
/// \version 		$Rev: 661 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \addtogroup Debug_Framework
/// @{
/// \defgroup Debug_io
/// \addtogroup Debug_io
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define DEBUG
#define DEBUG_UPLINK_UART0
#define DEBUG_UPLINK_UART1
#define DEBUG_UPLINK_SPI_HW
#define DEBUG_UPLINK_SPI_SW
#define DEBUG_UPLINK_I2C_HW
#define DEBUG_UPLINK_I2C_SW
#define DEBUG_DEFINE_PUTCHAR
#define DEBUG_PRINTF_BUFFERSIZE			30
#define DEBUG_UART_BAUD_RATE			115200
#define DEBUG_SPI_SCK_ACTIV      		DDRB|=0x02
#define DEBUG_SPI_SCK_HIGH       		PORTB|=0x02
#define DEBUG_SPI_SCK_LOW        		PORTB&=~0x02
#define DEBUG_SPI_MOSI_ACTIV     		DDRB|=0x04
#define DEBUG_SPI_MOSI_HIGH      		PORTB|=0x04
#define DEBUG_SPI_MOSI_LOW       		PORTB&=~0x04
#define DEBUG_SPI_MISO_PASSIV    		DDRB&=~0x08
#define DEBUG_SPI_MISO_PULLUP      		PORTB|=0x08
#define DEBUG_SPI_MISO_PIN       		((PINB&0x08)!=0)
#define	DEBUG_SPI_CS_ACTIV				DDRB|=0x01
#define DEBUG_SPI_CS_HIGH				PORTB|=0x01
#define DEBUG_SPI_CS_LOW				PORTB&=~0x01
#define	DEBUG_I2C_SCL_ACTIV				DDRD|=0x01
#define	DEBUG_I2C_SCL_PASSIV			DDRD&=~0x01
#define	DEBUG_I2C_SCL_LOW				PORTD&=~0x01
//@}
#endif


///	\def DEBUG
///		This macro enables the whole debug interface. Is the main macro for the debug module 
///		together with DEBUG_UPLINK_xx. It also activates the debug.c module.
///
/// \def DEBUG_UPLINK_UART0
/// 	This define activates the UART0 debug channel. The macro DEBUG must also be defined.
///		The hardware UART0 of the AVR is used.
//
/// \def DEBUG_UPLINK_UART1
/// 	This define activates the UART1 debug channel. The macro DEBUG must also be defined.
///		The hardware UART1 of the AVR is used.
//
/// \def DEBUG_UPLINK_SPI_HW
/// 	This define activates the SPI debug channel. The macro DEBUG must also be defined.
///		The hardware SPI interface of the AVR is used.
//
/// \def DEBUG_UPLINK_SPI_SW
/// 	This define activates the SPI debug channel. The macro DEBUG must also be defined.
///		An software SPI is used to commmunicate with the debugUSB.
//
/// \def DEBUG_UPLINK_I2C_HW
/// 	This define activates the I2C debug channel. The macro DEBUG must also be defined.
///		The hardware TWI interface of the AVR is used.
//
/// \def DEBUG_UPLINK_I2C_SW
/// 	This define activates the I2C debug channel. The macro DEBUG must also be defined.
///		The CodevisionAVR I2C library is used. You have to define the appropriate assembler defines.
///		See Codevision manual or example software for details.
//
/// \def DEBUG_DEFINE_PUTCHAR
/// 	If this macro is defined, the default putchar() function is redefined. If you call putchar()
///		the data will be sent to the debug interface. This also redirects the printf() output, since
///		printf() uses putchar() for transmitting. You can also use debug_putchar() or debug_printf()
///		for debug output if you want to use putchar() for other purposes.
//
/// \def DEBUG_PRINTF_BUFFERSIZE
/// 	If you use debug_printf, vprintf is used to use the stdio functions. Doing this an SRAM buffer
///		for the output string is needed. An default value for the buffer size is defined in debug_io.h
///		You can define DEBUG_PRINTF_BUFFERSIZE to an alternate value in your project.h
//
/// \def DEBUG_UART_BAUD_RATE
///		Specifies the baudrate, when DEBUG_UPLINK_UARTx is defined. The default value is 57600. Defining
///		this macro in project.h overwrites the default value.
//
/// \def DEBUG_SPI_SCK_ACTIV
///		Sets the SPI clock line as output. This macro must be defined for DEBUG_UPLINK_SPI_xx.
//
/// \def DEBUG_SPI_SCK_HIGH
///		Sets the SPI clock line high. This macro must be defined for DEBUG_UPLINK_SPI_xx.
//
/// \def DEBUG_SPI_SCK_LOW
///		Sets the SPI clock line low. This macro must be defined for DEBUG_UPLINK_SPI_xx.
//
/// \def DEBUG_SPI_MOSI_ACTIV
///		Sets the SPI MOSI line as output. This macro must be defined for DEBUG_UPLINK_SPI_xx.
//
/// \def DEBUG_SPI_MOSI_HIGH
///		Sets the SPI MOSI line high. This macro must be defined for DEBUG_UPLINK_SPI_xx.
//
/// \def DEBUG_SPI_MOSI_LOW
///		Sets the SPI MOSI line low. This macro must be defined for DEBUG_UPLINK_SPI_xx.
//
/// \def DEBUG_SPI_MISO_PASSIV
///		Sets the SPI MISO line as input. This macro must be defined for DEBUG_UPLINK_SPI_xx.
//
/// \def DEBUG_SPI_MISO_PULLUP
///		Activates the internal pullup on the SPI MISO line. This macro must be defined for DEBUG_UPLINK_SPI_xx.
//
/// \def DEBUG_SPI_MISO_PIN
///		Reads the input value of the SPI MISO line. This macro must be defined for DEBUG_UPLINK_SPI_xx.
//
/// \def DEBUG_SPI_CS_ACTIV
///		Sets the SPI Chip Select line as output. This macro must be defined for DEBUG_UPLINK_SPI_xx.
//
/// \def DEBUG_SPI_CS_HIGH
///		Sets the SPI Chip Select line high. This macro must be defined for DEBUG_UPLINK_SPI_xx.
//
/// \def DEBUG_SPI_CS_LOW
///		Sets the SPI Chip Select line low. This macro must be defined for DEBUG_UPLINK_SPI_xx.
//
/// \def DEBUG_I2C_SCL_ACTIV
///		Sets the I2C clock line as output. This macro must be defined for DEBUG_UPLINK_I2C_xx.
//
/// \def DEBUG_I2C_SCL_PASSIV
///		Sets the I2C clock line as input. This macro must be defined for DEBUG_UPLINK_I2C_xx.
//
/// \def DEBUG_I2C_SCL_LOW
///		Sets the I2C clock line low. This macro must be defined for DEBUG_UPLINK_I2C_xx.

#ifndef _DEBUG_IO_INCLUDED_
#define _DEBUG_IO_INCLUDED_

#include "project.h"		// Project configuration

#ifdef DEBUG

#if !defined(_CHIP_ATMEGA128_)&&!defined(_CHIP_ATMEGA128L_)&&\
    !defined(_CHIP_ATMEGA64_)&&!defined(_CHIP_ATMEGA64L_)&&\
    !defined(_CHIP_ATMEGA32_)&&!defined(_CHIP_ATMEGA32L_)&&\
    !defined(_CHIP_ATMEGA16_)&&!defined(_CHIP_ATMEGA16L_)&&\
    !defined(_CHIP_ATMEGA8535_)&&!defined(_CHIP_ATMEGA8535L_)&&\
    !defined(_CHIP_ATMEGA8_)&&!defined(_CHIP_ATMEGA8L_)&&\
    !defined(_CHIP_ATMEGA2561_)&&!defined(_CHIP_ATMEGA2561V_)
#error "Debug-Driver: AVR type not supported!"
#endif

#ifndef DEBUG_UART_BAUD_RATE
#define	DEBUG_UART_BAUD_RATE		57600			///< Sets default baud rate for internal UARTs
#endif

// --------------------------------------------------------------------------------
// Some common Baud rate dividers (doublespeed always on):
// ==16 with 115 kBaud and XTAL=16.0000Mhz (-2.1% error)
// ==15 with 115 kBaud and XTAL=14.7456Mhz (0.0%  error)
// ==7  with 115 kBaud and XTAL=7.3728Mhz  (+0.0% error)
// ==3  with 115 kBaud and XTAL=3.6864Mhz  (+0.0% error)
// -------------------------------------------------------------------------------- 
#define	DEBUG_UBRRL_VALUE			(_MCU_CLOCK_FREQUENCY_/(8*DEBUG_UART_BAUD_RATE)-1)   ///< register value
#define	DEBUG_UBRRH_VALUE			((DEBUG_UBRRL_VALUE&0xff00) >> 8)					///< register value


#ifdef DEBUG_UPLINK_UART0
	#define _DEBUG_UPLINK_SELECTED_
#endif
#ifdef DEBUG_UPLINK_UART1
	#ifdef _DEBUG_UPLINK_SELECTED_
	#error "DEBUG: Multiple Uplinks defined!"
	#else
	#define _DEBUG_UPLINK_SELECTED_
	#endif
#endif
#ifdef DEBUG_UPLINK_SPI_HW
	#ifdef _DEBUG_UPLINK_SELECTED_
	#error "DEBUG: Multiple Uplinks defined!"
	#else
	#define _DEBUG_UPLINK_SELECTED_
	#endif
#endif
#ifdef DEBUG_UPLINK_SPI_SW
	#ifdef _DEBUG_UPLINK_SELECTED_
	#error "DEBUG: Multiple Uplinks defined!"
	#else
	#define _DEBUG_UPLINK_SELECTED_
	#endif
#endif
#ifdef DEBUG_UPLINK_I2C_HW
	#ifdef _DEBUG_UPLINK_SELECTED_
	#error "DEBUG: Multiple Uplinks defined!"
	#else
	#define _DEBUG_UPLINK_SELECTED_
	#endif
#endif
#ifdef DEBUG_UPLINK_I2C_SW
	#ifdef _DEBUG_UPLINK_SELECTED_
	#error "DEBUG: Multiple Uplinks defined!"
	#else
	#define _DEBUG_UPLINK_SELECTED_
	#endif
#endif
#ifdef DEBUG_UPLINK_UDP
	#ifdef _DEBUG_UPLINK_SELECTED_
	#error "DEBUG: Multiple Uplinks defined!"
	#else
	#define _DEBUG_UPLINK_SELECTED_
	#endif
#endif
#ifndef _DEBUG_UPLINK_SELECTED_
#error "No DEBUG_UPLINK_.. defined!"
#endif

#ifdef DEBUG_DEFINE_PUTCHAR
	#if defined(DEBUG_UPLINK_SPI_HW) ||\
	    defined(DEBUG_UPLINK_SPI_SW) ||\
	    defined(DEBUG_UPLINK_UART1) ||\
	    defined(DEBUG_UPLINK_I2C_SW) ||\
	    defined(DEBUG_UPLINK_I2C_HW)
		#ifndef _ALTERNATE_PUTCHAR_
			#define _ALTERNATE_PUTCHAR_
		#endif
	#endif
#endif

#ifndef DEBUG_PRINTF_BUFFERSIZE
#define	DEBUG_PRINTF_BUFFERSIZE			30
#endif

// Prototypes
#pragma used+
void 		debug_io_init(void);
void 		debug_putchar(unsigned char c);
void 		debug_puts(unsigned char* str);
void 		debug_putsf(unsigned char flash *str);
signed int 	debug_check_rx(void);
#ifdef _ALTERNATE_PUTCHAR_
void		putchar(char);
#endif
void 		debug_printf(char flash *fmtstr,...);
#pragma used-

#ifdef DEBUG_LIBRARY_ENABLE
#pragma library debug_io.c
#endif

#endif	// #ifdef DEBUG
#endif 	// #ifndef _DEBUG_IO_INCLUDED_

/// @}
/// @}