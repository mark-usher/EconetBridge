// ************************************************************************************************
///
/// \file 			twi_avr.c
/// \brief			AVR I2C interface (TWI)
/// 
/// \note			module untested!
/// \date	 		$LastChangedDate: 2007-03-13 11:15:08 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 628 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration
#include "twi.h"

#ifdef TWI_AVR_ENABLE

#include <delay.h>

// --------------------------------------------------------------------------------
// TWI Control Register TWCR - BIT Definitions
// -------------------------------------------------------------------------------- 
#define TWCR_TWINT			0x80   		// TWI-interrupt Flag in TWCR
#define TWCR_TWEA 			0x40		// TWI-enable acknowledge-bit in TWCR
#define TWCR_TWSTA			0x20		// TWI-START-Condition in TWCR
#define TWCR_TWSTO			0x10	 	// TWI-STOP-Condition in TWCR
#define TWCR_TWEN 			0x04		// TWI-Enable-bit in TWCR
#define TWCR_TWIE			0x01		// TWI-Interrupt Enable in TWCR

// --------------------------------------------------------------------------------
// TWI Status Register TWSR - BIT Definitions
// -------------------------------------------------------------------------------- 
#define TWSR_TWPS0			0x01		// TWI-Prescaler Bit.0 in TWSR
#define TWSR_TWPS1			0x02		// TWI-Prescaler Bit.1 in TWSR

#define TWI_HW_CLOCK		100000L		// I2C Clock with 100 kHz


// ************************************************************************************************
/// \brief		Initializes I2C
///
// ************************************************************************************************
void twi_init(void)
{
TWCR = 0x00;				// TWI off
TWAR = 0x00;				// no own address
TWSR = 0x00;				// TWSR_TWPS0==0 and TWSR_TWPS1==0
TWBR = (_MCU_CLOCK_FREQUENCY_/(2*TWI_HW_CLOCK)) - 8;
TWCR = TWCR_TWEN;			// TWI enable
} 


#define TWI_TIMEOUT_COUNT		96*_MCU_CLOCK_FREQUENCY_/16000000L	// approx. 120 us for start-sign
// ************************************************************************************************
/// \brief		Waits until actual TWI operation is complete
///
/// @retval		0 - timeout
/// @retval		1 - success
// ************************************************************************************************
unsigned char twi_wait_finished(void)
{
unsigned int timeout = TWI_TIMEOUT_COUNT;

while (!(TWCR & TWCR_TWINT))						// wait for end of transmission
	if (--timeout == 0)
		{
		#ifdef TWI_DEBUG
		putsf("I2C-HW timeout\r");
		#endif
		return 0;
		}

return 1;
}


// ************************************************************************************************
/// \brief		Issues a START condition.
///
/// @retval		0 - the I2C bus is busy
/// @retval		1 - bus is free
// ************************************************************************************************
unsigned char twi_start(void)
{
TWCR = TWCR_TWINT | TWCR_TWSTA | TWCR_TWEN;			// send start-condition

if (twi_wait_finished() == 0)
	return 0;
if (((TWSR & 0xf8)==0x08) | ((TWSR & 0xf8)==0x10))	// if start-condition is acknowledged
	return 1;
#ifdef TWI_DEBUG
putsf("I2C-HW start error\r");
#endif

return 0;
}


// ************************************************************************************************
/// \brief		Writes the byte data to the bus.
/// @param[in]	data byte
/// @retval 	0 - nack or timeout
/// @retval 	1 - the slave acknowledges
// ************************************************************************************************
unsigned char twi_write_byte(unsigned char data)
{
TWDR = data;		  			// write data to data-register
TWCR = TWCR_TWINT | TWCR_TWEN; 	// send data on i2c-bus
if (twi_wait_finished() == 0)
	return 0;
switch (TWSR&0xf8)
	{
	case 0x18:			// SLA+W transmitted and ack received
	case 0x28:			// data transmitted and ack received
	case 0x40:			// SLA+R transmitted and ack received
		return 1;
	case 0x20:			// SLA+W transmitted and nack received
	case 0x48:			// SLA+R transmitted and nack received
	case 0x30:			// data transmitted and nack received
		return 0;
	default:
		#ifdef TWI_DEBUG
		printf("I2C-HW write unknown: 0x%02X\r\n", TWSR&0xf8);
		#endif
		return 0;
	}
}


// ************************************************************************************************
/// \brief		Reads a byte from the bus
/// @param[in]  The ack parameter specifies if an acknowledgement is to be issued after the 
///				byte was read. Set ack to 0 for no acknowledgement or 1 for acknowledgement.
/// \note		Call this function only, if SLA+R or twi_read() was acked before
/// @return		read byte / 0x00 if error
// ************************************************************************************************
unsigned char twi_read_byte(unsigned char ack)
{
if ((TWSR&0xf8)==0x40 || (TWSR&0xf8)==0x50)	// i2c-slave answered address/data - sent before - with ack
	{
	if (ack)
		TWCR = TWCR_TWINT | TWCR_TWEA | TWCR_TWEN;		// ACK will be send
	else
		TWCR = TWCR_TWINT | TWCR_TWEN;		// NACK will be send
	if (twi_wait_finished() == 0)
		return 0;
	return TWDR;
	} 
else
	{
	#ifdef TWI_DEBUG
	putsf("I2C-HW read-error!!\r");
	#endif
	return 0;
	}
}


// ************************************************************************************************
/// \brief		Issues a STOP condition.
///
// ************************************************************************************************
void twi_stop(void)
{
TWCR = TWCR_TWINT | TWCR_TWSTA | TWCR_TWSTO; // send stop-condition
// TWINT is NOT set after Stop-condition is sent!
//delay_us(20);	// wait for slave to switch to non-addressed mode
}

#endif	// #ifdef TWI_AVR_ENABLE