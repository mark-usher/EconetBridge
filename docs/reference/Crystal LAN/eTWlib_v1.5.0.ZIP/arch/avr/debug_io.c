// ************************************************************************************************
///
/// \file 			debug_io.c
/// \brief			Debug-Interface access drivers
///
/// \note			When defining _ALTERNATE_PUTCHAR_ and using the debug-io module in library 
///					mode (DEBUG_LIBRARY_ENABLE), be sure to include <stdio.h> in your code AFTER
///					including debug_io.h to prevent compiler error.
/// \todo			When using library mode (DEUG_LIBRARY_ENABLE) and using printf() in the main c
///					file, Codevision returns error "Putchar has already been declared in current
///					scope"
/// \date	 		$LastChangedDate: 2007-03-30 10:17:04 +0200 (Fr, 30 Mrz 2007) $
/// \version 		$Rev: 661 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"

#ifdef DEBUG

#include <io.h>
#include <stdio.h>
#include <delay.h>
#ifdef DEBUG_UPLINK_SPI_HW
#include "avr_spi.h"
#endif
#include "debug_io.h"
#ifdef DEBUG_UPLINK_UDP
#include "udp.h"
#endif


#ifdef DEBUG_UPLINK_UART0
    #if defined(_CHIP_ATMEGA128_)||defined(_CHIP_ATMEGA128L_)||\
        defined(_CHIP_ATMEGA64_)||defined(_CHIP_ATMEGA64L_)||\
        defined(_CHIP_ATMEGA2561_)||defined(_CHIP_ATMEGA2561V_)
    // init UART0
    // Communication Parameters: 8 Data, 1 Stop, No Parity
    // UART Receiver: On
    // UART Transmitter: On
    // UART IRQ-Receiver: Off
    #define DEBUG_CONFIG_UART 					UCSR0B=0x18					///< configure hardware UART
    #define DEBUG_SET_UART_BAUDRATE				(UBRR0L=DEBUG_UBRRL_VALUE, UBRR0H=DEBUG_UBRRH_VALUE)		///< set UART baudrate
    #define DEBUG_SET_UART_DOUBLESPEED 			UCSR0A |= 0x02					///< set UART doublespeed
    #define DEBUG_UART_FLAG_REGISTER  			UCSR0A						///< access UART register
    #define DEBUG_UART_DATA_REGISTER  			UDR0						///< access UART register
    #define DEBUG_UART_PULLUP_ENABLE			(DDRE&=~0x01, PORTE|=0x01)	///< set UART pins input & enable Pullups
    #endif

    #if defined(_CHIP_ATMEGA32_)||defined(_CHIP_ATMEGA32L_)||\
        defined(_CHIP_ATMEGA16_)||defined(_CHIP_ATMEGA16L_)||\
        defined(_CHIP_ATMEGA8535_)||defined(_CHIP_ATMEGA8535L_)||\
        defined(_CHIP_ATMEGA8_)||defined(_CHIP_ATMEGA8L_)
    // init UART0
    // Communication Parameters: 8 Data, 1 Stop, No Parity
    // UART Receiver: On
    // UART Transmitter: On
    // UART IRQ-Receiver: Off
    #define DEBUG_CONFIG_UART 					UCSRB=0x18
    #define DEBUG_SET_UART_BAUDRATE				(UBRRL=DEBUG_UBRRL_VALUE, UBRRH=DEBUG_UBRRH_VALUE)
    #define DEBUG_SET_UART_DOUBLESPEED 			UCSRA|=0x02;
    #define DEBUG_UART_FLAG_REGISTER			UCSRA
    #define DEBUG_UART_DATA_REGISTER  			UDR
    #define DEBUG_UART_PULLUP_ENABLE			(DDRD&=~0x01, PORTD|=0x01)	// input&Pullup enable
    #endif
#endif

#ifdef DEBUG_UPLINK_UART1
    #if defined(_CHIP_ATMEGA128_)||defined(_CHIP_ATMEGA128L_)||\
        defined(_CHIP_ATMEGA64_)||defined(_CHIP_ATMEGA64L_)||\
        defined(_CHIP_ATMEGA2561_)||defined(_CHIP_ATMEGA2561V_)
    // init UART0
    // Communication Parameters: 8 Data, 1 Stop, No Parity
    // UART Receiver: On
    // UART Transmitter: On
    // UART IRQ-Receiver: Off
    #define DEBUG_CONFIG_UART 					UCSR1B=0x18
    #define DEBUG_SET_UART_BAUDRATE				(UBRR1L=DEBUG_UBRRL_VALUE,UBRR1H=DEBUG_UBRRH_VALUE)		// set new baudrate
    #define DEBUG_SET_UART_DOUBLESPEED 			UCSR1A |= 0x02
    #define DEBUG_UART_FLAG_REGISTER			UCSR1A
    #define DEBUG_UART_DATA_REGISTER  			UDR1
    #define DEBUG_UART_PULLUP_ENABLE			(DDRD&=~0x04, PORTD|=0x04)					// input&Pullup enable
    #endif

    #if defined(_CHIP_ATMEGA32_)||defined(_CHIP_ATMEGA32L_)||\
        defined(_CHIP_ATMEGA16_)||defined(_CHIP_ATMEGA16L_)||\
        defined(_CHIP_ATMEGA8535_)||defined(_CHIP_ATMEGA8535L_)||\
        defined(_CHIP_ATMEGA8_)||defined(_CHIP_ATMEGA8L_)
    #error "DEBUG_UPLINK_UART1 not available with this chip!"
    #endif
#endif


// local prototypes
void _debug_io_init(void);

// ************************************************************************************************
/// \brief		Inits the selected debug channel
///
// ************************************************************************************************
void debug_io_init(void)
{
_debug_io_init();
}


#ifdef _ALTERNATE_PUTCHAR_
// ************************************************************************************************
/// \brief		Writes a character to the selected debug channel
///
/// @param[in]	c - character to send
// ************************************************************************************************
void putchar(char c)
{
debug_putchar((unsigned char)c);
}
#endif	// #ifdef _ALTERNATE_PUTCHAR_


// ************************************************************************************************
/// \brief		Alternate printf-function for debug interface
///
///	\note		You can also use printf() for debug output! Use debug_printf(), if you also use
////			printf() in your application with another interface!
///	\note		The function buffers the transmitted data in SRAM. The ASCII data must not exceed 
///				the buffersize specified in DEBUG_PRINTF_BUFFERSIZE. See debug_io.h
///	@param[in]	fmtstr - Formatstring, see printf()
// ************************************************************************************************
void debug_printf(char flash *fmtstr,...)
{
unsigned char temp_str[DEBUG_PRINTF_BUFFERSIZE];
va_list       argptr;       // va_list is defined as char pointer

va_start(argptr,fmtstr);    // load pointer to first parameter in arg_ptr
vsprintf(temp_str, fmtstr, argptr);    
va_end(argptr);
debug_puts(temp_str);
}


// ************************************************************************************************
/// \brief		Alternate puts-function for debug interface
///
///	@param[in]	str - \0-terminated string in SRAM
// ************************************************************************************************
void debug_puts(unsigned char* str)
{
while (*str)
	{
	debug_putchar(*str);
	str++;
	}
}


// ************************************************************************************************
/// \brief		Alternate putsf-function for debug interface
///
///	@param[in]	str - \0-terminated string in FLASH
// ************************************************************************************************
void debug_putsf(unsigned char flash *str)
{
while (*str)
	{
	debug_putchar(*str);
	str++;
	}
}


#if defined(DEBUG_UPLINK_UART1) || defined(DEBUG_UPLINK_UART0)

	#if defined(_CHIP_ATMEGA8535_)||defined(_CHIP_ATMEGAS8535L_)||\
	    defined(_CHIP_ATMEGA8_)||defined(_CHIP_ATMEGA8L_)||\
	    defined(_CHIP_ATMEGA16_)||defined(_CHIP_ATMEGAS16L_)||\
	    defined(_CHIP_ATMEGA32_)||defined(_CHIP_ATMEGA32L_)
		#define DEBUG_UDR					UDR
		#define DEBUG_UCSR					UCSRA
	#else
		#ifdef DEBUG_UPLINK_UART0
			#define DEBUG_UDR				UDR0
			#define DEBUG_UCSR				UCSR0A
		#else
			#define DEBUG_UDR				UDR1
			#define DEBUG_UCSR				UCSR1A
		#endif
	#endif
	#define DEBUG_FRAMING_ERROR				0x10
	#define DEBUG_PARITY_ERROR 				0x04
	#define DEBUG_DATA_OVERRUN				0x08
	#define DEBUG_DATA_REGISTER_EMPTY 		0x20
	#define DEBUG_RX_COMPLETE 				0x80
	
	// ************************************************************************************************
	/// \brief		Inits the selected debug channel
	///
	// ************************************************************************************************
	void _debug_io_init(void)
	{
	DEBUG_SET_UART_BAUDRATE;
	DEBUG_SET_UART_DOUBLESPEED;
	DEBUG_CONFIG_UART;
	DEBUG_UART_PULLUP_ENABLE;   
	// Pullups are needed, in case there is no Level-Shifter connected to the UART-Receive-Pin.
	}
	

	// ************************************************************************************************
	/// \brief		Checks for received data from debugUSB
	///
	/// @retvalue	-1   - no character received
	/// @retvalue	>=0  - reveived character
	// ************************************************************************************************
	signed int debug_check_rx(void)
	{
	unsigned char status, data;
	
	if (((status=DEBUG_UCSR) & DEBUG_RX_COMPLETE)==0)
		return -1;
	data = DEBUG_UDR;			// read data to reset RXC-Bit
	if ((status & (DEBUG_FRAMING_ERROR | DEBUG_PARITY_ERROR | DEBUG_DATA_OVERRUN))==0)
		return data;
	else
		return -1;
	}

	
	// ************************************************************************************************
	/// \brief		Writes a character to debugUSB
	///
	/// @param		c - character to send
	// ************************************************************************************************
	void debug_putchar(unsigned char c)
	{
	while ((DEBUG_UCSR & DEBUG_DATA_REGISTER_EMPTY)==0);
	DEBUG_UDR = c;
	}
#endif	// #if defined(DEBUG_UPLINK_UART1) || defined(DEBUG_UPLINK_UART0)


#if defined(DEBUG_UPLINK_SPI_SW) || defined(DEBUG_UPLINK_SPI_HW)

	#ifdef DEBUG_UPLINK_SPI_HW
		#define DEBUG_SPI_WRITE(c)    spi_transfer(c)	// Codevision Function
		#ifndef SPI_ENABLE
		#error "avr-spi module needed for DEBUG_UPLINK_SPI_HW. Define SPI_ENABLE!"
		#endif
	#else
		#define DEBUG_SPI_WRITE(c)    debug_spi_soft_write(c)
	#endif

	// --------------------------------------------------------------------------------
	// SPI Mode macros
	// -------------------------------------------------------------------------------- 
	#define	DEBUG_SPCR_SPIE			0x80	// SPI Interrupt Enable
	#define	DEBUG_SPCR_SPE			0x40	// SPI Enable
	#define	DEBUG_SPCR_DORD			0x20	// SPI Data Order 1=LSB; 0=MSB
	#define	DEBUG_SPCR_MSTR			0x10	// SPI Master/Slave Select 1=Master; 0=Slave
	#define	DEBUG_SPCR_CPOL			0x08	// SPI Clock Polarity 1=SCK=HIGH; 0=SCK=LOW
	#define	DEBUG_SPCR_CPHA	 		0x04	// SPI Clock Phase
	#define	DEBUG_SPCR_128			0x03	// SPI Clock 1/128 Main-Clock
	#define	DEBUG_SPCR_64			0x02	// SPI Clock 1/64 Main-Clock
	#define	DEBUG_SPCR_16			0x01	// SPI Clock 1/16 Main-Clock
	#define	DEBUG_SPCR_4			0x00	// SPI Clock 1/4 Main-Clock
	
	#ifdef _CHIP_ATMEGA128_
	// Double Speed Bit - Register SPSR(SPI Status Register)
	#define	DEBUG_SPCR_32			0x02	// SPI Clock 1/32 Main-Clock
	#define	DEBUG_SPCR_8			0x01	// SPI Clock 1/8 Main-Clock
	#define	DEBUG_SPCR_2			0x00	// SPI Clock 1/2 Main-Clock
	#endif


	// ************************************************************************************************
	/// \brief		Inits the selected debug channel
	///
	// ************************************************************************************************
	void _debug_io_init(void)
	{
	DEBUG_SPI_CS_HIGH;
	DEBUG_SPI_CS_ACTIV;
	DEBUG_SPI_SCK_LOW;
	DEBUG_SPI_SCK_ACTIV;
	DEBUG_SPI_MOSI_HIGH;
	DEBUG_SPI_MOSI_ACTIV;
	DEBUG_SPI_MISO_PASSIV;
	DEBUG_SPI_MISO_PULLUP;
	#ifdef DEBUG_UPLINK_SPI_HW
	// Clear the SPI interrupt flag
	#asm
	    in   r30,spsr
	    in   r30,spdr
	#endasm
	SPCR   = DEBUG_SPCR_SPE | DEBUG_SPCR_MSTR | DEBUG_SPCR_16;
	SPSR.0 = 0;		// disable double speed
	#endif	// #ifdef DEBUG_UPLINK_SPI_HW
	}
	

	#pragma used+
	// ************************************************************************************************
	/// \brief		Writes a Byte via Software-SPI in SPI-Mode 0
	///
	/// @param		data_out - data to send
	/// @return		received data
	// ************************************************************************************************
	unsigned char debug_spi_soft_write(unsigned char data_out)
	{
	unsigned char data_in=0, i;
	
	// Clock polarity: 0 - SCK low, when idle
	// Clock phase:    0 - sample data with leading edge (rising)
	// vor SCK High MOSI setzen
	// nach SCK LOW MISO einlesen
	for (i=0; i<8; i++)
		{
		delay_us(1);
		data_in <<= 1;
		data_in|=DEBUG_SPI_MISO_PIN;
	
		if (data_out & 0x80)      // highest bit set?
		    DEBUG_SPI_MOSI_HIGH;
		else
		    DEBUG_SPI_MOSI_LOW;
		data_out <<= 1;
		DEBUG_SPI_SCK_HIGH;
		delay_us(1);
		DEBUG_SPI_SCK_LOW;
		}

	return data_in;
	}
	#pragma used-


	// ************************************************************************************************
	/// \brief		Writes a character to debugUSB
	///
	/// @param		c - character to send
	// ************************************************************************************************
	void debug_putchar(char c)
	{
	DEBUG_SPI_CS_LOW;
	DEBUG_SPI_WRITE(0x80 | c);			// set highest Bit for 'write mode'
	DEBUG_SPI_CS_HIGH;
	delay_us(10);
	}


	// ************************************************************************************************
	/// \brief		Checks for received data from debugUSB
	///
	/// @retvalue	-1   - no character received
	/// @retvalue	>=0  - reveived character
	// ************************************************************************************************
	signed int debug_check_rx(void)
	{
	static unsigned char func_call_count=0;
	unsigned char data;

	if (++func_call_count == 4)
		func_call_count = 0;
	else
		return -1;

	DEBUG_SPI_CS_LOW;
	data = DEBUG_SPI_WRITE(0x00);		// highest Bit='0' for 'read mode'
	DEBUG_SPI_CS_HIGH;

	if (data&0x80)
		return (data & 0x7F);    		// clear r/w-Mode bit
	else
		return -1;
	}
#endif	// #if defined(DEBUG_UPLINK_SPI_SW) || defined(DEBUG_UPLINK_SPI_HW)


#if defined(DEBUG_UPLINK_I2C_HW) || defined(DEBUG_UPLINK_I2C_SW)

	#ifdef DEBUG_UPLINK_I2C_HW

	// --------------------------------------------------------------------------------
	// TWI Control Register TWCR - BIT Definitions
	// -------------------------------------------------------------------------------- 
	#define DEBUG_TWCR_TWINT			0x80   		// TWI-interrupt Flag in TWCR
	#define DEBUG_TWCR_TWEA 			0x40		// TWI-enable acknowledge-bit in TWCR
	#define DEBUG_TWCR_TWSTA			0x20		// TWI-START-Condition in TWCR
	#define DEBUG_TWCR_TWSTO			0x10	 	// TWI-STOP-Condition in TWCR
	#define DEBUG_TWCR_TWEN 			0x04		// TWI-Enable-bit in TWCR
	#define DEBUG_TWCR_TWIE				0x01		// TWI-Interrupt Enable in TWCR
	
	// --------------------------------------------------------------------------------
	// TWI Status Register TWSR - BIT Definitions
	// -------------------------------------------------------------------------------- 
	#define DEBUG_TWSR_TWPS0			0x01		// TWI-Prescaler Bit.0 in TWSR
	#define DEBUG_TWSR_TWPS1			0x02		// TWI-Prescaler Bit.1 in TWSR

	#define DEBUG_I2C_HW_CLOCK			100000L		// I2C Clock with 100 kHz

	#define DEBUG_I2C_HW_START_TIMEOUT	16*_MCU_CLOCK_FREQUENCY_/16000000L	// approx. 20 us for start-sign
	#define DEBUG_I2C_HW_RW_TIMEOUT		96*_MCU_CLOCK_FREQUENCY_/16000000L	// approx. 120 us for start-sign

	#pragma used+
	unsigned char 	debug_io_i2c_hw_start(void);
	unsigned char 	debug_io_i2c_hw_read(unsigned char tx_ack);
	unsigned char 	debug_io_i2c_hw_write(unsigned char c);
	void 			debug_io_i2c_hw_stop(void);
	#pragma used-


	// ************************************************************************************************
	/// \brief		Generates a START-sign on the I2C bus
	/// @retval	0 - failure - timeout of approx. 20 us exeeded
	/// @retval	0 - failure - start condition was not acknowledged
	/// @retval	1 - success
	// ************************************************************************************************
	unsigned char debug_io_i2c_hw_start(void)
	{
	unsigned int timeout_countdown = DEBUG_I2C_HW_START_TIMEOUT;

	TWCR = DEBUG_TWCR_TWINT | DEBUG_TWCR_TWEN | DEBUG_TWCR_TWSTA;	// send start-condition
	while (!(TWCR & DEBUG_TWCR_TWINT))						// wait for end of transmission
		if (--timeout_countdown==0)
			{
			TWCR = 0x00;
			return 0;
			}
	if (((TWSR & 0xf8)==0x08) | ((TWSR & 0xf8)==0x10))		// if start-condition is acknowledged
		return 1;
	return 0;
	}
	
	
	// ************************************************************************************************
	/// \brief		Reads a Byte from I2C
	///
	/// \note		i2c_hw_write() must be called for addressing slave
	/// @param[in]	tx_ack - send ack to slave (1 for ack)
	/// @return		red byte / 0x00 if error
	// ************************************************************************************************
	unsigned char debug_io_i2c_hw_read(unsigned char tx_ack)
	{
	unsigned int timeout_countdown = DEBUG_I2C_HW_RW_TIMEOUT;
	
	if ((TWSR&0xf8)==0x40 || (TWSR&0xf8)==0x50)	// i2c-slave answered address/data - sent before - with ack
		{
		if (tx_ack)
			TWCR = DEBUG_TWCR_TWINT | DEBUG_TWCR_TWEN | DEBUG_TWCR_TWEA;		// ACK will be send
		else
			TWCR = DEBUG_TWCR_TWINT | DEBUG_TWCR_TWEN;		// NACK will be send
		while (!(TWCR & DEBUG_TWCR_TWINT))			// wait for end of transmission
			if (--timeout_countdown==0)
				{
				TWCR = 0x00;
				return 0;
				}
		return TWDR;
		} 
	else
		return 0;
	}
	
	
	// ************************************************************************************************
	/// \brief		Write a byte to the I2C (data or address)
	/// @param[in]	c - data or address to send
	/// @retval		1 - data/address sent and ack received
	/// @retval		0 - data/address sent and nack received
	/// @retval		0 - timeout
	/// @retval		0 - error
	// ************************************************************************************************
	unsigned char debug_io_i2c_hw_write(unsigned char c)
	{
	unsigned int timeout_countdown = DEBUG_I2C_HW_RW_TIMEOUT;
	
	TWDR = c;		  				// write data to data-register
	TWCR = DEBUG_TWCR_TWINT | DEBUG_TWCR_TWEN; 	// send data on i2c-bus
	while(!(TWCR & DEBUG_TWCR_TWINT))  	// wait for end of transmission
		if (--timeout_countdown == 0)
			{
			TWCR = 0x00;
			return 0;
			}
	switch (TWSR&0xf8)
		{
		case 0x18:			// SLA+W transmitted and ack received
		case 0x28:			// data transmitted and ack received
		case 0x40:			// SLA+R transmitted and ack received
			return 1;
		}
	return 0;
	}


	// ************************************************************************************************
	/// \brief		Generates STOP-sign on I2C bus
	///
	// ************************************************************************************************
	void debug_io_i2c_hw_stop(void)
	{
	TWCR = DEBUG_TWCR_TWINT | DEBUG_TWCR_TWEN | DEBUG_TWCR_TWSTO; // send stop-condition
	delay_us(20);
	// TWINT is NOT set after Stop-condition is sent!
	}
	#endif	// #ifdef DEBUG_UPLINK_I2C_HW

	#ifdef DEBUG_UPLINK_I2C_HW
		#define DEBUG_I2C_START	   	debug_io_i2c_hw_start
		#define DEBUG_I2C_WRITE   	debug_io_i2c_hw_write
		#define DEBUG_I2C_READ    	debug_io_i2c_hw_read
		#define DEBUG_I2C_STOP    	debug_io_i2c_hw_stop
	#else
		#define DEBUG_I2C_INIT      
		#define DEBUG_I2C_START     i2c_start
		#define DEBUG_I2C_WRITE  	i2c_write
		#define DEBUG_I2C_READ		i2c_read
		#define DEBUG_I2C_STOP    	i2c_stop
	#endif


	// ************************************************************************************************
	/// \brief		Inits the selected debug channel
	///
	// ************************************************************************************************
	void _debug_io_init(void)
	{
	unsigned char i;

	#ifdef DEBUG_UPLINK_I2C_HW
	TWCR = 0x00;				// TWI off
	#endif
	
	DEBUG_I2C_SCL_PASSIV;		// SCL input
	DEBUG_I2C_SCL_LOW;			// output value: 0
	for (i=0; i<10; i++)
		{
		DEBUG_I2C_SCL_ACTIV;	// SCL output -> signal low
		delay_us(5);
		DEBUG_I2C_SCL_PASSIV;	// SCL input -> signal high
		delay_us(5);
		}

	#ifdef DEBUG_UPLINK_I2C_HW
	TWAR = 0x00;				// no own address
	TWSR = 0x00;				// TWSR_TWPS0==0 and TWSR_TWPS1==0
	TWBR = (_MCU_CLOCK_FREQUENCY_/(2*DEBUG_I2C_HW_CLOCK)) - 8;
	TWAR = 0x00;
	TWCR = DEBUG_TWCR_TWEN;		// TWI enable
	#else
	i2c_init();
	#endif
	}


	// ************************************************************************************************
	/// \brief		Writes a character to debugUSB
	///
	/// @param		c - character to send
	// ************************************************************************************************
	void debug_putchar(unsigned char c)
	{
	if (!DEBUG_I2C_START())					// returns 1, if succeeded
		return;
	if (!DEBUG_I2C_WRITE(0x7E<<1 | 0x00))	// address: 0x7E + direction bit '0' -> write
		{
		DEBUG_I2C_STOP();
		return;
		}
	DEBUG_I2C_WRITE(c);						// character
	DEBUG_I2C_STOP();
	}
	
	
	// ************************************************************************************************
	/// \brief		Checks for received data from debugUSB
	///
	/// @retvalue	-1   - no character received
	/// @retvalue	>=0  - reveived character
	// ************************************************************************************************
	signed int debug_check_rx(void)
	{
	static unsigned char func_call_count=0;
	unsigned char data;

	if (++func_call_count == 5)
		func_call_count = 0;
	else
		return -1;

	if (DEBUG_I2C_START())				// returns 1, if succeeded
		{
		DEBUG_I2C_WRITE(0x7E<<1 | 0x01);// address: 0x7E + direction bit '1' -> read
		data = DEBUG_I2C_READ(0x00);		// send ack
		if (data & 0x80)	// WR-Bit
			{
			// character from PC available
			DEBUG_I2C_STOP();
			return data & 0x7F;
			}
		else
			{
			// no data available
			DEBUG_I2C_STOP();
			return -1;
			}
 		}
	else
		return -1;
	}
#endif	// #if defined(DEBUG_UPLINK_I2C_HW) || defined(DEBUG_UPLINK_I2C_SW)


#ifdef DEBUG_UPLINK_UDP

	unsigned char debug_io_udp_handle=UDP_WRONG_CONNECTIONS;
	// ************************************************************************************************
	/// \brief		Inits the selected debug channel
	///
	// ************************************************************************************************
	void _debug_io_init(void)
	{
	debug_io_udp_handle = udp_open(DEBUG_LOCAL_PORT, 0, 0, 0, UDP_FLAG_PASSIVE);
/*	if (debug_io_udp_handle == UDP_WRONG_CONNECTIONS)
		{
		#ifdef WEB_DEBUG_UDP
		if(web_debug_flag & WEB_DEBUG_UDP_BIT)
			printf("UDP(%u) Passiv Open Error!!!!\r\n", port_number);
		#endif
		}*/

	}


	// ************************************************************************************************
	/// \brief		Writes a character to debugUSB
	///
	/// @param		c - character to send
	// ************************************************************************************************
	void debug_putchar(unsigned char c)
	{
	unsigned char* p_data;
	
	p_data = &c;
	udp_tx_buffer_prepare(debug_io_udp_handle, p_data, 1);
	}
	
	
	// ************************************************************************************************
	/// \brief		Checks for received data from debugUSB
	///
	/// @retvalue	-1   - no character received
	/// @retvalue	>=0  - reveived character
	// ************************************************************************************************
	signed int debug_check_rx(void)
	{
	return -1;
	}
#endif	// #ifdef DEBUG_UPLINK_TELNET


#endif	// #ifdef DEBUG