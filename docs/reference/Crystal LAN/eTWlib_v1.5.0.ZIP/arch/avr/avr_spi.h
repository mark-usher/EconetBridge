// ************************************************************************************************
///
/// \file 			avr_spi.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _AVR_SPI_INCLUDED_
#define _AVR_SPI_INCLUDED_

#include "project.h"

#ifdef SPI_ENABLE

// --------------------------------------------------------------------------------
// SPI Mode macros
// -------------------------------------------------------------------------------- 
#define	SPCR_SPIE			0x80	// SPI Interrupt Enable
#define	SPCR_SPE			0x40	// SPI Enable
#define	SPCR_DORD			0x20	// SPI Data Order 1=LSB; 0=MSB
#define	SPCR_MSTR			0x10	// SPI Master/Slave Select 1=Master; 0=Slave
#define	SPCR_CPOL			0x08	// SPI Clock Polarity 1=SCK=HIGH; 0=SCK=LOW
#define	SPCR_CPHA			0x04	// SPI Clock Phase
#define	SPCR_128			0x03	// SPI Clock 1/128 Main-Clock
#define	SPCR_64				0x02	// SPI Clock 1/64 Main-Clock
#define	SPCR_16				0x01	// SPI Clock 1/16 Main-Clock
#define	SPCR_4				0x00	// SPI Clock 1/4 Main-Clock

#if defined(_CHIP_ATMEGA128_)||defined(_CHIP_ATMEGA128L_)||defined(_CHIP_ATMEGA32_)||defined(_CHIP_ATMEGA32L_)||defined(_CHIP_ATMEGA161_)||defined(_CHIP_ATMEGA161L_)
// Double Speed Bit - Register SPSR(SPI Status Register)
#define	SPCR_32				0x0102	// SPI Clock 1/32 Main-Clock
#define	SPCR_8				0x0101	// SPI Clock 1/8 Main-Clock
#define	SPCR_2				0x0100	// SPI Clock 1/2 Main-Clock
#endif


#pragma used+
void 		  spi_init(unsigned int mode);
unsigned char spi_transfer(unsigned char data);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
#pragma library avr_spi.c
#endif

#endif  // #ifdef SPI_ENABLE
#endif  // #ifndef _AVR_SPI_INCLUDED_