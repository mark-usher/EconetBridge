// ************************************************************************************************
///
/// \file 			twi_bb.c
/// \brief			Bit-Banged I2C interface using the Codevision assembler library
/// 
/// \date	 		$LastChangedDate: 2007-03-12 18:16:38 +0100 (Mo, 12 Mrz 2007) $
/// \version 		$Rev: 623 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration
#include "twi.h"

#ifdef TWI_CVAVR_ENABLE

// prepare assembler macros for Codevision library
#if defined TWI_PORTA
#asm(".equ __i2c_port=0x1B")
#elif defined TWI_PORTB
#asm(".equ __i2c_port=0x18")
#elif defined TWI_PORTC
#asm(".equ __i2c_port=0x15")
#endif

#if defined TWI_SDA_BIT0
#asm(".equ __sda_bit=0")
#elif defined TWI_SDA_BIT1
#asm(".equ __sda_bit=1")
#elif defined TWI_SDA_BIT2
#asm(".equ __sda_bit=2")
#elif defined TWI_SDA_BIT3
#asm(".equ __sda_bit=3")
#elif defined TWI_SDA_BIT4
#asm(".equ __sda_bit=4")
#elif defined TWI_SDA_BIT5
#asm(".equ __sda_bit=5")
#elif defined TWI_SDA_BIT6
#asm(".equ __sda_bit=6")
#elif defined TWI_SDA_BIT7
#asm(".equ __sda_bit=7")
#endif

#if defined TWI_SCL_BIT0
#asm(".equ __scl_bit=0")
#elif defined TWI_SCL_BIT1
#asm(".equ __scl_bit=1")
#elif defined TWI_SCL_BIT2
#asm(".equ __scl_bit=2")
#elif defined TWI_SCL_BIT3
#asm(".equ __scl_bit=3")
#elif defined TWI_SCL_BIT4
#asm(".equ __scl_bit=4")
#elif defined TWI_SCL_BIT5
#asm(".equ __scl_bit=5")
#elif defined TWI_SCL_BIT6
#asm(".equ __scl_bit=6")
#elif defined TWI_SCL_BIT7
#asm(".equ __scl_bit=7")
#endif

// now we can include the I2C Functions
#include <i2c.h>


// ************************************************************************************************
/// \brief		Initializes I2C
///
// ************************************************************************************************
void twi_init(void)
{
i2c_init();
}


// ************************************************************************************************
/// \brief		Issues a START condition.
///
/// @retval		0 - the I2C bus is busy
/// @retval		1 - bus is free
// ************************************************************************************************
unsigned char twi_start(void)
{
return i2c_start();
}


// ************************************************************************************************
/// \brief		Writes the byte data to the bus.
/// @param[in]	data byte
/// @retval 	0 - nack
/// @retval 	1 - the slave acknowledges
// ************************************************************************************************
unsigned char twi_write_byte(unsigned char data)
{
return i2c_write(data);
}


// ************************************************************************************************
/// \brief		Reads a byte from the bus
/// @param[in]  The ack parameter specifies if an acknowledgement is to be issued after the 
///				byte was read. Set ack to 0 for no acknowledgement or 1 for acknowledgement.
/// @return		read byte
// ************************************************************************************************
unsigned char twi_read_byte(unsigned char ack)
{
return i2c_read(ack);
}


// ************************************************************************************************
/// \brief		issues a STOP condition.
///
// ************************************************************************************************
void twi_stop(void)
{
i2c_stop();
}

#endif	// #ifdef TWI_CVAVR_ENABLE