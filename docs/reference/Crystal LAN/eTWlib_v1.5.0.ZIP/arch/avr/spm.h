// ************************************************************************************************
///
/// \file 			spm.h
/// \brief			header file of spm.c
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Daniel Matthes, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup AVR_Driver
/// @{
/// \defgroup SPM
/// @{
  
#ifndef _SPM_INCLUDED_
#define _SPM_INCLUDED_ 

#ifndef _DOXYGEN_PARSER_
#if 	defined (_CHIP_ATMEGA8_) || defined (_CHIP_ATMEGA8L_) ||\
		defined (_CHIP_ATMEGA88_) || defined (_CHIP_ATMEGA88V_) ||\
		defined (_CHIP_ATMEGA8515_) || defined (_CHIP_ATMEGA8515L_) ||\
		defined (_CHIP_ATMEGA8535_) || defined (_CHIP_ATMEGA8535L_) ||\
		defined (_CHIP_ATMEGA16_) || defined (_CHIP_ATMEGA16L_) ||\ 
		defined (_CHIP_ATMEGA168_) || defined (_CHIP_ATMEGA168V_) ||\
		defined (_CHIP_ATMEGA162_) || defined (_CHIP_ATMEGA162V_) ||\
		defined (_CHIP_ATMEGA165_) || defined (_CHIP_ATMEGA165V_) ||\
		defined (_CHIP_ATMEGA169_) || defined (_CHIP_ATMEGA169V_) ||\
		defined (_CHIP_ATMEGA32_) || defined (_CHIP_ATMEGA32L_) ||\
		defined (_CHIP_ATMEGA325_) || defined (_CHIP_ATMEGA325V_) ||\
		defined (_CHIP_ATMEGA3250_) || defined (_CHIP_ATMEGA3250V_) ||\
		defined (_CHIP_ATMEGA329_) || defined (_CHIP_ATMEGA329V_) ||\
		defined (_CHIP_ATMEGA3290_) || defined (_CHIP_ATMEGA3290V_) ||\
		defined (_CHIP_ATMEGA64_) || defined (_CHIP_ATMEGA64L_) ||\
		defined (_CHIP_ATMEGA640_) || defined (_CHIP_ATMEGA640V_) ||\
		defined (_CHIP_ATMEGA644_) || defined (_CHIP_ATMEGA644V_) ||\
		defined (_CHIP_ATMEGA645_) || defined (_CHIP_ATMEGA645V_) ||\
		defined (_CHIP_ATMEGA6450_) || defined (_CHIP_ATMEGA6450V_) ||\
		defined (_CHIP_ATMEGA649_) || defined (_CHIP_ATMEGA649V_) ||\
		defined (_CHIP_ATMEGA6490_) || defined (_CHIP_ATMEGA6490V_)
			#define SPM_ADDR_SIZE_FLASH_16BIT
#elif	defined (_CHIP_ATMEGA128_) || defined (_CHIP_ATMEGA128L_) ||\
		defined (_CHIP_ATMEGA1280_) || defined (_CHIP_ATMEGA1280V_) ||\
	  	defined (_CHIP_ATMEGA1281_) || defined (_CHIP_ATMEGA1281V_) ||\
      	defined (_CHIP_ATMEGA2560_) || defined (_CHIP_ATMEGA2560V_) ||\
      	defined (_CHIP_ATMEGA2561_) || defined (_CHIP_ATMEGA2561V_)
			#define SPM_ADDR_SIZE_FLASH_24BIT
#endif
#endif //	#ifndef _DOXYGEN_PARSER_


// ************************************************************************************************
/// @name Macro Definition
/// \brief 	Controller flash size parameters
//@{
#ifdef _DOXYGEN_PARSER_
		#define SPM_ADDR_SIZE_FLASH_24BIT
		#define SPM_ADDR_SIZE_FLASH_16BIT		
#endif
//@}
///	\def SPM_ADDR_SIZE_FLASH_24BIT
///		Makro depends on controller type (\ref auto "automatically set")<br/> 
///		Alternative: \ref SPM_ADDR_SIZE_FLASH_16BIT		
///
///	\def SPM_ADDR_SIZE_FLASH_16BIT
///		Makro depends on controller type (\ref auto "automatically set")<br/> 
///		Alternative: \ref SPM_ADDR_SIZE_FLASH_24BIT		
// ************************************************************************************************


#pragma used+
#ifdef SPM_ADDR_SIZE_FLASH_24BIT
	void    spm_erasepage_24(unsigned long addr);
	void    spm_programpage_24(unsigned long addr);
	void 	spm_readflash_24(unsigned char* p_sram, unsigned long addr, unsigned int size);
#endif

#ifdef SPM_ADDR_SIZE_FLASH_16BIT
	void    spm_erasepage_16(unsigned int addr);
	void    spm_programpage_16(unsigned int addr);
	void 	spm_readflash_16(unsigned char* p_sram, unsigned int addr, unsigned int size);
#endif

void    		spm_writeword(unsigned int addr, unsigned int data);
void    		spm_eewritebyte(unsigned int addr, unsigned char data);
void 			spm_eeread(unsigned char* p_sram, unsigned int addr);
void    		spm_writelockbits(unsigned char data);
unsigned char 	spm_readfuselockbits(unsigned int code);
#pragma used-

// ************************************************************************************************
/// @name Macro Definition
/// \brief 	Abstraction of flash access functions
//@{
#if defined (SPM_ADDR_SIZE_FLASH_24BIT)
	#define SPM_ERASEPAGE(addr)         		spm_erasepage_24(addr)
	#define	SPM_PROGRAMPAGE(addr)       		spm_programpage_24(addr)
	#define SPM_READFLASH(p_sram, addr, size)	spm_readflash_24(p_sram, addr, size)	
#elif defined (SPM_ADDR_SIZE_FLASH_16BIT) 
   	#define SPM_ERASEPAGE(addr)         		spm_erasepage_16((unsigned int)addr)
	#define	SPM_PROGRAMPAGE(addr)				spm_programpage_16((unsigned int)addr)
	#define	SPM_READFLASH(p_sram, addr, size)	spm_readflash_16(p_sram, (unsigned int)addr , size)
#endif
//@}
///	\def SPM_ERASEPAGE(addr)
///		Use this Makro instead of this functions:<br> 
///		- spm_erasepage_16() 
///		- spm_erasepage_24()
///
///	\def SPM_PROGRAMPAGE(addr)
///		Use this Makro instead of this functions:<br> 
///		- spm_programpage_16() 
///		- spm_programpage_24()
///
///	\def SPM_READFLASH(p_sram, addr, size)
///		Use this Makro instead of this functions:<br> 
///		- spm_readflash_16() 
///		- spm_readflash_24()
// ************************************************************************************************
#endif

/// @}
/// @}
