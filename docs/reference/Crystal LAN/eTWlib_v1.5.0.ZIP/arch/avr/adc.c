// ************************************************************************************************
///
/// \file 			adc.c
/// \brief			AVR internal analog-digital converter
///
/// \date	 		$LastChangedDate: 2007-04-05 17:44:32 +0200 (Do, 05 Apr 2007) $
/// \version 		$Rev: 662 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <io.h>
#include "adc.h"
#include "bitdefs.h"
#include "debug.h"

#ifdef ADC_ENABLE

// local prototypes
#pragma used+
void adc_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);
#pragma used-

// ************************************************************************************************
/// \brief		Registers the ADC debug handler
///
// ************************************************************************************************
void adc_init(void)
{
#ifdef ADC_DEBUG
T_DEBUG_HANDLER_STRUCT p_struct;
                      
p_struct.fp_handler = &adc_debug_handler;
p_struct.id_string = "adc";
debug_register_handler(&p_struct);
#endif
}

// ************************************************************************************************
/// \brief		Initialization of the ADC
///
///	@param [in]	cfg - see ADCSR_xxxx macros
///	@param [in]	ref - see ADMUX_REF_xxxx macros
// ************************************************************************************************
void adc_configure(unsigned char cfg, unsigned char ref)
{
// ADMUX_REF_EXT	enable external REF
// ADMUX_REF_AVCC	enable external REF from AVCC
// ADMUX_REF_256	enable internal REF (2.3V .. 2.7V)
ADMUX = ref;	 // see function adc_read_poll() overwrite with new channel
// ADCSR_ADEN	ADC Enable
// ADCSR_ADSC	ADC Start Conversion
// ADCSR_ADFR	ADC Free Running Select
// ADCSR_ADIF	ADC Interrupt Flag
// ADCSR_ADIE	ADC Interrupt Enable
// ADCSR_128	ADC Prescaler Selects Bits - XTAL/128
// ADCSR_64		ADC Prescaler Selects Bits - XTAL/64
// ADCSR_32		ADC Prescaler Selects Bits - XTAL/32
// ADCSR_16		ADC Prescaler Selects Bits - XTAL/16
// ADCSR_8		ADC Prescaler Selects Bits - XTAL/8
// ADCSR_4		ADC Prescaler Selects Bits - XTAL/4
// ADCSR_2		ADC Prescaler Selects Bits - XTAL/2
ADCSRA  = cfg;
ADCSRA |= ADCSR_ADIF;		// clear Pending ADC Interrupt Flag
}


#define ADC_START			SETBIT(ADCSRA, ADCSR_ADSC)
#define ADC_RUNNING			TSTBIT(ADCSRA, ADCSR_ADSC)
// ************************************************************************************************
/// \brief		ADC conversion with polling
///
///	@param[in]	channel number 0..7
/// @return		10-Bit AD value, right adjusted
// ************************************************************************************************
unsigned int adc_read_poll(unsigned char channel)
{
unsigned char admux_value;

while (ADC_RUNNING);			// wait until last conversation finished
admux_value = ADMUX & 0xe0;     // disable lower 5 bits
ADMUX = admux_value | channel;
ADC_START;
while (ADC_RUNNING);	// wait until conversation finished

return ADCW;
}


#ifdef ADC_DEBUG
// ************************************************************************************************
/// \brief		Command handler for incoming commands
///
/// @param[in] 	command	pointer to received string
// ************************************************************************************************
void adc_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
signed char  channel;
unsigned int ad_value;


if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-cfg", 2)==0)
		{
		adc_configure(ADCSR_ADEN | ADCSR_16, ADMUX_REF_AVCC);
		}
	if (strncmpf(command, "-read", 2)==0)
		{
		channel = debug_get_int_parameter(command);
		if (channel<0)
			channel = 0;
		ad_value = adc_read_poll(channel);
		printf("ADC Channel %u: %u\r\n", channel, ad_value);
		}
	}
}
#endif

#endif	// #ifdef ADC_ENABLE