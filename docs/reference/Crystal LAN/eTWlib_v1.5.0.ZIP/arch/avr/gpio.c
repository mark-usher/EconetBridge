// ************************************************************************************************
///
/// \file 			gpio.c
/// \brief			AVR GPIO module
///
///					The module provides a way of random access to the AVR general purpose I/Os.
///					The provided functions (which are in fact macros) are less code efficient than
///					the codevision specific '.' instruction (e.g. PORTA.0=1)
/// \date	 		$LastChangedDate: 2007-03-26 09:08:32 +0200 (Mo, 26 Mrz 2007) $
/// \version 		$Rev: 656 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#ifdef _DOXYGEN_PARSER_
#define GPIO_ENABLE
#define GPIO_DEBUG
#endif

#ifdef GPIO_ENABLE

#include <stdio.h>
#include <string.h>
#include "gpio.h"
#include "debug.h"

#if defined _CHIP_ATMEGA128_ || defined _CHIP_ATMEGA128L_
    #define GPIO_PORT_COUNT 7
    flash unsigned char gpio_pin_addr[GPIO_PORT_COUNT]={0x39, 0x36, 0x33, 0x30, 0x21, 0x20, 0x63};
    flash unsigned char gpio_ddr_addr[GPIO_PORT_COUNT]={0x3A, 0x37, 0x34, 0x31, 0x22, 0x61, 0x64};
    flash unsigned char gpio_port_addr[GPIO_PORT_COUNT]={0x3B, 0x38, 0x35, 0x32, 0x23, 0x62, 0x65};
// first 32 locations  - Register file
// next 64 location    - standard I/O memory
// next 160 locations  - extended I/O memory
// next 4096 locations - internal data RAM.
#elif defined _CHIP_ATMEGA32_ || defined _CHIP_ATMEGA32L_
    #define GPIO_PORT_COUNT 4
    flash unsigned char gpio_pin_addr[GPIO_PORT_COUNT]={0x39, 0x36, 0x33, 0x30};
    flash unsigned char gpio_ddr_addr[GPIO_PORT_COUNT]={0x3A, 0x37, 0x34, 0x31};
    flash unsigned char gpio_port_addr[GPIO_PORT_COUNT]={0x3B, 0x38, 0x35, 0x32};
#else
#error "UART: Controller is not supported yet"
#endif

#ifdef GPIO_DEBUG
// local prototype
void gpio_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);
#endif

// ************************************************************************************************
/// \brief		Initialize GPIO module.
///
// ************************************************************************************************
void gpio_init(void)
{
#ifdef GPIO_DEBUG
T_DEBUG_HANDLER_STRUCT p_struct;
                      
p_struct.fp_handler = &gpio_debug_handler;
p_struct.id_string = "gpio";
debug_register_handler(&p_struct);
#endif
}


#ifdef GPIO_DEBUG
// ************************************************************************************************
/// \brief		Command handler for incoming commands
///
/// @param[in] 	command	- pointer to received string
/// @param[in] 	mode	- see debug.h
// ************************************************************************************************
void gpio_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
unsigned char i;
unsigned char reg_value;
unsigned char act_port_char;

if (mode == DEBUG_HANDLER_MODE_INFO)
    {
    // add output for 'info' command here
    }                   
else if (mode == DEBUG_HANDLER_MODE_HELP)
    {
    // add output for 'help' command here
    }
else if (mode == DEBUG_HANDLER_MODE_SWITCH)
    {
    }
else if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-info", 5)==0)
		{
		for (i=0; i<GPIO_PORT_COUNT; i++)
		    {
		    act_port_char = 'A' + i;
        	printf("-%c-:\r\n", act_port_char);

        	reg_value = *(unsigned char*)gpio_ddr_addr[i];
    		printf("DDR%c: ", act_port_char);
    		debug_display_8bit_pattern(reg_value);
    		printf("\r\n");
		    
        	reg_value = *(unsigned char*)gpio_port_addr[i];
    		printf("PORT%c:", act_port_char);
    		debug_display_8bit_pattern(reg_value);
    		printf("\r\n");

        	reg_value = *(unsigned char*)gpio_pin_addr[i];
    		printf("PIN%c: ", act_port_char);
    		debug_display_8bit_pattern(reg_value);
    		printf("\r\n");
		    }
		}
	}
}
#endif	// #ifdef GPIO_DEBUG
#endif	// #ifdef GPIO_ENABLE