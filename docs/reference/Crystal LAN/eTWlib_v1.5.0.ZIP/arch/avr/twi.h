// ************************************************************************************************
///
/// \file 			twi.h
/// \brief			I2C interface (TWI)
/// 
/// \date	 		$LastChangedDate: 2007-03-13 15:08:25 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 632 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

/// \defgroup AVR_Driver
/// \addtogroup AVR_Driver
/// @{
/// \defgroup TWI
/// @{

#ifdef _DOXYGEN_PARSER_
// --------------------------------------------------------------------------------
/// @name 	Project.h Macros
/// 	  	The following macros can be defined in project.h to enable and 
///			configure this module. Some of them are mandatory and others are
///			optional. See description for details.
// --------------------------------------------------------------------------------
//@{
#define TWI_CVAVR_ENABLE
#define TWI_AVR_ENABLE
#define TWI_PORTA
#define TWI_SDA_BIT1
#define TWI_SCL_BIT0
//@}
#endif

///	\def TWI_CVAVR_ENABLE
///		This macro enables the I2C Interface in bit-bang mode. Codevision-internal assembler 
///		functions are used.
///
///	\def TWI_AVR_ENABLE
///		This macro enables the I2C Interface using AVR hardware interface.
///
///	\def TWI_PORTA
///		Specifies the port, that is used for the I2C signals. Both signals must use the same port.
///		Define TWI_PORTB for PORTB etc.
///
///	\def TWI_SDA_BIT1
///		Specifies the pin, that is used for the I2C serial data signal. Define TWI_SDA_BIT0 for Bit 0 etc.
///
///	\def TWI_SCL_BIT0
///		Specifies the pin, that is used for the I2C serial clock signal. Define TWI_SCL_BIT1 for Bit 1 etc.

#ifndef _TWI_INCLUDED_
#define _TWI_INCLUDED_

typedef enum  {
	TWI_ERR_OK=0,	///< transfer successful
	TWI_ERR_BUSY=1,	///< bus is busy. No start sign could be issued. Maybe the pullups are not active.
	TWI_ERR_NACK=2	///< device doesn't ack. Wrong address?
	} T_TWI_ERR;


#pragma used+
void 	  	  twi_init(void);
unsigned char twi_start(void);
unsigned char twi_write_byte(unsigned char data);
unsigned char twi_read_byte(unsigned char ack);
void 		  twi_stop(void);
T_TWI_ERR 	  twi_write_msg(unsigned char addr, unsigned char len, unsigned char* buf);
T_TWI_ERR 	  twi_read_msg(unsigned char addr, unsigned char len, unsigned char* buf);
#pragma used-

#ifdef COMMON_LIBRARY_ENABLE
	#pragma library twi_core.c
	#ifdef TWI_CVAVR_ENABLE
		#pragma library twi_cvavr.c
	#endif
	#ifdef TWI_AVR_ENABLE
		#pragma library twi_avr.c
	#endif
#endif

#endif	// #ifdef TWI_ENABLE
