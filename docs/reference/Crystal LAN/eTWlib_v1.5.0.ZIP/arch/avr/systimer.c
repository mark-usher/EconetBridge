// ************************************************************************************************
///
/// \file 			systimer.c
/// \brief			Provides hardware based timebase
///
///					Supported Chips so far:<br>
///					ATmega128 ->tested<br>
///					ATmega64		<br>
///					ATmega32->tested<br>
///					ATmega8			<br>
/// \todo			Add possibility to clock systimer with 32768 Hz quarz
/// \todo			More testing. This module is EXPERIMENTAL
/// \date	 		$LastChangedDate: 2007-08-13 18:41:59 +0200 (Mo, 13 Aug 2007) $
/// \version 		$Rev: 676 $
///	\author  		Carsten K�gler, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br>
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef _DOXYGEN_PARSER_
#define SYSTIMER_ENABLE
#endif

#ifdef SYSTIMER_ENABLE

#include <io.h>
#include <string.h>
#include "systimer.h"

typedef void (*SYSTIMER_FP)(void);

#ifndef SYSTIMER_ISR_HOOK_MAX
#define SYSTIMER_ISR_HOOK_MAX   2
#endif

#pragma regalloc-
volatile unsigned int systimer_cnt;    						///< counter with variable resolution
volatile SYSTIMER_FP  systimer_isr_hook[SYSTIMER_ISR_HOOK_MAX]; ///< array of function pointer
#pragma regalloc+

#if defined _CHIP_ATMEGA128_ | defined _CHIP_ATMEGA128L_ | \
	defined _CHIP_ATMEGA64_ | defined _CHIP_ATMEGA64L_ 
	#define SYSTIMER_TIM0_EXIST
	#define SYSTIMER_TIM0_IS_8BIT_ASYNCHRON
	#define SYSTIMER_TIM1_EXIST
	#define SYSTIMER_TIM1_IS_16BIT
	#define SYSTIMER_TIM2_EXIST
	#define SYSTIMER_TIM2_IS_8BIT
	#define SYSTIMER_TIM3_EXIST
	#define SYSTIMER_TIM3_IS_16BIT
#elif defined _CHIP_ATMEGA32_ | defined _CHIP_ATMEGA32L_ | \
	  defined _CHIP_ATMEGA8_ | defined _CHIP_ATMEGA8L_
	#define SYSTIMER_TIM0_EXIST
	#define SYSTIMER_TIM0_IS_8BIT
	#define SYSTIMER_TIM1_EXIST
	#define SYSTIMER_TIM1_IS_16BIT
	#define SYSTIMER_TIM2_EXIST
	#define SYSTIMER_TIM2_IS_8BIT_ASYNCHRON
#endif

#if defined SYSTIMER_SOURCE_TIM0 && defined SYSTIMER_TIM0_EXIST
	#define SYSTIMER_8BIT_TIMER				///< TIM0 is always 8 Bit on the supported chips
	#ifdef SYSTIMER_TIM0_IS_8BIT_ASYNCHRON
		#define SYSTIMER_8BIT_PRESCALE1			///< asynchronous timers need these settings
	#else
		#define SYSTIMER_8BIT_PRESCALE2			///< synchronous timers need these settings
	#endif
	#define SYSTIMER_INT_VECTOR		TIM0_COMP	///< interupt vector for system timer
	#define SYSTIMER_TCNT_READ		TCNT0		///< read hardware timer value
	#define SYSTIMER_TCNT_WRITE(a)	TCNT0=a		///< write hardware timer value
	#define SYSTIMER_OCR_READ		OCR0		///< read output compare register
	#define SYSTIMER_OCR_WRITE(a)	OCR0=a		///< write output compare register
	#define SYSTIMER_TCCR			TCCR0		///< hardware timer control register
	#define SYSTIMER_INT_ON			TIMSK|=0x02	///< enable system timer interrupt
	#define SYSTIMER_INT_OFF		TIMSK&=~0x02///< disable system timer interrupt
	#define SYSTIMER_CLR_INT_FLAG	TIFR|=0x02	///< clear system timer interrupt flag
#elif defined SYSTIMER_SOURCE_TIM1 && defined SYSTIMER_TIM1_EXIST
	#define SYSTIMER_16BIT_TIMER
	#define SYSTIMER_INT_VECTOR		TIM1_COMPA
	#define SYSTIMER_TCNT_READ		(TCNT1L|((unsigned int)TCNT1H<<8))
	#define SYSTIMER_TCNT_WRITE(a)	(TCNT1H=(a>>8),TCNT1L=(a&0xff))
	#define SYSTIMER_OCR_READ		(OCR1AL|((unsigned int)OCR1AH<<8))
	#define SYSTIMER_OCR_WRITE(a)	(OCR1AH=(a>>8),OCR1AL=(a&0xff))
	#define SYSTIMER_TCCR			TCCR1B
	#define SYSTIMER_INT_ON			TIMSK|=0x10
	#define SYSTIMER_INT_OFF		TIMSK&=~0x10
	#define SYSTIMER_CLR_INT_FLAG	TIFR|=0x10
#elif defined SYSTIMER_SOURCE_TIM2 && defined SYSTIMER_TIM2_EXIST
	#define SYSTIMER_8BIT_TIMER
	#ifdef SYSTIMER_TIM2_IS_8BIT_ASYNCHRON
		#define SYSTIMER_8BIT_PRESCALE1
	#else
		#define SYSTIMER_8BIT_PRESCALE2
	#endif
	#define SYSTIMER_INT_VECTOR		TIM2_COMP
	#define SYSTIMER_TCNT_READ		TCNT2
	#define SYSTIMER_TCNT_WRITE(a)	TCNT2=a
	#define SYSTIMER_OCR_READ		OCR2
	#define SYSTIMER_OCR_WRITE(a)	OCR2=a
	#define SYSTIMER_TCCR			TCCR2
	#define SYSTIMER_INT_ON			TIMSK|=0x80
	#define SYSTIMER_INT_OFF		TIMSK&=~0x80
	#define SYSTIMER_CLR_INT_FLAG	TIFR|=0x80
#elif defined SYSTIMER_SOURCE_TIM3 && defined SYSTIMER_TIM3_EXIST	
	#define SYSTIMER_16BIT_TIMER
	#define SYSTIMER_INT_VECTOR		TIM3_COMPA
	#define SYSTIMER_TCNT_READ		(TCNT3L|((unsigned int)TCNT3H<<8))
	#define SYSTIMER_TCNT_WRITE(a)	(TCNT3H=(a>>8),TCNT3L=(a&0xff))
	#define SYSTIMER_OCR_READ		(OCR3AL|((unsigned int)OCR3AH<<8))
	#define SYSTIMER_OCR_WRITE(a)	(OCR3AH=(a>>8),OCR3AL=(a&0xff))
	#define SYSTIMER_TCCR			TCCR3B
	#define SYSTIMER_INT_ON			ETIMSK|=0x10
	#define SYSTIMER_INT_OFF		ETIMSK&=~0x10
	#define SYSTIMER_CLR_INT_FLAG	ETIFR|=0x10
#else
	#error "Define an existing timer with SYSTIMER_SOURCE_TIMx"
#endif
	
#ifdef SYSTIMER_16BIT_TIMER
	#define	SYSTIMER_PRESCALE			8			///< Hardware Timer Prescale
#endif

// 8-Bit timers have reduced resolution!
// we have to look at:
// - output compare value can be max. 256
// - error increases with smaller output compare values
#ifdef SYSTIMER_8BIT_TIMER
	#ifdef SYSTIMER_CYCLE_10MS
		#define	SYSTIMER_PRESCALE		1024
	#else
		#define	SYSTIMER_PRESCALE		256
	#endif
#endif

#define	SYSTIMER_OC_TICS_10MS	_MCU_CLOCK_FREQUENCY_/(100*SYSTIMER_PRESCALE)
// Examples:
// 20.000 with 	Divider=8; XTAL=16 MHz
// 2500 with 	Divider=64; XTAL=16 MHz
// 625 with 	Divider=256; XTAL=16 MHz
// 156,25 with 	Divider=1024; XTAL=16 MHz
// 78,125 with	Divider=1024; XTAL=8 MHz

#ifdef SYSTIMER_CYCLE_10MS
#define SYSTIMER_OC_TICS		SYSTIMER_OC_TICS_10MS		///< HW Timer Tics between Interrupts
#else
#define SYSTIMER_OC_TICS		SYSTIMER_OC_TICS_10MS/10
#endif


// there are 2 different assignments between timer prescaler and register settings
#if defined(SYSTIMER_8BIT_PRESCALE2) || defined(SYSTIMER_16BIT_TIMER) 
	#if   (SYSTIMER_PRESCALE==1)
		#define	SYSTIMER_PRESC_BITS		1
	#elif (SYSTIMER_PRESCALE==8)
		#define	SYSTIMER_PRESC_BITS		2
	#elif (SYSTIMER_PRESCALE==64)
		#define	SYSTIMER_PRESC_BITS		3
	#elif (SYSTIMER_PRESCALE==256)
		#define	SYSTIMER_PRESC_BITS		4
	#elif (SYSTIMER_PRESCALE==1024)
		#define	SYSTIMER_PRESC_BITS		5
	#endif
#elif defined(SYSTIMER_8BIT_PRESCALE1)
	#if   (SYSTIMER_PRESCALE==1)
		#define	SYSTIMER_PRESC_BITS		1
	#elif (SYSTIMER_PRESCALE==8)
		#define	SYSTIMER_PRESC_BITS		2
	#elif (SYSTIMER_PRESCALE==32)
		#define	SYSTIMER_PRESC_BITS		3
	#elif (SYSTIMER_PRESCALE==64)
		#define	SYSTIMER_PRESC_BITS		4
	#elif (SYSTIMER_PRESCALE==128)
		#define	SYSTIMER_PRESC_BITS		5
	#elif (SYSTIMER_PRESCALE==256)
		#define	SYSTIMER_PRESC_BITS		6
	#elif (SYSTIMER_PRESCALE==1024)
		#define	SYSTIMER_PRESC_BITS		7
	#endif
#endif
// ************************************************************************************************
/// \brief		Initialization of System Timer.
///
/// \note		1 hardware Timer Tick = SYSTIMER_PRESCALE/XTAL (500ns for Divider=8; XTAL=16 MHz)
///         	16-Bit-Timer overflows after ca. 33 ms with this setting.
// ************************************************************************************************
void systimer_init(void)
{
unsigned char i;

SYSTIMER_TCCR = 0;				        // Stop Timer
SYSTIMER_TCNT_WRITE(0);
SYSTIMER_OCR_WRITE(SYSTIMER_OC_TICS);
SYSTIMER_INT_ON;                     	// enable "Timer/Counter1 Output Compare A Match Interrupt Enable"
SYSTIMER_CLR_INT_FLAG;					// clear Interrupt Flag "Timer/Counter1 Output CompareA Match Flag"
SYSTIMER_TCCR = SYSTIMER_PRESC_BITS;	// Set Prescale and Start Timer
//printf("SYSTIMER_OC_TICS: %1u\r\n", SYSTIMER_OC_TICS);
//printf("SYSTIMER_PRESC_BITS: %1u\r\n", SYSTIMER_PRESC_BITS);
//printf("SYSTIMER_PRESCALE: %1u\r\n", SYSTIMER_PRESCALE);
for (i=0; i<SYSTIMER_ISR_HOOK_MAX; i++)
    systimer_isr_hook[i] = 0;
}


// ************************************************************************************************
/// \brief		Interrupt increases the 'systimer_cnt' and calls hook functions
///
// ************************************************************************************************
interrupt [SYSTIMER_INT_VECTOR] void systimer_isr(void)
{
unsigned char i;

SYSTIMER_OCR_WRITE(SYSTIMER_OCR_READ + SYSTIMER_OC_TICS);
systimer_cnt++;
for (i=0; i<SYSTIMER_ISR_HOOK_MAX; i++)
    if (systimer_isr_hook[i] != 0)
        systimer_isr_hook[i]();
}


// ************************************************************************************************
/// \brief		register interrupt hook function called in isr
///
/// @retval		0 - Function registered
/// @retval		1 - error
// ************************************************************************************************
unsigned char systimer_register_isr_hook(void (*fp)(void))
{
unsigned char i;

for (i=0; i<SYSTIMER_ISR_HOOK_MAX; i++)
    if (systimer_isr_hook[i] == 0)
        {
        systimer_isr_hook[i] = fp;
        return 0;
        }
return 1;
}


// ************************************************************************************************
/// \brief		Measuring a time interval
/// \note		Resets hardware and system timer
// ************************************************************************************************
void systimer_tic(void)
{
SYSTIMER_TCCR = 0; 				                            // stop timer
SYSTIMER_OCR_WRITE(SYSTIMER_OCR_READ - SYSTIMER_TCNT_READ); // tics until next interrupt
SYSTIMER_TCNT_WRITE(0);					                    // reset hardware timer
systimer_cnt = 0;
SYSTIMER_TCCR = SYSTIMER_PRESC_BITS;						// Set Prescale and Start Timer
}


#define SYS_HWTIMER_TICS_2_US(hw_tics)	(hw_tics/2)
// ************************************************************************************************
/// \brief		Measuring a time interval
///
///	\todo		Measure minimum time interval
/// @return		Time interval in us. Depends only on hardware timer granularity.
// ************************************************************************************************
unsigned long systimer_tac(void)
{
unsigned int tics_to_next_isr;
unsigned int syscounter_temp;

SYSTIMER_TCCR = 0; 					    // stop timer
tics_to_next_isr = SYSTIMER_OCR_READ-SYSTIMER_TCNT_READ;
syscounter_temp = systimer_cnt;
SYSTIMER_TCCR = SYSTIMER_PRESC_BITS;	// Set Prescale and Start Timer
return SYS_TICS2MS((unsigned long)syscounter_temp)*1000 + SYS_HWTIMER_TICS_2_US(tics_to_next_isr);
}

#endif	// #ifdef SYSTIMER_ENABLE
