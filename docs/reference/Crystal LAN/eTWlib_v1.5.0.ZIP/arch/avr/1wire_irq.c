// ************************************************************************************************
///
/// \file 			1wire_irq.c
/// \brief			1Wire functions with IRQ-Flag
///
/// \date	 		$LastChangedDate: 2007-01-09 16:44:42 +0100 (Di, 09 Jan 2007) $
/// \version 		$Rev: 459 $
/// \todo			revise whole module. Create generic 1-wire module
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include "1wire_irq.h"

#ifdef WIRE_IRQ

// ********************************************************************************
// Description	: this function initializes the 1 Wire devices on the bus.
// Input	   	: none
// Output      	: 1.) return==0x00 - 1wire device not present
//				      return==0x01 - 1wire device found
// Indication	: 1Wire-Level
// *********************************************************************************
unsigned char w1_init_irq(void)
{
unsigned char Lva;
unsigned char sreg;
sreg=SREG;
#asm("cli");
Lva=w1_init();
SREG=sreg;
return Lva;
}


// ********************************************************************************
// Description	: this function reads a byte from the 1 Wire bus.
// Input	   	: none
// Output      	: 1.) data of 1wire device
// Indication	: check with "W1_INIT" wether 1wire device is present
// 				  1Wire-Level
// *********************************************************************************
unsigned char w1_read_irq(void)
{
unsigned char Lva;
unsigned char sreg;
sreg=SREG;
#asm("cli");
Lva=w1_read();
SREG=sreg;
return Lva;
}


// ********************************************************************************
// Description	: this function writes the byte data to the 1 Wire bus.
// Input	   	: 1.) data - data to 1wire device
// Output      	: 1.) return==0x00 - 1wire write not ok
//				      return==0x01 - 1wire write ok
// Indication	: check with "W1_INIT" wether 1wire device is present
// 				  1Wire-Level
// *********************************************************************************
unsigned char w1_write_irq(unsigned char data)
{
unsigned char Lva;
unsigned char sreg;
sreg=SREG;
#asm("cli");
Lva=w1_write(data);
SREG=sreg;
return Lva;
}

#endif	// #ifdef WIRE_IRQ