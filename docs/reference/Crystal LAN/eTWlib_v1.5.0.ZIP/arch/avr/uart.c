// ************************************************************************************************
///
/// \file 			uart.c
/// \brief			Interfacing AVR internal UARTs
///
///					The UART module provides an flexible UART interface with buffer functions. 
///					It can be configured by various compiler macros in project.h.
///					It can work in interrupt and polling mode
///					Supported Chips so far:<br>
///					ATmega128 ->tested<br>
///					ATmega161		 <br>
///					ATmega64		 <br>
///					ATmega8535       <br>
///					ATmega32 ->tested<br>
///					ATmega8			 <br>
///
/// \date	 		$LastChangedDate: 2007-03-26 09:07:13 +0200 (Mo, 26 Mrz 2007) $
/// \version 		$Rev: 655 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#ifdef _DOXYGEN_PARSER_
#define UART_ENABLE
#endif

#ifdef UART_ENABLE

#include <io.h>
#include <stdio.h>
#include <string.h>
#include <delay.h>
#include "uart.h"
#include "debug.h"
#include "bitdefs.h"

// ---------------------------------------------------------------------------
// UART Buffer structure
// ---------------------------------------------------------------------------
typedef struct{
	unsigned char*			rbuffer;			// read data buffer
	UART_RX_VAR_TYPE	    rtop;				// read top pointer
	UART_RX_VAR_TYPE	    rbottom;			// read bottom pointer
	UART_RX_VAR_TYPE	    rgap;				// read gap
	unsigned char*			wbuffer;			// write data buffer
	UART_TX_VAR_TYPE  		wtop;				// write top pointer
	UART_TX_VAR_TYPE	    wbottom;	  		// write bottom pointer
	UART_TX_VAR_TYPE 		wgap;				// write gap
	unsigned char* 			p_ucsra;
	unsigned char* 			p_ucsrb;
	unsigned char* 			p_ucsrc;
	unsigned char* 			p_udr;
	unsigned char* 			p_ubrrh;
	unsigned char* 			p_ubrrl;
#ifdef UART_PARSE_CHAR
	unsigned char			parse_counter;
#endif
#ifdef UART_STATISTIC_ENABLE
    UART_STAT_STRUCT  		stat;
#endif
} UART_BUFFER;


// ---------------------------------------------------------------------------
// Count activated UART devices
// ---------------------------------------------------------------------------
#if defined(UART_DEVICE0_ENABLE) && defined(UART_DEVICE1_ENABLE)
	#define UART_DEV_USABLE		2
#else
	#define UART_DEV_USABLE		1
#endif

// ---------------------------------------------------------------------------
// Global variables
// ---------------------------------------------------------------------------
#pragma regalloc-
unsigned char	uart_rx_buffer[UART_DEV_USABLE][UART_RX_BUFFER_SIZE];
unsigned char	uart_tx_buffer[UART_DEV_USABLE][UART_TX_BUFFER_SIZE];
UART_BUFFER		uart_buffer[UART_DEV_USABLE];
#pragma regalloc+


// ---------------------------------------------------------------------------
// macros for chip-independend register access
// ---------------------------------------------------------------------------
#if   defined _CHIP_ATMEGA128_ || defined _CHIP_ATMEGA128L_ || \
      defined _CHIP_ATMEGA64_  || defined _CHIP_ATMEGA64L_
	#define UART_UCSRA_ADDRESS		{0x2b, 0x9b}
	#define UART_UCSRB_ADDRESS		{0x2a, 0x9a}
	#define UART_UCSRC_ADDRESS		{0x95, 0x9d}
	#define UART_UDR_ADDRESS		{0x2c, 0x9c}
	#define UART_UBRRH_ADDRESS		{0x90, 0x98}
	#define UART_UBRRL_ADDRESS		{0x29, 0x99}
	#define UART_DEV_COUNT			2
	#define UART_DBLSPEED_SUPPORT
	#define UART_RXC0_IRQ_NO		USART0_RXC
	#define UART_DRE0_IRQ_NO		USART0_DRE
	#define UART_TXC0_IRQ_NO		USART0_TXC
	#define UART_RXC1_IRQ_NO		USART1_RXC
	#define UART_DRE1_IRQ_NO		USART1_DRE
	#define UART_TXC1_IRQ_NO		USART1_TXC
#elif defined _CHIP_ATMEGA161_ || defined _CHIP_ATMEGA161L_
	#define UART_UCSRA_ADDRESS		{0x2b, 0x22}
	#define UART_UCSRB_ADDRESS		{0x2a, 0x21}
	#define UART_UCSRC_ADDRESS		{0,0}
	#define UART_UDR_ADDRESS		{0x2c, 0x23}
	#define UART_UBRRH_ADDRESS		{0,0}
	#define UART_UBRRL_ADDRESS		{0x29, 0x20}
	#define UART_DEV_COUNT			2
	#define UART_DBLSPEED_SUPPORT
	#define UART_RXC0_IRQ_NO		UART0_RXC
	#define UART_DRE0_IRQ_NO		UART0_DRE
	#define UART_TXC0_IRQ_NO		UART0_TXC
	#define UART_RXC1_IRQ_NO		UART1_RXC
	#define UART_DRE1_IRQ_NO		UART1_DRE
	#define UART_TXC1_IRQ_NO		UART1_TXC
#elif defined _CHIP_ATMEGA8_ || defined _CHIP_ATMEGA8L_ || \
	  defined _CHIP_ATMEGA8535_ || defined _CHIP_ATMEGA8535L_ ||\
	  defined _CHIP_ATMEGA32_ || defined _CHIP_ATMEGA32L_
	#define UART_UCSRA_ADDRESS		{0x2b}
	#define UART_UCSRB_ADDRESS		{0x2a}
	#define UART_UCSRC_ADDRESS		{0x40}
	#define UART_UDR_ADDRESS		{0x2c}
	#define UART_UBRRH_ADDRESS		{0x40}
	#define UART_UBRRL_ADDRESS		{0x29}
	#define UART_DEV_COUNT			1
	#define UART_SHARED_REGISTER
	#define UART_DBLSPEED_SUPPORT
	#define UART_RXC0_IRQ_NO		USART_RXC
	#define UART_DRE0_IRQ_NO		USART_DRE
	#define UART_TXC0_IRQ_NO		USART_TXC
#else
#error "UART: Controller is not supported yet"
#endif

unsigned char* flash uart_reg_ucsra[UART_DEV_COUNT] = UART_UCSRA_ADDRESS;
unsigned char* flash uart_reg_ucsrb[UART_DEV_COUNT] = UART_UCSRB_ADDRESS;
unsigned char* flash uart_reg_ucsrc[UART_DEV_COUNT] = UART_UCSRC_ADDRESS;
unsigned char* flash uart_reg_udr[UART_DEV_COUNT]   = UART_UDR_ADDRESS;
unsigned char* flash uart_reg_ubrrh[UART_DEV_COUNT] = UART_UBRRH_ADDRESS;
unsigned char* flash uart_reg_ubrrl[UART_DEV_COUNT] = UART_UBRRL_ADDRESS;

#define UART_UCSRA(uart_dev)		*(uart_buffer[uart_dev].p_ucsra)
#define UART_UCSRB(uart_dev)		*(uart_buffer[uart_dev].p_ucsrb)
#define UART_UCSRC(uart_dev)		*(uart_buffer[uart_dev].p_ucsrc)
#define UART_UDR(uart_dev)			*(uart_buffer[uart_dev].p_udr)
#define UART_UBRRH(uart_dev)		*(uart_buffer[uart_dev].p_ubrrh)
#define UART_UBRRL(uart_dev)		*(uart_buffer[uart_dev].p_ubrrl)


// ---------------------------------------------------------------------------
// macros for commonly used register access
// ---------------------------------------------------------------------------
#define UART_RXC_INT_ON(dev)		SETBIT(UART_UCSRB(dev), BIT7)	// enable Receive-Interrupt
#define UART_RXC_INT_OFF(dev)		CLRBIT(UART_UCSRB(dev), BIT7)	// disable Receive-Interrupt
#define UART_RXC_INT_STATE(dev)		TSTBIT(UART_UCSRB(dev), BIT7)	// status of Receive-Interrupt
#define UART_DRE_INT_ON(dev)		SETBIT(UART_UCSRB(dev), BIT5)	// enable Empty-Interrupt
#define UART_DRE_INT_OFF(dev)		CLRBIT(UART_UCSRB(dev), BIT5)	// disable Empty-Interrupt
#define UART_DRE_INT_STATE(dev)		TSTBIT(UART_UCSRB(dev), BIT5)	// status of Empty-Interrupt
#define UART_TXC_INT_ON(dev)		SETBIT(UART_UCSRB(dev), BIT6)	// enable TXC-Interrupt
#define UART_TXC_INT_OFF(dev)		CLRBIT(UART_UCSRB(dev), BIT6)	// disable TXC-Interrupt
#define UART_RX_ENABLE(dev)			SETBIT(UART_UCSRB(dev), BIT4)	// enable Receive
#define UART_RX_DISABLE(dev)		CLRBIT(UART_UCSRB(dev), BIT4)	// disable Receive
#define UART_TX_ENABLE(dev)			SETBIT(UART_UCSRB(dev), BIT3)	// enable Transmit
#define UART_TX_DISABLE(dev)		CLRBIT(UART_UCSRB(dev), BIT3)	// disable Transmit
#define UART_RXC_BIT(dev)			TSTBIT(UART_UCSRA(dev), BIT7)	// UART Receive Complete
#define UART_UDRE_BIT(dev)			TSTBIT(UART_UCSRA(dev), BIT5)	// UART Data Register Empty
#define UART_ERROR_BITS(dev)		UART_UCSRA(dev)
#define UART_DATA_READ(dev)			UART_UDR(dev) 	        		// reads data from UART
#define UART_DATA_WRITE(dev,x)		UART_UDR(dev)=x 	        	// writes data to UART


// ---------------------------------------------------------------------------
// Error bit macros
// ---------------------------------------------------------------------------
#define UART_RECEIVE_FE				0x10	// Receive Frame Error
#define UART_RECEIVE_DOR			0x08	// Receive Data OverRun
#define UART_RECEIVE_UPE			0x04	// Receive Parity Error


// ---------------------------------------------------------------------------
// check for wrong configuration
// ---------------------------------------------------------------------------
#if (UART_DEV_COUNT==1) && defined (UART_DEVICE2_ENABLE)
#error "UART: Chip has no second UART"
#endif

// prototype
void uart_debug_init(void);

// *********************************************************************************
/// \brief		Initialize uart module
///
// *********************************************************************************
void uart_init(void)
{
#ifdef UART_DEBUG
uart_debug_init();
#endif

#ifdef UART_DEVICE0_ENABLE
	uart_buffer[UART_DEV0].p_ucsra = uart_reg_ucsra[0];
	uart_buffer[UART_DEV0].p_ucsrb = uart_reg_ucsrb[0];
	uart_buffer[UART_DEV0].p_ucsrc = uart_reg_ucsrc[0];
	uart_buffer[UART_DEV0].p_udr   = uart_reg_udr[0];
	uart_buffer[UART_DEV0].p_ubrrh = uart_reg_ubrrh[0];
	uart_buffer[UART_DEV0].p_ubrrl = uart_reg_ubrrl[0];
	uart_buffer[UART_DEV0].rbuffer = &uart_rx_buffer[UART_DEV0][0];	// rbuffer
	uart_buffer[UART_DEV0].wbuffer = &uart_tx_buffer[UART_DEV0][0];	// wbuffer
	uart_clear_buffer(UART_DEV0);

	UART_UCSRA(UART_DEV0) = 0x00;	// reset UART status
	UART_UCSRB(UART_DEV0) = 0x00;	// reset UART status
	// Standard initialization:
	// UART Parameters: 8 Data, 1 Stop, No Parity
	// UART Receiver/Transmitter: On
	// UART Double Speed enable
	// UART Interrupt mode if selected via macro
	// UART Baudrate, see UART_DEFAULT_BAUDRATE
	uart_configure(UART_DEV0, UART_CFG_SETDBLSPEED, 1);
	uart_set_baudrate(UART_DEV0, UART_DEFAULT_BAUDRATE);	// enables receiver&transmitter
	#ifdef UART_RS485_DEV0_ENABLE
	UART_RS485_DEV0_TX_OFF;
	UART_RS485_DEV0_ACTIVE;
	#endif
#endif
#ifdef UART_DEVICE1_ENABLE
	uart_buffer[UART_DEV1].p_ucsra = uart_reg_ucsra[1];
	uart_buffer[UART_DEV1].p_ucsrb = uart_reg_ucsrb[1];
	uart_buffer[UART_DEV1].p_ucsrc = uart_reg_ucsrc[1];
	uart_buffer[UART_DEV1].p_udr   = uart_reg_udr[1];
	uart_buffer[UART_DEV1].p_ubrrh = uart_reg_ubrrh[1];
	uart_buffer[UART_DEV1].p_ubrrl = uart_reg_ubrrl[1];
	uart_buffer[UART_DEV1].rbuffer = &uart_rx_buffer[UART_DEV1][0];	// rbuffer
	uart_buffer[UART_DEV1].wbuffer = &uart_tx_buffer[UART_DEV1][0];	// wbuffer
	uart_clear_buffer(UART_DEV1);

	UART_UCSRA(UART_DEV1) = 0x00;	// reset UART status
	UART_UCSRB(UART_DEV1) = 0x00;	// reset UART status
	// Standard initialization:
	// UART Parameters: 8 Data, 1 Stop, No Parity
	// UART Receiver/Transmitter: On
	// UART Double Speed enable
	// UART Interrupt mode if selected via macro
	// UART Baudrate, see UART_DEFAULT_BAUDRATE
	uart_configure(UART_DEV1, UART_CFG_SETDBLSPEED, 1);
	uart_set_baudrate(UART_DEV1, UART_DEFAULT_BAUDRATE);	// enables receiver&transmitter
	#ifdef UART_RS485_DEV1_ENABLE
	UART_RS485_DEV1_TX_OFF;
	UART_RS485_DEV1_ACTIVE;
	#endif
#endif
}


// *********************************************************************************
/// \brief		Clears all buffer of UART-interface
/// @param[in]	dev_id	- UART-ID, see UART_DEV_ENUM
// *********************************************************************************
void uart_clear_rx_buffer(UART_DEV_ENUM dev_id)
{
uart_buffer[dev_id].rtop = 0;
uart_buffer[dev_id].rbottom = 0;
uart_buffer[dev_id].rgap = UART_RX_BUFFER_SIZE;
#ifdef UART_PARSE_CHAR
uart_buffer[dev_id].parse_counter = 0;
#endif
}


// *********************************************************************************
/// \brief		Clears all buffer of UART-interface
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
// *********************************************************************************
void uart_clear_tx_buffer(UART_DEV_ENUM dev_id)
{
uart_buffer[dev_id].wtop = 0;
uart_buffer[dev_id].wbottom = 0;
uart_buffer[dev_id].wgap = UART_TX_BUFFER_SIZE;
}


// *********************************************************************************
/// \brief		Clears all buffer of UART-interface
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
// *********************************************************************************
void uart_clear_buffer(UART_DEV_ENUM dev_id)
{
uart_clear_tx_buffer(dev_id);
uart_clear_rx_buffer(dev_id);
}


// *********************************************************************************
/// \brief		Disables UART interface
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
// *********************************************************************************
void uart_disable(UART_DEV_ENUM dev_id)
{
// Disable UART interrupts
#ifdef UART_MODE_IRQ
UART_RXC_INT_OFF(dev_id);
UART_DRE_INT_OFF(dev_id);
#endif

// Allow incoming or outgoing character to finish
// \todo this section should be based on register polling
delay_us(10);

// Now disable UART functions
UART_RX_DISABLE(dev_id);
UART_TX_DISABLE(dev_id);
}


// *********************************************************************************
/// \brief		Enables UART interface
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
// *********************************************************************************
void uart_enable(UART_DEV_ENUM dev_id)
{
// Enable UART interrupts
#ifdef UART_MODE_IRQ
UART_RXC_INT_ON(dev_id);
if (uart_buffer[dev_id].wgap < UART_TX_BUFFER_SIZE)
	UART_DRE_INT_ON(dev_id);
#endif

// Now enable UART functions
UART_RX_ENABLE(dev_id);
UART_TX_ENABLE(dev_id);
}


// *********************************************************************************
/// \brief		Writes value in Baudrate register
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
/// @param[in]	baudrate - baudrate
// *********************************************************************************
void uart_set_baudrate(UART_DEV_ENUM dev_id, unsigned long baudrate)
{
unsigned int ubrr_value;

uart_disable(dev_id);

#ifdef UART_DBLSPEED_SUPPORT
if (TSTBIT(UART_UCSRA(dev_id), BIT1))
    baudrate <<= 2;
else
    baudrate <<= 3;
#else
baudrate <<= 3;
#endif
ubrr_value = ((_MCU_CLOCK_FREQUENCY_ / baudrate + 1) / 2) - 1;

if (uart_buffer[dev_id].p_ubrrh == 0x00)  // no UBRRH available (e.g. ATmega161)
    UART_UBRRL(dev_id) = ubrr_value & 0xff;
else
    {
    // with some chips, UBRRH and UCSRC share the same memory location.
    // To be sure to write to UBRRH, we set the higest bit to zero
    // (UBRR is an 12 Bit value anyway)
    UART_UBRRH(dev_id) = (ubrr_value>>8) & 0x7F;
    UART_UBRRL(dev_id) = ubrr_value & 0xff;     // write low byte first
    // Datasheet: Writing UBRRnL will trigger an immediate update
    // of the baud rate prescaler. So we write UBRRH first.
    }

uart_enable(dev_id);
}


// *********************************************************************************
/// \brief		Reads value from Baudrate register
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
/// @return	    baudrate value
// *********************************************************************************
unsigned long uart_get_baudrate(UART_DEV_ENUM dev_id)
{
unsigned int ubrr_value;
unsigned long baudrate;

if (uart_buffer[dev_id].p_ubrrh == 0x00)  // no UBRRH available (e.g. ATmega161)
    ubrr_value = UART_UBRRL(dev_id);
else
    {
    // if UBRRH and UCSRC share the same memory location, read access is managed
    // by an timed sequence. When the memory location is read once, UBRRH is returned
    // So we don't have to do something special here.
    ubrr_value = UART_UBRRL(dev_id);
    ubrr_value |= (unsigned int)UART_UBRRH(dev_id) << 8;
    }

baudrate = ubrr_value + 1;
#ifdef UART_DBLSPEED_SUPPORT
if (TSTBIT(UART_UCSRA(dev_id), BIT1))
    baudrate <<= 3;
else
    baudrate <<= 4;
#else
baudrate <<= 4;
#endif
baudrate = _MCU_CLOCK_FREQUENCY_ / baudrate;

return baudrate;
}


// *********************************************************************************
/// \brief	    Configure UART
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
/// @param[in]	cmd    - what should be configured. see mode UART_CFG_CMD_ENUM
/// @param[in]	param  - parameter value, see UART_CFG_DATABITS, UART_CFG_PARITY and
///						 UART_CFG_STOPBITS, depending on variable cmd
/// @return	 	requested value, if read command, otherwise 0
// *********************************************************************************
unsigned char uart_configure(UART_DEV_ENUM dev_id, UART_CFG_CMD_ENUM cmd, unsigned char param)
{
unsigned char retval_u8=0;

switch (cmd)
    {
    case UART_CFG_SETDBLSPEED:
    	if (param)
			SETBIT(UART_UCSRA(dev_id), BIT1);
		else
			CLRBIT(UART_UCSRA(dev_id), BIT1);
        break;
    case UART_CFG_GETDBLSPEED:
    	if (TSTBIT(UART_UCSRA(dev_id), BIT1))
    		return 1;
    	else
    		return 0;
        break;
    case UART_CFG_SETDATABITS:
        switch (param)
            {
            case(UART_CFG_DATABITS_5):
            	UART_UCSRB(dev_id) &= ~BIT2;
            	UART_UCSRC(dev_id) &= ~(BIT1|BIT2);
            	break;
            case(UART_CFG_DATABITS_6):
            	UART_UCSRB(dev_id) &= ~BIT2;
            	UART_UCSRC(dev_id) |= BIT1;
            	UART_UCSRC(dev_id) &= ~BIT2;
            	break;            	
            case(UART_CFG_DATABITS_7):
            	UART_UCSRB(dev_id) &= ~BIT2;
            	UART_UCSRC(dev_id) &= ~BIT1;
            	UART_UCSRC(dev_id) |= BIT2;
            	break;
            case(UART_CFG_DATABITS_8):
            	UART_UCSRB(dev_id) &= ~BIT2;
            	UART_UCSRC(dev_id) |= (BIT1|BIT2);
            	break;
            case(UART_CFG_DATABITS_9):
            	UART_UCSRB(dev_id) |= BIT2;
            	UART_UCSRC(dev_id) |= (BIT1|BIT2);
            	break;
            default:
            }
        break;
    case UART_CFG_GETDATABITS:
    	if (TSTBIT(UART_UCSRC(dev_id), BIT1))
    	    {
            if (TSTBIT(UART_UCSRC(dev_id), BIT2))
                {
                if (TSTBIT(UART_UCSRB(dev_id), BIT2))
                	retval_u8 = UART_CFG_DATABITS_9;
                else
                	retval_u8 = UART_CFG_DATABITS_8;
            	}
            else
            	retval_u8 = UART_CFG_DATABITS_6;
    	    }
        else
            {
            if (TSTBIT(UART_UCSRC(dev_id), BIT2))
            	retval_u8 = UART_CFG_DATABITS_7; 
            else
            	retval_u8 = UART_CFG_DATABITS_5;
            }
        break;
    case UART_CFG_SETPARITY:
        switch (param)
            {
            case(UART_CFG_PARITY_NONE):
            	UART_UCSRC(dev_id) &= ~(BIT4|BIT5);
            	break;
            case(UART_CFG_PARITY_EVEN):
            	UART_UCSRC(dev_id) &= ~BIT4;
            	UART_UCSRC(dev_id) |= BIT5;
            	break;
            case(UART_CFG_PARITY_ODD):
            	UART_UCSRC(dev_id) |= (BIT4|BIT5);
            	break;
            default:
            }
        break;
    case UART_CFG_GETPARITY:
    	if (TSTBIT(UART_UCSRC(dev_id), BIT5))
    	    {
    	    if (TSTBIT(UART_UCSRC(dev_id), BIT4))
            	retval_u8 = UART_CFG_PARITY_ODD;
    	    else
            	retval_u8 = UART_CFG_PARITY_EVEN;
    	    }
        else
        	retval_u8 = UART_CFG_PARITY_NONE;
        break;
    case UART_CFG_SETSTOPBITS: 
        switch(param)
            {
            case(UART_CFG_STOPBITS_1):
            	UART_UCSRC(dev_id) &= ~BIT3;
            	break;
            case(UART_CFG_STOPBITS_2):
            	UART_UCSRC(dev_id) |= BIT3;
            	break;
            default:
            }
        break;
    case UART_CFG_GETSTOPBITS:
    	if (TSTBIT(UART_UCSRC(dev_id), BIT3))
        	retval_u8 = UART_CFG_STOPBITS_2;
        else
        	retval_u8 = UART_CFG_STOPBITS_1;
        break;
    default:
    }
return retval_u8;
}


// *********************************************************************************
/// \brief		test the buffer whether Data present
/// @param[in]	dev_id   - UART-ID, see UART_DEV_ENUM
/// @return     number of bytes in receive buffer
// *********************************************************************************
UART_RX_VAR_TYPE uart_get_rx_count(UART_DEV_ENUM dev_id)
{
UART_RX_VAR_TYPE rgap;
unsigned char 	 int_state;

int_state = UART_RXC_INT_STATE(dev_id);  // save state of Receive-Interrupt
UART_RXC_INT_OFF(dev_id);				// disable Receive-Interrupt

rgap = UART_RX_BUFFER_SIZE - uart_buffer[dev_id].rgap;

if (int_state)
	UART_RXC_INT_ON(dev_id);			// enable Receive-Interrupt

return rgap;
}


// *********************************************************************************
/// \brief		check the size of transmit-buffer
/// @param[in]	dev_id   - UART-ID, see UART_DEV_ENUM
/// @return     number of space in transmit buffer
// *********************************************************************************
UART_TX_VAR_TYPE uart_get_tx_gap(UART_DEV_ENUM dev_id)
{
UART_TX_VAR_TYPE wgap;
unsigned char 	 int_state;

int_state = UART_DRE_INT_STATE(dev_id);  	// save state of Empty-Interrupt
UART_DRE_INT_OFF(dev_id); 				// disable Empty-Interrupt
wgap = uart_buffer[dev_id].wgap;
if (int_state)
	UART_DRE_INT_ON(dev_id); 		// enable Empty-Interrupt

return wgap;
}


#ifdef UART_PARSE_CHAR
// *********************************************************************************
/// \brief		Check the parse counter
/// @param[in]	dev_id   - UART-ID, see UART_DEV_ENUM
/// @return     number of that special character in receive buffer,
///				see UART_PARSE_CHAR
// *********************************************************************************
unsigned char uart_get_parse_counter(UART_DEV_ENUM dev_id)
{
return uart_buffer[dev_id].parse_counter;
}
#endif


// *********************************************************************************
/// \brief		send a char to the uart
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
/// @param[in]	data   - data to send
// *********************************************************************************
void uart_putchar(UART_DEV_ENUM dev_id, unsigned char data)
{
/// \todo UART lost counter should only be incremented, if data is really lost.
///	\todo An timeout should be added in this function.
#ifdef UART_STATISTIC_ENABLE
if (uart_buffer[dev_id].wgap==0)
	uart_buffer[dev_id].stat.wlost++;		// counter of lost data
uart_buffer[dev_id].stat.wcount++;	   		// counter of transmit-data
#endif

while (uart_buffer[dev_id].wgap==0)	// if buffer full? - wait
	{
	#ifndef UART_MODE_IRQ
	uart_transmit_poll(dev_id);
	#endif
	}
UART_DRE_INT_OFF(dev_id); 		// disable Empty-Interrupt

uart_buffer[dev_id].wbuffer[uart_buffer[dev_id].wtop] = data;
uart_buffer[dev_id].wtop++;
if (uart_buffer[dev_id].wtop == UART_TX_BUFFER_SIZE)
	uart_buffer[dev_id].wtop = 0;
uart_buffer[dev_id].wgap--;

#ifdef UART_MODE_IRQ
UART_DRE_INT_ON(dev_id);	 	// enable Empty-Interrupt
#endif
}


// *********************************************************************************
/// \brief		read a char from an UART device
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
/// @return     the character
// *********************************************************************************
unsigned char uart_getchar(UART_DEV_ENUM dev_id)
{
unsigned char tmp_u8=0;
unsigned char 	 int_state;

/// \todo UART lost counter should only be incremented, if data is really lost.
///	\todo An timeout should be added in this function.
#ifdef UART_STATISTIC_ENABLE
uart_buffer[dev_id].stat.rcount++;	   	// counter of receive-data
#endif

while (uart_buffer[dev_id].rgap == UART_RX_BUFFER_SIZE)	// no data available?
	{
	#ifndef UART_MODE_IRQ
	uart_receive_poll(dev_id);
	#endif
	}

// save state of Receive-Interrupt before disable
int_state = UART_RXC_INT_STATE(dev_id);
UART_RXC_INT_OFF(dev_id);

tmp_u8 = uart_buffer[dev_id].rbuffer[uart_buffer[dev_id].rbottom];
uart_buffer[dev_id].rbottom++;
if (uart_buffer[dev_id].rbottom == UART_RX_BUFFER_SIZE)
	uart_buffer[dev_id].rbottom = 0;
uart_buffer[dev_id].rgap++;
#ifdef UART_PARSE_CHAR
if (tmp_u8 == UART_PARSE_CHAR)
	if (uart_buffer[dev_id].parse_counter > 0)
		uart_buffer[dev_id].parse_counter--;
#endif

// enable Receive-Interrupt
if (int_state)
	UART_RXC_INT_ON(dev_id);

return tmp_u8;
}


// *********************************************************************************
/// \brief		Write a block of data to an UART device
///
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
/// @param[in]	data   - pointer to data
/// @param[in]	size   - size of data
// *********************************************************************************
void uart_write_block(UART_DEV_ENUM dev_id, unsigned char* data, UART_TX_VAR_TYPE size)
{
UART_TX_VAR_TYPE i;

for (i=0; i<size; i++)
	{
	uart_putchar(dev_id, *data);
	data++;
	}
}


// *********************************************************************************
/// \brief		Writes 0-terminated string to UART
///
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
/// @param[in]	data   - pointer to 0-terminated string
// *********************************************************************************
void uart_puts(UART_DEV_ENUM dev_id, unsigned char* data)
{
while (*data)
	{
	uart_putchar(dev_id, *data);
	data++;
	}
}


// *********************************************************************************
/// \brief		Writes 0-terminated string to UART
///
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
/// @param[in]	data   - pointer to 0-terminated string in flash
// *********************************************************************************
void uart_putsf(UART_DEV_ENUM dev_id, unsigned char flash *data)
{
while (*data)
	{
	uart_putchar(dev_id, *data);
	data++;
	}
}


// *********************************************************************************
/// \brief		Reads an block of data from an UART device
///
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
/// @param[in]	data   - pointer to data
/// @param[in]	size   - size of data
// *********************************************************************************
void uart_read_block(UART_DEV_ENUM dev_id, unsigned char* data, UART_RX_VAR_TYPE size)
{
UART_RX_VAR_TYPE i;

for (i=0; i<size; i++)
	{
	*data = uart_getchar(dev_id);
	data++;
	}
}


#ifdef UART_MODE_IRQ
// *********************************************************************************
/// \brief		Common Receive ISR for both UARTs
///
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
// *********************************************************************************
void uart_common_rxc_isr(UART_DEV_ENUM dev_id)
{
unsigned char  tmp;
#ifdef UART_STATISTIC_ENABLE
unsigned char  uart_error;

// error bits must be read before reading the receive buffer
uart_error = UART_ERROR_BITS(dev_id) & (UART_RECEIVE_FE | UART_RECEIVE_DOR | UART_RECEIVE_UPE);
#endif
tmp = UART_DATA_READ(dev_id);
#ifdef UART_STATISTIC_ENABLE
if (uart_error)
	{
	if (uart_error & UART_RECEIVE_FE)
		uart_buffer[dev_id].stat.r_frame_error++;	// counter of Receive Frame Error
	if (uart_error & UART_RECEIVE_DOR)
		{
		uart_buffer[dev_id].stat.r_data_over_run++;	// counter of Receive Data OverRun
		uart_buffer[dev_id].stat.rlost++;			// counter of lost data
		}
	if (uart_error & UART_RECEIVE_UPE)
		uart_buffer[dev_id].stat.r_parity_error++;	// counter of Receive Parity Error
	}
#endif	// #ifdef UART_STATISTIC_ENABLE
if (uart_buffer[dev_id].rgap > 0)
	{
	uart_buffer[dev_id].rgap--;
	uart_buffer[dev_id].rbuffer[uart_buffer[dev_id].rtop]=tmp;
	uart_buffer[dev_id].rtop++;
	if (uart_buffer[dev_id].rtop==UART_RX_BUFFER_SIZE)
		uart_buffer[dev_id].rtop = 0;
	#ifdef UART_PARSE_CHAR
	if (tmp == UART_PARSE_CHAR)
		if (uart_buffer[dev_id].parse_counter < 255)
			uart_buffer[dev_id].parse_counter++;
	#endif
	}
#ifdef UART_STATISTIC_ENABLE
else
	uart_buffer[dev_id].stat.rlost++;				// counter of lost data
#endif
}


// *********************************************************************************
/// \brief		Common Transmit ISR for both UARTs
///
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
// *********************************************************************************
void uart_common_dre_isr(UART_DEV_ENUM dev_id)
{
if (uart_buffer[dev_id].wgap < UART_TX_BUFFER_SIZE)
	{
	#ifdef UART_RS485_DEV0_ENABLE
	if (dev_id == UART_DEV0)
		{
		UART_RS485_DEV0_TX_ON;
		UART_TXC_INT_ON(UART_DEV0);
		}
	#endif
	#ifdef UART_RS485_DEV1_ENABLE
	if (dev_id == UART_DEV1)
		{
		UART_RS485_DEV1_TX_ON;
		UART_TXC_INT_ON(UART_DEV1);
		}
	#endif
	uart_buffer[dev_id].wgap++;
	UART_DATA_WRITE(dev_id, uart_buffer[dev_id].wbuffer[uart_buffer[dev_id].wbottom]);
	uart_buffer[dev_id].wbottom++;
	if (uart_buffer[dev_id].wbottom == UART_TX_BUFFER_SIZE)
		{
		uart_buffer[dev_id].wbottom = 0;
		}
	}
else
	UART_DRE_INT_OFF(dev_id);	 	// disable Empty-Interrupt
}


#ifdef UART_DEVICE0_ENABLE
// *********************************************************************************
/// \brief		Receive ISR for UART0
///
// *********************************************************************************
interrupt [UART_RXC0_IRQ_NO] void uart_rxc0_isr(void)
{
uart_common_rxc_isr(UART_DEV0);
}


// *********************************************************************************
/// \brief               Interrupt-Handler UART1 Empty
// *********************************************************************************
interrupt [UART_DRE0_IRQ_NO] void uart_dre0_isr(void)
{
uart_common_dre_isr(UART_DEV0);
}


#ifdef UART_RS485_DEV0_ENABLE
// *********************************************************************************
/// \brief		Receive ISR for UART0
///
// *********************************************************************************
interrupt [UART_TXC0_IRQ_NO] void uart_txc0_isr(void)
{
UART_RS485_DEV0_TX_OFF;
UART_TXC_INT_OFF(UART_DEV0);
}
#endif	// #ifdef UART_RS485_DEV0_ENABLE
#endif	// #ifdef UART_DEVICE0_ENABLE


#ifdef UART_DEVICE1_ENABLE
// *********************************************************************************
/// \brief		Receive ISR for UART0
///
// *********************************************************************************
interrupt [UART_RXC1_IRQ_NO] void uart_rxc1_isr(void)
{
uart_common_rxc_isr(UART_DEV1);
}


// *********************************************************************************
/// \brief		Receive ISR for UART0
///
// *********************************************************************************
interrupt [UART_DRE1_IRQ_NO] void uart_dre1_isr(void)
{
uart_common_dre_isr(UART_DEV1);
}


#ifdef UART_RS485_DEV1_ENABLE
// *********************************************************************************
/// \brief		Receive ISR for UART0
///
// *********************************************************************************
interrupt [UART_TXC1_IRQ_NO] void uart_txc1_isr(void)
{
UART_RS485_DEV1_TX_OFF;
UART_TXC_INT_OFF(UART_DEV1);
}
#endif	// #ifdef UART_RS485_DEV1_ENABLE
#endif	// #ifdef UART_DEVICE1_ENABLE
#endif  // #ifdef UART_MODE_IRQ


#ifdef UART_MODE_POLL
// *********************************************************************************
/// \brief		Receive routine in polling mode
///
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
/// \remark		Called the often the better
// *********************************************************************************
void uart_receive_poll(UART_DEV_ENUM dev_id)
{
unsigned char tmp;

if (UART_RXC_BIT(dev_id))			// RXC - UART Receive Complete
	{
	tmp = UART_DATA_READ(dev_id);	// reads data from UART
	if (uart_buffer[dev_id].rgap > 0)
		{
		uart_buffer[dev_id].rgap--;
		uart_buffer[dev_id].rbuffer[uart_buffer[dev_id].rtop] = tmp;
		uart_buffer[dev_id].rtop++;
		if (uart_buffer[dev_id].rtop==UART_RX_BUFFER_SIZE)
			uart_buffer[dev_id].rtop = 0;
		#ifdef UART_PARSE_CHAR
		if (tmp == UART_PARSE_CHAR)
			if (uart_buffer[dev_id].parse_counter < 255)
				uart_buffer[dev_id].parse_counter++;
		#endif
		}
	}
	#ifdef UART_STATISTIC_ENABLE
	else
		uart_buffer[dev_id].stat.rlost++;		// counter of lost data
	#endif
}


// *********************************************************************************
/// \brief		Transmit routine in polling mode
///
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
/// \remark		Called the often the better
// *********************************************************************************
void uart_transmit_poll(UART_DEV_ENUM dev_id)
{

if (UART_UDRE_BIT(dev_id))		// UDRE: UART Data Register Empty
	{
	if (uart_buffer[dev_id].wgap < UART_TX_BUFFER_SIZE)
		{
		uart_buffer[dev_id].wgap++;
		UART_DATA_WRITE(dev_id, uart_buffer[dev_id].wbuffer[uart_buffer[dev_id].wbottom]);	// writes data to UART
		uart_buffer[dev_id].wbottom++;
		if (uart_buffer[dev_id].wbottom == UART_TX_BUFFER_SIZE)
			uart_buffer[dev_id].wbottom = 0;
		}
	}
}
#endif	// #ifdef UART_MODE_POLL


#ifdef UART_STATISTIC_ENABLE
// *********************************************************************************
/// \brief		Reset statistic counter
/// @param[in]	dev_id - UART-ID, see UART_DEV_ENUM
/// \remark		UART Interrupts must be disabled before calling this function
// *********************************************************************************
void uart_reset_statistic(UART_DEV_ENUM dev_id)
{
memset(&uart_buffer[dev_id].stat, 0x00, sizeof(UART_STAT_STRUCT));
}


// *********************************************************************************
/// \brief		Get structure of uart status information
/// @param[in]	dev_id 	 - UART-ID, see UART_DEV_ENUM
/// @param[out]	p_struct - pointer to structure, data will be copied in
// *********************************************************************************
void uart_get_statistic(UART_DEV_ENUM dev_id, UART_STAT_STRUCT *p_struct)
{
unsigned char dre_int_status;
unsigned char rxc_int_status;

dre_int_status = UART_DRE_INT_STATE(dev_id);
rxc_int_status = UART_RXC_INT_STATE(dev_id);
UART_RXC_INT_OFF(dev_id);
UART_DRE_INT_OFF(dev_id);

if (p_struct != 0x0)
    {
    // disable of uart interrupts necessary
    memcpy(p_struct, &uart_buffer[dev_id].stat, sizeof(UART_STAT_STRUCT));
    uart_reset_statistic(dev_id);
    }

// restore interrupt status
if (dre_int_status)
	UART_DRE_INT_ON(dev_id);
if (rxc_int_status)
	UART_RXC_INT_ON(dev_id);
}
#endif


#ifdef UART_DEBUG
void uart_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);

// *********************************************************************************
/// \brief		Registers debug handler
///
// *********************************************************************************
void uart_debug_init(void)
{
T_DEBUG_HANDLER_STRUCT p_struct;

p_struct.fp_handler = &uart_debug_handler;
p_struct.id_string = "uart";
debug_register_handler(&p_struct);
}


// *********************************************************************************
/// \brief		Write info of UART interface to debug uart

/// @param[in]	dev_id 	 - UART-ID, see UART_DEV_ENUM
// *********************************************************************************
void uart_debug_info(UART_DEV_ENUM dev_id)
{
unsigned long baudrate;

putsf("Base-Addr/top/bot/gap:\r");
printf("Rx: 0x%04x/%u/%u/%u\r\n", uart_buffer[dev_id].rbuffer, uart_buffer[dev_id].rtop,
					uart_buffer[dev_id].rbottom, uart_buffer[dev_id].rgap);
printf("Tx: 0x%04x/%u/%u/%u\r\n", uart_buffer[dev_id].wbuffer, uart_buffer[dev_id].wtop,
					uart_buffer[dev_id].wbottom, uart_buffer[dev_id].wgap);
printf("Application count: r:%u t:%u\r\n", uart_buffer[dev_id].stat.rcount, uart_buffer[dev_id].stat.wcount);
uart_buffer[dev_id].stat.rcount=0;
uart_buffer[dev_id].stat.wcount=0;
if(uart_buffer[dev_id].stat.rlost)		// counter of lost data
	printf("receive-lost: %u\r\n", uart_buffer[dev_id].stat.rlost);
else
	putsf("NO receive-lost\r");
uart_buffer[dev_id].stat.rlost=0;
if(uart_buffer[dev_id].stat.wlost)		// counter of lost data
	printf("transmit-lost: %u\r\n", uart_buffer[dev_id].stat.wlost);
else
	putsf("NO transmit-lost\r");
uart_buffer[dev_id].stat.wlost=0;
printf("Frame-Error : %u\r\n", uart_buffer[dev_id].stat.r_frame_error);		// counter of Receive Frame Error
uart_buffer[dev_id].stat.r_frame_error=0;
printf("Data OverRun: %u\r\n", uart_buffer[dev_id].stat.r_data_over_run);	// counter of Receive Data OverRun
uart_buffer[dev_id].stat.r_data_over_run = 0;
printf("Parity Error: %u\r\n", uart_buffer[dev_id].stat.r_parity_error);	// counter of Receive Parity Error
uart_buffer[dev_id].stat.r_parity_error=0;
baudrate = uart_get_baudrate(dev_id);
printf("Baudrate : %luBaud\r\n", baudrate);
}


// *********************************************************************************
/// \brief		Write the UART tx-buffer to debug uart
/// @param[in]	uart_device   UART-ID, see UART_DEV_ENUM
// *********************************************************************************
void uart_debug_display_tx(UART_DEV_ENUM dev_id)
{
printf("Tx-Buffer Top:%u/Bot:%u/Gap:%u\r\n", uart_buffer[dev_id].wtop, uart_buffer[dev_id].wbottom, uart_buffer[dev_id].wgap);
debug_display_buffer(uart_buffer[dev_id].wbuffer, UART_TX_BUFFER_SIZE, uart_buffer[dev_id].wtop);
memset(uart_buffer[dev_id].wbuffer, 0x00, UART_TX_BUFFER_SIZE);
uart_clear_tx_buffer(dev_id);
}


// *********************************************************************************
/// \brief		Write the UART rx-buffer to debug uart
/// @param[in]	uart_device   UART-ID, see UART_DEV_ENUM
// *********************************************************************************
void uart_debug_display_rx(UART_DEV_ENUM dev_id)
{
printf("Rx-Buffer Top:%u/Bot:%u/Gap:%u\r\n", uart_buffer[dev_id].rtop, uart_buffer[dev_id].rbottom, uart_buffer[dev_id].rgap);
debug_display_buffer(uart_buffer[dev_id].rbuffer, UART_RX_BUFFER_SIZE, uart_buffer[dev_id].rtop);
memset(uart_buffer[dev_id].rbuffer, 0x00, UART_RX_BUFFER_SIZE);
uart_clear_rx_buffer(dev_id);
}


// *********************************************************************************
/// \brief		Returns the device-ID for a hardware device
/// @param[in]	device_number - 0..1
/// @retval		device-ID, range UART_DEV0..UART_DEVx
/// @retval		0xFF - hardware not available. (Not present with this chip, or 
///					   not enabled, see UART_DEVICEx_ENABLE
// *********************************************************************************
UART_DEV_ENUM uart_debug_dev2id(unsigned char device_number)
{
switch (device_number)
	{
	#ifdef UART_DEVICE0_ENABLE
	case 0:  return UART_DEV0;
	#endif
	#ifdef UART_DEVICE1_ENABLE
	case 1:	 return UART_DEV1;
	#endif
	default: return 0xFF;
	}
}


// ************************************************************************************************
/// \brief		Command handler for incoming commands
///
/// @param[in] 	command	- pointer to received string
/// @param[in] 	mode	- see debug.h
// ************************************************************************************************
void uart_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{
UART_STAT_STRUCT uart_stat;
unsigned char 	 uart_device;
UART_DEV_ENUM	 dev_id;

if (mode == DEBUG_HANDLER_MODE_CMD)
	{
	if (strncmpf(command, "-info", 5)==0)
	    {
		uart_device = debug_get_int_parameter(command);
		dev_id = uart_debug_dev2id(uart_device);
		if (dev_id != 0xff)
			{
			printf("-- UART%1u/ID:%1u --\r\n", uart_device, dev_id);
	        uart_debug_info(dev_id);
	        }
	    else
	    	printf("Specify valid UART device.\r\n");
	    }
	else if (strncmpf(command, "-rx", 3)==0)
		{
		uart_device = debug_get_int_parameter(command);
		dev_id = uart_debug_dev2id(uart_device);
		if (dev_id != 0xff)
			{
			printf("-- UART%1u/ID:%1u --\r\n", uart_device, dev_id);
	        uart_debug_display_rx(dev_id);
	        }
	    else
	    	printf("Specify valid UART device.\r\n");
		}
	else if (strncmpf(command, "-tx", 3)==0)
		{
		uart_device = debug_get_int_parameter(command);
		dev_id = uart_debug_dev2id(uart_device);
		if (dev_id != 0xff)
			{
			printf("-- UART%1u/ID:%1u --\r\n", uart_device, dev_id);
	        uart_debug_display_tx(dev_id);
	        }
	    else
	    	printf("Specify valid UART device.\r\n");
		}
	else if (strncmpf(command, "-status", 7)==0)
		{
		uart_device = debug_get_int_parameter(command);
		dev_id = uart_debug_dev2id(uart_device);
		if (dev_id != 0xff)
	        {
	        uart_get_statistic(dev_id, &uart_stat);
	        printf("UART status structure (uart %u)\r\n", uart_device);
	        printf("rcount:  %u\r\n", uart_stat.rcount);
	        printf("wcount:  %u\r\n", uart_stat.wcount);
	        printf("rlost:   %u\r\n", uart_stat.rlost);
	        printf("wlost:   %u\r\n", uart_stat.wlost);
	        printf("frm_err: %u\r\n", uart_stat.r_frame_error);
	        printf("ovr_run: %u\r\n", uart_stat.r_data_over_run);
	        printf("pty_err: %u\r\n", uart_stat.r_parity_error);
	        }
	    else
	    	printf("Specify valid UART device.\r\n");
		}
	}
}
#endif 	// #ifdef UART_DEBUG
#endif	// #ifdef UART_ENABLE
