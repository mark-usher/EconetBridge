// ************************************************************************************************
///
/// \file 			spm.c
/// \brief			Read and write FLASH, EEPROM and BLB
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Daniel Matthes, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include "spm.h"
#include <io.h>

// ************************************************************************************************
//  definitions and equations 	
// ************************************************************************************************
// Codevision Help:
// The registers R0, R1, R22, R23, R24, R25, R26, R27, R30 and R31 can be freely used 
// in assembly routines.
// we are using the z-register as our flash-pointer Z=R30+R31
#ifndef _DOXYGEN_PARSER_ 
#if 	defined (_CHIP_ATMEGA8_) || defined (_CHIP_ATMEGA8L_) ||\
		defined (_CHIP_ATMEGA88_) || defined (_CHIP_ATMEGA88V_) ||\
		defined (_CHIP_ATMEGA8515_) || defined (_CHIP_ATMEGA8515L_) ||\
		defined (_CHIP_ATMEGA8535_) || defined (_CHIP_ATMEGA8535L_) ||\
		defined (_CHIP_ATMEGA16_) || defined (_CHIP_ATMEGA16L_) ||\ 
		defined (_CHIP_ATMEGA168_) || defined (_CHIP_ATMEGA168V_) ||\
		defined (_CHIP_ATMEGA162_) || defined (_CHIP_ATMEGA162V_) ||\
		defined (_CHIP_ATMEGA165_) || defined (_CHIP_ATMEGA165V_) ||\
		defined (_CHIP_ATMEGA169_) || defined (_CHIP_ATMEGA169V_) ||\
		defined (_CHIP_ATMEGA32_) || defined (_CHIP_ATMEGA32L_) ||\
		defined (_CHIP_ATMEGA325_) || defined (_CHIP_ATMEGA325V_) ||\
		defined (_CHIP_ATMEGA3250_) || defined (_CHIP_ATMEGA3250V_) ||\
		defined (_CHIP_ATMEGA329_) || defined (_CHIP_ATMEGA329V_) ||\
		defined (_CHIP_ATMEGA3290_) || defined (_CHIP_ATMEGA3290V_) ||\
		defined (_CHIP_ATMEGA640_) || defined (_CHIP_ATMEGA640V_) ||\
		defined (_CHIP_ATMEGA644_) || defined (_CHIP_ATMEGA644V_) ||\
		defined (_CHIP_ATMEGA645_) || defined (_CHIP_ATMEGA645V_) ||\
		defined (_CHIP_ATMEGA6450_) || defined (_CHIP_ATMEGA6450V_) ||\
		defined (_CHIP_ATMEGA649_) || defined (_CHIP_ATMEGA649V_) ||\
		defined (_CHIP_ATMEGA6490_) || defined (_CHIP_ATMEGA6490V_)		
    		#asm(".equ 	SPMCR = 0x57")
    		
#elif 	defined (_CHIP_ATMEGA64_) || defined (_CHIP_ATMEGA64L_)
    		#asm(".equ 	SPMCR = 0x68")
    		
#elif 	defined (_CHIP_ATMEGA128_) || defined (_CHIP_ATMEGA128L_)
			#asm(".equ 	RAMPZ_ADR = 0x5b")
			#asm(".equ 	SPMCR = 0x68")
			
#elif 	defined (_CHIP_ATMEGA1280_) || defined (_CHIP_ATMEGA1280V_) ||\
	  	defined (_CHIP_ATMEGA1281_) || defined (_CHIP_ATMEGA1281V_) ||\
      	defined (_CHIP_ATMEGA2560_) || defined (_CHIP_ATMEGA2560V_) ||\
      	defined (_CHIP_ATMEGA2561_) || defined (_CHIP_ATMEGA2561V_) 
			#asm(".equ 	RAMPZ_ADR = 0x5b")
			#asm(".equ  SPMCR = 0x57")
#endif
 
#asm
   .equ 	SPMEN = 0x01
   .equ 	SPMEN_BIT_NO = 0
   .equ 	PGERS = 0x02
   .equ 	PGWRT = 0x04
   .equ 	BLBSET = 0x08
   .equ 	RWWSRE = 0x10
   .def 	ZL = r30
   .def 	ZH = r31
   .def 	XL=r26
   .def 	XH=r27
   .def 	temp = r22
   .def 	spmcrval = r23
   .def 	looplo=r24
   .def 	loophi=r25
#endasm
#endif //	#ifndef _DOXYGEN_PARSER_

// ************************************************************************************************
/// \brief  	function writes one word to a temporary page buffer	
/// @param[in]  addr - address of a temporary storage cell
/// @param[in]  data - two databytes, which have to be written to the temporary page
// ************************************************************************************************
#pragma warn-
void spm_writeword(unsigned int addr, unsigned int data)
{
#asm("wdr");
#asm
        ldd    	ZH, y+3       				; MSB addr   
   		ldd   	ZL, y+2						; LSB addr
   		ldd   	r1, y+1 					; MSB data
   		ld   	r0, y	 					; LSB data
   		
    	ldi  	spmcrval, SPMEN
    	rcall 	Do_spm
		
#endasm
}
#pragma warn+


// ************************************************************************************************
/// \brief  	function erases one flash page
/// @param[in]  addr - address of flash page, which has to be erased
// ************************************************************************************************
#ifdef SPM_ADDR_SIZE_FLASH_24BIT
#pragma warn-
void spm_erasepage_24(unsigned long addr)
{
unsigned char temp;
temp = RAMPZ;
#asm("wdr");
#asm
        ldd   	temp, y+3 					; 2.Byte addr
   		sts   	RAMPZ_ADR, temp
        ldd    	ZH, y+2       				; 3.Byte addr   
   		ldd   	ZL, y+1						; 4.Byte addr
   		   			
    	ldi 	spmcrval, PGERS | SPMEN
		rcall 	Do_spm
		
		ldi     spmcrval, RWWSRE | SPMEN
		rcall 	Do_spm
#endasm  
RAMPZ = temp;    
}
#pragma warn+
#endif


// ************************************************************************************************
/// \brief  	function erases one flash page
/// @param[in]  addr - address of flash page, which has to be erased
// ************************************************************************************************

#ifdef SPM_ADDR_SIZE_FLASH_16BIT
#pragma warn-
void spm_erasepage_16(unsigned int addr)
{
#asm("wdr");
#asm    
		ldd    	ZH, y+1       				; MSB addr   
   		ld   	ZL, y						; LSB addr
   		   			
    	ldi 	spmcrval, PGERS | SPMEN
		rcall 	Do_spm
			
		ldi     spmcrval, RWWSRE | SPMEN
		rcall 	Do_spm
#endasm
}
#pragma warn+
#endif


// ************************************************************************************************
/// \brief  	function programs the temporary buffer to flash memory
/// @param[in]  addr - address of flash page, which has to be programmed
// ************************************************************************************************
#ifdef SPM_ADDR_SIZE_FLASH_24BIT
#pragma warn-
void spm_programpage_24(unsigned long addr)
{
unsigned char temp;
temp = RAMPZ;
#asm("wdr");
#asm
        ldd   	temp, y+3 					; 2.Byte addr
   		sts   	RAMPZ_ADR, temp
        ldd    	ZH, y+2       				; 3.Byte addr   
   		ldd   	ZL, y+1						; 4.Byte addr
   		   			
    	ldi  	spmcrval, PGWRT | SPMEN
    	call 	Do_spm
		
		ldi     spmcrval, RWWSRE | SPMEN
		rcall 	Do_spm
#endasm  
RAMPZ = temp;
}
#pragma warn+
#endif


// ************************************************************************************************
/// \brief  	function programs the temporary buffer to flash memory
/// @param[in]  addr - address of flash page, which has to be programmed
// ************************************************************************************************
#ifdef SPM_ADDR_SIZE_FLASH_16BIT
#pragma warn-
void spm_programpage_16(unsigned int addr)
{
#asm("wdr");
#asm
        ldd    	ZH, y+1       				; MSB addr   
   		ld   	ZL, y						; LSB addr
   		   			
    	ldi  	spmcrval, PGWRT | SPMEN
    	rcall 	Do_spm
		
		ldi     spmcrval, RWWSRE | SPMEN
		rcall 	Do_spm
#endasm
}
#pragma warn+
#endif


// ************************************************************************************************
/// \brief  	function read x byte from flash memory 
/// @param[in]  psram - pointer to sram-array
/// @param[in]  addr - address of flash page, which has to be read
/// @param[in]  size - number of bytes, which have to read
// ************************************************************************************************
#ifdef SPM_ADDR_SIZE_FLASH_24BIT
#pragma warn-
void spm_readflash_24(unsigned char* p_sram, unsigned long addr, unsigned int size)
{
unsigned char temp;
temp = RAMPZ;
#asm("wdr");
#asm        
			rcall    Wait_spm
   			rcall    Wait_ee
			
			ldd		XH,y+8 					; MSB p_sram 	
   			ldd   	XL,y+7 					; LSB p_sram 
   			ldd   	temp,y+5 				; 2.Byte addr
   			sts   	RAMPZ_ADR,temp 	
   			ldd   	ZH,y+4 					; 3.Byte addr
   			ldd   	ZL,y+3 					; 4.Byte addr
   			ldd   	loophi,y+2 				; MSB size
   			ldd    	looplo,y+1 				; LSB size
Rdloop1:	elpm 	r0, Z+
			st		X+, r0
			sbiw 	loophi:looplo, 1
			brne 	Rdloop1
#endasm
RAMPZ = temp;
}
#pragma warn+
#endif


// ************************************************************************************************
/// \brief  	function read x byte from flash memory 
/// @param[in]  psram - pointer to sram-array
/// @param[in]  addr - address of flash page, which has to be read
/// @param[in]  size - number of bytes, which have to read
// ************************************************************************************************
#ifdef SPM_ADDR_SIZE_FLASH_16BIT
#pragma warn-
void spm_readflash_16(unsigned char* p_sram, unsigned int address, unsigned int size)
{
#asm("wdr");
#asm
			rcall    Wait_spm
        	rcall    Wait_ee
			
			ldd		XH,y+5 			; MSB p_sram 
   			ldd   	XL,y+4 			; LSB p_sram 
   			ldd   	ZH,y+3 			; MSB p_flash
   			ldd   	ZL,y+2 			; LSB p_flash 
   			ldd   	loophi,y+1 		; MSB size
   			ld    	looplo,y   		; LSB size

Rdloop2:    lpm 	r0, Z+
			st		X+, r0
			sbiw 	loophi:looplo, 1
			brne 	Rdloop2
#endasm
}
#pragma warn+
#endif

// ************************************************************************************************
/// \brief  	function writes one byte to EEPROM memory 
/// @param[in]  addr - address of EEPROM storage cell, which has to be written
/// @param[in]  data - one byte, which has to be written to EEPROM
// ************************************************************************************************
#pragma warn-
void spm_eewritebyte(unsigned int addr, unsigned char data)
{
#asm("wdr");
#asm
        rcall    Wait_spm
        rcall    Wait_ee
        
        ldd     temp, y+2
        out     EEARH, temp
        ldd     temp, y+1
        out     EEARL, temp
        ld      temp, y
        out     EEDR, temp
        
        sbi     EECR, EEMWE     
        sbi     EECR, EEWE
#endasm
}
#pragma warn+


// ************************************************************************************************
/// \brief  	function read x byte from flash memory 
/// @param[in]  psram - pointer to sram-array
/// @param[in]  addr - address of flash page, which has to be read
/// @param[in]  size - number of bytes, which have to read
// ************************************************************************************************
#pragma warn-
void spm_eeread(unsigned char* p_sram, unsigned int addr)
{
#asm("wdr")
#asm
		rcall    Wait_spm
        rcall    Wait_ee
		
		ldd		XH, y+3 		; MSB p_sram
   		ldd   	XL, y+2 		; LSB p_sram
   		ldd   	temp, y+1 		; MSB address
   		out		EEARH, temp
   		ld   	temp,y 			; LSB address
   		out     EEARL, temp
   		
   		sbi		EECR, EERE

		in		temp, EEDR
		st		X, temp
#endasm
}

    
// ************************************************************************************************
/// \brief  	function writes lock bits
/// @param[in]  data - one byte, which contains the BLB`s on bitposition 5..2
// ************************************************************************************************
#pragma warn-
void spm_writelockbits(unsigned char data)
{
#asm("wdr");
#asm
        ld      r0, y
   		   			
    	ldi  	spmcrval, BLBSET | SPMEN
    	rcall 	Do_spm
		
		ldi     spmcrval, RWWSRE | SPMEN
		rcall 	Do_spm
#endasm
}
#pragma warn+


// ************************************************************************************************
/// \brief  	function reads fuse and lock bits
/// @param[in]  code - to select high-, low-, ext.- fusebits or BLB's
/// @retval		read high-, low-, ext.- fusebits or BLB's
// ************************************************************************************************
#pragma warn-
unsigned char spm_readfuselockbits(unsigned int code)
{
// code=0x0000	low fuse bits
// code=0x0001  boot lock bits
// code=0x0002  ext fuse bits
// code=0x0003  high fuse bits
#asm("wdr")
#asm
           	rcall    Wait_spm
			rcall    Wait_ee
           	
           	ldd  	ZH, y+1
			ld  	ZL, y
        	
			ldi  	spmcrval, SPMEN|BLBSET
			sts 	SPMCR, spmcrval	
			lpm	
	
			mov	r30, r0
#endasm
}
#pragma warn+

#ifndef _DOXYGEN_PARSER_
// ************************************************************************************************
// function do_spm
//
// ************************************************************************************************
#asm
    		; check for previous SPM complete
Wait_spm:   lds    	temp, SPMCR
			sbrc 	temp, SPMEN_BIT_NO
			rjmp 	Wait_spm
			ret
Wait_ee:	sbic	EECR,EEWE          
        	rjmp    Wait_ee
        	ret
			; input: spmcrval determines SPM action
			; SPM timed sequence
Do_spm:		rcall    Wait_spm
			rcall    Wait_ee
			in	temp, SREG
			cli
			sts SPMCR, spmcrval
			spm
			out	SREG,temp
			wdr
			ret
#endasm
#endif
