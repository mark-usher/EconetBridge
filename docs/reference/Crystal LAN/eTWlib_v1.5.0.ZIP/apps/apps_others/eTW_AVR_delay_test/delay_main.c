// ************************************************************************************************
///
/// \file 			delay_main.c
/// \brief			Main file for delay-test example
///
/// \todo			With SYSTIMER_CYCLE_10MS defined, the 2 LEDs are not synchronous. Why?
/// \date	 		$LastChangedDate: 2007-08-06 19:41:08 +0200 (Mo, 06 Aug 2007) $
/// \version 		$Rev: 674 $
///	\author  		Carsten K�gler, Thomas Kellner<br> Copyright (c) FTZ Leipzig <br>
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <io.h>
#include <stdio.h>
#include <delay.h>
#include "debug.h"
#include "systimer.h"
#include "sys_delay.h"
#include "sys_callback.h"
#include "etwlib.h"


unsigned char board_reset_status;   // must be declared for debug module

// *********************************************************************************
/// \brief   toggle LED1
///
// *********************************************************************************
void board_toggle_led1(void)
{
if (LED1_PIN)
	LED1_ON;
else
	LED1_OFF;
}


// *********************************************************************************
/// \brief   toggle LED4
///
// *********************************************************************************
void board_toggle_led4(void)
{
if (LED4_PIN)
	LED4_ON;
else
	LED4_OFF;
}

#define LED_TOGGLE_DELAY_MS           	1000

// *********************************************************************************
/// \brief   main program with initialization and main loop
///
// *********************************************************************************
void main(void)
{
unsigned char delay_handle;
unsigned long time_us;

etwlib_init();

board_reset_status = (MCUCSR & 0x1f);
MCUCSR &= ~0x1f;		// delete all reset sources
debug_info(0x00);

LED1_ACTIVE;
LED4_ACTIVE;
LED1_ON;
LED4_ON;
delay_ms(1000);
board_toggle_led1();	// showing, that LED is ok
board_toggle_led4();	// showing, that LED is ok


// LED1 is toggled directly in the ISR
sys_callback_register(board_toggle_led1,
					       SYS_CALLBACK_CYCLIC,
					       LED_TOGGLE_DELAY_MS);

// LED4 is toggled in the main loop with polling
delay_handle = sys_delay_start(LED_TOGGLE_DELAY_MS); // start delay
printf("delay_handle: %u\r\n", delay_handle);

// start 9 unused delay channels
delay_handle = sys_delay_start(LED_TOGGLE_DELAY_MS);
delay_handle = sys_delay_start(LED_TOGGLE_DELAY_MS);
delay_handle = sys_delay_start(LED_TOGGLE_DELAY_MS);
delay_handle = sys_delay_start(LED_TOGGLE_DELAY_MS);
delay_handle = sys_delay_start(LED_TOGGLE_DELAY_MS);
delay_handle = sys_delay_start(LED_TOGGLE_DELAY_MS);
delay_handle = sys_delay_start(LED_TOGGLE_DELAY_MS);
delay_handle = sys_delay_start(LED_TOGGLE_DELAY_MS);
delay_handle = sys_delay_start(LED_TOGGLE_DELAY_MS);
printf("delay_handle: %u\r\n", delay_handle);

#asm("sei");
systimer_tic();
while (1)
    {
    debug_main();

    if (sys_delay_ended(delay_handle))
    	{
        sys_delay_restart(delay_handle, LED_TOGGLE_DELAY_MS); // start delay
        board_toggle_led4();
        time_us = systimer_tac();
        printf("Time: %lu us\r\n", time_us);
        systimer_tic();
        }
    }
}
