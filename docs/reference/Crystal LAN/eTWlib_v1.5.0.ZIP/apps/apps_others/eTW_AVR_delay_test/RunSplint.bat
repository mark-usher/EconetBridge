splint  delay_main.c .\..\..\..\tools\sys_callback.c .\..\..\..\tools\sys_delay.c .\..\..\..\debug\debug.c  .\..\..\..\arch\avr\debug_io.c -f splintrc
