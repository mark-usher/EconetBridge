// ************************************************************************************************
///
/// \file 			eTW_AVR_delay_test/project.h
/// \brief			Configuration of delay test example
///
/// \date	 		$LastChangedDate: 2007-03-14 11:21:52 +0100 (Mi, 14 Mrz 2007) $
/// \version 		$Rev: 639 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br>
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License
///					This library is free software; you can redistribute it and/or modify it
///					under the terms of the GNU Lesser General Public License as published by
///					the Free Software Foundation; either version 2.1 of the License, or
///					(at your option) any later version. This library is distributed in the hope
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html
///					You should have received a copy of the GNU Lesser General Public License
///					along with this library; if not, write to the Free Software Foundation,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der
///					GNU Lesser General Public License, wie von der Free Software Foundation
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem��
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version.
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK.
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#ifndef _PROJECT_INCLUDED_
#define _PROJECT_INCLUDED_


// --------------------------------------------------------------------------------
// Global Module Macros
// --------------------------------------------------------------------------------
#define DEBUG

// --------------------------------------------------------------------------------
// debug.c & debug_io.c
// --------------------------------------------------------------------------------
#define DEBUG_PROJECT_NAME				"Delay-Test-App"
#define DEBUG_PROJECT_VERSION			"1.1"
#define DEBUG_UPLINK_UART1
#define DEBUG_DEFINE_PUTCHAR
#define	DEBUG_UART_BAUD_RATE			115200


// --------------------------------------------------------------------------------
// USER Status LED Definitions
// --------------------------------------------------------------------------------
#define	LED1_ON	   		 	 			PORTD&=~0x10
#define	LED1_OFF						PORTD|=0x10
#define	LED1_PIN		 				(PIND&0x10)
#define	LED1_PASSIVE		 			DDRD&=~0x10
#define	LED1_ACTIVE		 				DDRD|=0x10
#define	LED4_ON							PORTD&=~0x80
#define	LED4_OFF						PORTD|=0x80
#define	LED4_PIN						(PIND&0x80)
#define	LED4_ACTIVE						DDRD|=0x80


// --------------------------------------------------------------------------------
// System Timer
// --------------------------------------------------------------------------------
#define SYSTIMER_ENABLE
//#define SYSTIMER_CYCLE_1MS
#define SYSTIMER_CYCLE_10MS
//#define SYSTIMER_SOURCE_TIM0
//#define SYSTIMER_SOURCE_TIM1
//#define SYSTIMER_SOURCE_TIM2
#define SYSTIMER_SOURCE_TIM3

// --------------------------------------------------------------------------------
// System timer Delay & Callback functions
// --------------------------------------------------------------------------------
#define SYS_CALLBACK_ENABLE
#define SYS_CALLBACK_CHANNEL_SIZE  10
#define SYS_DELAY_ENABLE
#define SYS_DELAY_CHANNEL_SIZE     10

#endif	// #define _PROJECT_INCLUDED_
