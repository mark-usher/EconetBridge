// ************************************************************************************************
///
/// \file 			etw_aio.c
/// \brief			Main file for AiO hardware example
///
/// \date	 		$LastChangedDate: 2007-03-07 15:45:14 +0100 (Mi, 07 Mrz 2007) $
/// \version 		$Rev: 608 $
///	\author  		Thomas Kellner<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <stdio.h> 
#include <sleep.h> 
#include <mega128.h> 
#include "debug.h"
#include "board.h"
#include "cs8900_sleep.h"
#include "ds2415.h"
#include "gpio.h"
#include "max7301.h"

#pragma regalloc-
#pragma regalloc+

//*********************************************************************************
// Description	: main routine to start the USER-Program
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void main(void)
{
unsigned char	counter_10ms_delay0=20;
unsigned char	counter_10ms_old; 
TIME_DATE time_date;
unsigned char	modul1_max7301_port=20; 
unsigned char	modul2_max7301_port=8; 

board_init();
cs8900_sleep_active();
#ifdef DEBUG
debug_info(0x00);
#endif	// #ifdef DEBUG
if(ds2415_get_time_date(&time_date))
	{
	if(time_date.year!=2007)
		{
		time_date.day=05;
		time_date.month=03;
		time_date.year=2007;
		time_date.hour=15;
		time_date.min=46;
		time_date.sec=30;
		ds2415_set_time_date(&time_date);
		}
	#ifdef DS2415_DEBUG
	ds2415_debug_print_time();
	#endif	// #ifdef DS2415_DEBUG
	}
else
	printf("DS2415 error\r\n");
gpio_init();
max7301_nibble_config(0, 5, 0x55);	// Port20-Port23 Output
max7301_nibble_config(0, 6, 0x55);	// Port24-Port27 Output
max7301_nibble_config(0, 7, 0x55);	// Port28-Port31 Output
max7301_nibble_config(0, 2, 0x55);	// Port8-Port11 Output
max7301_write_8bit(0, 20, 0xff);
max7301_write_8bit(0, 8, 0xff);
max7301_write_8bit(0, 28, 0xff);
counter_10ms_old = (unsigned char)counter_10ms_16bit;
while (1)
	{
	#asm("wdr");	// Reset Watchdog
	idle();	   		// every time with IDLE-Mode
	#ifdef DEBUG
	debug_main();
	#endif
	if(counter_10ms_old!=(unsigned char)counter_10ms_16bit)
		{
		counter_10ms_old=(unsigned char)counter_10ms_16bit;
		if(counter_10ms_delay0>0)
			counter_10ms_delay0--;
		else
			{		
			counter_10ms_delay0=40;
			if(LED1_PIN)
				{
				max7301_write_bit(0, modul1_max7301_port, 0);
				modul1_max7301_port++; 
				max7301_write_bit(0, modul2_max7301_port, 0);
				modul2_max7301_port++; 
				if(modul2_max7301_port==12)
					modul2_max7301_port=28; 
				LED1_ON;
				}
			else
				{	
				if(modul1_max7301_port>27)
					{
					max7301_write_8bit(0, 20, 0xff);
					modul1_max7301_port=20; 
					}
				if(modul2_max7301_port>31)
					{
					max7301_write_8bit(0, 8, 0xff);
					max7301_write_8bit(0, 28, 0xff);
					modul2_max7301_port=8; 
					}
				LED1_OFF;
				}
			}
		}
	}
}

