// ************************************************************************************************
///
/// \file 			eTW_AIO_hardware/project.h
/// \brief			Configuration of hardware example for eTW_AIO
///
/// \date	 		$LastChangedDate: 2007-03-06 15:56:30 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 601 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************
#ifndef _PROJECT_INCLUDED_
#define _PROJECT_INCLUDED_

// --------------------------------------------------------------------------------
// USER Global Module definitions
// -------------------------------------------------------------------------------- 
#define BOARD_ETW_AVR			// enable easyToWeb-AVR Board

// --------------------------------------------------------------------------------
// USER Global Debug definitions
// -------------------------------------------------------------------------------- 
#define DEBUG					// enable all global debug functions, see debug.c
#define WEB_DEBUG				// enable all easytoweb debug functions, see web_debug.c
#define DS2415_DEBUG			// enable ds2415 debug functions, see ds2415.c
#define MAX7301_DEBUG			// enable max7301 debug functions, see max7301.c
#define GPIO_DEBUG				// enable gpio debug functions, see gpio.c

// --------------------------------------------------------------------------------
// Debug-Interface
// -------------------------------------------------------------------------------- 
#define DEBUG_UPLINK_UART0				// select first UART
#define DEBUG_DEFINE_PUTCHAR			// printf() can be used for debug output
#define DEBUG_CMD_BUFFERSIZE		  	80				// size of debug-command-buffer
#define DEBUG_PROJECT_NAME				"eTW_AiO_Hardware"
#define DEBUG_PROJECT_VERSION			"0.3"
#define	DEBUG_UART_BAUD_RATE			115200			// actual baudrate of Debug-Interface

// --------------------------------------------------------------------------------
// see board_xx.c
// -------------------------------------------------------------------------------- 
#define	LED1_ON	   		 			PORTD&=~0x10	// easyToWeb-LED function enable/disable
#define	LED1_OFF					PORTD|=0x10
#define	LED1_PIN		 			(PIND&0x10)
#define	LED1_PASSIVE	 			DDRD&=~0x10
#define	LED1_ACTIVE		 			DDRD|=0x10
#define	BOARD_MAX_1WIRE_DEVICES		2		// 1Wire-Interface definitions

// --------------------------------------------------------------------------------
// see max7301.c
// -------------------------------------------------------------------------------- 
#define MAX7301_ENABLE
#define MAX7301_CHECK_PARAMS

// --------------------------------------------------------------------------------
// see gpio.c
// -------------------------------------------------------------------------------- 
#define GPIO_ENABLE

// --------------------------------------------------------------------------------
// see avr_spi.c
// -------------------------------------------------------------------------------- 
#define SPI_ENABLE


#endif	// #define _PROJECT_INCLUDED_