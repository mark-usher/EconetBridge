// ************************************************************************************************
///
/// \file 			board.c
/// \brief			Basic hardware functions
///
/// \date	 		$LastChangedDate: 2007-03-14 10:33:07 +0100 (Mi, 14 Mrz 2007) $
/// \version 		$Rev: 638 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
/// \par History
///					1.) 30.07.2003 Version 2.00a
///					2.) 11.11.2003 Version 2.02
///						a.)	- add variable "second_counter"(32bit) and "day_counter"(16bit)
///								3.) 30.01.2004 Version 2.03
///						a.)	- functions memcpye() and memcpy2e() now with 16bit count
///					4.) 31.01.2004 Version 2.03
///						a.)	- new function memsete(), see memset
///					5.) 25.02.2004 Version 2.03
///						a.)	- new file structure, see also so util.c
///					6.) 31.05.2005 Version 2.0x
///						a.)	- etw_mc_spi_init renamed to hardware_spi_init()
///					7.) 09.06.2005 Version 2.0x
///						a.)	- rename the file etw_mc.c to hardware.c
///						--- History will not be continued, see subversion ---
///
// ************************************************************************************************

#include "project.h"		// Project configuration

// PORTA.x (address 0x1B)
// PORTB.x (address 0x18)
// PORTC.x (address 0x15)
// PORTD.x (address 0x12)
// the 1 Wire bus is connected to PORTD
// PORTD.7 (the data signal is bit 7)

#asm
    .equ __w1_port=0x12
    .equ __w1_bit=7
#endasm


#include <1wire.h>
#include <ds2430.h>
#include <stdio.h>
#include <string.h>
#include <sleep.h>
#include <delay.h>
#include <io.h>
#include "util.h"
#include "board.h"
#ifdef WEB_DEBUG
	#include "web_debug.h"
#endif
#ifdef WEB_DEBUG_MEASURE			// enable time-measure debug functions, see measure.c
	#include "measure.h"
#endif
#ifdef TCP_ENABLE
	#include "tcp.h"
#endif
#ifdef DEVICE_PPP
	#include "ppp.h"
#endif
#ifdef DATAFLASH_ENABLE
	#include "dataflash.h"
#endif	// #ifdef	DATAFLASH_ENABLE
#ifdef AT_DEVICE_BLUETOOTH			// AT-Interface = Bluetooth
	#include "bluetooth.h"
#endif
#include "max7301.h"
#include "gpio.h"
#include "adc.h"
#include "cs8900.h"
#include "device.h"


#ifdef BOARD_IP_FROM_EEPROM
eeprom unsigned char eeprom_ip[IP_ADR_SIZE] =IP_DEFAULT;
eeprom unsigned char eeprom_submask[IP_ADR_SIZE] =IP_SUBMASK_DEFAULT;
eeprom unsigned char eeprom_gateway[IP_ADR_SIZE] =IP_GATEWAY_DEFAULT;
#endif
#pragma regalloc-
unsigned int 	counter_10ms_16bit;    // generell counter with 10ms resolution
unsigned long 	second_counter=0;		// to handle seconds inside of board_timer1_compa  
unsigned int 	day_counter=378;		// 315 Tage seit 1.1.2003 (13.01.2004)
unsigned char 	board_reset_status=0;
//unsigned char 	romcodes_1wire[BOARD_MAX_1WIRE_DEVICES, 9];
#pragma regalloc+


#ifndef DS2430_PROM_SIZE
#define DS2430_PROM_SIZE	8
#endif
// ************************************************************************************************
/// \brief		Init the 1-wire-Interface and read the MAC-address from DS2430-PROM
///
///				The function checks the correctness of MAC-Address 
///				(10:00:aa or 00:50:c2 first 24bit of MAC-address)
/// \note		supports only ONE 1Wire-Device
/// @param[out]	romcode_buffer	- pointer to SRAM memory, see DS2430 functions
/// @param[out]	data_buffer		- pointer to data of DS2430-PROM
/// @param[in]	device			- number to address a device on 1Wire bus (0..254)
/// @retval		0	- ERROR - wrong MAC / empty MAC / wrong "device" number / read error from DS2430
/// @retval		1	- MAC ok, data inside of 'data_buffer'
// ************************************************************************************************
unsigned char board_read_mac(unsigned char *romcode_buffer, unsigned char *data_buffer)
{
unsigned char devices_1wire, device_mac;
unsigned char romcodes_1wire[BOARD_MAX_1WIRE_DEVICES, 9];
unsigned char new_data_buffer[DS2430_PROM_SIZE];
unsigned char sreg;

sreg = SREG;
#asm("cli");
devices_1wire = w1_search(0xf0, romcodes_1wire);	// search all 1Wire-Devices
if(devices_1wire>BOARD_MAX_1WIRE_DEVICES)
	devices_1wire = 0;		// return error (no devices found)
device_mac=devices_1wire;
while(device_mac)
	{
	device_mac--;
	if(romcode_buffer)
		memcpy(romcode_buffer, romcodes_1wire, sizeof(romcodes_1wire));
	if(romcodes_1wire[device_mac, 0] == DS2430_FAMILY_CODE)	// found DS2430A
		{
		if (!ds2430_read_appreg_block(&romcodes_1wire[device_mac,0], new_data_buffer, 0, DS2430_PROM_SIZE))
			devices_1wire = 0;
		else
			{
			if(data_buffer)
				memcpy(data_buffer, new_data_buffer, DS2430_PROM_SIZE);
			if(((new_data_buffer[0]!=0x10)||(new_data_buffer[1]!=0x00)||(new_data_buffer[2]!=0xaa)) &&
			   ((new_data_buffer[0]!=0x00)||(new_data_buffer[1]!=0x50)||(new_data_buffer[2]!=0xc2)))
			   	{
				devices_1wire = 0;
				}
			else
				break;
			}
		}
	}	// while(devices_mac)
SREG = sreg;
return devices_1wire;
}

// *********************************************************************************
/// \brief   toggle LED4
///
// *********************************************************************************
void board_toggle_led4(void)
{
if (LED4_PIN)
	LED4_ON;
else
	LED4_OFF;
}

// ************************************************************************************************
/// \brief		reads the 16bit counter value of Timer 1
///
/// \note		TCP stacks needs this function to init the first sequence number
/// @return		16bit value of TCNT1 register
// ************************************************************************************************
unsigned int board_timer1_counter(void)
{
return 0;
}

// ************************************************************************************************
/// \brief		Set a new value of "second_counter"
///
/// \note 		used inside of icmp modul
/// @param[in]	new_value - new second value
// ************************************************************************************************
void board_set_second_counter(unsigned long new_value)
{
}


// ************************************************************************************************
/// \brief		Inits the microcontroller of easyToWeb boards
///
///				enables the LEDs
///				config the memory interface
///				init debug interface
///				init watchdog
///				init sleep modes
///				init dataflash
// ************************************************************************************************
void board_init(void)
{
LED1_ON;		// LED1 (eTW-AVR PortD.4; eTW-ATmega32 PortD.0)
LED2_ON;		// LED2 (eTW-AVR PortD.5; eTW-ATmega32 PortD.1)
LED3_ON;		// LED3 (eTW-AVR PortD.6; eTW-ATmega32 not supported)
LED4_ON;		// LED4 (eTW-AVR PortD.7; eTW-ATmega32 not supported)
LED1_ACTIVE;		// LED1 (eTW-AVR DDRD.4; eTW-ATmega32 DDRD.0)
LED2_ACTIVE;		// LED2 (eTW-AVR DDRD.5; eTW-ATmega32 DDRD.1)
LED3_ACTIVE;		// LED3 (eTW-AVR DDRD.6; eTW-ATmega32 not supported)
LED4_ACTIVE;		// LED4 (eTW-AVR DDRD.7; eTW-ATmega32 not supported)

#ifdef BOARD_ETW_AVR
	XMCRA=SRL_6;	// Lower sector=0x1100..0xBfff / Upper sector=0xC000..0xffff
	MCUCR=0x80;	   	// Enable external Interface
	#if(_MCU_CLOCK_FREQUENCY_==16000000)
	XMCRA|=SRW11_XMCRA;			// + 2 wait upper
	#endif
	#if(_MCU_CLOCK_FREQUENCY_==7372800)
	MCUCR|=SRW10_MCUCR;			// one wait upper
	#endif
#endif	// #ifdef BOARD_ETW_AVR

#asm("wdr");			// Reset Watchdog
#ifdef WATCHDOG_ENABLE
	WDTCR=0x18;		 	// Watchdog Change Enable (WDTCR.WDCE=1)
	#ifdef WATCHDOG_16MS
	WDTCR=(0x08 | 0x00);	// Watchdog enable (WDTCR.WDE=1) and 16k Zyklus-16ms
	#endif
	#ifdef WATCHDOG_32MS
	WDTCR=(0x08 | 0x01);	// Watchdog enable (WDTCR.WDE=1) and 32k Zyklus-32ms
	#endif
	#ifdef WATCHDOG_65MS
	WDTCR=(0x08 | 0x02);	// Watchdog enable (WDTCR.WDE=1) and 64k Zyklus-65ms
	#endif
	#ifdef WATCHDOG_130MS
	WDTCR=(0x08 | 0x03);	// Watchdog enable (WDTCR.WDE=1) and 128k Zyklus-130ms
	#endif
	#ifdef WATCHDOG_260MS
	WDTCR=(0x08 | 0x04);	// Watchdog enable (WDTCR.WDE=1) and 256k Zyklus-260ms
	#endif
	#ifdef WATCHDOG_520MS
	WDTCR=(0x08 | 0x05);	// Watchdog enable (WDTCR.WDE=1) and 512k Zyklus-520ms
	#endif
	#ifdef WATCHDOG_1000MS
	WDTCR=(0x08 | 0x06);	// Watchdog enable (WDTCR.WDE=1) and 1024k Zyklus-1000ms
	#endif
	#ifdef WATCHDOG_2100MS
	WDTCR=(0x08 | 0x07);	// Watchdog enable (WDTCR.WDE=1) and 2048k Zyklus-2100ms
	#endif
#endif // #ifdef WATCHDOG_ENABLE
#asm("sei");	 		// Global enable interrupts
}

#ifdef DEVICE_CS8900
// ************************************************************************************************
/// \brief		Reads the MAC address from DS2430
///
// ************************************************************************************************
void board_init_mac_address(void)
{
unsigned char ds2430_buffer[DS2430_PROM_SIZE];

if (board_read_mac(0x0, ds2430_buffer))
	{
	memcpy(mac_address, ds2430_buffer, sizeof(mac_address));
	cs8900_set_mac(mac_address);
	}
}
#endif	// #ifdef DEVICE_CS8900


#ifdef IP_ENABLE
#ifdef BOARD_IP_FROM_DS2430
// ************************************************************************************************
/// \brief		Calculates XOR-Checksum of an array
///
/// @param[in]	data - pointer to data in SRAM
/// @param[in]	size - size
///	@return		XOR-checksum
// ************************************************************************************************
unsigned char board_calc_xor_checksum(unsigned char* data, unsigned char size)
{
unsigned char checksum=0;

while (size)
	{
	checksum ^= *data;
	data++;
	size--;
	}
return checksum;
}


// ************************************************************************************************
/// \brief		Reads the IP addresses from DS2430A
///
///	@retval		0 - error
/// @retval		1 - success
// ************************************************************************************************
unsigned char board_load_ip_from_ds2430(unsigned char* ip_temp, unsigned char* submask_temp, unsigned char* gateway_temp)
{
unsigned char return_value=0;
unsigned char devices_1wire;
unsigned char romcodes_1wire[BOARD_MAX_1WIRE_DEVICES, 9];
unsigned char data_buffer[IP_ADR_SIZE*3+1];	// 1 extra Byte for checksum
unsigned char sreg_temp;

sreg_temp = SREG;
#asm("cli");
devices_1wire = w1_search(0xf0, romcodes_1wire);	// search all 1Wire-Devices
if (devices_1wire && romcodes_1wire[0,0]==DS2430_FAMILY_CODE)
	if (ds2430_read_block(romcodes_1wire[0], data_buffer, 0, 3*IP_ADR_SIZE+1))
		if (data_buffer[3*IP_ADR_SIZE] == board_calc_xor_checksum(data_buffer, 3*IP_ADR_SIZE))
			{
			memcpy(ip_temp, 	 data_buffer, 	  			IP_ADR_SIZE);
			memcpy(submask_temp, data_buffer+IP_ADR_SIZE, 	IP_ADR_SIZE);
			memcpy(gateway_temp, data_buffer+2*IP_ADR_SIZE, IP_ADR_SIZE);
			return_value = 1;
			}
SREG = sreg_temp;
return return_value;
}


// ************************************************************************************************
/// \brief		Writes the IP addresses to DS2430A
///
///	@retval		0 - error.
/// @retval		1 - success
// ************************************************************************************************
unsigned char board_write_ip2_ds2430(unsigned char* ip_temp, unsigned char* submask_temp, unsigned char* gateway_temp)
{
unsigned char return_value=0;
unsigned char devices_1wire;
unsigned char romcodes_1wire[BOARD_MAX_1WIRE_DEVICES, 9];
unsigned char data_buffer[IP_ADR_SIZE*3+1];	// 1 extra Byte for checksum
unsigned char sreg_temp;

sreg_temp = SREG;
#asm("cli");
devices_1wire = w1_search(0xf0, romcodes_1wire);	// search all 1Wire-Devices
if (devices_1wire && romcodes_1wire[0,0]==DS2430_FAMILY_CODE)
	{
	memcpy(data_buffer, 			  ip_temp, 	    IP_ADR_SIZE);
	memcpy(data_buffer+IP_ADR_SIZE,   submask_temp, IP_ADR_SIZE);
	memcpy(data_buffer+2*IP_ADR_SIZE, gateway_temp, IP_ADR_SIZE);
	data_buffer[3*IP_ADR_SIZE] = board_calc_xor_checksum(data_buffer, 3*IP_ADR_SIZE);
	return_value = ds2430_write_block(romcodes_1wire[0], data_buffer, 0, 3*IP_ADR_SIZE+1);
	}
SREG = sreg_temp;
return return_value;
}
#endif	// #ifdef BOARD_IP_FROM_DS2430


// ************************************************************************************************
/// \brief		Reads the IP addresses from EEPROM or DS2430, see ip_address in ip.c,
///
///	@retval		0 - error. ip_address not modified
/// @retval		1 - success
// ************************************************************************************************
unsigned char board_load_ip_addresses(unsigned char* ip_temp, unsigned char* submask_temp, unsigned char* gateway_temp)
{
#ifdef BOARD_IP_FROM_EEPROM   
util_memcpye(ip_temp, 	 	 eeprom_ip, 	 IP_ADR_SIZE);
util_memcpye(submask_temp,   eeprom_submask, IP_ADR_SIZE);
util_memcpye(gateway_temp, 	 eeprom_gateway, IP_ADR_SIZE);
return 1;
#endif
#ifdef BOARD_IP_FROM_DS2430   
return board_load_ip_from_ds2430(ip_temp, submask_temp, gateway_temp);
#endif
return 0;
}


// ************************************************************************************************
/// \brief		Save the IP addresses to DS2430 or EEPROM
///
///	@retval		0 - error
/// @retval		1 - success
// ************************************************************************************************
unsigned char board_store_ip_addresses(unsigned char* ip_temp, unsigned char* submask_temp, unsigned char* gateway_temp)
{
#ifdef BOARD_IP_FROM_EEPROM
util_memcpy2e(eeprom_ip, 	  ip_temp, 	  	IP_ADR_SIZE);
util_memcpy2e(eeprom_submask, submask_temp, IP_ADR_SIZE);
util_memcpy2e(eeprom_gateway, gateway_temp, IP_ADR_SIZE);
return 1;
#endif
#ifdef BOARD_IP_FROM_DS2430
return board_write_ip2_ds2430(ip_temp, submask_temp, gateway_temp);
#endif                
return 0;
}
#endif	// #ifdef IP_ENABLE
