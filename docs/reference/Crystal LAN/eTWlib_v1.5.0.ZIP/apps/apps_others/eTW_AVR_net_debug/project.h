// ************************************************************************************************
///
/// \file 			eTW_AVR_debug_test/project.h
/// \brief			Configuration of debug test example
///
/// \date	 		$LastChangedDate: 2007-03-06 08:50:49 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 591 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#ifndef _PROJECT_H_INCLUDED_
#define _PROJECT_H_INCLUDED_


// ================================================================================
// ==========================(     Debug macro     )===============================
// ================================================================================
#define DEBUG



// ================================================================================
// =======================(     Application macros     )===========================
// ================================================================================
// --------------------------------------------------------------------------------
// board.c
// -------------------------------------------------------------------------------- 
#define	LED1_ON		 		      		PORTD&=~0x10
#define	LED1_OFF		    	  		PORTD|=0x10
#define	LED1_PIN	    		  		(PIND&0x10)
#define	LED1_ACTIVE  					DDRD|=0x10
#define WATCHDOG_ENABLE					// enable the Watchdog function of MC
//#define WATCHDOG_16MS					// Watchdog with about 16ms timeout
//#define WATCHDOG_32MS					// Watchdog with about 32ms timeout
//#define WATCHDOG_65MS					// Watchdog with about 65ms timeout
//#define WATCHDOG_130MS				// Watchdog with about 130ms timeout
#define WATCHDOG_260MS					// Watchdog with about 260ms timeout
//#define WATCHDOG_520MS				// Watchdog with about 520ms timeout
//#define WATCHDOG_1000MS				// Watchdog with about 1000ms timeout
//#define WATCHDOG_2100MS				// Watchdog with about 2100ms timeout
#define BOARD_ETW_AVR
#define BOARD_IP_FROM_EEPROM

// --------------------------------------------------------------------------------
// USER IP-addresses for internet
// -------------------------------------------------------------------------------- 
#define IP_DEFAULT						{141, 57, 27, 151}	  	// our internet protocol (IP) address
#define IP_SUBMASK_DEFAULT				{255, 255, 252, 0}		// subnet mask
#define IP_GATEWAY_DEFAULT				{141, 57, 24, 3}		// standard gateway




// ================================================================================
// =========================(     eTWlib macros     )==============================
// ================================================================================
// --------------------------------------------------------------------------------
// debug.c
// -------------------------------------------------------------------------------- 
#define DEBUG_CMD_BUFFERSIZE		  	80				// size of debug-command-buffer
#define DEBUG_PROJECT_NAME				"Debug-Test-App"

// --------------------------------------------------------------------------------
// debug_driver.c
// -------------------------------------------------------------------------------- 
#define DEBUG_UPLINK_UDP				// debug output via web
#define DEBUG_DEFINE_PUTCHAR			// printf() can be used for debug output
#define _ALTERNATE_PUTCHAR_
#define DEBUG_SERVER_IP					{141, 57, 27, 182}
#define DEBUG_LOCAL_PORT				4107

// --------------------------------------------------------------------------------
// Miscellaneous network debug function
// -------------------------------------------------------------------------------- 
#ifdef DEBUG
	#define WEB_DEBUG							// enable web debug functions, see web_debug.c
#endif

// --------------------------------------------------------------------------------
// Internet Protocol (ip.c)
// -------------------------------------------------------------------------------- 
#define IP_ENABLE					// enable the IP-Protocol
#ifdef DEBUG
	#define WEB_DEBUG_IP			// enable IP debug functions, see ip.c
#endif

// --------------------------------------------------------------------------------
// Ethernet (ethernet.c)
// -------------------------------------------------------------------------------- 
#define ETHERNET_ENABLE				// enable the ETHERNET-Protocol
#ifdef DEBUG
	#define WEB_DEBUG_ETHERNET		// enable ETHERNET debug functions, see ethernet.c
#endif

// --------------------------------------------------------------------------------
// Device (CS8900, PPP and so on) definitions
// -------------------------------------------------------------------------------- 
#define DEVICE_CS8900				// switch on the CS8900 device 

// --------------------------------------------------------------------------------
// Stack buffer functions (buffer.c)
// -------------------------------------------------------------------------------- 
#ifdef DEBUG
	#define WEB_DEBUG_BUFFER		// enable BUFFER debug functions, see buffer.c
#endif

// --------------------------------------------------------------------------------
// UDP (udp.c)
// -------------------------------------------------------------------------------- 
#define	UDP_ENABLE
#define	UDP_TX_DATA_SIZE				300		// the lowest size to handle BootP-Data
#define	UDP_RX_DATA_SIZE				12		// user receive data size
#define UDP_MAX_CONNECTIONS				1		// for BootP-Protokoll

// --------------------------------------------------------------------------------
// Ethernet Controller CS8900 (cs8900.c + cs8900_debug.c)
// -------------------------------------------------------------------------------- 
#define CS8900_MEMORY							// data to/from CS8900 over Memory-Bus
//#define CS8900_TX_PADDING_DISABLE				// disable Padding of TX-Frame if <60Byte, see "CS8900_PP_TX_CMD_WO"
//#define CS8900_IO_ADDRESS  		  	0xf000	// define the address to read/write IO of Ethernet
#define CS8900_TRAFFIC_RECEIVE_OUTPUT	DDRD|=0x40
#define CS8900_TRAFFIC_RECEIVE_H		PORTD|=0x40
#define CS8900_TRAFFIC_RECEIVE_L		PORTD&=~0x40

#define CS8900_TRAFFIC_TRANSMIT_OUTPUT	DDRD|=0x20
#define CS8900_TRAFFIC_TRANSMIT_H       PORTD|=0x20
#define CS8900_TRAFFIC_TRANSMIT_L		PORTD&=~0x20
#ifdef DEBUG
	#define CS8900_DEBUG						// enable low level CS8900 debug functions, see cs8900.c
#endif

// --------------------------------------------------------------------------------
// arp.c
// -------------------------------------------------------------------------------- 
#define ARP_ENABLE								// enable the ARP-Protocol
#define ARP_CACHE_SIZE					2		// sets the size of ARP-Cache
//#define ARP_CACHE_ENABLE						// Enable ARP-Cache
#ifdef DEBUG
	#define WEB_DEBUG_ARP						// enable ARP debug functions, see arp.c
#endif

// --------------------------------------------------------------------------------
// icmp.c
// -------------------------------------------------------------------------------- 
#define ICMP_ENABLE								// enable the ICMP-Protocol
#define ICMP_DATA_SIZE					1472  	// Linux uses this size
#ifdef DEBUG
	#define WEB_DEBUG_ICMP						// enable ICMP debug functions, see icmp.c
#endif

// --------------------------------------------------------------------------------
// System Timer
// --------------------------------------------------------------------------------
#define SYSTIMER_ENABLE
//#define SYSTIMER_CYCLE_1MS
#define SYSTIMER_CYCLE_10MS
//#define SYSTIMER_SOURCE_TIM0
//#define SYSTIMER_SOURCE_TIM1
//#define SYSTIMER_SOURCE_TIM2
#define SYSTIMER_SOURCE_TIM3

// --------------------------------------------------------------------------------
// System timer Delay & Callback functions
// --------------------------------------------------------------------------------
#define SYS_DELAY_ENABLE
#define SYS_DELAY_CHANNEL_SIZE     10

#endif	// #ifndef _PROJECT_H_INCLUDED_
