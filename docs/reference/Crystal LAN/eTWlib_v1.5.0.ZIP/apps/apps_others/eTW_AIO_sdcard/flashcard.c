// ************************************************************************************************
///
/// \file 			flashcard.c
/// \brief			Main file for Flashcard example
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Nico M�ding<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#include <io.h>
#include "board.h"
#include "cs8900_sleep.h"
#include "debug.h"
#include "web_debug.h"
#include "fat.h"
#include "sdcard.h"
#include "gpio.h"

/// \example 		flashcard.c
/// 				This example uses the SD-Card and the FAT module to interface the SD-Card 
///					module of the eTW-All-in-One Board.
///


#pragma regalloc-
// add your project-global variables here (better having none of them!)
#pragma regalloc+


// ************************************************************************************************
/// \brief		main routine to start the USER-Program
///
// ************************************************************************************************
void main(void)
{
unsigned char	counter_10ms_delay=20;
unsigned char	counter_10ms_old;

board_init();
cs8900_sleep_active();
#ifdef GPIO_ENABLE
gpio_init();
#endif
#ifdef SDCARD_ENABLE
sdc_init();
#endif //#ifdef SDCARD_ENABLE
#ifdef FAT_ENABLE
fat_init();
#endif
#ifdef DEBUG
debug_info(0x0);
#endif
counter_10ms_old = (unsigned char)counter_10ms_16bit;
while(1)
	{
	#asm("wdr");		// Reset Watchdog
	#ifdef SDCARD_ENABLE
	sdc_main();
	#endif 
	#ifdef FAT_ENABLE
	fat_main_process();
	#endif	// #ifdef FAT
	#ifdef DEBUG
	debug_main();
	#endif	// #ifdef DEBUG
	if (counter_10ms_old!=(unsigned char)counter_10ms_16bit)
		{
		counter_10ms_old=(unsigned char)counter_10ms_16bit;
		if (counter_10ms_delay>0)
			counter_10ms_delay--;
		else
			{		
			counter_10ms_delay=40;
			LED4_ACTIVE;
			if (LED4_PIN)
				LED4_ON;
			else
				LED4_OFF;
			}
		}
	}
}

