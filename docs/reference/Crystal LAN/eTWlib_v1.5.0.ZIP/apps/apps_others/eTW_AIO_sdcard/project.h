// ************************************************************************************************
///
/// \file 			eTW_AIO_sdcard/project.h
/// \brief			Configuration of sdcard example for eTW_AIO
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#ifndef _PROJECT_INCLUDED_
#define _PROJECT_INCLUDED_

// --------------------------------------------------------------------------------
// USER Global Module definitions
// --------------------------------------------------------------------------------
#define BOARD_ETW_AVR		// enable easyToWeb-AVR Board
#define FAT_ENABLE		 	// enable Module1 Funktionen
#define SDCARD_ENABLE		// enable Module1 Funktionen
#define DEBUG				// main macro to enable/disable ALL Debug functions
#define WEB_DEBUG			// main macro to enable/disable ALL Debug functions


// --------------------------------------------------------------------------------
// debug_io.c & debug.c
// --------------------------------------------------------------------------------
#define DEBUG_UPLINK_UART0
#define DEBUG_DEFINE_PUTCHAR			// printf() can be used for debug output
#define DEBUG_UART_BAUD_RATE			115200
#define DEBUG_CMD_BUFFERSIZE		  	80				// size of debug-command-buffer
#define DEBUG_PROJECT_NAME				"eTW_AIO_SDcard"


// --------------------------------------------------------------------------------
// sdcard.c
// --------------------------------------------------------------------------------
#define ETW_AIO_SDC_IN_SLOT1
//#define ETW_AIO_SDC_IN_SLOT2
#define SDCARD_DEBUG
#define SDCARD_MMC_COMPATIBILITY
#define SDC_HW_DETECT_ENABLE			// enables hardware detection
#define POLL_BUSY_FLAG_SPI				(SPSR & 0x80)
#define SHIFT_REGISTER_SPI	   			SPDR
#ifdef ETW_AIO_SDC_IN_SLOT1
	#define SDC_CHIP_SELECT_ACTIV		DDRB|=0x40
	#define SDC_CHIP_SELECT_LOW			PORTB&=~0x40
	#define SDC_CHIP_SELECT_HIGH		PORTB|=0x40
	// init card detection input
	#define SDC_INIT_CARD_DETECTION		max7301_port_config(0, 23, 0x02) 	// set port SDC_IOx on device 0 as input
	#define SDC_POLL_CARD_DETECTION		(max7301_read_bit(0, 23)==0)		// low = card inserted / high = without card
	// init write protection input
	#define SDC_INIT_WP_DETECTION		max7301_port_config(0, 22, 0x02)	// set port SDC_IOx on device 0 as input
	#define SDC_POLL_WP_DETECTION   	(max7301_read_bit(0, 22)==0)		// low = unlocked / high = locked
#endif
#ifdef ETW_AIO_SDC_IN_SLOT2
	#define SDC_CHIP_SELECT_ACTIV		DDRB|=0x80
	#define SDC_CHIP_SELECT_LOW			PORTB&=~0x80
	#define SDC_CHIP_SELECT_HIGH		PORTB|=0x80
	// init card detection input
	#define SDC_INIT_CARD_DETECTION		max7301_port_config(0, 11, 0x02) 	// set port SDC_IOx on device 0 as input
	#define SDC_POLL_CARD_DETECTION		(max7301_read_bit(0, 11)==0)		// low = card inserted / high = without card
	// init write protection input
	#define SDC_INIT_WP_DETECTION		max7301_port_config(0, 10, 0x02)	// set port SDC_IOx on device 0 as input
	#define SDC_POLL_WP_DETECTION   	(max7301_read_bit(0, 10)==0)		// low = unlocked / high = locked
#endif

// --------------------------------------------------------------------------------
// fat.c
// --------------------------------------------------------------------------------
#define FAT_DEBUG

// --------------------------------------------------------------------------------
// crc.c
// --------------------------------------------------------------------------------
#ifdef SDCARD_ENABLE
	#define CRC16_ENABLE
#endif
#define CRC16_LOOKUP_FLASH
//#define CRC16_LOOKUP_RAM
//#define CRC16_POLYNOM               	0x1021

// --------------------------------------------------------------------------------
// max7301.c
// --------------------------------------------------------------------------------
#ifdef SDCARD_ENABLE
	#define MAX7301_ENABLE
#endif
#define MAX7301_DEBUG
#define MAX7301_CHECK_PARAMS			// if defined, function parameters will be checked for validity


// --------------------------------------------------------------------------------
// gpio.c
// --------------------------------------------------------------------------------
#ifdef SDCARD_ENABLE
	#define GPIO_ENABLE
#endif
#define GPIO_DEBUG


// --------------------------------------------------------------------------------
// avr_spi.c
// --------------------------------------------------------------------------------
#ifdef SDCARD_ENABLE
	#define SPI_ENABLE
#endif

// --------------------------------------------------------------------------------
// board_xx.c
// --------------------------------------------------------------------------------
#define	LED4_ON			 				PORTD&=~0x80
#define	LED4_OFF						PORTD|=0x80
#define	LED4_PIN						(PIND&0x80)
#define	LED4_PASSIVE						DDRD&=~0x80
#define	LED4_ACTIVE						DDRD|=0x80

#define	LED2_ON			 				PORTD&=~0x20
#define	LED2_OFF						PORTD|=0x20
#define	LED2_PIN						(PIND&0x20)
#define	LED2_PASSIVE						DDRD&=~0x20
#define	LED2_ACTIVE						DDRD|=0x20

#endif	// #ifndef _PROJECT_INCLUDED_