// ************************************************************************************************
///
/// \file 			eTW_AVR_debug_test/project.h
/// \brief			Configuration of debug test example
///
/// \date	 		$LastChangedDate: 2007-03-06 08:50:49 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 591 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#ifndef _PROJECT_H_INCLUDED_
#define _PROJECT_H_INCLUDED_

// --------------------------------------------------------------------------------
// Global Module Macros
// -------------------------------------------------------------------------------- 
#define DEBUG

// --------------------------------------------------------------------------------
// debug.c
// -------------------------------------------------------------------------------- 
#define DEBUG_CMD_BUFFERSIZE		  	80				// size of debug-command-buffer
#define DEBUG_PROJECT_NAME				"Debug-Test-App"

// --------------------------------------------------------------------------------
// debug_driver.c
// -------------------------------------------------------------------------------- 
#define DEBUG_UPLINK_UART0			// connected to debugUSB
//#define DEBUG_UPLINK_UART1			// connected to level shifter
//#define DEBUG_UPLINK_SPI_HW
//#define DEBUG_UPLINK_SPI_SW
//#define DEBUG_UPLINK_I2C_HW
//#define DEBUG_UPLINK_I2C_SW			// CVAVR min. v1.24.7 required!
#define DEBUG_DEFINE_PUTCHAR			// printf() can be used for debug output
#define DEBUG_DEFINE_PRINTF
#define DEBUG_PRINTF_BUFFERSIZE			30
#define DEBUG_UART_BAUD_RATE			115200
#define DEBUG_SPI_SCK_ACTIV      		DDRB|=0x02
#define DEBUG_SPI_SCK_HIGH       		PORTB|=0x02
#define DEBUG_SPI_SCK_LOW        		PORTB&=~0x02
#define DEBUG_SPI_MOSI_ACTIV     		DDRB|=0x04
#define DEBUG_SPI_MOSI_HIGH      		PORTB|=0x04
#define DEBUG_SPI_MOSI_LOW       		PORTB&=~0x04
#define DEBUG_SPI_MISO_PASSIV    		DDRB&=~0x08
#define DEBUG_SPI_MISO_PULLUP      		PORTB|=0x08
#define DEBUG_SPI_MISO_PIN       		((PINB&0x08)!=0)
#define	DEBUG_SPI_CS_ACTIV				DDRB|=0x01
#define DEBUG_SPI_CS_HIGH				PORTB|=0x01
#define DEBUG_SPI_CS_LOW				PORTB&=~0x01
#define	DEBUG_I2C_SCL_ACTIV				DDRD|=0x01
#define	DEBUG_I2C_SCL_PASSIV			DDRD&=~0x01
#define	DEBUG_I2C_SCL_LOW				PORTD&=~0x01


// --------------------------------------------------------------------------------
// board_xx.c
// -------------------------------------------------------------------------------- 
#define	LED1_ON		 		      		PORTD&=~0x10
#define	LED1_OFF		    	  		PORTD|=0x10
#define	LED1_PIN	    		  		(PIND&0x10)
#define	LED1_ACTIVE  					DDRD|=0x10
#define WATCHDOG_ENABLE					// enable the Watchdog function of MC
//#define WATCHDOG_16MS					// Watchdog with about 16ms timeout
//#define WATCHDOG_32MS					// Watchdog with about 32ms timeout
//#define WATCHDOG_65MS					// Watchdog with about 65ms timeout
//#define WATCHDOG_130MS				// Watchdog with about 130ms timeout
#define WATCHDOG_260MS					// Watchdog with about 260ms timeout
//#define WATCHDOG_520MS				// Watchdog with about 520ms timeout
//#define WATCHDOG_1000MS				// Watchdog with about 1000ms timeout
//#define WATCHDOG_2100MS				// Watchdog with about 2100ms timeout
#define BOARD_ETW_AVR

#endif	// #ifndef _PROJECT_H_INCLUDED_