// ************************************************************************************************
///
/// \file 			dbg_test.c
/// \brief			Main file for debug-test example
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"

#include <io.h>
#include <delay.h>
#include <stdio.h>
#include "board.h"
#include "debug.h"
#ifdef DEBUG_UPLINK_I2C_SW
	// the I2C bus is connected to PORTD
	// the SDA signal is bit 1
	// the SCL signal is bit 0
	#asm
		.equ __i2c_port=0x12 
	    .equ __sda_bit=1
	    .equ __scl_bit=0
	#endasm
	#include <i2c.h>
#endif	// #ifdef DEBUG_UPLINK_I2C_SW


/// \example 		dbg_test.c
/// 				This example demonstates the use of the debug interface over 
///					various interfaces
///

#if (__CODEVISIONAVR__ >= 1253)
	#define EXAMPLE_DEBUG
	
	#ifdef EXAMPLE_DEBUG
	#define EXAMPLE_DBG_PRINTF(...)     {	if (omron_debug_flag) {		\
											putsf("EXAMPLE");          \
											printf(__VA_ARGS__)\
											} \
										} while (0)
	#else
	#define EXAMPLE_DBG_PRINTF(...)     {	} while (0)
	#endif	// #ifdef EXAMPLE_DEBUG
#endif	// #if (__CODEVISIONAVR__ >= 1253)


#pragma regalloc-
// add your project-global variables here (better having none of them!)
#pragma regalloc+

extern unsigned char debug_cmd_buffer[DEBUG_CMD_BUFFERSIZE];

// ************************************************************************************************
/// \brief		main routine to start the User-Program
///
// ************************************************************************************************
void main(void)
{
unsigned char	counter_10ms_delay=20;
unsigned char	counter_10ms_old;
#ifdef DEBUG
unsigned char*	debug_command;
#endif

board_init();
#ifdef DEBUG
debug_info(0x00);
#endif
#asm("sei");
counter_10ms_old = (unsigned char)counter_10ms_16bit;
while(1)
	{
	#asm("wdr");		// Reset Watchdog
	#ifdef DEBUG
	debug_command = debug_get_command();
	if (debug_command)
		{
		putsf("Debug-Cmd received!\r");
		putsf("ASCII:\r");
		debug_display_mem_ascii(debug_cmd_buffer, DEBUG_CMD_BUFFERSIZE, 0);
		putsf("Hex:\r");
		debug_display_mem_hex(debug_cmd_buffer, DEBUG_CMD_BUFFERSIZE, 0);
		}
	#endif
	if (counter_10ms_old != (unsigned char)counter_10ms_16bit)
		{
		counter_10ms_old = (unsigned char)counter_10ms_16bit;
		if (counter_10ms_delay > 0)
			counter_10ms_delay--;
		else
			{		
			counter_10ms_delay = 50;
			LED1_ACTIVE;
			if(LED1_PIN)
				LED1_ON;
			else
				LED1_OFF;
			}
		}
	}
}