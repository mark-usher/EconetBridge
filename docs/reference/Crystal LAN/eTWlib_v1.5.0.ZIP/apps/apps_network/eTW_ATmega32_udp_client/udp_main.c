// ************************************************************************************************
///
/// \file 			udp_main.c
/// \brief			Main file for ATmega32 UDP client
///
/// \date	 		$LastChangedDate: 2007-03-06 08:50:49 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 591 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <sleep.h> 
#include <stdio.h>
#include <string.h>

#include "board.h"
#include "udp.h"
#include "udp_client.h"
#include "server.h"
#include "debug.h"
#ifdef WEB_DEBUG
#include "web_debug.h"
#endif
                                                     
#pragma regalloc-
#pragma regalloc+                                                                          

//*********************************************************************************
// Description	: main routine to start the USER-Program
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void main(void)
{
unsigned char	counter_10ms_delay0=50;
unsigned char	counter_10ms_old; 

board_init();		// init microcontroller and interfaces
#ifdef WEB_DEBUG
web_debug_flag|=WEB_DEBUG_UDP_BIT;
#endif
udp_client_init();
#ifdef DEBUG
debug_info(0x00);
#ifdef UDP_ENABLE
if(udp_client_ok)
	putsf("UDP Client OK\r");
else
	putsf("UDP Client Error\r");
#endif	// #ifdef UDP_ENABLE
#endif
counter_10ms_old = (unsigned char)counter_10ms_16bit;
LED1_OFF;
LED2_OFF;
while(1)
	{
	#asm("wdr");	// Reset Watchdog
	idle();	   		// every time with IDLE-Mode
	udp_client_main();
	#ifdef DEBUG
	debug_main();
	#endif
	if (counter_10ms_old != (unsigned char)counter_10ms_16bit)
		{
		counter_10ms_old = (unsigned char)counter_10ms_16bit;
		if (counter_10ms_delay0 > 0)
			counter_10ms_delay0--;
		else
			{		
			//udp_client_send_message();	// sends cyclic with 400ms
			counter_10ms_delay0=100;
			if (LED1_PIN)
				LED1_ON;
			else
				LED1_OFF;
			}
		}
	}
}
                                                                                                         
                          
