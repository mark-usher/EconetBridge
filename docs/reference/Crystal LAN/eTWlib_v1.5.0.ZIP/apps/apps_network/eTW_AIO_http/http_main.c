// ************************************************************************************************
///
/// \file 			http_main.c
/// \brief			Main file for HTTP server example
///
/// \date	 		$LastChangedDate: 2006-12-22 16:55:38 +0100 (Fr, 22 Dez 2006) $
/// \version 		$Rev: 389 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <mega128.h> 
#include <sleep.h> 
#include <stdio.h>

#include "board.h"
#include "http_server.h"
#ifdef WEB_DEBUG
#include "debug.h"
#include "web_debug.h"
#endif
#include "server.h"
#include "ds2415.h"
#include "gpio.h"
#include "max7301.h"

#pragma regalloc-
#pragma regalloc+

//*********************************************************************************
// \brief    main routine to start the USER-Program
// \param    none
// \warning  none
//*********************************************************************************/
void main(void)
{
unsigned char	counter_10ms_delay0=20;
unsigned char	counter_10ms_old; 
TIME_DATE time_date;

board_init();		// init microcontroller and interfaces
#ifdef HTTP_ENABLE
server_init();
#endif
#ifdef DEBUG
debug_info(0x00);
	#ifdef HTTP_ENABLE
	if(server_ok)
		putsf("HTTP-Server OK\r");
	else
		putsf("HTTP-Server ERROR\r");
	#endif
#ifdef DS2415_DEBUG
if(ds2415_get_time_date(&time_date))
	ds2415_debug_print_time();
else
	printf("DS2415 error\r\n");
#endif	// #ifdef DS2415_DEBUG
#endif	// #ifdef DEBUG
counter_10ms_old = (unsigned char)counter_10ms_16bit;
LED1_OFF;		// PortD.4 LED1
while(1)
	{
	#asm("wdr");		// Reset Watchdog
	#ifdef HTTP_ENABLE
	server_main();
	#endif
	idle();				// every time with IDLE-Mode
	#ifdef DEBUG
	debug_main();
	#endif
	if (counter_10ms_old != (unsigned char)counter_10ms_16bit)
		{
		counter_10ms_old = (unsigned char)counter_10ms_16bit;
		if (counter_10ms_delay0 > 0)
			counter_10ms_delay0--;
		else
			{		
			counter_10ms_delay0=40;
			if (LED1_PIN)
				LED1_ON;
			else
				LED1_OFF;
			}
		}
	}
}
