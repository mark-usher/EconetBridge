// ************************************************************************************************
///
/// \file 			eTW_AVR_security/project.h
/// \brief			Configuration of security example
///
/// \date	 		$LastChangedDate: 2006-12-22 16:55:38 +0100 (Fr, 22 Dez 2006) $
/// \version 		$Rev: 389 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************
#ifndef _PROJECT_INCLUDED_
#define _PROJECT_INCLUDED_

// --------------------------------------------------------------------------------
// USER Global Module definitions
// -------------------------------------------------------------------------------- 
#define BOARD_ETW_AVR			// enable easyToWeb-AVR Board


// --------------------------------------------------------------------------------
// USER Global Debug definitions
// -------------------------------------------------------------------------------- 
#define DEBUG					// enable all global debug functions, see debug.c
//#define WEB_DEBUG				// enable web debug functions, see web_debug.c
//#define DEBUG_DATAFLASH			// enable dataflash functions , see dataflash_debug.c
//#define DEBUG_DATAFLASH_FILE	// enable file functions , see dataflash_file.c
//#define DEBUG_DATAFLASH_FILE_TIME	// enable file functions , see dataflash_file.c
//#define WEB_DEBUG_MEASURE		// enable time-measure debug functions, see measure.c
//#define CS8900_DEBUG		// enable low level CS8900 debug functions, see cs8900.c
//#define PPP_DEBUG			// enable low level PPP debug functions, see ppp.c
//#define WEB_DEBUG_MODEM		// enable low level MODEM debug functions, see modem.c
//#define WEB_DEBUG_BUFFER		// enable BUFFER debug functions, see buffer.c
//#define WEB_DEBUG_ETHERNET  	// enable ETHERNET debug functions, see ethernet.c
//#define WEB_DEBUG_ARP			// enable ARP debug functions, see arp.c
//#define WEB_DEBUG_IP			// enable IP debug functions, see ip.c
//#define WEB_DEBUG_ICMP			// enable ICMP debug functions, see icmp.c
//#define WEB_DEBUG_UDP			// enable UDP debug functions, see udp.c
//#define WEB_DEBUG_BOOTP			// enable BOOTP debug functions, see bootp.c
//#define TCP_DEBUG			// enable TCP debug functions, see tcp.c
//#define WEB_DEBUG_HTTP			// enable HTTP debug functions, see http_server.c
//#define WEB_DEBUG_FTP			// enable FTP debug functions, see ftp.c


// --------------------------------------------------------------------------------
// Debug-Interface
// -------------------------------------------------------------------------------- 
#define DEBUG_UPLINK_UART0			// select first UART
#define DEBUG_DEFINE_PUTCHAR		// printf() can be used for debug output
#define DEBUG_CMD_BUFFERSIZE		80				// size of debug-command-buffer
#define DEBUG_PROJECT_NAME			"eTW-AVR-Security-Test"
#define	DEBUG_UART_BAUD_RATE		115200			// actual baudrate of Debug-Interface

// --------------------------------------------------------------------------------
// USER easyToWeb-LED function enable/disable
// -------------------------------------------------------------------------------- 
#define	LED1_ON			PORTD&=~0x10
#define	LED1_OFF		PORTD|=0x10
#define	LED1_PIN		(PIND&0x10)
#define	LED1_PASSIVE		DDRD&=~0x10
#define	LED1_ACTIVE		DDRD|=0x10  
//#define BOARD_IP_FROM_EEPROM

// --------------------------------------------------------------------------------
// Security 
// -------------------------------------------------------------------------------- 
#define	MD5_ENABLE
#define	MD5_TEST_ENABLE
#define	HMAC_MD5_ENABLE
#define	HMAC_MD5_TEST_ENABLE
#define	SHA1_ENABLE
#define	SHA1_TEST_ENABLE
#define	HMAC_SHA1_ENABLE
#define	HMAC_SHA1_TEST_ENABLE
#define	DES_ENABLE
#define	DES_TEST_ENABLE
#define	DES_SPEED			// switch on the Speed Option


#endif	// #define _PROJECT_INCLUDED_

