// ************************************************************************************************
///
/// \file 			sec_main.c
/// \brief			Main file for Security example
///
/// \date	 		$LastChangedDate: 2007-03-06 08:50:49 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 591 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <mega128.h> 
#include <sleep.h> 
#include <string.h>
#include <stdio.h>
#include "board.h"
#include "md5_test.h"
#include "sha1_test.h"
#include "hmac_md5_test.h"
#include "hmac_sha1_test.h"
#include "des_test.h"
#include "debug.h"


#pragma regalloc-
#pragma regalloc+

//*********************************************************************************
// Description	: main routine to start the USER-Program
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void main(void)
{
unsigned char	counter_10ms_delay0=20;
unsigned char	counter_10ms_old; 
unsigned char	*new_command; 

debug_init();
board_init();
#ifdef DEBUG
debug_info(0x00);
#endif
counter_10ms_old = (unsigned char)counter_10ms_16bit;
LED1_OFF;		// PortD.4 LED1
LED2_OFF;		// PortD.5 LED2
LED3_OFF;		// PortD.6 LED3
LED4_OFF;		// PortD.7 LED4
while(1)
	{
	#asm("wdr");	// Reset Watchdog
	idle();	   		// every time with IDLE-Mode
	#ifdef DEBUG
	new_command=debug_get_command();
	if (new_command)
		{
		#ifdef	MD5_TEST_ENABLE
		md5_test_cmd(new_command);
		#endif
		#ifdef	SHA1_TEST_ENABLE
		sha1_test_cmd(new_command);
		#endif
		#ifdef	HMAC_MD5_TEST_ENABLE
		hmac_md5_test_cmd(new_command);
		#endif
		#ifdef	HMAC_SHA1_TEST_ENABLE
		hmac_sha1_test_cmd(new_command);
		#endif
		#ifdef	DES_TEST_ENABLE
		des_test_cmd(new_command);
		#endif
		if (strncmpf(new_command, "all", 3)==0)
			{
			#ifdef	MD5_TEST_ENABLE
			md5_test_suite();
			#endif
			#ifdef	HMAC_MD5_TEST_ENABLE
			hmac_md5_test_suite();
			#endif
			#ifdef	SHA1_TEST_ENABLE
			sha1_test_suite();
			#endif
			#ifdef	HMAC_SHA1_TEST_ENABLE
			hmac_sha1_test_suite();
			#endif
			#ifdef	DES_TEST_ENABLE
			des_test_suite();
			#endif
        	printf("ready..\r\n");
			}
		}
	#endif  // #ifdef DEBUG
	if (counter_10ms_old != (unsigned char)counter_10ms_16bit)
		{
		counter_10ms_old = (unsigned char)counter_10ms_16bit;
		if (counter_10ms_delay0 > 0)
			counter_10ms_delay0--;
		else
			{		
			counter_10ms_delay0=50;
			if(LED1_PIN)
				LED1_ON;	// PortD.4 LED1
			else
				LED1_OFF;	// PortD.4 LED1
			}
		}
	}
}


