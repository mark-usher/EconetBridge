// ************************************************************************************************
///
/// \file 			eTW_AVR_http_ftp/project.h
/// \brief			Configuration of http-ftp example
///
/// \date	 		$LastChangedDate: 2007-03-13 15:10:06 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 633 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#ifndef _PROJECT_INCLUDED_
#define _PROJECT_INCLUDED_

// --------------------------------------------------------------------------------
// USER Global Module definitions
// -------------------------------------------------------------------------------- 
#define BOARD_ETW_AVR			// enable easyToWeb-AVR Board

// --------------------------------------------------------------------------------
// USER Global Device (CS8900, PPP and so on) definitions
// -------------------------------------------------------------------------------- 
#define DEVICE_CS8900			// switch on the CS8900 device 

// --------------------------------------------------------------------------------
// USER Global Interface between CS8900 and MC definitions
// -------------------------------------------------------------------------------- 
#define CS8900_MEMORY			// data to/from CS8900 over Memory-Bus

// --------------------------------------------------------------------------------
// USER Global Ethernet-Protocol definitions
// -------------------------------------------------------------------------------- 
#define ETHERNET_ENABLE			// enable the ETHERNET-Protocol
#define ARP_ENABLE				// enable the ARP-Protocol
#define IP_ENABLE				// enable the IP-Protocol
#define ICMP_ENABLE				// enable the ICMP-Protocol (Ping)
#define TCP_ENABLE				// enable the TCP-Protocol
#define HTTP_ENABLE				// enable the HTTP-Protocol
#define FTP_ENABLE				// enable the FTP-Protocol

// --------------------------------------------------------------------------------
// USER Global Debug definitions
// -------------------------------------------------------------------------------- 
#define DEBUG					// enable all global debug functions, see debug.c
#define WEB_DEBUG				// enable web debug functions, see web_debug.c
//#define WEB_DEBUG_MEASURE		// enable time-measure debug functions, see measure.c
#define CS8900_DEBUG		// enable low level CS8900 debug functions, see cs8900.c
#define WEB_DEBUG_BUFFER		// enable BUFFER debug functions, see buffer.c
#define WEB_DEBUG_ETHERNET  	// enable ETHERNET debug functions, see ethernet.c
#define WEB_DEBUG_ARP			// enable ARP debug functions, see arp.c
#define WEB_DEBUG_IP			// enable IP debug functions, see ip.c
#define WEB_DEBUG_ICMP			// enable ICMP debug functions, see icmp.c
#define TCP_DEBUG			// enable TCP debug functions, see tcp.c
#define TCP_DEBUG_TESTBENCH	// enable TCP debug functions, see tcp_debug.c
#define WEB_DEBUG_HTTP			// enable HTTP debug functions, see http_server.c
#define WEB_DEBUG_FTP			// enable FTP debug functions, see ftp.c

// --------------------------------------------------------------------------------
// Debug-Interface
// -------------------------------------------------------------------------------- 
#define DEBUG_UPLINK_UART0			// select first UART
#define DEBUG_DEFINE_PUTCHAR		// printf() can be used for debug output
#define DEBUG_CMD_BUFFERSIZE		80				// size of debug-command-buffer
#define DEBUG_PROJECT_NAME			"eTW-HTTP-FTP-Server (eTW-Filesystem)"
#define DEBUG_PROJECT_VERSION		"0.9"
#define	DEBUG_UART_BAUD_RATE		115200			// actual baudrate of Debug-Interface

// --------------------------------------------------------------------------------
// USER IP-addresses for own subnet
// -------------------------------------------------------------------------------- 
#define IP_DEFAULT					{192, 168, 0, 2}		// our internet protocol (IP) address
#define IP_SUBMASK_DEFAULT			{255, 255, 255, 0}		// subnet mask
#define IP_GATEWAY_DEFAULT			{192, 168, 0, 100}		// standard gateway
                                          
// --------------------------------------------------------------------------------
// USER TCP-definitions
// -------------------------------------------------------------------------------- 
#define TCP_TX_BUFFER_SIZE			2000	// max. TCP-TX-Buffer data size
#define TCP_TX_SEGMENT_SIZE			500		// max. outgoing TCP data size
#define TCP_RX_BUFFER_SIZE			2000 	// max. TCP-RX-Buffer data size
#define TCP_RX_SEGMENT_SIZE			500		// max. incoming TCP data size
#define TCP_MAX_CONNECTIONS			4		// max. TCP connections
#define TCP_RETRY_TIMEOUT			5		// wait max. 5 x 50ms for an ACK (about 250msec.)
#define TCP_FIN_TIMEOUT				10		// wait max. 10 x 50ms for an ACK of a FIN (about 0.5 s)
#define TCP_PORT_FTP_DATA			20		// FTP Data Port
#define TCP_PORT_FTP_COMMAND		21		// FTP Command Port

// --------------------------------------------------------------------------------
// USER HTTP-definitions
// -------------------------------------------------------------------------------- 
#define HTTP_DEFAULT_FILE			"start.html"	// longest size of 20 signs

// --------------------------------------------------------------------------------
// USER FTP-definitions
// -------------------------------------------------------------------------------- 
#define	FTP_CRLF					"\r\n"			// define end of line code
#define	FTP_USER_ID					"etw"			//
#define	FTP_PASSWORD				"etw"			//
#define	FTP_ACCOUNT					"test"			//
//#define FTP_ACCOUNT_ENABLE		// enable account function

// --------------------------------------------------------------------------------
// USER dataflash.c and dataflash_debug.c
// -------------------------------------------------------------------------------- 
#define DATAFLASH_AT45DB081
#define	DATAFLASH_ENABLE			// dataflash enable
#define DEBUG_DATAFLASH		  		// enable dataflash functions , see dataflash_debug.c

// --------------------------------------------------------------------------------
// USER dataflash_file.c and dataflash_file_debug.c
// -------------------------------------------------------------------------------- 
#define	DATAFLASH_FILE_ENABLE			// dataflash file enable
#define FILE_HANDLE_COUNT	   		1	// count of possible open file-handler
#define DEBUG_DATAFLASH_FILE   	   		// enable file functions , see dataflash_file.c

// --------------------------------------------------------------------------------
// board_xx.c
// -------------------------------------------------------------------------------- 
#define	LED4_ON						PORTD&=~0x80
#define	LED4_OFF					PORTD|=0x80
#define	LED4_PIN					(PIND&0x80)
#define	LED4_PASSIVE				DDRD&=~0x80
#define	LED4_ACTIVE					DDRD|=0x80
#define	BOARD_IP_FROM_EEPROM

// --------------------------------------------------------------------------------
// see file webpage.h
// -------------------------------------------------------------------------------- 
#define WEBPAGE_DEFAULT_ENABLE	// with default webpage

// --------------------------------------------------------------------------------
// avr_spi.c
// -------------------------------------------------------------------------------- 
#define	SPI_ENABLE

#endif	// #define _PROJECT_INCLUDED_

