// ************************************************************************************************
///
/// \file 			http_ftp.c
/// \brief			Main file for HTTP/FTP example
///
/// \date	 		$LastChangedDate: 2006-12-22 16:55:38 +0100 (Fr, 22 Dez 2006) $
/// \version 		$Rev: 389 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration
#include <mega128.h> 
#include <sleep.h> 
#include <stdio.h>
#include "board.h"
#include "server.h"
#ifdef DEBUG
#include "debug.h"
#endif
#ifdef WEB_DEBUG_MEASURE		  			// enable time-measure debug functions, see measure.c
#include "measure.h"
#endif

#pragma regalloc-
#pragma regalloc+


//*********************************************************************************
// \brief    main routine to start the USER-Program
// \param    none
// \warning  none
//*********************************************************************************/
void main(void)
{
unsigned char	counter_10ms_delay0=20;
unsigned char	counter_10ms_old; 

board_init();		// init microcontroller and interfaces
server_init();
#ifdef DEBUG
debug_info(0x00);
if(server_ok)
	putsf("HTTP-FTP-Server OK\r");
else
	putsf("HTTP-FTP-Server ERROR\r");
#endif	// #ifdef WEB_DEBUG
counter_10ms_old = (unsigned char)counter_10ms_16bit;
LED1_OFF;		// PortD.4 LED1
LED2_OFF;		// PortD.5 LED2
LED3_OFF;		// PortD.6 LED3
LED4_OFF;		// PortD.7 LED4
while (1)
	{
	#ifdef WEB_DEBUG_MEASURE
	MEASURE_SETTIME(MEA_MAIN_S)
	measure_time();
	#endif
	#asm("wdr");	// Reset Watchdog
	server_main();
	//idle();	   		// every time with IDLE-Mode
	#ifdef DEBUG
	debug_main();
	#endif	// #ifdef WEB_DEBUG
	if(counter_10ms_old!=(unsigned char)counter_10ms_16bit)
		{
		counter_10ms_old=(unsigned char)counter_10ms_16bit;
		if(counter_10ms_delay0>0)
			counter_10ms_delay0--;
		else
			{		
			LED4_ACTIVE;
			counter_10ms_delay0=40;
			if(LED4_PIN)
				LED4_ON;
			else
				LED4_OFF;
			}
		}
	#ifdef WEB_DEBUG_MEASURE
	MEASURE_SETTIME(MEA_MAIN_E)
	measure_switch_time_frame();
	#endif
	}
}