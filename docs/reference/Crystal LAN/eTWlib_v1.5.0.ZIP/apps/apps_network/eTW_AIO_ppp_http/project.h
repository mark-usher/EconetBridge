// ************************************************************************************************
///
/// \file 			eTW_AIO_ppp_http/project.h
/// \brief			Configuration of ppp example for eTW_AIO
///
/// \date	 		$LastChangedDate: 2007-03-06 08:50:49 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 591 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#ifndef _PROJECT_INCLUDED_
#define _PROJECT_INCLUDED_

// --------------------------------------------------------------------------------
// USER Global Module definitions
// -------------------------------------------------------------------------------- 
#define BOARD_ETW_AVR			// enable easyToWeb-AVR Board
//#define BOARD_ETW_ATMEGA32	// enable easyToWeb-ATmega32 Board

// --------------------------------------------------------------------------------
// USER Global Device (CS8900, PPP and so on) definitions
// -------------------------------------------------------------------------------- 
#define DEVICE_PPP	   		// switch on the PPP device 

// --------------------------------------------------------------------------------
// USER Global Interface between AT-Interface and MC definitions
// -------------------------------------------------------------------------------- 
#define AT_DEVICE_MODEM				// AT-Interface = Modem
//#define AT_DEVICE_BLUETOOTH				// AT-Interface = Bluetooth

// --------------------------------------------------------------------------------
// USER Global Ethernet-Protocol definitions
// -------------------------------------------------------------------------------- 
#define IP_ENABLE				// enable the IP-Protocol
#define ICMP_ENABLE				// enable the ICMP-Protocol
#define TCP_ENABLE				// enable the TCP-Protocol
#define HTTP_ENABLE				// enable the HTTP-Protocol

// --------------------------------------------------------------------------------
// USER Global Debug definitions
// -------------------------------------------------------------------------------- 
#define DEBUG					// enable all global debug functions, see debug.c
#define WEB_DEBUG				// enable web debug functions, see web_debug.c
//#define WEB_DEBUG_MEASURE		// enable time-measure debug functions, see measure.c
//#define CS8900_DEBUG		// enable low level CS8900 debug functions, see cs8900.c
#define PPP_DEBUG			// enable low level PPP debug functions, see ppp.c
#define ATI_DEBUG			// enable low level AT-INTERFACE debug functions, see ati.c
#define WEB_DEBUG_BUFFER		// enable BUFFER debug functions, see buffer.c
//#define WEB_DEBUG_ETHERNET	// enable ETHERNET debug functions, see ethernet.c
//#define WEB_DEBUG_ARP			// enable ARP debug functions, see arp.c
#define WEB_DEBUG_IP			// enable IP debug functions, see ip.c
#define WEB_DEBUG_ICMP			// enable ICMP debug functions, see icmp.c
#define TCP_DEBUG			// enable TCP debug functions, see tcp.c
#define TCP_DEBUG_TESTBENCH	// enable TCP debug functions, see tcp_debug.c
#define WEB_DEBUG_HTTP			// enable HTTP debug functions, see meteolog_http.c

// --------------------------------------------------------------------------------
// Debug-Interface
// -------------------------------------------------------------------------------- 
#define DEBUG_UPLINK_UART0				// select first UART
#define DEBUG_DEFINE_PUTCHAR			// printf() can be used for debug output
#define DEBUG_CMD_BUFFERSIZE		  	80				// size of debug-command-buffer
#define DEBUG_PROJECT_NAME				"PPP-TCP-HTTP-Server"
#define	DEBUG_UART_BAUD_RATE			115200			// actual baudrate of Debug-Interface 

// --------------------------------------------------------------------------------
// ati.c
// -------------------------------------------------------------------------------- 
#define ATI_ANSWER_ENABLE_DEFAULT		
// #define ATI_RECEIVE_DEBUG

// --------------------------------------------------------------------------------
// see file ppp.c
// -------------------------------------------------------------------------------- 
#define IP_REMOTE_DEFAULT		{192, 168, 0, 13}
//#define PPP_SERVER_CLIENT_MODE	PPP_SERVER
#define PPP_MRU					512		// the Maximum-Receive-Unit in bytes
#define PPP_MTU			 		512		// the Maximum-Transmit-Unit in bytes

// --------------------------------------------------------------------------------
// USER IP-addresses for own subnet
// -------------------------------------------------------------------------------- 
#define IP_DEFAULT				{192, 168, 0, 2}		// our internet protocol (IP) address
#define IP_SUBMASK_DEFAULT		{255, 255, 255, 0}		// subnet mask
#define IP_GATEWAY_DEFAULT		{192, 168, 0, 100}		// standard gateway

// --------------------------------------------------------------------------------
// USER TCP-definitions
// -------------------------------------------------------------------------------- 
#define TCP_TX_BUFFER_SIZE		250		// max. TCP-TX-Buffer data size
#define TCP_TX_SEGMENT_SIZE		250		// max. outgoing TCP data size

#define TCP_RX_BUFFER_SIZE		500		// max. TCP-RX-Buffer data size
#define TCP_RX_SEGMENT_SIZE		250		// max. incoming TCP data size
#define TCP_MAX_CONNECTIONS		1		// max. TCP connections

// --------------------------------------------------------------------------------
// see board_xxx.c
// -------------------------------------------------------------------------------- 
#define	LED1_ON		 			PORTD&=~0x10
#define	LED1_OFF				PORTD|=0x10
#define	LED1_PIN				(PIND&0x10)
#define	LED1_PASSIVE				DDRD&=~0x10
#define	LED1_ACTIVE				DDRD|=0x10
#define	BOARD_MAX_1WIRE_DEVICES	2
#define	BOARD_IP_FROM_EEPROM

// --------------------------------------------------------------------------------
// see webpage.c
// -------------------------------------------------------------------------------- 
#define WEBPAGE_DEFAULT_ENABLE		// with default webpage

#endif	// #define _PROJECT_INCLUDED_

