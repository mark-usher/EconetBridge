// ************************************************************************************************
///
/// \file 			ppp_http.c
///
/// \brief			Main file for easyToWeb-PPP Sample Project
///
/// \date	 		$LastChangedDate: 2007-03-06 08:50:49 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 591 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br>	W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <stdio.h> 
#include <sleep.h> 
#include <mega128.h> 
#include "ppp.h"
#include "board.h"
#include "ppp_debug.h"
#include "server.h"
#include "cs8900_sleep.h"
#ifdef WEB_DEBUG_MEASURE			// enable time-measure debug functions, see measure.c
#include "measure.h"
#endif
#include "debug.h"

#pragma regalloc-
#pragma regalloc+

/// \example 		ppp_http.c
/// 				This example provides an http server over an ppp connection
///

//*********************************************************************************
// Description	: main routine to start the USER-Program
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void main(void)
{
unsigned char	counter_10ms_delay0=20;
unsigned char	counter_10ms_old; 

board_init();
cs8900_sleep_active();
#ifdef HTTP_ENABLE
server_init();
	#ifdef DEBUG
	if (server_ok)
		putsf("HTTP-Server OK\r");
	else
		putsf("HTTP-Server ERROR\r");
	#endif
#endif
counter_10ms_old = (unsigned char)counter_10ms_16bit;
while (1)
	{
	#asm("wdr");	// Reset Watchdog
	#ifdef HTTP_ENABLE
	server_main();
	#endif
	idle();	   		// every time with IDLE-Mode
	#ifdef DEBUG
	debug_main();
	#endif
	if(counter_10ms_old!=(unsigned char)counter_10ms_16bit)
		{
		counter_10ms_old=(unsigned char)counter_10ms_16bit;
		if(counter_10ms_delay0>0)
			counter_10ms_delay0--;
		else
			{		
			counter_10ms_delay0=40;
			if(LED1_PIN)
				LED1_ON;	// PortD.4 LED1
			else
				LED1_OFF;	// PortD.4 LED1
			}
		}
	}
}

/// @}
/// @}