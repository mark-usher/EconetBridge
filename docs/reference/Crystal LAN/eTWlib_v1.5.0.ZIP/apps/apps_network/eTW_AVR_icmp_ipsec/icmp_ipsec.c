// ************************************************************************************************
///
/// \file 			icmp_ipsec.c
/// \brief			Main file for IMPV-over-IPSec example
///
/// \date	 		$LastChangedDate: 2006-12-22 16:55:38 +0100 (Fr, 22 Dez 2006) $
/// \version 		$Rev: 389 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <mega128.h> 
#include <sleep.h> 
#include <stdio.h>

#include "board.h"
#include "device.h"
#include "buffer.h"
#include "ethernet.h"
#include "ipsec_sa.h"
#include "ipsec_sa_debug.h"
#include "debug.h"

#pragma regalloc-
#pragma regalloc+

//*********************************************************************************
// Description	: main routine to start the USER-Program
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
void main(void)
{
unsigned char	counter_10ms_delay0=20;
unsigned char	counter_10ms_old; 

board_init();		// init microcontroller and interfaces
board_init_mac_address();
board_load_ip_addresses(ip_address, ip_subnet_mask, ip_gateway);
buffer_clear();
if(DEVICE_INIT()==0)
	return;
#ifdef ARP_ENABLE
arp_request_timer(ARP_REQUEST_TIMER_START);			// start mode
#endif
#ifdef DEBUG
debug_info(0x00);
#endif
#if defined(WEB_DEBUG_IPSEC) && defined(IPSEC_ENABLE)
ipsec_sa_debug_new_spd(0xff);
#endif
counter_10ms_old = (unsigned char)counter_10ms_16bit;
LED1_OFF;		// PortD.4 LED1
LED2_OFF;		// PortD.5 LED2
LED3_OFF;		// PortD.6 LED3
LED4_OFF;		// PortD.7 LED4
while(1)
	{
	#asm("wdr");	// Reset Watchdog
	#ifdef ETHERNET_ENABLE
	ethernet_process();		// handle network and easyToWeb-stack events
	#endif
	buffer_process();		// handles the buffer management	#ifdef WEB_DEBUG
	#ifdef DEBUG
	debug_main();
	#endif
	if(counter_10ms_old!=(unsigned char)counter_10ms_16bit)
		{
		counter_10ms_old=(unsigned char)counter_10ms_16bit;
		if(counter_10ms_delay0>0)
			counter_10ms_delay0--;
		else
			{		
			counter_10ms_delay0=20;
			if(LED1_PIN)
				LED1_ON;	// PortD.4 LED1
			else
				LED1_OFF;	// PortD.4 LED1
			}
		}
	}
}

