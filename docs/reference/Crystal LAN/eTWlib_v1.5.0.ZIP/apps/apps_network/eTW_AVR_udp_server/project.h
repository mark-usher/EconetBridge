// ************************************************************************************************
///
/// \file 			eTW_AVR_udp_server/project.h
/// \brief			Configuration of udp server example
///
/// \date	 		$LastChangedDate: 2006-12-22 16:55:38 +0100 (Fr, 22 Dez 2006) $
/// \version 		$Rev: 389 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************
#ifndef _PROJECT_INCLUDED_
#define _PROJECT_INCLUDED_

// --------------------------------------------------------------------------------
// USER Global Module definitions
// -------------------------------------------------------------------------------- 
#define BOARD_ETW_AVR			// enable easyToWeb-AVR Board


// --------------------------------------------------------------------------------
// USER Global Device (CS8900, PPP and so on) definitions
// -------------------------------------------------------------------------------- 
#define DEVICE_CS8900			// switch on the CS8900 device 
//#define DEVICE_PPP	   		// switch on the PPP device 

// --------------------------------------------------------------------------------
// USER Global Interface between CS8900 and MC definitions
// -------------------------------------------------------------------------------- 
#define CS8900_MEMORY			// data to/from CS8900 over Memory-Bus
//#define CS8900_IO_PORT8		// data to/from CS8900 over Port-IO
//#define CS8900_IO_PORT16		// data to/from CS8900 over Port-IO
//#define CS8900_I2C_HW_8		// data to/from CS8900 over I2C-HW-Bus (about 400kHz)
//#define CS8900_I2C_HW_16		// data to/from CS8900 over I2C-HW-Bus (about 400kHz)
//#define CS8900_I2C_SW_8		// data to/from CS8900 over I2C-SW-Bus (about 100kHz)
//#define CS8900_I2C_SW_16		// data to/from CS8900 over I2C-SW-Bus (about 100kHz)

// --------------------------------------------------------------------------------
// USER Global Ethernet-Protocol definitions
// -------------------------------------------------------------------------------- 
#define ETHERNET_ENABLE			// enable the ETHERNET-Protocol
#define ARP_ENABLE			// enable the ARP-Protocol
#define IP_ENABLE		     	// enable the IP-Protocol
#define ICMP_ENABLE		     	// enable the ICMP-Protocol
#define UDP_ENABLE		     	// enable the UDP-Protocol

// --------------------------------------------------------------------------------
// USER Global Debug definitions
// -------------------------------------------------------------------------------- 
#define DEBUG					// enable all global debug functions, see debug.c
#define WEB_DEBUG				// enable web debug functions, see web_debug.c
//#define WEB_DEBUG_MEASURE		// enable time-measure debug functions, see measure.c
//#define CS8900_DEBUG		// enable low level CS8900 debug functions, see cs8900.c
//#define PPP_DEBUG			// enable low level PPP debug functions, see ppp.c
//#define WEB_DEBUG_MODEM		// enable low level MODEM debug functions, see modem.c
//#define WEB_DEBUG_BUFFER		// enable BUFFER debug functions, see buffer.c
//#define WEB_DEBUG_ETHERNET  	// enable ETHERNET debug functions, see ethernet.c
#define WEB_DEBUG_ARP			// enable ARP debug functions, see arp.c
//#define WEB_DEBUG_IP			// enable IP debug functions, see ip.c
#define WEB_DEBUG_ICMP			// enable ICMP debug functions, see icmp.c
#define WEB_DEBUG_UDP			// enable UDP debug functions, see udp.c

// --------------------------------------------------------------------------------
// Debug-Interface
// -------------------------------------------------------------------------------- 
#define DEBUG_UPLINK_UART0			// select first UART
#define DEBUG_DEFINE_PUTCHAR		// printf() can be used for debug output
#define DEBUG_PROJECT_NAME			"eTW-AVR UDP-Server"
#define	DEBUG_UART_BAUD_RATE		115200			// actual baudrate of Debug-Interface

// --------------------------------------------------------------------------------
// USER IP-addresses for own subnet
// -------------------------------------------------------------------------------- 
//#define IP_DEFAULT		       	{192, 168, 50, 216}		// our internet protocol (IP) address
//#define IP_SUBMASK_DEFAULT		{255, 255, 255, 0}		// subnet mask
//#define IP_GATEWAY_DEFAULT		{192, 168, 50, 160}		// standard gateway

// --------------------------------------------------------------------------------
// USER IP-addresses for internet
// -------------------------------------------------------------------------------- 
#define IP_DEFAULT		      	{141, 57, 27, 180}	  	// our internet protocol (IP) address
#define IP_SUBMASK_DEFAULT		{255, 255, 252, 0}		// subnet mask
#define IP_GATEWAY_DEFAULT		{141, 57, 24, 3}		// standard gateway


// --------------------------------------------------------------------------------
// USER UDP-definitions
// -------------------------------------------------------------------------------- 
#define	UDP_TX_DATA_SIZE		300		// the lowest size to handle BootP-Data
#define	UDP_RX_DATA_SIZE		300		// user receive data size
#define UDP_MAX_CONNECTIONS		1		// for BootP-Protokoll

// --------------------------------------------------------------------------------
// USER easyToWeb-LED function enable/disable
// -------------------------------------------------------------------------------- 
#define	LED1_ON		  			PORTD&=~0x10
#define	LED1_OFF   	  			PORTD|=0x10
#define	LED1_PIN	  			(PIND&0x10)
#define	LED1_PASSIVE	  			DDRD&=~0x10
#define	LED1_ACTIVE	 			DDRD|=0x10
#define	BOARD_IP_FROM_EEPROM

#endif	// #define _PROJECT_INCLUDED_