// *********************************************************************************
///
/// \file comm.h
///
/// communication module
///
/// \par Created
///					xx.xx.200x
/// \date	 		$LastChangedDate: 2006-06-07 15:28:49 +0200 (Mi, 07 Jun 2006) $
/// \version 		$Rev: 152 $
///	\author  		$Author: tkellner $
/// \par Copyright
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// *********************************************************************************
#ifndef _COMM_INCLUDED_
#define _COMM_INCLUDED_

#include "project.h"
#include "debug.h"  

       
#define COMM_DEVICE_MAX     2
typedef enum{
    COMM_DEVICE_COM_1,
    COMM_DEVICE_COM_2
} T_COMM_DEVICE;

typedef enum{
    COMM_CONN_IP_TO_SERIAL,
    COMM_CONN_SERIAL_TO_SERIAL
} T_COMM_CONN_TYPE;  


#pragma used+                                     
#ifdef COMM_DEBUG
#define COMM_DEBUG_BIT          0x01
extern eeprom unsigned char comm_debug_flag; 
#endif
        
void            comm_init(void);
void            comm_main(void); 
#ifdef COMM_DEBUG
void            comm_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode);
#endif
#pragma used-

#endif	// #ifndef _COMM_INCLUDED_