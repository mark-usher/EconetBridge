// ************************************************************************************************
///
/// \file 			eTW_AVR_NVT/project.h
/// \brief			Configuration of NVT example
///
/// \date	 		$LastChangedDate: 2007-04-16 09:16:49 +0200 (Mo, 16 Apr 2007) $
/// \version 		$Rev: 664 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************
#ifndef _PROJECT_INCLUDED_
#define _PROJECT_INCLUDED_

// --------------------------------------------------------------------------------
// USER Global Module definitions
// -------------------------------------------------------------------------------- 
#define BOARD_ETW_AVR		// enable easyToWeb-AVR Board
#define IP2SERIAL_ENABLE
#define DEBUG_IP2SERIAL
#define UART_ENABLE
#define COMM_ENABLE


// --------------------------------------------------------------------------------
// USER Global Device (CS8900, PPP and so on) definitions
// -------------------------------------------------------------------------------- 
#define DEVICE_CS8900			// switch on the CS8900 device 
//#define DEVICE_PPP	   		// switch on the PPP device 

// --------------------------------------------------------------------------------
// USER Global Interface between CS8900 and MC definitions
// -------------------------------------------------------------------------------- 
#define CS8900_MEMORY			// data to/from CS8900 over Memory-Bus
//#define CS8900_IO_PORT8		// data to/from CS8900 over Port-IO
//#define CS8900_IO_PORT16		// data to/from CS8900 over Port-IO
//#define CS8900_I2C_HW_8		// data to/from CS8900 over I2C-HW-Bus (about 400kHz)
//#define CS8900_I2C_HW_16		// data to/from CS8900 over I2C-HW-Bus (about 400kHz)
//#define CS8900_I2C_SW_8		// data to/from CS8900 over I2C-SW-Bus (about 100kHz)
//#define CS8900_I2C_SW_16		// data to/from CS8900 over I2C-SW-Bus (about 100kHz)

//#define CS8900_TX_PADDING_DISABLE	// disable Padding of TX-Frame if <60Byte, see "CS8900_PP_TX_CMD_WO"
//#define CS8900_IO_ADDRESS  		  	0xf000	// define the address to read/write IO of Ethernet

// --------------------------------------------------------------------------------
// USER Global Ethernet-Protocol definitions
// -------------------------------------------------------------------------------- 
#define ETHERNET_ENABLE			// enable the ETHERNET-Protocol
#define ARP_ENABLE				// enable the ARP-Protocol
#define IP_ENABLE				// enable the IP-Protocol
#define ICMP_ENABLE				// enable the ICMP-Protocol
//#define UDP_ENABLE				// enable the UDP-Protocol
//#define BOOTP_ENABLE			// enable the BOOTP-Protocol
#define TCP_ENABLE				// enable the TCP-Protocol
#define HTTP_ENABLE				// enable the HTTP-Protocol

// --------------------------------------------------------------------------------
// USER Global Debug definitions
// -------------------------------------------------------------------------------- 
#define DEBUG					// enable all global debug functions, see debug.c
#define WEB_DEBUG				// enable web debug functions, see web_debug.c
//#define WEB_DEBUG_MEASURE		// enable time-measure debug functions, see measure.c
#define CS8900_DEBUG		// enable low level CS8900 debug functions, see cs8900.c
//#define PPP_DEBUG			// enable low level PPP debug functions, see ppp.c
//#define WEB_DEBUG_MODEM		// enable low level MODEM debug functions, see modem.c
#define WEB_DEBUG_BUFFER		// enable BUFFER debug functions, see buffer.c
#define WEB_DEBUG_ETHERNET		// enable ETHERNET debug functions, see ethernet.c
#define WEB_DEBUG_ARP			// enable ARP debug functions, see arp.c
#define WEB_DEBUG_IP			// enable IP debug functions, see ip.c
#define WEB_DEBUG_ICMP			// enable ICMP debug functions, see icmp.c
//#define WEB_DEBUG_UDP			// enable UDP debug functions, see udp.c
//#define WEB_DEBUG_BOOTP			// enable BOOTP debug functions, see bootp.c
#define TCP_DEBUG			// enable TCP debug functions, see tcp.c
#define TCP_DEBUG_TESTBENCH	// enable TCP debug functions, see tcp_debug.c
#define WEB_DEBUG_HTTP			// enable HTTP debug functions, see http_server.c
//#define WEB_DEBUG_FTP			// enable FTP debug functions, see ftp.c  

// --------------------------------------------------------------------------------
// Debug-Interface
// -------------------------------------------------------------------------------- 
//#define DEBUG_UPLINK_UART1				// select first UART
#define DEBUG_UPLINK_I2C_HW
#define DEBUG_MAX_HANDLER               10
#define DEBUG_DEFINE_PUTCHAR			// printf() can be used for debug output
#define DEBUG_CMD_BUFFERSIZE		  	80				// size of debug-command-buffer
#define DEBUG_PROJECT_NAME				"eTW-AVR-NVT-Server"
#define	DEBUG_UART_BAUD_RATE			115200			// actual baudrate of Debug-Interface

#ifdef DEBUG_UPLINK_I2C_HW
#define	DEBUG_I2C_SCL_ACTIV			    DDRD.0=1
#define	DEBUG_I2C_SCL_PASSIV		    DDRD.0=0
#define	DEBUG_I2C_SCL_LOW			    PORTD.0=0
//#define	DEBUG_I2C_SCL_HIGH              PORTD.0=1
#endif   // #ifdef DEBUG_UPLINK_I2C_HW

// --------------------------------------------------------------------------------
// USER IP-addresses for own subnet
// -------------------------------------------------------------------------------- 
#define IP_DEFAULT						{192, 168, 168, 222}		// our internet protocol (IP) address
#define IP_SUBMASK_DEFAULT				{255, 255, 255, 0}		// subnet mask
#define IP_GATEWAY_DEFAULT				{192, 168, 168, 100}		// standard gateway

// --------------------------------------------------------------------------------
// USER IP-addresses for internet
// -------------------------------------------------------------------------------- 
//#define IP_DEFAULT					{141, 57, 27, 167}	  	// our internet protocol (IP) address
//#define IP_SUBMASK_DEFAULT			{255, 255, 252, 0}		// subnet mask
//#define IP_GATEWAY_DEFAULT			{141, 57, 24, 3}		// standard gateway

// --------------------------------------------------------------------------------
// USER TCP-definitions
// -------------------------------------------------------------------------------- 
#define TCP_TX_BUFFER_SIZE				480		// max. TCP-TX-Buffer data size
#define TCP_TX_SEGMENT_SIZE				250		// max. outgoing TCP data size

#define TCP_RX_BUFFER_SIZE				500		// max. TCP-RX-Buffer data size
#define TCP_RX_SEGMENT_SIZE				250		// max. incoming TCP data size

#define TCP_MAX_CONNECTIONS				3		// max. TCP connections

// --------------------------------------------------------------------------------
// USER UDP-definitions
// -------------------------------------------------------------------------------- 
#define	UDP_TX_DATA_SIZE				300		// the lowest size to handle BootP-Data
#define	UDP_RX_DATA_SIZE				12		// user receive data size
#define UDP_MAX_CONNECTIONS				1		// for BootP-Protokoll

// --------------------------------------------------------------------------------
// USER BootP-definitions
// -------------------------------------------------------------------------------- 
#define	BOOTP_TIMEOUT					1000	// 10 sec. timeout until wait of anwser from BootP-Server (max. 655,35 sec.)

// --------------------------------------------------------------------------------
// USER easyToWeb-LED function enable/disable
// -------------------------------------------------------------------------------- 
#define	LED1_ON	   		 				PORTD&=~0x10
#define	LED1_OFF						PORTD|=0x10
#define	LED1_PIN		 				PIND.4
#define	LED1_PASSIVE		 				DDRD&=~0x10
#define	LED1_ACTIVE		 				DDRD|=0x10

// --------------------------------------------------------------------------------
// USER CS8900-Mikrocontroller-Interface Traffic-Lines
// -------------------------------------------------------------------------------- 
#define CS8900_TRAFFIC_RECEIVE_OUTPUT	DDRD|=0x40
#define CS8900_TRAFFIC_RECEIVE_H		PORTD|=0x40
#define CS8900_TRAFFIC_RECEIVE_L		PORTD&=~0x40

#define CS8900_TRAFFIC_TRANSMIT_OUTPUT	DDRD|=0x20
#define CS8900_TRAFFIC_TRANSMIT_H       PORTD|=0x20
#define CS8900_TRAFFIC_TRANSMIT_L		PORTD&=~0x20

// --------------------------------------------------------------------------------
// see file arp.c
// -------------------------------------------------------------------------------- 
#define ARP_CACHE_SIZE					2		// sets the size of ARP-Cache
//#define ARP_CACHE_ENABLE			// Enable ARP-Cache

// --------------------------------------------------------------------------------
// see file icmp.c
// -------------------------------------------------------------------------------- 
#define ICMP_DATA_SIZE					1472  	// Linux uses this size

// --------------------------------------------------------------------------------
// see file webpage.c
// -------------------------------------------------------------------------------- 
#define WEBPAGE_DEFAULT_ENABLE		// with default webpage

// --------------------------------------------------------------------------------
// board_xx.c
// -------------------------------------------------------------------------------- 
#define	LED4_ON					 		PORTD&=~0x80
#define	LED4_OFF						PORTD|=0x80
#define	LED4_PIN						(PIND&0x80)
#define	LED4_PASSIVE						DDRD&=~0x80
#define	LED4_ACTIVE						DDRD|=0x80
#define	BOARD_IP_FROM_EEPROM
#define	BOARD_MAX_1WIRE_DEVICES			2

// --------------------------------------------------------------------------------
// USER Global Definitions For IP2SERIAL module
// --------------------------------------------------------------------------------
//#define IP2SERIAL_CONNECTION_MAX        2
#define IP2SERIAL_TCP_PORT_TELNET       23
#define IP2SERIAL_TCP_MAX_WINDOW_SIZE   128

// --------------------------------------------------------------------------------
// USER Global Definitions For Uart module
// --------------------------------------------------------------------------------                                                              
#define UART_DEBUG
#define UART_DEVICE0_ENABLE
//#define UART_DEVICE1_ENABLE
#define UART_RX_BUFFER_SIZE     TCP_TX_SEGMENT_SIZE
#define UART_TX_BUFFER_SIZE     TCP_RX_BUFFER_SIZE
#define UART_STATISTIC_ENABLE
#define UART_MODE_IRQ

// --------------------------------------------------------------------------------
// adc
// -------------------------------------------------------------------------------- 
#define ADC_ENABLE

// --------------------------------------------------------------------------------
// systimer
// --------------------------------------------------------------------------------                                                                                  
#define SYSTIMER_ENABLE
#define SYSTIMER_CYCLE_1MS
#define SYSTIMER_SOURCE_TIM3

#endif	// #define _PROJECT_INCLUDED_
