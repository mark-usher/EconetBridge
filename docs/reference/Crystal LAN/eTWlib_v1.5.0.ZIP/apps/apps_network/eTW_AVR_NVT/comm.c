// *********************************************************************************
///
/// \file comm.c
///
/// communication module
///
/// \par Created
///					xx.xx.200x
/// \date	 		$LastChangedDate: 2006-08-10 14:59:28 +0200 (Do, 10 Aug 2006) $
/// \version 		$Rev: 158 $
///	\author  		$Author: tkellner $
/// \par Copyright
///
/// Annotation: If keywords are not substituted by subversion, add property to file.
/// see http://svnbook.red-bean.com/en/1.1/ch07s02.html#svn-ch-7-sect-2.3 for details
///
// *********************************************************************************
#include "project.h"		// USER defines

#ifdef COMM_ENABLE
#ifndef UART_ENABLE
error "define UART_ENABLE first!"
#endif
#ifndef IP2SERIAL_ENABLE
error "define IP2SERIAL_ENABLE first!"
#endif
#include <stdio.h>
#include <string.h>
#include <io.h>
#include "uart.h"
#include "comm.h"
#include "board.h"
#include "nvt.h"


#ifdef COMM_DEBUG
eeprom unsigned char comm_debug_flag = 0x00;	// default: debug output off
#endif
                      
// *********************************************************************************
/// \brief                   check comm-device (uart-) availability
/// \param[in] comm_device   id of comm_device
/// \retval                  '0' unavailable
/// \retval                  '1' available
// *********************************************************************************
unsigned char comm_uart_available(unsigned char comm_device, unsigned char *uart_device)
{
#ifdef UART_DEVICE0_ENABLE
if(comm_device==COMM_DEVICE_COM_1)
    {
    if(uart_device)
        *uart_device = UART_DEV0;
    return 1;
    }
#else
if(comm_device==COMM_DEVICE_COM_1)
    return 0;
#endif
#ifdef UART_DEVICE1_ENABLE
if(comm_device==COMM_DEVICE_COM_2)
    {
    if(uart_device)
        *uart_device = UART_DEV1;
    return 1;
    }
#else
if(comm_device==COMM_DEVICE_COM_2)
    return 0;
#endif
return 0;
}


// *********************************************************************************
/// \brief
/// \param[in] Lva      comm_device
/// \retval
/// \retval
// *********************************************************************************
unsigned int comm_device_get_rx_count(unsigned char Lva)
{
if(comm_uart_available(Lva, &Lva))
    return uart_get_rx_count(Lva);
return 0;
}


// *********************************************************************************
/// \brief
/// \param[in] Lva      comm_device
/// \retval
// *********************************************************************************
unsigned int comm_device_get_tx_gap(unsigned char Lva)
{
if(comm_uart_available(Lva, &Lva))
    return uart_get_tx_gap(Lva);
return 0;
}


// *********************************************************************************
/// \brief                   read data from comm-device's uart buffer
/// \param[in] p_data        pointer to allocated sram
/// \param[in] comm_device   id of comm_device
/// \return                  size of data or '0' if error
// *********************************************************************************
unsigned int comm_device_read_data(unsigned char comm_device, unsigned char *p_data, unsigned int size)
{
unsigned char uart_no;

if(p_data==0x0)
    return 0;
if(comm_uart_available(comm_device, &uart_no) && (size!=0))
    {
    uart_read_block(uart_no, p_data, size);
    #ifdef COMM_DEBUG
    if(comm_debug_flag & COMM_DEBUG_BIT)
        printf("COMM comm_device_read_data(), rx %u from com%u\r\n", size, comm_device);
    #endif
    return size;
    }
else
    return 0;
}


// *********************************************************************************
/// \brief                   write to comm device's uart buffer
/// \param[in] p_data        pointer to data in sram
/// \param[in] size          size of data in sram to write to uart buffer
/// \param[in] comm_device   id of comm_device
// *********************************************************************************
unsigned int comm_device_write_data(unsigned char comm_device, unsigned char *p_data, unsigned int size)
{
unsigned char uart_no;

if(p_data==0x0)
    return 0;
if(comm_uart_available(comm_device, &uart_no))
    {
    uart_write_block(uart_no, p_data, size);
    #ifdef COMM_DEBUG
    if(comm_debug_flag & COMM_DEBUG_BIT)
        printf("COMM comm_device_write_data(), tx %u to com%u\r\n", size, comm_device);
    #endif
    return size;
    }
else
    return 0;
}


// *********************************************************************************
/// \brief				handles data received from tcp
/// \param[in] Lva		id of ip2serial connection
/// \param[in] p_data	pointer to data
/// \param[in] size 	size of data
// *********************************************************************************
void comm_ip2serial_rx_handler(unsigned char Lva, unsigned char* p_data, unsigned int size)
{

if(Lva==IP2SERIAL_CONNECTION_1)
    Lva = COMM_DEVICE_COM_1;
else if(Lva==IP2SERIAL_CONNECTION_2)
    Lva = COMM_DEVICE_COM_2;
else
    return;
if(!comm_uart_available(Lva, 0x0))
    return;
comm_device_write_data(Lva, p_data, size);
}


// *********************************************************************************
/// \brief				retrieves data for tcp transmit
/// \param[in] Lva		id of ip2serial connection
/// \param[in] p_data	pointer to data
/// \param[in] size 	size of data
// *********************************************************************************
void comm_ip2serial_tx_handler(unsigned char Lva, unsigned char* p_data, unsigned int size)
{
                
if(Lva==IP2SERIAL_CONNECTION_1)
    Lva = COMM_DEVICE_COM_1;
else if(Lva==IP2SERIAL_CONNECTION_2)
    Lva = COMM_DEVICE_COM_2;
else
    return;
if(!comm_uart_available(Lva, 0x0))
    return;
comm_device_read_data(Lva, p_data, size);    
}


// ************************************************************************************************
/// \brief      init the comm software module
/// \remarks    this function should be called once after reset
// ************************************************************************************************
void comm_init(void)
{
T_IP2SERIAL_STRUCT *p_struct;
unsigned char i;
#ifdef COMM_DEBUG
T_DEBUG_HANDLER_STRUCT p_struct;

p_struct.fp_handler = &comm_debug_handler;
p_struct.id_string = "comm-";
debug_register_handler(&p_struct);
if(comm_debug_flag & COMM_DEBUG_BIT)
    putsf("COMM comm_init \r");
#endif
// init ip2serial structures
for(i=0;i<IP2SERIAL_CONNECTION_MAX;i++)
	{
	p_struct = ip2serial_get_struct(i);
	p_struct->fp_buffer_write = &comm_ip2serial_rx_handler;
	p_struct->fp_buffer_read = &comm_ip2serial_tx_handler;
	p_struct->fp_buffer_get_rx_count = &comm_device_get_rx_count;
	p_struct->fp_buffer_get_tx_gap = &comm_device_get_tx_gap;
	}
uart_init();
}


#ifdef COMM_DEBUG
// *********************************************************************************
/// \brief                  debug command handler
/// \param[in] command      pointer to command string
/// \param[in] mode         mode of debug command
// *********************************************************************************
void comm_debug_handler(unsigned char *command, T_DEBUG_HANDLER_MODE mode)
{

if(mode==DEBUG_HANDLER_MODE_INFO)
    {
    printf("COMM_DEBUG");
	if(comm_debug_flag & COMM_DEBUG_BIT)
		putsf(" ON\r");
	else
		putsf(" OFF\r");
	}
else if(mode==DEBUG_HANDLER_MODE_HELP)
    {
//    comm_debug_cmd_list();
    // add output for 'help' command here
    }
else if(mode==DEBUG_HANDLER_MODE_SWITCH)
	{
	if(strncmpf(command, "comm", strlenf("comm"))==0)
	    {
    	comm_debug_flag ^= COMM_DEBUG_BIT;
        printf("COMM_DEBUG");
    	if (comm_debug_flag & COMM_DEBUG_BIT)
    		putsf(" ON\r");
    	else
    		putsf(" OFF\r");
	    }
	}
// if(mode==DEBUG_HANDLER_MODE_CMD)
else if(strncmpf(command, "status", 6)==0)
    {

	}
}
#endif   // #ifdef COMM_DEBUG
#endif   // #ifdef COMM_ENABLE
