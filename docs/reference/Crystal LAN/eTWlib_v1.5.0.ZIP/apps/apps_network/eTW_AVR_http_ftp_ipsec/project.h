// ************************************************************************************************
///
/// \file 			eTW_AVR_http_ftp_ipsec/project.h
/// \brief			Configuration of http-ftp-ipsec example
///
/// \date	 		$LastChangedDate: 2007-03-13 15:10:06 +0100 (Di, 13 Mrz 2007) $
/// \version 		$Rev: 633 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#ifndef _PROJECT_INCLUDED_
#define _PROJECT_INCLUDED_

// --------------------------------------------------------------------------------
// USER Global Module definitions
// -------------------------------------------------------------------------------- 
#define BOARD_ETW_AVR			// enable easyToWeb-AVR Board

// --------------------------------------------------------------------------------
// USER Global Device (CS8900, PPP and so on) definitions
// -------------------------------------------------------------------------------- 
#define DEVICE_CS8900			// switch on the CS8900 device 
//#define DEVICE_PPP	   		// switch on the PPP device 

// --------------------------------------------------------------------------------
// USER Global Interface between CS8900 and MC definitions
// -------------------------------------------------------------------------------- 
#define CS8900_MEMORY			// data to/from CS8900 over Memory-Bus
//#define CS8900_IO_PORT8		// data to/from CS8900 over Port-IO
//#define CS8900_IO_PORT16		// data to/from CS8900 over Port-IO
//#define CS8900_I2C_HW_8		// data to/from CS8900 over I2C-HW-Bus (about 400kHz)
//#define CS8900_I2C_HW_16		// data to/from CS8900 over I2C-HW-Bus (about 400kHz)
//#define CS8900_I2C_SW_8		// data to/from CS8900 over I2C-SW-Bus (about 100kHz)
//#define CS8900_I2C_SW_16		// data to/from CS8900 over I2C-SW-Bus (about 100kHz)

// --------------------------------------------------------------------------------
// USER Global Ethernet-Protocol definitions
// -------------------------------------------------------------------------------- 
#define ETHERNET_ENABLE			// enable the ETHERNET-Protocol
#define ARP_ENABLE				// enable the ARP-Protocol
#define IP_ENABLE				// enable the IP-Protocol
#define IPSEC_ENABLE			// enable the IPSEC-Protocol (Security)
#define ICMP_ENABLE				// enable the ICMP-Protocol (Ping)
//#define UDP_ENABLE				// enable the UDP-Protocol
//#define BOOTP_ENABLE			// enable the BOOTP-Protocol
#define TCP_ENABLE				// enable the TCP-Protocol
#define HTTP_ENABLE				// enable the HTTP-Protocol
#define HTTP_FILE_ENABLE		// enable the HTTP-Protocol with FILE Support
#define FTP_ENABLE				// enable the FTP-Protocol

// --------------------------------------------------------------------------------
// USER Global Debug definitions
// -------------------------------------------------------------------------------- 
#define DEBUG					// enable all global debug functions, see debug.c
#define WEB_DEBUG				// enable web debug functions, see web_debug.c
//#define WEB_DEBUG_MEASURE		// enable time-measure debug functions, see measure.c
#define CS8900_DEBUG		// enable low level CS8900 debug functions, see cs8900.c
//#define PPP_DEBUG			// enable low level PPP debug functions, see ppp.c
//#define WEB_DEBUG_MODEM		// enable low level MODEM debug functions, see modem.c
#define WEB_DEBUG_BUFFER		// enable BUFFER debug functions, see buffer.c
#define WEB_DEBUG_ETHERNET  	// enable ETHERNET debug functions, see ethernet.c
#define WEB_DEBUG_ARP			// enable ARP debug functions, see arp.c
#define WEB_DEBUG_IP			// enable IP debug functions, see ip.c
#define WEB_DEBUG_IPSEC			// enable IPSec debug functions, see ipsec.c
#define WEB_DEBUG_ICMP			// enable ICMP debug functions, see icmp.c
//#define WEB_DEBUG_UDP			// enable UDP debug functions, see udp.c
//#define WEB_DEBUG_BOOTP			// enable BOOTP debug functions, see bootp.c
#define TCP_DEBUG			// enable TCP debug functions, see tcp.c
#define TCP_DEBUG_TESTBENCH	// enable TCP debug functions, see tcp_debug.c
#define WEB_DEBUG_HTTP			// enable HTTP debug functions, see http_server.c
#define WEB_DEBUG_FTP			// enable FTP debug functions, see ftp.c

// --------------------------------------------------------------------------------
// Debug-Interface
// -------------------------------------------------------------------------------- 
#define DEBUG_UPLINK_UART0			// select first UART
#define DEBUG_DEFINE_PUTCHAR		// printf() can be used for debug output
#define DEBUG_CMD_BUFFERSIZE		80				// size of debug-command-buffer
#define DEBUG_PROJECT_NAME			"eTW-IPSec-HTTP-FTP-Server (eTW-Filesystem)"
#define	DEBUG_UART_BAUD_RATE		115200			// actual baudrate of Debug-Interface


// --------------------------------------------------------------------------------
// USER IP-addresses for own subnet
// -------------------------------------------------------------------------------- 
#define IP_DEFAULT				{192, 168, 50, 216}		// our internet protocol (IP) address
#define IP_SUBMASK_DEFAULT		{255, 255, 255, 0}		// subnet mask
#define IP_GATEWAY_DEFAULT		{192, 168, 50, 160}		// standard gateway

                                          
// --------------------------------------------------------------------------------
// USER IP-addresses for internet
// -------------------------------------------------------------------------------- 
//#define IP_DEFAULT				{141, 57, 27, 167}	  	// our internet protocol (IP) address
//#define IP_SUBMASK_DEFAULT		{255, 255, 252, 0}		// subnet mask
//#define IP_GATEWAY_DEFAULT		{141, 57, 24, 3}		// standard gateway 

// --------------------------------------------------------------------------------
// USER TCP-definitions
// -------------------------------------------------------------------------------- 
#define TCP_TX_BUFFER_SIZE		500		// max. TCP-TX-Buffer data size
#define TCP_TX_SEGMENT_SIZE		250		// max. outgoing TCP data size
#define TCP_RX_BUFFER_SIZE		500		// max. TCP-RX-Buffer data size
#define TCP_RX_SEGMENT_SIZE		250		// max. incoming TCP data size
#define TCP_MAX_CONNECTIONS		4		// max. TCP connections

#define TCP_PORT_FTP_DATA		20		// FTP Data Port
#define TCP_PORT_FTP_COMMAND	21		// FTP Command Port
#define TCP_RETRY_TIMEOUT		5		// wait max. 5 x 50ms for an ACK (about 250msec.)
#define TCP_FIN_TIMEOUT			10		// wait max. 10 x 50ms for an ACK of a FIN (about 0.5 s)
#define TCP_ADD_PSH_FLAG				// to each payload packet otherwise problems with 
										// delays in some windows-tcp/ip-stacks occur

// --------------------------------------------------------------------------------
// USER HTTP-definitions
// -------------------------------------------------------------------------------- 
#define HTTP_DEFAULT_FILE		"start.html"	// longest size of 20 signs

// --------------------------------------------------------------------------------
// USER FTP-definitions
// -------------------------------------------------------------------------------- 
#define	FTP_CRLF				"\r\n"			// define end of line code
#define	FTP_USER_ID				"udo"			//
#define	FTP_PASSWORD			"geheim"			//
//#define	FTP_USER_ID				"anonymous"		//
//#define	FTP_PASSWORD			"anonymous"		//
#define	FTP_ACCOUNT				"test"			//
//#define FTP_ACCOUNT_ENABLE		// enable account function

// --------------------------------------------------------------------------------
// USER dataflash.c and dataflash_debug.c
// -------------------------------------------------------------------------------- 
//#define DATAFLASH_AT45DB041
#define DATAFLASH_AT45DB081
#define	DATAFLASH_ENABLE			// dataflash enable
#define DEBUG_DATAFLASH		  		// enable dataflash functions , see dataflash_debug.c

// --------------------------------------------------------------------------------
// USER dataflash_file.c and dataflash_file_debug.c
// -------------------------------------------------------------------------------- 
#define	DATAFLASH_FILE_ENABLE		// dataflash file enable
#define FILE_HANDLE_COUNT		1	// count of possible open file-handler
#define DEBUG_DATAFLASH_FILE   		// enable file functions , see dataflash_file.c

// --------------------------------------------------------------------------------
// USER board_xx.c
// -------------------------------------------------------------------------------- 
#define	LED4_ON	   		 		PORTD&=~0x80
#define	LED4_OFF				PORTD|=0x80
#define	LED4_PIN		 		(PIND&0x80)
#define	LED4_PASSIVE		 		DDRD&=~0x80
#define	LED4_ACTIVE		 		DDRD|=0x80
#define	BOARD_IP_FROM_EEPROM

// --------------------------------------------------------------------------------
// avr_spi.c
// -------------------------------------------------------------------------------- 
#define SPI_ENABLE

// --------------------------------------------------------------------------------
// USER icmp.c definitions
// -------------------------------------------------------------------------------- 
#define ICMP_DATA_SIZE 		  		1024

// --------------------------------------------------------------------------------
// USER IPSec and Security 
// -------------------------------------------------------------------------------- 
#define IPSEC_RX_BUFFER	   			1500
#ifdef IPSEC_ENABLE
#define IPSEC_REPLAY_ENABLE					// Enable the Replay Functions
#define IPSEC_AH_TRANSPORT_ENABLE			// Enable the IPSec-AH-Transport Protocol
#define IPSEC_AH_TUNNEL_ENABLE				// Enable the IPSec-AH-Tunnel Protocol
#define IPSEC_ESP_TRANSPORT_ENABLE			// Enable the IPSec-ESP-Transport Protocol
#define IPSEC_ESP_TUNNEL_ENABLE				// Enable the IPSec-ESP-Tunnel Protocol
#endif	// #ifdef IPSEC_ENABLE

#ifdef IPSEC_ENABLE
#define	MD5_ENABLE
#define	HMAC_MD5_ENABLE
#define	SHA1_ENABLE
#define	HMAC_SHA1_ENABLE
#if defined(IPSEC_ESP_TRANSPORT_ENABLE)||defined(IPSEC_ESP_TUNNEL_ENABLE)
#define	DES_ENABLE
#define	DES_SPEED	// Enables the Speed-Mode of DES
#endif
#endif	// #ifdef IPSEC_ENABLE

// --------------------------------------------------------------------------------
// USER Security Association
// -------------------------------------------------------------------------------- 
#define IPSEC_SA_MEMORY_SRAM  		// All Data of SA are inside of SRAM

#define IPSEC_MAX_SAD_ENTRIES	8				// Defines the size of SAD entries in the SAD table.
#define IPSEC_MAX_SPD_ENTRIES	12				// Defines the size of SPD entries in the SPD table.

#define IPSEC_SPD_DEF_SRC		{0, 0, 0, 0}	// SPD Default IP Source
#define IPSEC_SPD_DEF_SRC_MASK	{0, 0, 0, 0}	// SPD Default IP Source Mask
#define IPSEC_SPD_DEF_DEST		{0, 0, 0, 0}	// SPD Default IP Destination
#define IPSEC_SPD_DEF_DEST_MASK	{0, 0, 0, 0}	// SPD Default IP Destination Mask
#define IPSEC_SPD_DEF_SRC_PORT	0				// SPD Default IP Source Port
#define IPSEC_SPD_DEF_DEST_PORT	0				// SPD Default IP Destination Port
#define IPSEC_SPD_DEF_PROTOCOL	0				// SPD Default Protocol
												// 0x01 - Internet Control Message Protocol
												// 0x06 - Transmission Control Protocol
												// 0x11 - User Datagram Protocol
												// 0x32 - Encapsulating Security Payload Protocol
												// 0x33 - Authentication Header Protocol
#define IPSEC_SPD_DEF_POLICY	2				// SPD Default Policy - POLICY_APPLY==1; POLICY_BYPASS==2; POLICY_DISCARD==3 

#endif	// #define _PROJECT_INCLUDED_

