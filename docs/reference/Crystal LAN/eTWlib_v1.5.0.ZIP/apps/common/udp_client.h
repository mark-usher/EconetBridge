// ************************************************************************************************
///
/// \file 			udp_client.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
///
// ************************************************************************************************

#ifndef _UDP_CLIENT_INCLUDED_
#define _UDP_CLIENT_INCLUDED_

// --------------------------------------------------------------------------------
// UDP Client definitions
// -------------------------------------------------------------------------------- 
#ifndef UDP_CLIENT_PORT_LOCAL
#define	UDP_CLIENT_PORT_LOCAL	 	33333		// default local Port of UDP-Connection
#endif

#ifndef UDP_CLIENT_PORT_SERVER
#define	UDP_CLIENT_PORT_SERVER	 	33331		// default Server Port of UDP-Connection
#endif

// --------------------------------------------------------------------------------
// external variables and functions
// -------------------------------------------------------------------------------- 
#pragma used+
extern unsigned char udp_client_ok;

unsigned char udp_client_send_message(void);
void udp_client_main(void);
void udp_client_init(void);
#pragma used-

#ifdef NETWORK_LIBRARY_ENABLE
#pragma library udp_client.c
#endif

#endif		// #ifndef _UDP_CLIENT_INCLUDED_