// ************************************************************************************************
///
/// \file 			ipaddr.c
/// \brief			Loading/Storing of ip addresses
///
/// \date	 		$LastChangedDate: 2007-03-14 10:33:07 +0100 (Mi, 14 Mrz 2007) $
/// \version 		$Rev: 638 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"		// Project configuration

#include "ip.h"

#ifdef IPADDR_FROM_EEPROM
eeprom unsigned char ipaddr_eeprom_ip[IP_ADR_SIZE] = IP_DEFAULT;
eeprom unsigned char ipaddr_eeprom_submask[IP_ADR_SIZE] = IP_SUBMASK_DEFAULT;
eeprom unsigned char ipaddr_eeprom_gateway[IP_ADR_SIZE] = IP_GATEWAY_DEFAULT;
#endif


#ifdef IPADDR_FROM_DS2430
// ************************************************************************************************
/// \brief		Calculates XOR-Checksum of an array
///
/// @param[in]	data - pointer to data in SRAM
/// @param[in]	size - size
///	@return		XOR-checksum
// ************************************************************************************************
unsigned char ipaddr_calc_checksum(unsigned char* data, unsigned char size)
{
unsigned char checksum=0;

while (size)
	{
	checksum ^= *data;
	data++;
	size--;
	}
return checksum;
}


// ************************************************************************************************
/// \brief		Reads the IP addresses from DS2430A
///
///	@retval		0 - error
/// @retval		1 - success
// ************************************************************************************************
unsigned char ipaddr_load_ip_from_ds2430(unsigned char* ip_temp, 
										  unsigned char* submask_temp, 
										  unsigned char* gateway_temp)
{
unsigned char return_value=0;
unsigned char devices_1wire;
unsigned char romcodes_1wire[BOARD_MAX_1WIRE_DEVICES, 9];
unsigned char data_buffer[IP_ADR_SIZE*3+1];	// 1 extra Byte for checksum
unsigned char sreg_temp;

sreg_temp = SREG;
#asm("cli");
devices_1wire = w1_search(0xf0, romcodes_1wire);	// search all 1Wire-Devices
if (devices_1wire && romcodes_1wire[0,0]==DS2430_FAMILY_CODE)
	if (ds2430_read_block(romcodes_1wire[0], data_buffer, 0, 3*IP_ADR_SIZE+1))
		if (data_buffer[3*IP_ADR_SIZE] == board_calc_xor_checksum(data_buffer, 3*IP_ADR_SIZE))
			{
			memcpy(ip_temp, 	 data_buffer, 	  			IP_ADR_SIZE);
			memcpy(submask_temp, data_buffer+IP_ADR_SIZE, 	IP_ADR_SIZE);
			memcpy(gateway_temp, data_buffer+2*IP_ADR_SIZE, IP_ADR_SIZE);
			return_value = 1;
			}
SREG = sreg_temp;
return return_value;
}


// ************************************************************************************************
/// \brief		Writes the IP addresses to DS2430A
///
///	@retval		0 - error.
/// @retval		1 - success
// ************************************************************************************************
unsigned char ipaddr_write_ip2_ds2430(unsigned char* ip_temp, 
									   unsigned char* submask_temp, 
									   unsigned char* gateway_temp)
{
unsigned char return_value=0;
unsigned char devices_1wire;
unsigned char romcodes_1wire[BOARD_MAX_1WIRE_DEVICES, 9];
unsigned char data_buffer[IP_ADR_SIZE*3+1];	// 1 extra Byte for checksum
unsigned char sreg_temp;

sreg_temp = SREG;
#asm("cli");
devices_1wire = w1_search(0xf0, romcodes_1wire);	// search all 1Wire-Devices
if (devices_1wire && romcodes_1wire[0,0]==DS2430_FAMILY_CODE)
	{
	memcpy(data_buffer, 			  ip_temp, 	    IP_ADR_SIZE);
	memcpy(data_buffer+IP_ADR_SIZE,   submask_temp, IP_ADR_SIZE);
	memcpy(data_buffer+2*IP_ADR_SIZE, gateway_temp, IP_ADR_SIZE);
	data_buffer[3*IP_ADR_SIZE] = board_calc_xor_checksum(data_buffer, 3*IP_ADR_SIZE);
	return_value = ds2430_write_block(romcodes_1wire[0], data_buffer, 0, 3*IP_ADR_SIZE+1);
	}
SREG = sreg_temp;
return return_value;
}
#endif	// #ifdef IPADDR_FROM_DS2430


// ************************************************************************************************
/// \brief		Reads the IP addresses from EEPROM or DS2430, see ip_address in ip.c,
///
///	@retval		0 - error. ip_address not modified
/// @retval		1 - success
// ************************************************************************************************
unsigned char ipaddr_load_addresses(unsigned char* ip_temp, 
									  	unsigned char* submask_temp, 
									  	unsigned char* gateway_temp)
{
#ifdef IPADDR_FROM_EEPROM
util_memcpye(ip_temp, 	 	 ipaddr_eeprom_ip, 	    IP_ADR_SIZE);
util_memcpye(submask_temp,   ipaddr_eeprom_submask, IP_ADR_SIZE);
util_memcpye(gateway_temp, 	 ipaddr_eeprom_gateway, IP_ADR_SIZE);
return 1;
#endif
#ifdef IPADDR_FROM_DS2430   
return board_load_ip_from_ds2430(ip_temp, submask_temp, gateway_temp);
#endif
return 0;
}


// ************************************************************************************************
/// \brief		Save the IP addresses to DS2430 or EEPROM
///
///	@retval		0 - error
/// @retval		1 - success
// ************************************************************************************************
unsigned char ipaddr_store_addresses(unsigned char* ip_temp, 
										 unsigned char* submask_temp, 
										 unsigned char* gateway_temp)
{
#ifdef IPADDR_FROM_EEPROM
util_memcpy2e(ipaddr_eeprom_ip, 	 ip_temp,      IP_ADR_SIZE);
util_memcpy2e(ipaddr_eeprom_submask, submask_temp, IP_ADR_SIZE);
util_memcpy2e(ipaddr_eeprom_gateway, gateway_temp, IP_ADR_SIZE);
return 1;
#endif
#ifdef IPADDR_FROM_DS2430
return board_write_ip2_ds2430(ip_temp, submask_temp, gateway_temp);
#endif                
return 0;
}
