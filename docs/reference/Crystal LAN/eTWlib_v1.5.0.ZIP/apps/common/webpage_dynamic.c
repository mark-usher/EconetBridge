// ************************************************************************************************
///
/// \file 			webpage_dynamic.c
/// \brief			Provides default webpage for HTTP server containing dynamic adc values
///
/// \date	 		$LastChangedDate: 2007-03-06 08:50:49 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 591 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"			// Project configuration

#if defined(WEBPAGE_DEFAULT_ENABLE) && defined(HTTP_ENABLE)

#include "http_server.h"
#include "tcp.h"
#include "web_debug.h"
#include "adc.h"

void http_server_dynamic_values(unsigned int http_data_len, unsigned char *tcp_data);

unsigned char webpage[] = {
"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\r\n"
"\r\n"
"<html>\r\n"
"<head>\r\n"
"	<title>GET-Formular</title>\r\n"
"</head>\r\n"
"\r\n"
"<body><br><br><br>\r\n"
"<form action=\"default\" method=\"get\">\r\n"
"<table width=\"350\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\">\r\n"
"	<tr>\r\n"
"		<td width=\"100\">LED 1</td>\r\n"
"		<td width=\"250\">\r\n"
"			<input type=\"Radio\" name=\"led1\" value=\"1\" checked>On\r\n"
"			<input type=\"Radio\" name=\"led1\" value=\"0\">Off\r\n"
"		</td>\r\n"
"	</tr>\r\n"
"	<tr>\r\n"
"		<td>LED 2</td>\r\n"
"		<td>\r\n"
"			<input type=\"Radio\" name=\"led2\" value=\"1\" checked>On\r\n"
"			<input type=\"Radio\" name=\"led2\" value=\"0\">Off\r\n"
"		</td>\r\n"
"	</tr>\r\n"
"	<tr>\r\n"
"		<td>LED 3</td>\r\n"
"		<td>\r\n"
"			<input type=\"Radio\" name=\"led3\" value=\"1\" checked>On\r\n"
"			<input type=\"Radio\" name=\"led3\" value=\"0\">Off\r\n"
"		</td>\r\n"
"	</tr>\r\n"
"	<tr>\r\n"
"		<td>Input value:</td>\r\n"
"		<td><input type=\"text\" name=\"command\" size=\"40\" value=\"\"></td>\r\n"
"	</tr>\r\n"
"	<tr>\r\n"
"		<td colspan=\"2\" align=\"right\"><input type=\"submit\" value=\"OK\"></td>\r\n"
"	</tr>\r\n"
"</table>\r\n"
"</form>\r\n"
"<br><b>AD Converter channel 0:</b><br><br>\r\n"
"<table bgcolor=\"#00ff00\" border=\"5\" cellpadding=\"0\" cellspacing=\"0\" width=\"500\">\r\n"
"<tr>\r\n"
"<td>\r\n"
"<table width=\"AD1%%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n"
"<tr><td bgcolor=\"#ff0000\">&nbsp;</td></tr>\r\n"
"</table>\r\n"
"</td>\r\n"
"</tr>\r\n"
"</table>\r\n"
"<table border=\"0\" width=\"500\">\r\n"
"<tr>\r\n"
"<td width=\"20%\"> 0V</td>\r\n"
"<td width=\"20%\">2.5V</td>\r\n"
"<td width=\"20%\">5V</td>\r\n"
"<td width=\"20%\">7.5V</td>\r\n"
"<td width=\"20%\">10V</td>\r\n"
"<td width=\"20%\">12.5V</td>\r\n"
"</tr>\r\n"
"</table>\r\n"
"</body>\r\n"
"</html>\r\n"
"\r\n"};


// ************************************************************************************************
/// \brief		Write data from webpage to TCP/IP stack
///	@param[in]	status - see HTTP_SERVER_DEFAULT_STATUS
///	@retval		0 - wrong default webpage or all data sent
///	@retval		1 - OK (data write, tcp-busy)
// ************************************************************************************************
unsigned char http_server_default(HTTP_SERVER_DEFAULT_STATUS status)
{
static unsigned char *p_webpage;			// pointer to Webpage
static unsigned int	 http_bytes2send;     	// bytes left to send
unsigned int 		 http_data_len;
TCP_STRUCTURE*		 p_struct;                                    	

p_struct = tcp_get_struct(http_server_tcp);
if (status == HTTP_SERVER_DEFAULT_START)
	{
	http_bytes2send = strlen(webpage);
	p_webpage = &webpage[0];		// pointer to HTML-code
	#ifdef WEB_DEBUG_HTTP
	if (web_debug_flag & WEB_DEBUG_HTTP_BIT)
		printf("HTTP open default webpage: %u Byte\r\n", http_bytes2send);
	#endif	// #ifdef WEB_DEBUG_FTP
	//icmp_prepare_timestamp_request(p_struct->tcp_ip_remote, p_struct->tcp_mac_remote, 0);
	if (http_bytes2send == 0)				// wrong size of webpage
		{
		#ifdef WEB_DEBUG_HTTP
		if(web_debug_flag & WEB_DEBUG_HTTP_BIT)
			putsf("HTTP wrong size\r");
		#endif
		return 0;
		}
	http_response(HTTP_STATUS_200, http_bytes2send, 0x0);
	}
if (p_struct!=0 && p_struct->tcp_socket_status&SOCK_CONNECTED)  	// check if somebody has connected to our TCP
	{
	http_data_len = tcp_tx_buffer_write(http_server_tcp, 0x0, 0, TCP_TX_BUFFER_GET_SIZE);	// get size of buffer
	if (http_data_len == 0)	// TCP is busy
		return 1;
	if (http_bytes2send < http_data_len)	
		http_data_len = http_bytes2send;
	http_server_dynamic_values(http_data_len, p_webpage); 	// exchange some strings...
	tcp_tx_buffer_write(http_server_tcp, p_webpage, http_data_len, TCP_TX_BUFFER_WRITE_RAM_DATA);	// write data to 
	http_bytes2send -= http_data_len;
	p_webpage += http_data_len;
	#ifdef WEB_DEBUG_HTTP
	if (web_debug_flag & WEB_DEBUG_HTTP_BIT)
		printf("HTTP data: %u Byte (rest:%u)\r\n", http_data_len, http_bytes2send);
	#endif
	if (http_bytes2send == 0)
		return 0;
	}
return 1;
}

#ifndef ADC_ENABLE
#error "define ADC_ENABLE in project.h"
#endif


// ************************************************************************************************
/// \brief			Searches an array for special strings and replaces them
///
///					The array contains markers in the form of AD1%, AD2% AD3% etc.
///					The function replaces them with an ADC result (range 0..100)
///	@param[in]		http_data_len - length of array "tcp_data"
///	@param[in,out]	tcp_data - input array with position markers
// ************************************************************************************************
void http_server_dynamic_values(unsigned int http_data_len, unsigned char *tcp_data)
{
unsigned int Lva;
unsigned int data;
unsigned char value_str[5];
  
if (http_data_len < 4)
	return;	// there can't be any special string
for (Lva=0; Lva<(http_data_len-3); Lva++)
	{
	if ((*tcp_data =='A') && (*(tcp_data + 1)=='D') && (*(tcp_data + 3)=='%'))
		{
		data = 0;
		if (*(tcp_data + 2)=='1')
			data = 1;
		adc_configure(ADCSR_ADEN | ADCSR_32, ADMUX_REF_AVCC);
		data = adc_read_poll(data);
		data >>= 3;	  					// converts adc result to % by dividing by 8
		if (data > 100)
			data = 100;
		sprintf(value_str, "%3u", data);
		memcpy(tcp_data, value_str, 0);
		printf("HTTP data: %1u\r\n", data);
		}
	tcp_data++;
	}
}

#endif	// #if defined(WEBPAGE_DEFAULT_ENABLE) && defined(HTTP_ENABLE)