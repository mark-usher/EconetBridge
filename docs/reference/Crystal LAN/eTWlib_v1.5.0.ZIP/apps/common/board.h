// ************************************************************************************************
///
/// \file 			board.h
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
///
// ************************************************************************************************

#ifndef _BOARD_INCLUDED_
#define _BOARD_INCLUDED_

// --------------------------------------------------------------------------------
// include header-files
// -------------------------------------------------------------------------------- 
#include "project.h"		// Project configuration
#ifdef BOARD_IP_FROM_EEPROM
#include "ip.h"
#endif

// --------------------------------------------------------------------------------
// Global general definitions
// -------------------------------------------------------------------------------- 
#define IP_FFFFFFFF				"\xff\xff\xff\xff"

// --------------------------------------------------------------------------------
// Microcontroller-Interface definitions
// -------------------------------------------------------------------------------- 
#define	TIMER1_PRE			2			// Prescale=2 --> _MCU_CLOCK_FREQUENCY/8

#if(_MCU_CLOCK_FREQUENCY_==16000000)
#define	TIMER1_ACOMP		(2500*8)		// 10ms with 16.00 MHz
#endif

#if (_MCU_CLOCK_FREQUENCY_==14745600)
#define	TIMER1_ACOMP		(2304*8)		// 10ms with 14.7456 MHz
#endif

#if(_MCU_CLOCK_FREQUENCY_==7372800)
#define	TIMER1_ACOMP		(1152*8)		// 10ms with 7.3728 MHz
#endif

#if(_MCU_CLOCK_FREQUENCY_==3686400)
#define	TIMER1_ACOMP		(576*8)			// 10ms with 3.6864 MHz
#endif

#if(_MCU_CLOCK_FREQUENCY_==1843200)
#define	TIMER1_ACOMP		(288*8)			// 10ms with 3.6864 MHz
#endif

// --------------------------------------------------------------------------------
// LED definitions
// -------------------------------------------------------------------------------- 
#ifndef	LED1_ON
#define	LED1_ON
#endif
#ifndef	LED1_OFF
#define	LED1_OFF
#endif
#ifndef	LED1_PIN
#define	LED1_PIN		1
#endif
#ifndef	LED1_PASSIVE
#define	LED1_PASSIVE
#endif
#ifndef LED1_ACTIVE
#define	LED1_ACTIVE
#endif

#ifndef	LED2_ON
#define	LED2_ON
#endif
#ifndef	LED2_OFF
#define	LED2_OFF
#endif
#ifndef	LED2_PIN
#define	LED2_PIN		1
#endif
#ifndef	LED2_PASSIVE
#define	LED2_PASSIVE
#endif
#ifndef LED2_ACTIVE
#define	LED2_ACTIVE
#endif

#ifndef	LED3_ON
#define	LED3_ON
#endif
#ifndef	LED3_OFF
#define	LED3_OFF
#endif
#ifndef	LED3_PIN
#define	LED3_PIN		1
#endif
#ifndef	LED3_PASSIVE
#define	LED3_PASSIVE
#endif
#ifndef LED3_ACTIVE
#define	LED3_ACTIVE
#endif

#ifndef	LED4_ON
#define	LED4_ON
#endif
#ifndef	LED4_OFF
#define	LED4_OFF
#endif
#ifndef	LED4_PIN
#define	LED4_PIN		1
#endif
#ifndef	LED4_PASSIVE
#define	LED4_PASSIVE
#endif
#ifndef LED4_ACTIVE
#define	LED4_ACTIVE
#endif


// --------------------------------------------------------------------------------
// Memory-Interface definitions
// -------------------------------------------------------------------------------- 
#define	SRL_0	   		0x00	// Lower sector=NA / Upper sector=0x1100..0xffff
#define	SRL_1			0x10    // Lower sector=0x1100..0x1fff / Upper sector=0x2000..0xffff
#define	SRL_2			0x20    // Lower sector=0x1100..0x3fff / Upper sector=0x4000..0xffff
#define	SRL_3			0x30	// Lower sector=0x1100..0x5fff / Upper sector=0x6000..0xffff
#define	SRL_4			0x40	// Lower sector=0x1100..0x7fff / Upper sector=0x8000..0xffff
#define	SRL_5			0x50	// Lower sector=0x1100..0x9fff / Upper sector=0xA000..0xffff
#define	SRL_6			0x60	// Lower sector=0x1100..0xBfff / Upper sector=0xC000..0xffff
#define	SRL_7			0x70	// Lower sector=0x1100..0xDfff / Upper sector=0xE000..0xffff

#define	SRW00_XMCRA		0x04	// Lower sector wait
#define	SRW01_XMCRA		0x08	// Lower sector wait
#define	SRW10_MCUCR		0x40	// Upper sector wait
#define	SRW11_XMCRA		0x02	// Upper sector wait


// --------------------------------------------------------------------------------
// 1Wire-Interface definitions
// -------------------------------------------------------------------------------- 
#ifndef	BOARD_MAX_1WIRE_DEVICES
#define	BOARD_MAX_1WIRE_DEVICES	1
#endif

#if defined(BOARD_IP_FROM_EEPROM) && defined(BOARD_IP_FROM_DS2430)
#error "BOARD_IP_FROM_EEPROM or BOARD_IP_FROM_DS2430"
#endif

#pragma used+
extern unsigned int 	counter_10ms_16bit;
extern unsigned long 	second_counter; 		// 
extern unsigned int 	day_counter;			// 
extern unsigned char 	board_reset_status;	// save the old MCUCSR
#ifdef BOARD_IP_FROM_EEPROM
extern eeprom unsigned char eeprom_ip[IP_ADR_SIZE];		// our internet protocol (IP) address
extern eeprom unsigned char eeprom_submask[IP_ADR_SIZE];
extern eeprom unsigned char eeprom_gateway[IP_ADR_SIZE];// standard gateway (used if remote
#endif

unsigned char	board_read_mac(unsigned char *romcode_buffer, unsigned char *data_buffer);
void			board_timer1_init(void);
unsigned int 	board_timer1_counter(void);
void 			board_set_second_counter(unsigned long new_value);
void			board_init(void);
#ifdef DEVICE_CS8900
void			board_init_mac_address(void);
#endif
#ifdef IP_ENABLE
unsigned char 	board_load_ip_addresses(unsigned char* ip_temp, unsigned char* submask_temp, unsigned char* gateway_temp);
unsigned char 	board_store_ip_addresses(unsigned char* ip_temp, unsigned char* submask_temp, unsigned char* gateway_temp);
#endif
void 			uart1_irq_receive_enable(void);
void 			uart1_irq_receive_disable(void);
void 			uart1_putchar(unsigned char c);

#pragma used-

#endif	// #ifndef _BOARD_INCLUDED_