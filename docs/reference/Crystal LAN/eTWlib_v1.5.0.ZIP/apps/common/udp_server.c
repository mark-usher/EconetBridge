// ************************************************************************************************
///
/// \file 			udp_server.c
/// \brief			UDP server functions
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <stdio.h>
#include "board.h"
#include "buffer.h"
#include "device.h"
#include "ethernet.h"
#include "udp.h"
#include "server.h"
#include "udp_server.h"
#ifdef WEB_DEBUG
#include "web_debug.h"
#endif

#pragma regalloc-
unsigned char udp_server_handle=UDP_WRONG_CONNECTIONS;
#pragma regalloc+                                                                          


//*********************************************************************************
// Description	: simple function to send UDP-data
// Input	   	: type_id - simple number to init the receive data
// Output     	: 0 - no data sent
//            	: 1 - sending OK
// Indication	: sends 12 Byte Data
//*********************************************************************************
unsigned char udp_server_send_message(unsigned char udp_connection)
{
static unsigned int udp_server_tx_count=0;
unsigned char	udp_data[20];
                              
sprintf(udp_data, "udp_server:%d", udp_server_tx_count);
if(udp_tx_buffer_prepare(udp_connection, udp_data, sizeof(udp_data)))
	{
	udp_server_tx_count++;
	return 1;
	}
return 0;
}

//*********************************************************************************
// Description	: main routine to handle the UDP-Connections
// Input     	: none
// Output	   	: none
// Indication	: none
//*********************************************************************************
void udp_server_main(void)
{
UDP_STRUCTURE	*p_struct;                                    	
unsigned char	udp_data[5]={0xFE, 0x01, 0x04, 0x02, 0xFF};

server_main();
p_struct=udp_get_struct(udp_server_handle);
if((p_struct!=0) && (p_struct->udp_flags & UDP_DATA_AVAILABLE))	// check if remote UDP sent data
	{                                                
	#ifdef WEB_DEBUG_UDP
	if(web_debug_flag & WEB_DEBUG_UDP_BIT)
		debug_display_mem_hex(p_struct->udp_rx_frame, p_struct->udp_rx_data_count, 0);
    #endif
	udp_tx_buffer_prepare(udp_server_handle, udp_data, sizeof(udp_data));
//	udp_tx_buffer_prepare(udp_server_handle, p_struct->udp_rx_frame, p_struct->udp_rx_data_count);
	udp_rx_buffer_release(udp_server_handle);	// clear the UDP-RX-Buffer
//	udp_server_send_message(udp_server_handle);
	}
}

//*********************************************************************************
// Description	: init the UDP-Server-Connection
// Input   		: port_number: UDP-Port to listen
// Output  		: none
// Indication	: none
//*********************************************************************************
void udp_server_init(unsigned int port_number)
{
server_init();
udp_server_handle=udp_open(port_number, 0, 0, 0, UDP_FLAG_PASSIVE);
if(udp_server_handle==UDP_WRONG_CONNECTIONS)
	{
	#ifdef WEB_DEBUG_UDP
	if(web_debug_flag & WEB_DEBUG_UDP_BIT)
		printf("UDP(%u) Passiv Open Error!!!!\r\n", port_number);
	#endif
	}          
}