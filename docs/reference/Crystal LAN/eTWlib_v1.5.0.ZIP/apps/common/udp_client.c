// ************************************************************************************************
///
/// \file 			udp_client.c
/// \brief			UDP client functions
///
/// \date	 		$LastChangedDate: 2007-03-06 21:48:07 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 606 $
///	\author  		Udo Jakobza<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include <stdio.h>
#include <string.h>

#include "udp.h"
#include "arp_rarp.h"
#ifdef WEB_DEBUG
#include "web_debug.h"
#endif
                                                     
#pragma regalloc-
unsigned char udp_client_server_ip[IP_ADR_SIZE] =  IP_SERVER;
unsigned char udp_client_connection=UDP_WRONG_CONNECTIONS;
unsigned char udp_client_ok=0;
#pragma regalloc+                                                                          


//*********************************************************************************
// Description	: simple function to send UDP-data
// Input	   	: none
// Output     	: none
// Indication	: none
//*********************************************************************************
unsigned char udp_client_send_message(void)
{
static unsigned int udp_client_tx_count=0;
unsigned char	udp_data[20];

if(udp_client_ok)
	{
	sprintf(udp_data, "udp_client:%d", udp_client_tx_count);
	if(udp_tx_buffer_prepare(udp_client_connection, udp_data, sizeof(udp_data)))
		{
		udp_client_tx_count++;
		return 1;
		}
	}
return 0;
}

//*********************************************************************************
// Description	: main routine to handle the IP-Connections
// Input     	: none
// Output	   	: none
// Indication	: none
//*********************************************************************************
void udp_client_main(void)
{
UDP_STRUCTURE	*p_struct;                                    	

if(udp_client_ok)
	{
	server_main();
	p_struct=udp_get_struct(udp_client_connection);
	if((p_struct!=0)&&(p_struct->udp_flags & UDP_DATA_AVAILABLE))	// check if remote UDP sent data
		{                                                
		udp_client_send_message();
		udp_rx_buffer_release(udp_client_connection);	// clear the UDP-RX-Buffer
		}
	}
}

//*********************************************************************************
// Description	: init the UDP-IP-Connection
// Input   		: none
// Output  		: none
// Indication	: request the MAC-Address of udp_client_server_ip
//*********************************************************************************
void udp_client_init(void)
{
unsigned char	c_delay=200;	// wait until ARP-Anwser will come
unsigned char	c_old; 

udp_client_ok=0;
server_init();
if(server_ok)
	{
	arp_prepare_request(udp_client_server_ip, ARP_REQUEST_IP);
	memset(ip_of_last_frame, 0x0, IP_ADR_SIZE);	// clear last IP-Address
	c_old=(unsigned char)counter_10ms_16bit;
	while(1)
		{
		#asm("wdr");			// Reset Watchdog
		ethernet_process();	 	// handle network and easyToWeb-stack events
		buffer_process();		// handles the buffer management
		idle();	  		 		// every time with IDLE-Mode
		if(!memcmp(ip_of_last_frame, udp_client_server_ip, IP_ADR_SIZE))	// received the last Ethernet-Frame with MAC???
			{
			// connect to Server-Port "UDP_CLIENT_PORT_SERVER" with Client-Port "UDP_CLIENT_PORT_LOCAL"
			udp_client_connection=udp_open(UDP_CLIENT_PORT_LOCAL, mac_of_last_frame, udp_client_server_ip, 
			                          UDP_CLIENT_PORT_SERVER, UDP_FLAG_ACTIVE);
			if(udp_client_connection==UDP_WRONG_CONNECTIONS)
				{
				#ifdef WEB_DEBUG_UDP
				printf("UDP Active Open Error (Port:%d)!!!!\r\n", UDP_CLIENT_PORT_SERVER);
				#endif
				return;
				}          
			udp_client_ok=1;
			udp_client_send_message();	// sends cyclic with 400ms
			return;
			}
		if(c_old!=(unsigned char)counter_10ms_16bit)
			{
			c_old=(unsigned char)counter_10ms_16bit;
			if(c_delay>0)
				c_delay--;
			else
				break;	// timeout
			}
		}			
	}
}



                                                                                                         
                          
