// ************************************************************************************************
///
/// \file 			macaddr.c
/// \brief			Loading/Storing of MAC address
///
/// \date	 		$LastChangedDate: 2007-03-14 10:33:07 +0100 (Mi, 14 Mrz 2007) $
/// \version 		$Rev: 638 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"		// Project configuration

#include "cs8900.h"
// PORTA.x (address 0x1B)
// PORTB.x (address 0x18)
// PORTC.x (address 0x15)
// PORTD.x (address 0x12)
// the 1 Wire bus is connected to PORTD
// PORTD.7 (the data signal is bit 7)

#asm
    .equ __w1_port=0x12
    .equ __w1_bit=7
#endasm


#include <1wire.h>
#include <ds2430.h>

#ifndef DS2430_PROM_SIZE
#define DS2430_PROM_SIZE		8
#endif
#ifndef BOARD_MAX_1WIRE_DEVICES
#define BOARD_MAX_1WIRE_DEVICES 2
#endif
// ************************************************************************************************
/// \brief		Init the 1-wire-Interface and read the MAC-address from DS2430-PROM
///
///				The function checks the correctness of MAC-Address 
///				(10:00:aa or 00:50:c2 first 24bit of MAC-address)
/// \note		supports only ONE 1Wire-Device
/// @param[out]	romcode_buffer	- pointer to SRAM memory, see DS2430 functions
/// @param[out]	data_buffer		- pointer to data of DS2430-PROM
/// @param[in]	device			- number to address a device on 1Wire bus (0..254)
/// @retval		0	- ERROR - wrong MAC / empty MAC / wrong "device" number / read error from DS2430
/// @retval		1	- MAC ok, data inside of 'data_buffer'
// ************************************************************************************************
unsigned char macaddr_read(unsigned char *romcode_buffer, unsigned char *data_buffer)
{
unsigned char devices_1wire, device_mac;
unsigned char romcodes_1wire[BOARD_MAX_1WIRE_DEVICES, 9];
unsigned char new_data_buffer[DS2430_PROM_SIZE];
unsigned char sreg;

sreg = SREG;
#asm("cli");
devices_1wire = w1_search(0xf0, romcodes_1wire);	// search all 1Wire-Devices
if (devices_1wire > BOARD_MAX_1WIRE_DEVICES)
	devices_1wire = 0;		// return error (no devices found)
device_mac = devices_1wire;
while (device_mac)
	{
	device_mac--;
	if (romcode_buffer)
		memcpy(romcode_buffer, romcodes_1wire, sizeof(romcodes_1wire));
	if (romcodes_1wire[device_mac, 0] == DS2430_FAMILY_CODE)	// found DS2430A
		{
		if (!ds2430_read_appreg_block(&romcodes_1wire[device_mac,0], new_data_buffer, 0, DS2430_PROM_SIZE))
			devices_1wire = 0;
		else
			{
			if (data_buffer)
				memcpy(data_buffer, new_data_buffer, DS2430_PROM_SIZE);
			if (((new_data_buffer[0]!=0x10)||(new_data_buffer[1]!=0x00)||(new_data_buffer[2]!=0xaa)) &&
			   ((new_data_buffer[0]!=0x00)||(new_data_buffer[1]!=0x50)||(new_data_buffer[2]!=0xc2)))
			   	{
				devices_1wire = 0;
				}
			else
				break;
			}
		}
	}	// while(devices_mac)
SREG = sreg;

return devices_1wire;
}


#ifdef DEVICE_CS8900
// ************************************************************************************************
/// \brief		Reads the MAC address from DS2430
///
// ************************************************************************************************
void macaddr_init_address(void)
{
unsigned char ds2430_buffer[DS2430_PROM_SIZE];

if (macaddr_read(0x0, ds2430_buffer))
	{
	memcpy(mac_address, ds2430_buffer, sizeof(mac_address));
	cs8900_set_mac(mac_address);
	}
}
#endif	// #ifdef DEVICE_CS8900
