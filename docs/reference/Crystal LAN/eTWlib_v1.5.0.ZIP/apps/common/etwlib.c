// ************************************************************************************************
///
/// \file 			etwlib.c
/// \brief			Coordinates eTWlib Modules
///
/// \note			This module is still "Experimental"
/// \date	 		$LastChangedDate: 2007-04-05 17:44:52 +0200 (Do, 05 Apr 2007) $
/// \version 		$Rev: 663 $
///	\author  		Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///
// ************************************************************************************************

#include "project.h"		// Project configuration

#include "cal_rc.h"
#include "debug.h"
#include "web_debug.h"
#include "gpio.h"
//#include "avr_spi.h"
#include "uart.h"
#ifdef DATAFLASH_ENABLE
	#include "dataflash.h"
	#include "dataflash_file.h"
#endif
#include "max7301.h"
#include "keys.h"
#include "lcd_4bit.h"
#include "sdcard.h"
#include "fat.h"
#include "systimer.h"
#include "sys_delay.h"
#include "sys_callback.h"
#include "reset_source.h"
#include "twi.h"
#include "adc.h"
#include "device.h"
#include "buffer.h"
#include "board.h"
#ifdef ETHERNET_ENABLE
#include "ethernet.h"
#endif
#ifdef DEVICE_PPP
#include "ppp.h"
#endif
#ifdef TCP_ENABLE
#include "tcp.h"
#include "tcp_debug.h"
#endif
#ifdef DATAFLASH_FILE_ENABLE
#include "dataflash_file.h"
#include "dataflash_file_debug.h"
#endif
#ifdef HTTP_ENABLE
#include "http_server.h"
#endif
#ifdef FTP_ENABLE
#include "ftp_server.h"
#endif
#ifdef TFTP_ENABLE
#include "tftp.h"
#endif


unsigned char server_ok;

// ************************************************************************************************
/// \brief		   	Initialization of network stack
///	\todo			code from server.c should be moved here
///
// ************************************************************************************************
void etwlib_network_init(void)
{
server_ok = 0;

#ifdef DEVICE_CS8900
cs8900_init();
board_init_mac_address();	// write mac to CS8900-Init-Data-Buffer (cs8900_init_data)
#endif

#ifdef WEB_DEBUG
web_debug_init();
#endif

//board_load_ip_addresses(ip_address, ip_subnet_mask, ip_gateway);
//buffer_clear();
//if (DEVICE_INIT() == 0)
//	return;

#ifdef UDP_ENABLE
	udp_init();
	#ifdef BOOTP_ENABLE
	server_ok = 1;		// necessary to start "server_main"
	bootp_init();
	server_ok = 0;		// reset the server flag
	#endif
	#ifdef TFTP_ENABLE
	tftp_init();
	#endif
#endif					// #ifdef UDP_ENABLE

#ifdef TCP_ENABLE
tcp_init();
#endif

#ifdef HTTP_ENABLE
http_server_tcp = tcp_passive_open(TCP_PORT_HTTP);
if (http_server_tcp == TCP_WRONG_CONNECTIONS)	// set port we want to listen to
	return;
#endif

#ifdef FTP_ENABLE
ftp_server_init();
ftp_server_tcp_command = tcp_passive_open(TCP_PORT_FTP_COMMAND);
if(ftp_server_tcp_command == TCP_WRONG_CONNECTIONS)	// set port we want to listen to
	return;
#endif

#ifdef ARP_ENABLE
arp_request_timer(ARP_REQUEST_TIMER_START);		// start mode
#endif

#ifdef DATAFLASH_FILE_ENABLE
dataflash_file_init(DATAFLASH_SPI_MODE);		// init dataflash
#endif
server_ok = 1;
}


// ************************************************************************************************
/// \brief		   	Initialization of all eTWlib modules including network stack
///
// ************************************************************************************************
void etwlib_init(void)
{
#ifdef CAL_RC_ENABLE
if (!cal_rc_calibrate_first())
	OSCCAL = CAL_RC_OSCCAL_DEFAULT;
#endif
#ifdef RESET_SOURCE_ENABLE
reset_source_init();
#endif
#ifdef DEBUG
debug_init();
#endif

#ifdef SYSTIMER_ENABLE
systimer_init();
#endif
#ifdef SYS_DELAY_ENABLE
sys_delay_init();
#endif
#ifdef SYS_CALLBACK_ENABLE
sys_callback_init();
#endif
#ifdef GPIO_ENABLE
gpio_init();
#endif
#ifdef ADC_ENABLE
adc_init();
#endif
#ifdef SPI_ENABLE
//spi_init();		// function requires project specific parameters
#endif
#ifdef UART_ENABLE
uart_init();
#endif

#ifdef DATAFLASH_ENABLE
dataflash_init();
#endif
#ifdef DATAFLASH_FILE_ENABLE
//dataflash_file_init();		// function requires project specific parameters
#endif
#ifdef MAX7301_ENABLE
max7301_init();
#endif //#ifdef MAX7301_ENABLE
#ifdef KEYS_ENABLE
keys_init();
#endif
#ifdef LCD_4BIT
lcd_init();
#endif
#ifdef SDCARD_ENABLE
sdc_init();
#endif
#ifdef FAT_ENABLE
fat_init();
#endif
#ifdef AD5242_DEBUG
ad5242_init();
#endif
etwlib_network_init();
#if defined TWI_CVAVR_ENABLE || defined TWI_AVR_ENABLE
twi_init();
#endif
}


// ************************************************************************************************
/// \brief		   	Do network stuff
///	\todo			code from server.c should be moved here
///
// ************************************************************************************************
void etwlib_network_main(void)
{
if (server_ok == 1)
	{
	#ifdef DEVICE_PPP
	ppp_main();
	if (DEVICE_READ_READY())
		{
		#ifdef IP_ENABLE
		ip_process_frame(0);
		#endif
		ppp_data_clear();
		}
	#else
	ethernet_process();		 	// handle network and easyToWeb-stack events
	#endif	// #ifdef DEVICE_PPP
	
	buffer_process();			// handles the buffer management
	
	#ifdef UDP_ENABLE
		udp_main();
		#ifdef BOOTP_ENABLE
		bootp_process();
		#endif
		#ifdef TFTP_ENABLE
		tftp_main();
		#endif
	#endif
	
	#ifdef TCP_ENABLE
		tcp_main();	  	  	   	// handles all TCP-actions
		#ifdef TCP_DEBUG_TESTBENCH
		tcp_debug_client_server();
		#endif
		buffer_process();		// handles the buffer management
		#ifdef HTTP_ENABLE
		http_server();			// go to the http-Server
		#endif
		#ifdef FTP_ENABLE
		ftp_server_main();		// go to the ftp-Server
		#endif
	#endif
	buffer_process();			// handles the buffer management
	}
}


// ************************************************************************************************
/// \brief		   	Poll all eTWlib modules
///
// ************************************************************************************************
void etwlib_main(void)
{
//
etwlib_network_main();
}
