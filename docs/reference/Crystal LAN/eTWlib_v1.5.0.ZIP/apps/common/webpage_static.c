// ************************************************************************************************
///
/// \file 			webpage_static.c
/// \brief			Provides static default webpage for HTTP server
///
/// \date	 		$LastChangedDate: 2007-03-06 08:50:49 +0100 (Di, 06 Mrz 2007) $
/// \version 		$Rev: 591 $
///	\author  		Udo Jakobza, Carsten K�gler<br> Copyright (c) FTZ Leipzig <br> 
///					D-04107 Leipzig<br> W�chterstr. 13 info@easytoweb.de
/// \par License    
///					This library is free software; you can redistribute it and/or modify it 
///					under the terms of the GNU Lesser General Public License as published by 
///					the Free Software Foundation; either version 2.1 of the License, or 
///					(at your option) any later version. This library is distributed in the hope 
///					that it will be useful, but WITHOUT ANY WARRANTY; without even the implied 
///					warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
///					See the GNU Lesser General Public License for more details.
///					see: http://www.gnu.org/copyleft/lesser.html	
///					You should have received a copy of the GNU Lesser General Public License 
///					along with this library; if not, write to the Free Software Foundation, 
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA <br><br>
///					Die Bibliothek ist freie Software; Sie d�rfen sie unter den Bedingungen der 
///					GNU Lesser General Public License, wie von der Free Software Foundation 
///					ver�ffentlicht, weiterverteilen und/oder modifizieren; entweder gem�� 
///					Version 2.1 der Lizenz oder (nach Ihrer Option) jeder sp�teren Version. 
///					Diese Bibliothek wird in der Hoffnung weiterverbreitet, da� sie n�tzlich 
///					sein wird, jedoch OHNE IRGENDEINE GARANTIE, auch ohne die implizierte 
///					Garantie der MARKTREIFE oder der VERWENDBARKEIT F�R EINEN BESTIMMTEN ZWECK. 
///					Mehr Details finden Sie in der GNU Lesser General Public License.
///					see: http://www.gnu.org/copyleft/lesser.de.html	
///					Sie sollten eine Kopie der GNU Lesser General Public License zusammen mit 
///					dieser Bibliothek erhalten haben; falls nicht, schreiben Sie an die FSF,
///					Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
///					
// ************************************************************************************************

#include "project.h"			// Project configuration

#if defined(WEBPAGE_DEFAULT_ENABLE) && defined(HTTP_ENABLE)

#include "http_server.h"
#include "tcp.h"
#include "web_debug.h"

const unsigned char webpage[] = {
"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\r\n"
"\r\n"
"<html>\r\n"
"<head>\r\n"
"<title>easyToWeb-Software</title>\r\n"
"</head>\r\n"
"<body bgcolor=\"#3366ff\" text=\"#ffffff\" link=\"#79fbfb\" vlink=\"#79fbfb\" alink=\"#79fbfb\">\r\n"
"<table width=900 border=0><tr>\r\n"
"<td><b><font color=\"#ffcc00\" size=\"6\"><i>easyToWeb Webserver with ATmega128(L)<sup>TM</sup> or ATmega32(L)<sup>TM</sup></i></font></b></td>\r\n"
"</tr>\r\n"
"</table>\r\n"
"\r\n"
"<table width=700 border=0>\r\n"
"\r\n"
"<tr><td colspan=3>\r\n"
"<b><br>easyToWeb-Software and Protocols</b><br>\r\n"
"<ul><li>Software based on the free available C-sources from the <b>extra booklet &quot;Embedded Internet&quot;</b> to Design &amp; Elektronik</li>\r\n"
"<li>Projects with the CodeVisionAVR C-Compiler</li>\r\n"
"<li>PPP, ARP, TCP/IP, UDP, BooTP, ICMP, HTTP, FTP, IPSec</li>\r\n"
"<li><b>C-sources are freely available</b></li></ul>\r\n"
"</td></tr></table>\r\n"
"\r\n"
"</body>\r\n"
"</html>\r\n"
"\r\n"
"\r\n"};


// ************************************************************************************************
/// \brief		Write data from webpage to TCP/IP stack
///	@param[in]	status - see HTTP_SERVER_DEFAULT_STATUS
///	@retval		0 - wrong default webpage or all data sent
///	@retval		1 - OK (data write, tcp-busy)
// ************************************************************************************************
unsigned char http_server_default(HTTP_SERVER_DEFAULT_STATUS status)
{
static unsigned char flash *p_webpage;			// pointer to Webpage
static unsigned int	 http_bytes2send;     	// bytes left to send
unsigned int 		 http_data_len;
TCP_STRUCTURE*		 p_struct;                                    	

p_struct = tcp_get_struct(http_server_tcp);
if (status == HTTP_SERVER_DEFAULT_START)
	{
	http_bytes2send = strlenf(webpage);
	p_webpage = &webpage[0];		// pointer to HTML-code
	#ifdef WEB_DEBUG_HTTP
	if (web_debug_flag & WEB_DEBUG_HTTP_BIT)
		printf("HTTP open default webpage: %u Byte\r\n", http_bytes2send);
	#endif	// #ifdef WEB_DEBUG_FTP
	//icmp_prepare_timestamp_request(p_struct->tcp_ip_remote, p_struct->tcp_mac_remote, 0);
	if (http_bytes2send == 0)				// wrong size of webpage
		{
		#ifdef WEB_DEBUG_HTTP
		if(web_debug_flag & WEB_DEBUG_HTTP_BIT)
			putsf("HTTP wrong size\r");
		#endif
		return 0;
		}
	http_response(HTTP_STATUS_200, http_bytes2send, 0x0);
	}
if (p_struct!=0 && p_struct->tcp_socket_status&SOCK_CONNECTED)  	// check if somebody has connected to our TCP
	{
	http_data_len = tcp_tx_buffer_write(http_server_tcp, 0x0, 0, TCP_TX_BUFFER_GET_SIZE);	// get size of buffer
	if (http_data_len == 0)	// TCP is busy
		return 1;
	if (http_bytes2send < http_data_len)	
		http_data_len = http_bytes2send;
	tcp_tx_buffer_write_f(http_server_tcp, p_webpage, http_data_len, TCP_TX_BUFFER_WRITE_FLASH_DATA);	// write data to 
	http_bytes2send -= http_data_len;
	p_webpage += http_data_len;
	#ifdef WEB_DEBUG_HTTP
	if (web_debug_flag & WEB_DEBUG_HTTP_BIT)
		printf("HTTP data: %u Byte (rest:%u)\r\n", http_data_len, http_bytes2send);
	#endif
	if (http_bytes2send == 0)
		return 0;
	}
return 1;
}

#endif	// #if defined(WEBPAGE_DEFAULT_ENABLE) && defined(HTTP_ENABLE)