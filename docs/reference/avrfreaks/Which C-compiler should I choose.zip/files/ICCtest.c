//ICC-AVR application builder : 11/20/01 10:40:32 PM
// Target : 8515
// Crystal: 8.0000Mhz

#include <io8515.h>
#include <macros.h>

void port_init(void)
{
 PORTA = 0xFF;
 DDRA  = 0x00;
 PORTB = 0xFF;
 DDRB  = 0x00;
 PORTC = 0xFF;
 DDRC  = 0x80;
 PORTD = 0xFF;
 DDRD  = 0x00; 
}

//TIMER0 initialisation - prescale:1024
// desired value: 30.5Hz
// actual value: 30.518Hz (0.1%)
void timer0_init(void)
{
 TCCR0 = 0x00; //stop timer
 TCNT0 = 0x00; //set count value
 TCCR0 = 0x05; //start timer
}

#pragma interrupt_handler timer0_ovf_isr:8
void timer0_ovf_isr(void)
{
 static char a;
 
 a++;
 if (a==20)
 {
  	PORTC ^= 0x80;
  	a = 0;
 }
}

//call this routine to initialise all peripherals
void init_devices(void)
{
 //stop errant interrupts until set up
 CLI(); //disable all interrupts
 port_init();
 timer0_init();

 MCUCR = 0x00;
 GIMSK = 0x00;
 TIMSK = 0x02;
 SEI(); //re-enable interrupts
 //all peripherals are now initialised
}
main()
{
 init_devices();
 while(1);
}
