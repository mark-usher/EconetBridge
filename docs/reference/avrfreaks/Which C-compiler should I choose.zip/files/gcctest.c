/*
	GCCTEST.C by Adam Johnson.
	Written for AvrFreaks Compiler Comparison
	on 6-DEC-2001

	Intended System: Atmel AT90S8515 @ 8MHz with LED
	driven from PORTC.7
*/
	
#include <io8515.h>
#include <interrupt.h>
#include <sig-avr.h>

//initialisation routine
void system_init(void)
{
	//Init Port C (LED)
	outp(0x80,DDRC);	//Set up data direction
	outp(0x80,PORTC);	//Initialise port value (LED off on power up)
	
	//Init Timer 0 for 30.5Hz (ish)
	outp(0x00,TCCR0); 	//stop timer
 	outp(0x00,TCNT0); 	//set count value
 	outp(0x05,TCCR0); 	//start timer
 	
 	outp(0x02,TIMSK);	//Enable timer 0 interrupt
 	sei();
}
	
//Timer 0 overflow interrupt handler
SIGNAL(SIG_OVERFLOW0)
{
 static char a;
 
 a++;	
 
 if (a==20)	//If timer has interrupted 20 times
 {
  	outp(inp(PORTC)^0x80,PORTC);	//flash LED
  	a = 0;	//reset counter
 }    
}


int main(void)
{
	system_init();	//Initialise system
	
	while(1);		//loop forever (work is done by interrupt)
}
